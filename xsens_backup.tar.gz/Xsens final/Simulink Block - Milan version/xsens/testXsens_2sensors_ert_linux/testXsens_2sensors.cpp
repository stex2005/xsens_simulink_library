//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: testXsens_2sensors.cpp
//
// Code generated for Simulink model 'testXsens_2sensors'.
//
// Model version                  : 1.158
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Fri Oct 28 17:24:10 2016
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "testXsens_2sensors.h"
#include "testXsens_2sensors_private.h"
#include "testXsens_2sensors_dt.h"

// Named constants for Chart: '<S1>/Chart'
#define testXsens_2s_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define testXsens_2senso_IN_CALIBRATION ((uint8_T)1U)
#define testXsens_2sensors_CALL_EVENT_m (-1)
#define testXsens_2sensors_IN_INOUT    ((uint8_T)2U)

// Named constants for Chart: '<S3>/Chart'
#define testXsens_2sens_IN_DATARECEIVED ((uint8_T)1U)
#define testXsens_2senso_IN_WAITFORDATA ((uint8_T)2U)

// Block signals (auto storage)
B_testXsens_2sensors_T testXsens_2sensors_B;

// Block states (auto storage)
DW_testXsens_2sensors_T testXsens_2sensors_DW;

// Real-time model
RT_MODEL_testXsens_2sensors_T testXsens_2sensors_M_;
RT_MODEL_testXsens_2sensors_T *const testXsens_2sensors_M =
  &testXsens_2sensors_M_;

// Forward declaration for local functions
static void testXsens_2sensors_fileManager(FILE * *f, boolean_T *a);
static void testXsens_2sensors_fprintf(real32_T varargin_1, real_T varargin_2,
  real_T varargin_3, real_T varargin_4);
static void testXsens_DirectionToVector_sRb(real_T anatomical_axis, real_T
  vector[3]);
static void testXsens_2sensor_fileManager_p(FILE * *f, boolean_T *a);
static void testXsens_2sensors_fprintf_l(real32_T varargin_1, real_T varargin_2,
  real_T varargin_3, real_T varargin_4);
static void testXse_DirectionToVector_sRb_k(real_T anatomical_axis, real_T
  vector[3]);

//
// Initial conditions for atomic system:
//    '<S6>/Extractor'
//    '<S9>/Extractor'
//
void testXsens_2senso_Extractor_Init(DW_Extractor_testXsens_2senso_T *localDW)
{
  localDW->lastSampleNumber = 0.0;
  localDW->lastFactor = 1.0;
}

//
// Output and update for atomic system:
//    '<S6>/Extractor'
//    '<S9>/Extractor'
//
void testXsens_2sensors_Extractor(const real_T rtu_data[160],
  B_Extractor_testXsens_2sensor_T *localB, DW_Extractor_testXsens_2senso_T
  *localDW, real_T rtp_correction)
{
  real_T factor;
  real_T diff;

  // MATLAB Function 'Extract/Extractor': '<S7>:1'
  // '<S7>:1:4'
  // '<S7>:1:6'
  // '<S7>:1:7'
  localB->a[0] = rtu_data[1];
  localB->a[1] = rtu_data[2];
  localB->a[2] = rtu_data[3];

  // '<S7>:1:8'
  // '<S7>:1:9'
  // '<S7>:1:10'
  memcpy(&localB->rotmat[0], &rtu_data[10], 9U * sizeof(real_T));

  // '<S7>:1:11'
  // '<S7>:1:22'
  factor = 1.0;

  // '<S7>:1:24'
  diff = fabs(rtu_data[0] - localDW->lastSampleNumber);
  if (diff >= 1.0) {
    // '<S7>:1:26'
    // '<S7>:1:27'
    factor = diff;
  }

  if (diff == 0.0) {
    // '<S7>:1:29'
    // '<S7>:1:30'
    factor = localDW->lastFactor;
  }

  // '<S7>:1:33'
  localDW->lastFactor = factor;

  // '<S7>:1:34'
  localDW->lastSampleNumber = rtu_data[0];
  if (rtp_correction == 1.0) {
    // '<S7>:1:36'
    // '<S7>:1:37'
    localB->a[0] /= factor;
    localB->a[1] /= factor;
    localB->a[2] /= factor;

    // '<S7>:1:38'
    // '<S7>:1:39'
    // '<S7>:1:40'
  } else {
    // '<S7>:1:42'
    // '<S7>:1:43'
    // '<S7>:1:44'
    // '<S7>:1:45'
  }
}

// Function for Chart: '<S1>/Chart'
static void testXsens_2sensors_fileManager(FILE * *f, boolean_T *a)
{
  *f = stderr;
  *a = true;
}

// Function for Chart: '<S1>/Chart'
static void testXsens_2sensors_fprintf(real32_T varargin_1, real_T varargin_2,
  real_T varargin_3, real_T varargin_4)
{
  static const char_T cfmt[38] = { 'S', 'e', 'n', 's', 'o', 'r', ' ', '%', '1',
    '.', '0', 'f', ' ', 'a', 'c', 'c', 'e', 'l', 'e', 'r', 'a', 't', 'i', 'o',
    'n', ':', ' ', '%', 'f', ' ', '%', 'f', ' ', '%', 'f', ' ', '\x0a', '\x00' };

  FILE * b_NULL;
  FILE * filestar;
  boolean_T autoflush;
  b_NULL = NULL;
  testXsens_2sensors_fileManager(&filestar, &autoflush);
  if (!(filestar == b_NULL)) {
    fprintf(filestar, cfmt, varargin_1, varargin_2, varargin_3, varargin_4);
    if (autoflush) {
      fflush(filestar);
    }
  }
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T u0_0;
  int32_T u1_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = atan2((real_T)u0_0, (real_T)u1_0);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

// Function for Chart: '<S1>/Chart'
static void testXsens_DirectionToVector_sRb(real_T anatomical_axis, real_T
  vector[3])
{
  // MATLAB Function 'DirectionToVector_sRb': '<S5>:20'
  // '<S5>:20:2'
  vector[0] = 0.0;
  vector[1] = 0.0;
  vector[2] = 0.0;
  if (anatomical_axis == 1.0) {
    // '<S5>:20:3'
    //  Forwards
    // '<S5>:20:4'
    vector[0] = 1.0;
    vector[1] = 0.0;
    vector[2] = 0.0;
  } else if (anatomical_axis == 2.0) {
    // '<S5>:20:5'
    //  Backwards
    // '<S5>:20:6'
    vector[0] = -1.0;
    vector[1] = 0.0;
    vector[2] = 0.0;
  } else if (anatomical_axis == 3.0) {
    // '<S5>:20:7'
    //  Up
    // '<S5>:20:8'
    vector[0] = 0.0;
    vector[1] = 0.0;
    vector[2] = 1.0;
  } else if (anatomical_axis == 4.0) {
    // '<S5>:20:9'
    //  Down
    // '<S5>:20:10'
    vector[0] = 0.0;
    vector[1] = 0.0;
    vector[2] = -1.0;
  } else if (anatomical_axis == 5.0) {
    // '<S5>:20:11'
    //  Left
    // '<S5>:20:12'
    vector[0] = 0.0;
    vector[1] = 1.0;
    vector[2] = 0.0;
  } else {
    if (anatomical_axis == 6.0) {
      // '<S5>:20:13'
      //  Right
      // '<S5>:20:14'
      vector[0] = 0.0;
      vector[1] = -1.0;
      vector[2] = 0.0;
    }
  }
}

// Function for Chart: '<S2>/Chart'
static void testXsens_2sensor_fileManager_p(FILE * *f, boolean_T *a)
{
  *f = stderr;
  *a = true;
}

// Function for Chart: '<S2>/Chart'
static void testXsens_2sensors_fprintf_l(real32_T varargin_1, real_T varargin_2,
  real_T varargin_3, real_T varargin_4)
{
  static const char_T cfmt[38] = { 'S', 'e', 'n', 's', 'o', 'r', ' ', '%', '1',
    '.', '0', 'f', ' ', 'a', 'c', 'c', 'e', 'l', 'e', 'r', 'a', 't', 'i', 'o',
    'n', ':', ' ', '%', 'f', ' ', '%', 'f', ' ', '%', 'f', ' ', '\x0a', '\x00' };

  FILE * b_NULL;
  FILE * filestar;
  boolean_T autoflush;
  b_NULL = NULL;
  testXsens_2sensor_fileManager_p(&filestar, &autoflush);
  if (!(filestar == b_NULL)) {
    fprintf(filestar, cfmt, varargin_1, varargin_2, varargin_3, varargin_4);
    if (autoflush) {
      fflush(filestar);
    }
  }
}

// Function for Chart: '<S2>/Chart'
static void testXse_DirectionToVector_sRb_k(real_T anatomical_axis, real_T
  vector[3])
{
  // MATLAB Function 'DirectionToVector_sRb': '<S8>:20'
  // '<S8>:20:2'
  vector[0] = 0.0;
  vector[1] = 0.0;
  vector[2] = 0.0;
  if (anatomical_axis == 1.0) {
    // '<S8>:20:3'
    //  Forwards
    // '<S8>:20:4'
    vector[0] = 1.0;
    vector[1] = 0.0;
    vector[2] = 0.0;
  } else if (anatomical_axis == 2.0) {
    // '<S8>:20:5'
    //  Backwards
    // '<S8>:20:6'
    vector[0] = -1.0;
    vector[1] = 0.0;
    vector[2] = 0.0;
  } else if (anatomical_axis == 3.0) {
    // '<S8>:20:7'
    //  Up
    // '<S8>:20:8'
    vector[0] = 0.0;
    vector[1] = 0.0;
    vector[2] = 1.0;
  } else if (anatomical_axis == 4.0) {
    // '<S8>:20:9'
    //  Down
    // '<S8>:20:10'
    vector[0] = 0.0;
    vector[1] = 0.0;
    vector[2] = -1.0;
  } else if (anatomical_axis == 5.0) {
    // '<S8>:20:11'
    //  Left
    // '<S8>:20:12'
    vector[0] = 0.0;
    vector[1] = 1.0;
    vector[2] = 0.0;
  } else {
    if (anatomical_axis == 6.0) {
      // '<S8>:20:13'
      //  Right
      // '<S8>:20:14'
      vector[0] = 0.0;
      vector[1] = -1.0;
      vector[2] = 0.0;
    }
  }
}

// Model step function
void testXsens_2sensors_step(void)
{
  // local block i/o variables
  real_T rtb_XsensIMUs_o1[160];
  real_T rtb_XsensIMUs_o2[160];
  real_T rtb_XsensIMUs_o3[160];
  real_T rtb_XsensIMUs_o4[160];
  real_T rtb_XsensIMUs_o5[160];
  real_T rtb_XsensIMUs_o6[160];
  real_T rtb_XsensIMUs_o7[160];
  real_T rtb_XsensIMUs_o8[160];
  real_T rtb_XsensIMUs_o9[160];
  real_T rtb_XsensIMUs_o10[160];
  real_T factor;
  real_T diff;
  int32_T iy;
  int32_T ixstart;
  int32_T b_ix;
  int32_T b_ixstart;
  real_T absxk;
  real_T t;
  static const int8_T b[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

  static const int8_T b_0[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

  real_T matrix1_reshaped[9];
  real_T matrix2_reshaped[9];
  real_T Rot_twist[9];
  int8_T y[3];
  boolean_T x[9];
  real_T tmp[3];
  real_T tmp_0[3];
  real_T tmp_1[3];
  real_T tmp_2[9];

  // Reset subsysRan breadcrumbs
  srClearBC(testXsens_2sensors_DW.AlignmentCalibration1_SubsysRan);

  // Reset subsysRan breadcrumbs
  srClearBC(testXsens_2sensors_DW.AlignmentCalibration2_SubsysRan);

  // Reset subsysRan breadcrumbs
  srClearBC(testXsens_2sensors_DW.Extractangles_SubsysRanBC);

  // S-Function (ex_sfun_sci_xsens): '<Root>/Xsens IMUs'
  output_xsens( &testXsens_2sensors_DW.XsensIMUs_PWORK, &rtb_XsensIMUs_o1[0],
               &rtb_XsensIMUs_o2[0], &rtb_XsensIMUs_o3[0], &rtb_XsensIMUs_o4[0],
               &rtb_XsensIMUs_o5[0], &rtb_XsensIMUs_o6[0], &rtb_XsensIMUs_o7[0],
               &rtb_XsensIMUs_o8[0], &rtb_XsensIMUs_o9[0], &rtb_XsensIMUs_o10[0]);

  // Constant: '<Root>/Constant'
  testXsens_2sensors_B.Constant = testXsens_2sensors_P.Constant_Value;

  // MATLAB Function: '<S12>/Extractor'
  // MATLAB Function 'Extract/Extractor': '<S13>:1'
  // '<S13>:1:4'
  // '<S13>:1:6'
  // '<S13>:1:7'
  testXsens_2sensors_B.a[0] = rtb_XsensIMUs_o1[1];
  testXsens_2sensors_B.a[1] = rtb_XsensIMUs_o1[2];
  testXsens_2sensors_B.a[2] = rtb_XsensIMUs_o1[3];

  // '<S13>:1:8'
  // '<S13>:1:9'
  // '<S13>:1:10'
  // '<S13>:1:11'
  // '<S13>:1:22'
  factor = 1.0;

  // '<S13>:1:24'
  diff = fabs(rtb_XsensIMUs_o1[0] - testXsens_2sensors_DW.lastSampleNumber);
  if (diff >= 1.0) {
    // '<S13>:1:26'
    // '<S13>:1:27'
    factor = diff;
  }

  if (diff == 0.0) {
    // '<S13>:1:29'
    // '<S13>:1:30'
    factor = testXsens_2sensors_DW.lastFactor;
  }

  // '<S13>:1:33'
  testXsens_2sensors_DW.lastFactor = factor;

  // '<S13>:1:34'
  testXsens_2sensors_DW.lastSampleNumber = rtb_XsensIMUs_o1[0];
  if (testXsens_2sensors_P.Extract_correction_c == 1.0) {
    // '<S13>:1:36'
    // '<S13>:1:37'
    testXsens_2sensors_B.a[0] /= factor;
    testXsens_2sensors_B.a[1] /= factor;
    testXsens_2sensors_B.a[2] /= factor;

    // '<S13>:1:38'
    // '<S13>:1:39'
    // '<S13>:1:40'
  } else {
    // '<S13>:1:42'
    // '<S13>:1:43'
    // '<S13>:1:44'
    // '<S13>:1:45'
  }

  // End of MATLAB Function: '<S12>/Extractor'

  // Chart: '<S3>/Chart'
  // Gateway: Data Available/Chart
  testXsens_2sensors_DW.sfEvent = testXsens_2sensors_CALL_EVENT_m;

  // During: Data Available/Chart
  if (testXsens_2sensors_DW.is_active_c4_XsensLibrary2 == 0U) {
    // Entry: Data Available/Chart
    testXsens_2sensors_DW.is_active_c4_XsensLibrary2 = 1U;

    // Entry Internal: Data Available/Chart
    // Transition: '<S11>:36'
    testXsens_2sensors_DW.is_c4_XsensLibrary2 = testXsens_2senso_IN_WAITFORDATA;

    // Entry 'WAITFORDATA': '<S11>:35'
    testXsens_2sensors_B.FlagAvailable = 0.0;
    testXsens_2sensors_DW.do_transition = 0.0;
  } else if (testXsens_2sensors_DW.is_c4_XsensLibrary2 ==
             testXsens_2sens_IN_DATARECEIVED) {
    // During 'DATARECEIVED': '<S11>:39'
    testXsens_2sensors_B.FlagAvailable = 1.0;
  } else {
    // During 'WAITFORDATA': '<S11>:35'
    if (testXsens_2sensors_DW.do_transition > 0.0) {
      // Transition: '<S11>:40'
      testXsens_2sensors_DW.is_c4_XsensLibrary2 =
        testXsens_2sens_IN_DATARECEIVED;
    } else {
      if (sqrt((testXsens_2sensors_B.a[0] * testXsens_2sensors_B.a[0] +
                testXsens_2sensors_B.a[1] * testXsens_2sensors_B.a[1]) +
               testXsens_2sensors_B.a[2] * testXsens_2sensors_B.a[2]) >= 5.0) {
        testXsens_2sensors_DW.do_transition = 1.0;
      }
    }
  }

  // End of Chart: '<S3>/Chart'

  // Outputs for Enabled SubSystem: '<Root>/Alignment Calibration1' incorporates:
  //   EnablePort: '<S1>/Enable'

  if (testXsens_2sensors_B.FlagAvailable > 0.0) {
    // MATLAB Function: '<S6>/Extractor'
    testXsens_2sensors_Extractor(rtb_XsensIMUs_o1,
      &testXsens_2sensors_B.sf_Extractor_m,
      &testXsens_2sensors_DW.sf_Extractor_m,
      testXsens_2sensors_P.Extract_correction);

    // Chart: '<S1>/Chart'
    // Gateway: Alignment Calibration/Chart
    testXsens_2sensors_DW.sfEvent_l = testXsens_2sensors_CALL_EVENT_m;

    // During: Alignment Calibration/Chart
    if (testXsens_2sensors_DW.is_active_c3_XsensLibrary2_o == 0U) {
      // Entry: Alignment Calibration/Chart
      testXsens_2sensors_DW.is_active_c3_XsensLibrary2_o = 1U;

      // Entry Internal: Alignment Calibration/Chart
      // Transition: '<S5>:36'
      testXsens_2sensors_DW.is_c3_XsensLibrary2_a =
        testXsens_2senso_IN_CALIBRATION;

      // Entry 'CALIBRATION': '<S5>:1'
      for (iy = 0; iy < 15; iy++) {
        testXsens_2sensors_DW.Accelerationbuffer_h[iy] = (rtNaN);
      }

      for (iy = 0; iy < 45; iy++) {
        testXsens_2sensors_DW.RotMatbuffer_n[iy] = (rtNaN);
      }

      testXsens_2sensors_DW.samples_j = 1.0;
      testXsens_2sensors_DW.Calib_performed_m = 0.0;
      testXsens_DirectionToVector_sRb
        (testXsens_2sensors_P.AlignmentCalibration1_XAxis, tmp);
      testXsens_DirectionToVector_sRb
        (testXsens_2sensors_P.AlignmentCalibration1_YAxis, tmp_0);
      testXsens_DirectionToVector_sRb
        (testXsens_2sensors_P.AlignmentCalibration1_ZAxis, tmp_1);
      testXsens_2sensors_DW.sRb_n[0] = tmp[0];
      testXsens_2sensors_DW.sRb_n[1] = tmp_0[0];
      testXsens_2sensors_DW.sRb_n[2] = tmp_1[0];
      testXsens_2sensors_DW.sRb_n[3] = tmp[1];
      testXsens_2sensors_DW.sRb_n[4] = tmp_0[1];
      testXsens_2sensors_DW.sRb_n[5] = tmp_1[1];
      testXsens_2sensors_DW.sRb_n[6] = tmp[2];
      testXsens_2sensors_DW.sRb_n[7] = tmp_0[2];
      testXsens_2sensors_DW.sRb_n[8] = tmp_1[2];
    } else if (testXsens_2sensors_DW.is_c3_XsensLibrary2_a ==
               testXsens_2senso_IN_CALIBRATION) {
      // During 'CALIBRATION': '<S5>:1'
      if (testXsens_2sensors_DW.Calib_performed_m > 0.0) {
        // Transition: '<S5>:5'
        testXsens_2sensors_DW.is_c3_XsensLibrary2_a =
          testXsens_2sensors_IN_INOUT;

        // Entry 'INOUT': '<S5>:3'
        if (testXsens_2sensors_P.AlignmentCalibration1_RotationT == 1.0) {
          memcpy(&matrix1_reshaped[0],
                 &testXsens_2sensors_B.sf_Extractor_m.rotmat[0], 9U * sizeof
                 (real_T));
          for (iy = 0; iy < 3; iy++) {
            for (ixstart = 0; ixstart < 3; ixstart++) {
              matrix2_reshaped[iy + 3 * ixstart] = 0.0;
              matrix2_reshaped[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.gRf_g[iy] * matrix1_reshaped[ixstart];
              matrix2_reshaped[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.gRf_g[iy + 3] * matrix1_reshaped[ixstart +
                3];
              matrix2_reshaped[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.gRf_g[iy + 6] * matrix1_reshaped[ixstart +
                6];
            }
          }

          for (iy = 0; iy < 3; iy++) {
            for (ixstart = 0; ixstart < 3; ixstart++) {
              testXsens_2sensors_DW.RotMatrix_init_m[iy + 3 * ixstart] = 0.0;
              testXsens_2sensors_DW.RotMatrix_init_m[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.sRb_n[3 * ixstart] * matrix2_reshaped[iy];
              testXsens_2sensors_DW.RotMatrix_init_m[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.sRb_n[3 * ixstart + 1] *
                matrix2_reshaped[iy + 3];
              testXsens_2sensors_DW.RotMatrix_init_m[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.sRb_n[3 * ixstart + 2] *
                matrix2_reshaped[iy + 6];
            }
          }
        } else {
          for (iy = 0; iy < 9; iy++) {
            testXsens_2sensors_DW.RotMatrix_init_m[iy] = b[iy];
          }
        }
      } else {
        iy = (int32_T)testXsens_2sensors_DW.samples_j;
        testXsens_2sensors_DW.Accelerationbuffer_h[3 * (iy - 1)] =
          testXsens_2sensors_B.sf_Extractor_m.a[0];
        testXsens_2sensors_DW.Accelerationbuffer_h[1 + 3 * (iy - 1)] =
          testXsens_2sensors_B.sf_Extractor_m.a[1];
        testXsens_2sensors_DW.Accelerationbuffer_h[2 + 3 * (iy - 1)] =
          testXsens_2sensors_B.sf_Extractor_m.a[2];
        memcpy(&matrix1_reshaped[0],
               &testXsens_2sensors_B.sf_Extractor_m.rotmat[0], 9U * sizeof
               (real_T));
        iy = (int32_T)testXsens_2sensors_DW.samples_j;
        for (ixstart = 0; ixstart < 3; ixstart++) {
          testXsens_2sensors_DW.RotMatbuffer_n[3 * ixstart + 9 * (iy - 1)] =
            matrix1_reshaped[ixstart];
          testXsens_2sensors_DW.RotMatbuffer_n[(3 * ixstart + 9 * (iy - 1)) + 1]
            = matrix1_reshaped[ixstart + 3];
          testXsens_2sensors_DW.RotMatbuffer_n[(3 * ixstart + 9 * (iy - 1)) + 2]
            = matrix1_reshaped[ixstart + 6];
        }

        testXsens_2sensors_DW.samples_j++;
        if (testXsens_2sensors_DW.samples_j > 5.0) {
          iy = -1;
          ixstart = -1;
          for (b_ix = 0; b_ix < 3; b_ix++) {
            ixstart++;
            b_ixstart = ixstart + 3;
            factor = testXsens_2sensors_DW.Accelerationbuffer_h[ixstart] +
              testXsens_2sensors_DW.Accelerationbuffer_h[b_ixstart];
            b_ixstart += 3;
            factor += testXsens_2sensors_DW.Accelerationbuffer_h[b_ixstart];
            b_ixstart += 3;
            factor += testXsens_2sensors_DW.Accelerationbuffer_h[b_ixstart];
            b_ixstart += 3;
            factor += testXsens_2sensors_DW.Accelerationbuffer_h[b_ixstart];
            iy++;
            testXsens_2sensors_DW.mean_accel_f[iy] = factor;
          }

          testXsens_2sensors_DW.mean_accel_f[0] /= 5.0;
          testXsens_2sensors_DW.mean_accel_f[1] /= 5.0;
          testXsens_2sensors_DW.mean_accel_f[2] /= 5.0;
          iy = -1;
          b_ixstart = -1;
          for (ixstart = 0; ixstart < 9; ixstart++) {
            b_ixstart++;
            b_ix = b_ixstart + 9;
            factor = testXsens_2sensors_DW.RotMatbuffer_n[b_ixstart] +
              testXsens_2sensors_DW.RotMatbuffer_n[b_ix];
            b_ix += 9;
            factor += testXsens_2sensors_DW.RotMatbuffer_n[b_ix];
            b_ix += 9;
            factor += testXsens_2sensors_DW.RotMatbuffer_n[b_ix];
            b_ix += 9;
            factor += testXsens_2sensors_DW.RotMatbuffer_n[b_ix];
            iy++;
            testXsens_2sensors_DW.mean_rotmat_l[iy] = factor;
          }

          for (iy = 0; iy < 9; iy++) {
            testXsens_2sensors_DW.mean_rotmat_l[iy] /= 5.0;
          }

          for (iy = 0; iy < 3; iy++) {
            testXsens_2sensors_DW.mean_accel_b_g[iy] = 0.0;
            testXsens_2sensors_DW.mean_accel_b_g[iy] +=
              testXsens_2sensors_DW.sRb_n[3 * iy] *
              testXsens_2sensors_DW.mean_accel_f[0];
            testXsens_2sensors_DW.mean_accel_b_g[iy] +=
              testXsens_2sensors_DW.sRb_n[3 * iy + 1] *
              testXsens_2sensors_DW.mean_accel_f[1];
            testXsens_2sensors_DW.mean_accel_b_g[iy] +=
              testXsens_2sensors_DW.sRb_n[3 * iy + 2] *
              testXsens_2sensors_DW.mean_accel_f[2];
          }

          testXsens_2sensors_fprintf(testXsens_2sensors_B.Constant,
            testXsens_2sensors_DW.mean_accel_b_g[0],
            testXsens_2sensors_DW.mean_accel_b_g[1],
            testXsens_2sensors_DW.mean_accel_b_g[2]);
          diff = 2.2250738585072014E-308;
          absxk = fabs(testXsens_2sensors_DW.mean_accel_b_g[0]);
          if (absxk > 2.2250738585072014E-308) {
            factor = 1.0;
            diff = absxk;
          } else {
            t = absxk / 2.2250738585072014E-308;
            factor = t * t;
          }

          absxk = fabs(testXsens_2sensors_DW.mean_accel_b_g[1]);
          if (absxk > diff) {
            t = diff / absxk;
            factor = factor * t * t + 1.0;
            diff = absxk;
          } else {
            t = absxk / diff;
            factor += t * t;
          }

          absxk = fabs(testXsens_2sensors_DW.mean_accel_b_g[2]);
          if (absxk > diff) {
            t = diff / absxk;
            factor = factor * t * t + 1.0;
            diff = absxk;
          } else {
            t = absxk / diff;
            factor += t * t;
          }

          factor = diff * sqrt(factor);
          testXsens_2sensors_DW.mean_accel_b_g[0] /= factor;
          testXsens_2sensors_DW.mean_accel_b_g[1] /= factor;
          testXsens_2sensors_DW.mean_accel_b_g[2] /= factor;
          testXsens_2sensors_DW.gamma_b = rt_atan2d_snf
            (testXsens_2sensors_DW.mean_accel_b_g[1],
             testXsens_2sensors_DW.mean_accel_b_g[2]);
          testXsens_2sensors_DW.beta_k = rt_atan2d_snf
            (-testXsens_2sensors_DW.mean_accel_b_g[1],
             testXsens_2sensors_DW.mean_accel_b_g[2] / sin
             (testXsens_2sensors_DW.gamma_b));
          testXsens_2sensors_DW.gRb_i[0] = cos(testXsens_2sensors_DW.beta_k);
          testXsens_2sensors_DW.gRb_i[3] = sin(testXsens_2sensors_DW.beta_k) *
            sin(testXsens_2sensors_DW.gamma_b);
          testXsens_2sensors_DW.gRb_i[6] = sin(testXsens_2sensors_DW.beta_k) *
            cos(testXsens_2sensors_DW.gamma_b);
          testXsens_2sensors_DW.gRb_i[1] = 0.0;
          testXsens_2sensors_DW.gRb_i[4] = cos(testXsens_2sensors_DW.gamma_b);
          testXsens_2sensors_DW.gRb_i[7] = -sin(testXsens_2sensors_DW.gamma_b);
          testXsens_2sensors_DW.gRb_i[2] = -sin(testXsens_2sensors_DW.beta_k);
          testXsens_2sensors_DW.gRb_i[5] = cos(testXsens_2sensors_DW.beta_k) *
            sin(testXsens_2sensors_DW.gamma_b);
          testXsens_2sensors_DW.gRb_i[8] = cos(testXsens_2sensors_DW.beta_k) *
            cos(testXsens_2sensors_DW.gamma_b);
          for (iy = 0; iy < 3; iy++) {
            for (ixstart = 0; ixstart < 3; ixstart++) {
              matrix2_reshaped[iy + 3 * ixstart] = 0.0;
              matrix2_reshaped[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.gRb_i[iy] *
                testXsens_2sensors_DW.sRb_n[ixstart];
              matrix2_reshaped[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.gRb_i[iy + 3] *
                testXsens_2sensors_DW.sRb_n[ixstart + 3];
              matrix2_reshaped[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.gRb_i[iy + 6] *
                testXsens_2sensors_DW.sRb_n[ixstart + 6];
            }
          }

          for (iy = 0; iy < 3; iy++) {
            for (ixstart = 0; ixstart < 3; ixstart++) {
              testXsens_2sensors_DW.gRf_g[iy + 3 * ixstart] = 0.0;
              testXsens_2sensors_DW.gRf_g[iy + 3 * ixstart] +=
                matrix2_reshaped[iy] *
                testXsens_2sensors_DW.mean_rotmat_l[ixstart];
              testXsens_2sensors_DW.gRf_g[iy + 3 * ixstart] +=
                matrix2_reshaped[iy + 3] *
                testXsens_2sensors_DW.mean_rotmat_l[ixstart + 3];
              testXsens_2sensors_DW.gRf_g[iy + 3 * ixstart] +=
                matrix2_reshaped[iy + 6] *
                testXsens_2sensors_DW.mean_rotmat_l[ixstart + 6];
            }
          }

          // gRf = gRb*(sRb)'*(fRs)'
          testXsens_2sensors_DW.Calib_performed_m = 1.0;
        }
      }
    } else {
      // During 'INOUT': '<S5>:3'
      memcpy(&matrix1_reshaped[0], &testXsens_2sensors_B.sf_Extractor_m.rotmat[0],
             9U * sizeof(real_T));
      for (iy = 0; iy < 3; iy++) {
        for (ixstart = 0; ixstart < 3; ixstart++) {
          matrix2_reshaped[iy + 3 * ixstart] = 0.0;
          matrix2_reshaped[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.RotMatrix_init_m[3 * iy] *
            testXsens_2sensors_DW.gRf_g[3 * ixstart];
          matrix2_reshaped[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.RotMatrix_init_m[3 * iy + 1] *
            testXsens_2sensors_DW.gRf_g[3 * ixstart + 1];
          matrix2_reshaped[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.RotMatrix_init_m[3 * iy + 2] *
            testXsens_2sensors_DW.gRf_g[3 * ixstart + 2];
        }
      }

      for (iy = 0; iy < 3; iy++) {
        for (ixstart = 0; ixstart < 3; ixstart++) {
          tmp_2[iy + 3 * ixstart] = 0.0;
          tmp_2[iy + 3 * ixstart] += matrix2_reshaped[iy] *
            matrix1_reshaped[ixstart];
          tmp_2[iy + 3 * ixstart] += matrix2_reshaped[iy + 3] *
            matrix1_reshaped[ixstart + 3];
          tmp_2[iy + 3 * ixstart] += matrix2_reshaped[iy + 6] *
            matrix1_reshaped[ixstart + 6];
        }
      }

      for (iy = 0; iy < 3; iy++) {
        for (ixstart = 0; ixstart < 3; ixstart++) {
          testXsens_2sensors_B.RotMatrix_out_m[iy + 3 * ixstart] = 0.0;
          testXsens_2sensors_B.RotMatrix_out_m[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.sRb_n[3 * ixstart] * tmp_2[iy];
          testXsens_2sensors_B.RotMatrix_out_m[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.sRb_n[3 * ixstart + 1] * tmp_2[iy + 3];
          testXsens_2sensors_B.RotMatrix_out_m[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.sRb_n[3 * ixstart + 2] * tmp_2[iy + 6];
        }
      }
    }

    // End of Chart: '<S1>/Chart'
    srUpdateBC(testXsens_2sensors_DW.AlignmentCalibration1_SubsysRan);
  }

  // End of Outputs for SubSystem: '<Root>/Alignment Calibration1'

  // Constant: '<Root>/Constant1'
  testXsens_2sensors_B.Constant1 = testXsens_2sensors_P.Constant1_Value;

  // Outputs for Enabled SubSystem: '<Root>/Alignment Calibration2' incorporates:
  //   EnablePort: '<S2>/Enable'

  if (testXsens_2sensors_B.FlagAvailable > 0.0) {
    // MATLAB Function: '<S9>/Extractor'
    testXsens_2sensors_Extractor(rtb_XsensIMUs_o2,
      &testXsens_2sensors_B.sf_Extractor_l,
      &testXsens_2sensors_DW.sf_Extractor_l,
      testXsens_2sensors_P.Extract_correction_b);

    // Chart: '<S2>/Chart'
    // Gateway: Alignment Calibration/Chart
    testXsens_2sensors_DW.sfEvent_n = testXsens_2sensors_CALL_EVENT_m;

    // During: Alignment Calibration/Chart
    if (testXsens_2sensors_DW.is_active_c3_XsensLibrary2 == 0U) {
      // Entry: Alignment Calibration/Chart
      testXsens_2sensors_DW.is_active_c3_XsensLibrary2 = 1U;

      // Entry Internal: Alignment Calibration/Chart
      // Transition: '<S8>:36'
      testXsens_2sensors_DW.is_c3_XsensLibrary2 =
        testXsens_2senso_IN_CALIBRATION;

      // Entry 'CALIBRATION': '<S8>:1'
      for (iy = 0; iy < 15; iy++) {
        testXsens_2sensors_DW.Accelerationbuffer[iy] = (rtNaN);
      }

      for (iy = 0; iy < 45; iy++) {
        testXsens_2sensors_DW.RotMatbuffer[iy] = (rtNaN);
      }

      testXsens_2sensors_DW.samples = 1.0;
      testXsens_2sensors_DW.Calib_performed = 0.0;
      testXse_DirectionToVector_sRb_k
        (testXsens_2sensors_P.AlignmentCalibration2_XAxis, tmp);
      testXse_DirectionToVector_sRb_k
        (testXsens_2sensors_P.AlignmentCalibration2_YAxis, tmp_0);
      testXse_DirectionToVector_sRb_k
        (testXsens_2sensors_P.AlignmentCalibration2_ZAxis, tmp_1);
      testXsens_2sensors_DW.sRb[0] = tmp[0];
      testXsens_2sensors_DW.sRb[1] = tmp_0[0];
      testXsens_2sensors_DW.sRb[2] = tmp_1[0];
      testXsens_2sensors_DW.sRb[3] = tmp[1];
      testXsens_2sensors_DW.sRb[4] = tmp_0[1];
      testXsens_2sensors_DW.sRb[5] = tmp_1[1];
      testXsens_2sensors_DW.sRb[6] = tmp[2];
      testXsens_2sensors_DW.sRb[7] = tmp_0[2];
      testXsens_2sensors_DW.sRb[8] = tmp_1[2];
    } else if (testXsens_2sensors_DW.is_c3_XsensLibrary2 ==
               testXsens_2senso_IN_CALIBRATION) {
      // During 'CALIBRATION': '<S8>:1'
      if (testXsens_2sensors_DW.Calib_performed > 0.0) {
        // Transition: '<S8>:5'
        testXsens_2sensors_DW.is_c3_XsensLibrary2 = testXsens_2sensors_IN_INOUT;

        // Entry 'INOUT': '<S8>:3'
        if (testXsens_2sensors_P.AlignmentCalibration2_RotationT == 1.0) {
          memcpy(&matrix1_reshaped[0],
                 &testXsens_2sensors_B.sf_Extractor_l.rotmat[0], 9U * sizeof
                 (real_T));
          for (iy = 0; iy < 3; iy++) {
            for (ixstart = 0; ixstart < 3; ixstart++) {
              matrix2_reshaped[iy + 3 * ixstart] = 0.0;
              matrix2_reshaped[iy + 3 * ixstart] += testXsens_2sensors_DW.gRf[iy]
                * matrix1_reshaped[ixstart];
              matrix2_reshaped[iy + 3 * ixstart] += testXsens_2sensors_DW.gRf[iy
                + 3] * matrix1_reshaped[ixstart + 3];
              matrix2_reshaped[iy + 3 * ixstart] += testXsens_2sensors_DW.gRf[iy
                + 6] * matrix1_reshaped[ixstart + 6];
            }
          }

          for (iy = 0; iy < 3; iy++) {
            for (ixstart = 0; ixstart < 3; ixstart++) {
              testXsens_2sensors_DW.RotMatrix_init[iy + 3 * ixstart] = 0.0;
              testXsens_2sensors_DW.RotMatrix_init[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.sRb[3 * ixstart] * matrix2_reshaped[iy];
              testXsens_2sensors_DW.RotMatrix_init[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.sRb[3 * ixstart + 1] * matrix2_reshaped[iy
                + 3];
              testXsens_2sensors_DW.RotMatrix_init[iy + 3 * ixstart] +=
                testXsens_2sensors_DW.sRb[3 * ixstart + 2] * matrix2_reshaped[iy
                + 6];
            }
          }
        } else {
          for (iy = 0; iy < 9; iy++) {
            testXsens_2sensors_DW.RotMatrix_init[iy] = b_0[iy];
          }
        }
      } else {
        iy = (int32_T)testXsens_2sensors_DW.samples;
        testXsens_2sensors_DW.Accelerationbuffer[3 * (iy - 1)] =
          testXsens_2sensors_B.sf_Extractor_l.a[0];
        testXsens_2sensors_DW.Accelerationbuffer[1 + 3 * (iy - 1)] =
          testXsens_2sensors_B.sf_Extractor_l.a[1];
        testXsens_2sensors_DW.Accelerationbuffer[2 + 3 * (iy - 1)] =
          testXsens_2sensors_B.sf_Extractor_l.a[2];
        memcpy(&matrix1_reshaped[0],
               &testXsens_2sensors_B.sf_Extractor_l.rotmat[0], 9U * sizeof
               (real_T));
        iy = (int32_T)testXsens_2sensors_DW.samples;
        for (ixstart = 0; ixstart < 3; ixstart++) {
          testXsens_2sensors_DW.RotMatbuffer[3 * ixstart + 9 * (iy - 1)] =
            matrix1_reshaped[ixstart];
          testXsens_2sensors_DW.RotMatbuffer[(3 * ixstart + 9 * (iy - 1)) + 1] =
            matrix1_reshaped[ixstart + 3];
          testXsens_2sensors_DW.RotMatbuffer[(3 * ixstart + 9 * (iy - 1)) + 2] =
            matrix1_reshaped[ixstart + 6];
        }

        testXsens_2sensors_DW.samples++;
        if (testXsens_2sensors_DW.samples > 5.0) {
          iy = -1;
          ixstart = -1;
          for (b_ix = 0; b_ix < 3; b_ix++) {
            ixstart++;
            b_ixstart = ixstart + 3;
            factor = testXsens_2sensors_DW.Accelerationbuffer[ixstart] +
              testXsens_2sensors_DW.Accelerationbuffer[b_ixstart];
            b_ixstart += 3;
            factor += testXsens_2sensors_DW.Accelerationbuffer[b_ixstart];
            b_ixstart += 3;
            factor += testXsens_2sensors_DW.Accelerationbuffer[b_ixstart];
            b_ixstart += 3;
            factor += testXsens_2sensors_DW.Accelerationbuffer[b_ixstart];
            iy++;
            testXsens_2sensors_DW.mean_accel[iy] = factor;
          }

          testXsens_2sensors_DW.mean_accel[0] /= 5.0;
          testXsens_2sensors_DW.mean_accel[1] /= 5.0;
          testXsens_2sensors_DW.mean_accel[2] /= 5.0;
          iy = -1;
          b_ixstart = -1;
          for (ixstart = 0; ixstart < 9; ixstart++) {
            b_ixstart++;
            b_ix = b_ixstart + 9;
            factor = testXsens_2sensors_DW.RotMatbuffer[b_ixstart] +
              testXsens_2sensors_DW.RotMatbuffer[b_ix];
            b_ix += 9;
            factor += testXsens_2sensors_DW.RotMatbuffer[b_ix];
            b_ix += 9;
            factor += testXsens_2sensors_DW.RotMatbuffer[b_ix];
            b_ix += 9;
            factor += testXsens_2sensors_DW.RotMatbuffer[b_ix];
            iy++;
            testXsens_2sensors_DW.mean_rotmat[iy] = factor;
          }

          for (iy = 0; iy < 9; iy++) {
            testXsens_2sensors_DW.mean_rotmat[iy] /= 5.0;
          }

          for (iy = 0; iy < 3; iy++) {
            testXsens_2sensors_DW.mean_accel_b[iy] = 0.0;
            testXsens_2sensors_DW.mean_accel_b[iy] += testXsens_2sensors_DW.sRb
              [3 * iy] * testXsens_2sensors_DW.mean_accel[0];
            testXsens_2sensors_DW.mean_accel_b[iy] += testXsens_2sensors_DW.sRb
              [3 * iy + 1] * testXsens_2sensors_DW.mean_accel[1];
            testXsens_2sensors_DW.mean_accel_b[iy] += testXsens_2sensors_DW.sRb
              [3 * iy + 2] * testXsens_2sensors_DW.mean_accel[2];
          }

          testXsens_2sensors_fprintf_l(testXsens_2sensors_B.Constant1,
            testXsens_2sensors_DW.mean_accel_b[0],
            testXsens_2sensors_DW.mean_accel_b[1],
            testXsens_2sensors_DW.mean_accel_b[2]);
          diff = 2.2250738585072014E-308;
          absxk = fabs(testXsens_2sensors_DW.mean_accel_b[0]);
          if (absxk > 2.2250738585072014E-308) {
            factor = 1.0;
            diff = absxk;
          } else {
            t = absxk / 2.2250738585072014E-308;
            factor = t * t;
          }

          absxk = fabs(testXsens_2sensors_DW.mean_accel_b[1]);
          if (absxk > diff) {
            t = diff / absxk;
            factor = factor * t * t + 1.0;
            diff = absxk;
          } else {
            t = absxk / diff;
            factor += t * t;
          }

          absxk = fabs(testXsens_2sensors_DW.mean_accel_b[2]);
          if (absxk > diff) {
            t = diff / absxk;
            factor = factor * t * t + 1.0;
            diff = absxk;
          } else {
            t = absxk / diff;
            factor += t * t;
          }

          factor = diff * sqrt(factor);
          testXsens_2sensors_DW.mean_accel_b[0] /= factor;
          testXsens_2sensors_DW.mean_accel_b[1] /= factor;
          testXsens_2sensors_DW.mean_accel_b[2] /= factor;
          testXsens_2sensors_DW.gamma = rt_atan2d_snf
            (testXsens_2sensors_DW.mean_accel_b[1],
             testXsens_2sensors_DW.mean_accel_b[2]);
          testXsens_2sensors_DW.beta = rt_atan2d_snf
            (-testXsens_2sensors_DW.mean_accel_b[1],
             testXsens_2sensors_DW.mean_accel_b[2] / sin
             (testXsens_2sensors_DW.gamma));
          testXsens_2sensors_DW.gRb[0] = cos(testXsens_2sensors_DW.beta);
          testXsens_2sensors_DW.gRb[3] = sin(testXsens_2sensors_DW.beta) * sin
            (testXsens_2sensors_DW.gamma);
          testXsens_2sensors_DW.gRb[6] = sin(testXsens_2sensors_DW.beta) * cos
            (testXsens_2sensors_DW.gamma);
          testXsens_2sensors_DW.gRb[1] = 0.0;
          testXsens_2sensors_DW.gRb[4] = cos(testXsens_2sensors_DW.gamma);
          testXsens_2sensors_DW.gRb[7] = -sin(testXsens_2sensors_DW.gamma);
          testXsens_2sensors_DW.gRb[2] = -sin(testXsens_2sensors_DW.beta);
          testXsens_2sensors_DW.gRb[5] = cos(testXsens_2sensors_DW.beta) * sin
            (testXsens_2sensors_DW.gamma);
          testXsens_2sensors_DW.gRb[8] = cos(testXsens_2sensors_DW.beta) * cos
            (testXsens_2sensors_DW.gamma);
          for (iy = 0; iy < 3; iy++) {
            for (ixstart = 0; ixstart < 3; ixstart++) {
              matrix2_reshaped[iy + 3 * ixstart] = 0.0;
              matrix2_reshaped[iy + 3 * ixstart] += testXsens_2sensors_DW.gRb[iy]
                * testXsens_2sensors_DW.sRb[ixstart];
              matrix2_reshaped[iy + 3 * ixstart] += testXsens_2sensors_DW.gRb[iy
                + 3] * testXsens_2sensors_DW.sRb[ixstart + 3];
              matrix2_reshaped[iy + 3 * ixstart] += testXsens_2sensors_DW.gRb[iy
                + 6] * testXsens_2sensors_DW.sRb[ixstart + 6];
            }
          }

          for (iy = 0; iy < 3; iy++) {
            for (ixstart = 0; ixstart < 3; ixstart++) {
              testXsens_2sensors_DW.gRf[iy + 3 * ixstart] = 0.0;
              testXsens_2sensors_DW.gRf[iy + 3 * ixstart] += matrix2_reshaped[iy]
                * testXsens_2sensors_DW.mean_rotmat[ixstart];
              testXsens_2sensors_DW.gRf[iy + 3 * ixstart] += matrix2_reshaped[iy
                + 3] * testXsens_2sensors_DW.mean_rotmat[ixstart + 3];
              testXsens_2sensors_DW.gRf[iy + 3 * ixstart] += matrix2_reshaped[iy
                + 6] * testXsens_2sensors_DW.mean_rotmat[ixstart + 6];
            }
          }

          // gRf = gRb*(sRb)'*(fRs)'
          testXsens_2sensors_DW.Calib_performed = 1.0;
        }
      }
    } else {
      // During 'INOUT': '<S8>:3'
      memcpy(&matrix1_reshaped[0], &testXsens_2sensors_B.sf_Extractor_l.rotmat[0],
             9U * sizeof(real_T));
      for (iy = 0; iy < 3; iy++) {
        for (ixstart = 0; ixstart < 3; ixstart++) {
          matrix2_reshaped[iy + 3 * ixstart] = 0.0;
          matrix2_reshaped[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.RotMatrix_init[3 * iy] *
            testXsens_2sensors_DW.gRf[3 * ixstart];
          matrix2_reshaped[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.RotMatrix_init[3 * iy + 1] *
            testXsens_2sensors_DW.gRf[3 * ixstart + 1];
          matrix2_reshaped[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.RotMatrix_init[3 * iy + 2] *
            testXsens_2sensors_DW.gRf[3 * ixstart + 2];
        }
      }

      for (iy = 0; iy < 3; iy++) {
        for (ixstart = 0; ixstart < 3; ixstart++) {
          tmp_2[iy + 3 * ixstart] = 0.0;
          tmp_2[iy + 3 * ixstart] += matrix2_reshaped[iy] *
            matrix1_reshaped[ixstart];
          tmp_2[iy + 3 * ixstart] += matrix2_reshaped[iy + 3] *
            matrix1_reshaped[ixstart + 3];
          tmp_2[iy + 3 * ixstart] += matrix2_reshaped[iy + 6] *
            matrix1_reshaped[ixstart + 6];
        }
      }

      for (iy = 0; iy < 3; iy++) {
        for (ixstart = 0; ixstart < 3; ixstart++) {
          testXsens_2sensors_B.RotMatrix_out[iy + 3 * ixstart] = 0.0;
          testXsens_2sensors_B.RotMatrix_out[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.sRb[3 * ixstart] * tmp_2[iy];
          testXsens_2sensors_B.RotMatrix_out[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.sRb[3 * ixstart + 1] * tmp_2[iy + 3];
          testXsens_2sensors_B.RotMatrix_out[iy + 3 * ixstart] +=
            testXsens_2sensors_DW.sRb[3 * ixstart + 2] * tmp_2[iy + 6];
        }
      }
    }

    // End of Chart: '<S2>/Chart'
    srUpdateBC(testXsens_2sensors_DW.AlignmentCalibration2_SubsysRan);
  }

  // End of Outputs for SubSystem: '<Root>/Alignment Calibration2'

  // Outputs for Enabled SubSystem: '<Root>/Extract angles' incorporates:
  //   EnablePort: '<S4>/Enable'

  if (testXsens_2sensors_B.FlagAvailable > 0.0) {
    // MATLAB Function: '<S4>/ExtractAngles' incorporates:
    //   DataStoreRead: '<S4>/Data Store Read'

    // MATLAB Function 'Extract angles/ExtractAngles': '<S14>:1'
    // '<S14>:1:8'
    // '<S14>:1:9'
    memcpy(&matrix1_reshaped[0], &testXsens_2sensors_B.RotMatrix_out_m[0], 9U *
           sizeof(real_T));
    memcpy(&matrix2_reshaped[0], &testXsens_2sensors_B.RotMatrix_out[0], 9U *
           sizeof(real_T));
    if (testXsens_2sensors_P.Extractangles_TwistCorrection != 0.0) {
      // '<S14>:1:13'
      factor = rt_atan2d_snf(testXsens_2sensors_B.RotMatrix_out_m[7],
        testXsens_2sensors_B.RotMatrix_out_m[6]);

      // '<S14>:1:15'
      factor = -rt_atan2d_snf(testXsens_2sensors_B.RotMatrix_out_m[2] * sin
        (factor) - testXsens_2sensors_B.RotMatrix_out_m[5] * cos(factor),
        -testXsens_2sensors_B.RotMatrix_out_m[2] * cos(factor) -
        testXsens_2sensors_B.RotMatrix_out_m[5] * sin(factor));

      // '<S14>:1:17'
      Rot_twist[0] = cos(factor);
      Rot_twist[3] = -sin(factor);
      Rot_twist[6] = 0.0;
      Rot_twist[1] = sin(factor);
      Rot_twist[4] = cos(factor);
      Rot_twist[7] = 0.0;
      Rot_twist[2] = 0.0;
      Rot_twist[5] = 0.0;
      Rot_twist[8] = 1.0;

      // '<S14>:1:19'
      // '<S14>:1:20'
      for (iy = 0; iy < 3; iy++) {
        for (ixstart = 0; ixstart < 3; ixstart++) {
          matrix1_reshaped[iy + 3 * ixstart] = 0.0;
          matrix2_reshaped[iy + 3 * ixstart] = 0.0;
          matrix1_reshaped[iy + 3 * ixstart] += Rot_twist[3 * iy] *
            testXsens_2sensors_B.RotMatrix_out_m[3 * ixstart];
          matrix2_reshaped[iy + 3 * ixstart] += Rot_twist[3 * iy] *
            testXsens_2sensors_B.RotMatrix_out[3 * ixstart];
          matrix1_reshaped[iy + 3 * ixstart] += Rot_twist[3 * iy + 1] *
            testXsens_2sensors_B.RotMatrix_out_m[3 * ixstart + 1];
          matrix2_reshaped[iy + 3 * ixstart] += Rot_twist[3 * iy + 1] *
            testXsens_2sensors_B.RotMatrix_out[3 * ixstart + 1];
          matrix1_reshaped[iy + 3 * ixstart] += Rot_twist[3 * iy + 2] *
            testXsens_2sensors_B.RotMatrix_out_m[3 * ixstart + 2];
          matrix2_reshaped[iy + 3 * ixstart] += Rot_twist[3 * iy + 2] *
            testXsens_2sensors_B.RotMatrix_out[3 * ixstart + 2];
        }
      }
    }

    // '<S14>:1:23'
    for (iy = 0; iy < 3; iy++) {
      for (ixstart = 0; ixstart < 3; ixstart++) {
        Rot_twist[iy + 3 * ixstart] = 0.0;
        Rot_twist[iy + 3 * ixstart] += matrix2_reshaped[3 * iy] *
          matrix1_reshaped[3 * ixstart];
        Rot_twist[iy + 3 * ixstart] += matrix2_reshaped[3 * iy + 1] *
          matrix1_reshaped[3 * ixstart + 1];
        Rot_twist[iy + 3 * ixstart] += matrix2_reshaped[3 * iy + 2] *
          matrix1_reshaped[3 * ixstart + 2];
      }
    }

    for (iy = 0; iy < 9; iy++) {
      x[iy] = (testXsens_2sensors_DW.RotMatrix0[iy] == 0.0);
    }

    b_ixstart = 0;
    iy = -1;
    for (b_ix = 0; b_ix < 3; b_ix++) {
      ixstart = b_ixstart;
      b_ixstart++;
      b_ixstart++;
      factor = (real_T)x[b_ixstart - 1] + (real_T)x[ixstart];
      b_ixstart++;
      factor += (real_T)x[b_ixstart - 1];
      iy++;
      y[iy] = (int8_T)factor;
    }

    if (((real_T)y[0] + (real_T)y[1]) + (real_T)y[2] == 9.0) {
      // '<S14>:1:25'
      // '<S14>:1:26'
      memcpy(&matrix1_reshaped[0], &Rot_twist[0], 9U * sizeof(real_T));
    } else {
      // '<S14>:1:28'
      memcpy(&matrix1_reshaped[0], &testXsens_2sensors_DW.RotMatrix0[0], 9U *
             sizeof(real_T));
    }

    // '<S14>:1:31'
    for (iy = 0; iy < 3; iy++) {
      for (ixstart = 0; ixstart < 3; ixstart++) {
        matrix2_reshaped[iy + 3 * ixstart] = 0.0;
        matrix2_reshaped[iy + 3 * ixstart] += matrix1_reshaped[3 * iy] *
          Rot_twist[3 * ixstart];
        matrix2_reshaped[iy + 3 * ixstart] += matrix1_reshaped[3 * iy + 1] *
          Rot_twist[3 * ixstart + 1];
        matrix2_reshaped[iy + 3 * ixstart] += matrix1_reshaped[3 * iy + 2] *
          Rot_twist[3 * ixstart + 2];
      }
    }

    memcpy(&Rot_twist[0], &matrix2_reshaped[0], 9U * sizeof(real_T));

    // '<S14>:1:33'
    factor = rt_atan2d_snf(Rot_twist[7], Rot_twist[6]);

    // '<S14>:1:34'
    diff = rt_atan2d_snf(Rot_twist[7] * sin(factor) + Rot_twist[6] * cos(factor),
                         Rot_twist[8]);

    // '<S14>:1:35'
    testXsens_2sensors_B.flex_ext = -diff * cos(factor) * 180.0 /
      3.1415926535897931;

    // '<S14>:1:36'
    testXsens_2sensors_B.lat_bend = -diff * sin(factor) * 180.0 /
      3.1415926535897931;

    // '<S14>:1:37'
    testXsens_2sensors_B.twist = -rt_atan2d_snf(Rot_twist[2] * sin(factor) -
      Rot_twist[5] * cos(factor), -Rot_twist[2] * cos(factor) - Rot_twist[5] *
      sin(factor)) * 180.0 / 3.1415926535897931;

    // End of MATLAB Function: '<S4>/ExtractAngles'

    // DataStoreWrite: '<S4>/Data Store Write'
    memcpy(&testXsens_2sensors_DW.RotMatrix0[0], &matrix1_reshaped[0], 9U *
           sizeof(real_T));

    // SignalConversion: '<S4>/OutportBufferForOut1'
    testXsens_2sensors_B.OutportBufferForOut1 = testXsens_2sensors_B.flex_ext;

    // SignalConversion: '<S4>/OutportBufferForOut2'
    testXsens_2sensors_B.OutportBufferForOut2 = testXsens_2sensors_B.lat_bend;

    // SignalConversion: '<S4>/OutportBufferForOut3'
    testXsens_2sensors_B.OutportBufferForOut3 = testXsens_2sensors_B.twist;
    srUpdateBC(testXsens_2sensors_DW.Extractangles_SubsysRanBC);
  }

  // End of Outputs for SubSystem: '<Root>/Extract angles'

  // SignalConversion: '<Root>/TmpSignal ConversionAtTo Workspace1Inport1'
  testXsens_2sensors_B.TmpSignalConversionAtToWorkspac[0] =
    testXsens_2sensors_B.OutportBufferForOut1;
  testXsens_2sensors_B.TmpSignalConversionAtToWorkspac[1] =
    testXsens_2sensors_B.OutportBufferForOut2;
  testXsens_2sensors_B.TmpSignalConversionAtToWorkspac[2] =
    testXsens_2sensors_B.OutportBufferForOut3;

  // External mode
  rtExtModeUploadCheckTrigger(1);

  {                                    // Sample time: [0.01s, 0.0s]
    rtExtModeUpload(0, testXsens_2sensors_M->Timing.taskTime0);
  }

  // signal main to stop simulation
  {                                    // Sample time: [0.01s, 0.0s]
    if ((rtmGetTFinal(testXsens_2sensors_M)!=-1) &&
        !((rtmGetTFinal(testXsens_2sensors_M)-
           testXsens_2sensors_M->Timing.taskTime0) >
          testXsens_2sensors_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(testXsens_2sensors_M, "Simulation finished");
    }

    if (rtmGetStopRequested(testXsens_2sensors_M)) {
      rtmSetErrorStatus(testXsens_2sensors_M, "Simulation finished");
    }
  }

  // Update absolute time for base rate
  // The "clockTick0" counts the number of times the code of this task has
  //  been executed. The absolute time is the multiplication of "clockTick0"
  //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
  //  overflow during the application lifespan selected.

  testXsens_2sensors_M->Timing.taskTime0 =
    (++testXsens_2sensors_M->Timing.clockTick0) *
    testXsens_2sensors_M->Timing.stepSize0;
}

// Model initialize function
void testXsens_2sensors_initialize(void)
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // initialize real-time model
  (void) memset((void *)testXsens_2sensors_M, 0,
                sizeof(RT_MODEL_testXsens_2sensors_T));
  rtmSetTFinal(testXsens_2sensors_M, -1);
  testXsens_2sensors_M->Timing.stepSize0 = 0.01;

  // External mode info
  testXsens_2sensors_M->Sizes.checksums[0] = (1815717519U);
  testXsens_2sensors_M->Sizes.checksums[1] = (2284886422U);
  testXsens_2sensors_M->Sizes.checksums[2] = (3121621023U);
  testXsens_2sensors_M->Sizes.checksums[3] = (2609378783U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[11];
    testXsens_2sensors_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = (sysRanDType *)
      &testXsens_2sensors_DW.AlignmentCalibration1_SubsysRan;
    systemRan[2] = (sysRanDType *)
      &testXsens_2sensors_DW.AlignmentCalibration1_SubsysRan;
    systemRan[3] = (sysRanDType *)
      &testXsens_2sensors_DW.AlignmentCalibration1_SubsysRan;
    systemRan[4] = (sysRanDType *)
      &testXsens_2sensors_DW.AlignmentCalibration2_SubsysRan;
    systemRan[5] = (sysRanDType *)
      &testXsens_2sensors_DW.AlignmentCalibration2_SubsysRan;
    systemRan[6] = (sysRanDType *)
      &testXsens_2sensors_DW.AlignmentCalibration2_SubsysRan;
    systemRan[7] = &rtAlwaysEnabled;
    systemRan[8] = &rtAlwaysEnabled;
    systemRan[9] = (sysRanDType *)
      &testXsens_2sensors_DW.Extractangles_SubsysRanBC;
    systemRan[10] = (sysRanDType *)
      &testXsens_2sensors_DW.Extractangles_SubsysRanBC;
    rteiSetModelMappingInfoPtr(testXsens_2sensors_M->extModeInfo,
      &testXsens_2sensors_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(testXsens_2sensors_M->extModeInfo,
                        testXsens_2sensors_M->Sizes.checksums);
    rteiSetTPtr(testXsens_2sensors_M->extModeInfo, rtmGetTPtr
                (testXsens_2sensors_M));
  }

  // block I/O
  (void) memset(((void *) &testXsens_2sensors_B), 0,
                sizeof(B_testXsens_2sensors_T));

  // states (dwork)
  (void) memset((void *)&testXsens_2sensors_DW, 0,
                sizeof(DW_testXsens_2sensors_T));

  // data type transition information
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    testXsens_2sensors_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    // Block I/O transition table
    dtInfo.B = &rtBTransTable;

    // Parameters transition table
    dtInfo.P = &rtPTransTable;
  }

  // S-Function (ex_sfun_sci_xsens): <Root>/Xsens IMUs
  init_xsens( &testXsens_2sensors_DW.XsensIMUs_PWORK, (uint8_T*)
             testXsens_2sensors_P.XsensIMUs_p1, (uint32_T)10, (uint8_T*)
             testXsens_2sensors_P.XsensIMUs_p2, (uint32_T)8, (uint8_T*)
             testXsens_2sensors_P.XsensIMUs_p3, (uint32_T)8, (uint8_T*)
             &testXsens_2sensors_P.XsensIMUs_p4, (uint32_T)1, (uint8_T*)
             &testXsens_2sensors_P.XsensIMUs_p5, (uint32_T)1, (uint8_T*)
             &testXsens_2sensors_P.XsensIMUs_p6, (uint32_T)1, (uint8_T*)
             &testXsens_2sensors_P.XsensIMUs_p7, (uint32_T)1, (uint8_T*)
             &testXsens_2sensors_P.XsensIMUs_p8, (uint32_T)1, (uint8_T*)
             &testXsens_2sensors_P.XsensIMUs_p9, (uint32_T)1, (uint8_T*)
             &testXsens_2sensors_P.XsensIMUs_p10, (uint32_T)1, (uint8_T*)
             &testXsens_2sensors_P.XsensIMUs_p11, (uint32_T)1, (uint32_T)
             testXsens_2sensors_P.XsensIMUs_p12, (uint32_T)
             testXsens_2sensors_P.XsensIMUs_p13);

  // Start for Constant: '<Root>/Constant'
  testXsens_2sensors_B.Constant = testXsens_2sensors_P.Constant_Value;

  // Start for Enabled SubSystem: '<Root>/Alignment Calibration1'
  // Start for DataStoreMemory: '<S1>/Data storage' incorporates:
  //   Start for DataStoreMemory: '<S1>/Data storage1'
  //   Start for DataStoreMemory: '<S1>/Data storage2'

  memcpy(&testXsens_2sensors_DW.gRf_g[0],
         &testXsens_2sensors_P.Datastorage_InitialValue[0], 9U * sizeof(real_T));

  // Start for DataStoreMemory: '<S1>/Data storage1' incorporates:
  //   Start for DataStoreMemory: '<S1>/Data storage'
  //   Start for DataStoreMemory: '<S1>/Data storage2'

  memcpy(&testXsens_2sensors_DW.sRb_n[0],
         &testXsens_2sensors_P.Datastorage1_InitialValue[0], 9U * sizeof(real_T));

  // Start for DataStoreMemory: '<S1>/Data storage2' incorporates:
  //   Start for DataStoreMemory: '<S1>/Data storage'
  //   Start for DataStoreMemory: '<S1>/Data storage1'

  memcpy(&testXsens_2sensors_DW.RotMatrix_init_m[0],
         &testXsens_2sensors_P.Datastorage2_InitialValue[0], 9U * sizeof(real_T));

  // End of Start for SubSystem: '<Root>/Alignment Calibration1'

  // InitializeConditions for Enabled SubSystem: '<Root>/Alignment Calibration1' 
  // InitializeConditions for MATLAB Function: '<S6>/Extractor'
  testXsens_2senso_Extractor_Init(&testXsens_2sensors_DW.sf_Extractor_m);

  // InitializeConditions for Chart: '<S1>/Chart'
  testXsens_2sensors_DW.sfEvent_l = testXsens_2sensors_CALL_EVENT_m;
  testXsens_2sensors_DW.is_active_c3_XsensLibrary2_o = 0U;
  testXsens_2sensors_DW.is_c3_XsensLibrary2_a = testXsens_2s_IN_NO_ACTIVE_CHILD;

  // End of InitializeConditions for SubSystem: '<Root>/Alignment Calibration1'

  // Start for Constant: '<Root>/Constant1'
  testXsens_2sensors_B.Constant1 = testXsens_2sensors_P.Constant1_Value;

  // Start for Enabled SubSystem: '<Root>/Alignment Calibration2'
  // Start for DataStoreMemory: '<S2>/Data storage' incorporates:
  //   Start for DataStoreMemory: '<S2>/Data storage1'
  //   Start for DataStoreMemory: '<S2>/Data storage2'

  memcpy(&testXsens_2sensors_DW.gRf[0],
         &testXsens_2sensors_P.Datastorage_InitialValue_c[0], 9U * sizeof(real_T));

  // Start for DataStoreMemory: '<S2>/Data storage1' incorporates:
  //   Start for DataStoreMemory: '<S2>/Data storage'
  //   Start for DataStoreMemory: '<S2>/Data storage2'

  memcpy(&testXsens_2sensors_DW.sRb[0],
         &testXsens_2sensors_P.Datastorage1_InitialValue_d[0], 9U * sizeof
         (real_T));

  // Start for DataStoreMemory: '<S2>/Data storage2' incorporates:
  //   Start for DataStoreMemory: '<S2>/Data storage'
  //   Start for DataStoreMemory: '<S2>/Data storage1'

  memcpy(&testXsens_2sensors_DW.RotMatrix_init[0],
         &testXsens_2sensors_P.Datastorage2_InitialValue_c[0], 9U * sizeof
         (real_T));

  // End of Start for SubSystem: '<Root>/Alignment Calibration2'

  // InitializeConditions for Enabled SubSystem: '<Root>/Alignment Calibration2' 
  // InitializeConditions for MATLAB Function: '<S9>/Extractor'
  testXsens_2senso_Extractor_Init(&testXsens_2sensors_DW.sf_Extractor_l);

  // InitializeConditions for Chart: '<S2>/Chart'
  testXsens_2sensors_DW.sfEvent_n = testXsens_2sensors_CALL_EVENT_m;
  testXsens_2sensors_DW.is_active_c3_XsensLibrary2 = 0U;
  testXsens_2sensors_DW.is_c3_XsensLibrary2 = testXsens_2s_IN_NO_ACTIVE_CHILD;

  // End of InitializeConditions for SubSystem: '<Root>/Alignment Calibration2'

  // Start for Enabled SubSystem: '<Root>/Extract angles'
  // Start for DataStoreMemory: '<S4>/Data storage2'
  memcpy(&testXsens_2sensors_DW.RotMatrix0[0],
         &testXsens_2sensors_P.Datastorage2_InitialValue_n[0], 9U * sizeof
         (real_T));

  // VirtualOutportStart for Outport: '<S4>/Out1'
  testXsens_2sensors_B.OutportBufferForOut1 = testXsens_2sensors_P.Out1_Y0;

  // VirtualOutportStart for Outport: '<S4>/Out2'
  testXsens_2sensors_B.OutportBufferForOut2 = testXsens_2sensors_P.Out2_Y0;

  // VirtualOutportStart for Outport: '<S4>/Out3'
  testXsens_2sensors_B.OutportBufferForOut3 = testXsens_2sensors_P.Out3_Y0;

  // End of Start for SubSystem: '<Root>/Extract angles'

  // InitializeConditions for MATLAB Function: '<S12>/Extractor'
  testXsens_2sensors_DW.lastSampleNumber = 0.0;
  testXsens_2sensors_DW.lastFactor = 1.0;

  // InitializeConditions for Chart: '<S3>/Chart'
  testXsens_2sensors_DW.sfEvent = testXsens_2sensors_CALL_EVENT_m;
  testXsens_2sensors_DW.is_active_c4_XsensLibrary2 = 0U;
  testXsens_2sensors_DW.is_c4_XsensLibrary2 = testXsens_2s_IN_NO_ACTIVE_CHILD;
}

// Model terminate function
void testXsens_2sensors_terminate(void)
{
  // S-Function (ex_sfun_sci_xsens): <Root>/Xsens IMUs
  terminate_xsens( &testXsens_2sensors_DW.XsensIMUs_PWORK);
}

//
// File trailer for generated code.
//
// [EOF]
//
