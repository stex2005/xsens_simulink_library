  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 4;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (testXsens_2sensors_P)
    ;%
      section.nData     = 22;
      section.data(22)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_P.AlignmentCalibration1_RotationT
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_P.AlignmentCalibration2_RotationT
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testXsens_2sensors_P.Extractangles_TwistCorrection
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% testXsens_2sensors_P.AlignmentCalibration1_XAxis
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% testXsens_2sensors_P.AlignmentCalibration2_XAxis
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% testXsens_2sensors_P.AlignmentCalibration1_YAxis
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% testXsens_2sensors_P.AlignmentCalibration2_YAxis
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% testXsens_2sensors_P.AlignmentCalibration1_ZAxis
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% testXsens_2sensors_P.AlignmentCalibration2_ZAxis
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% testXsens_2sensors_P.Extract_correction
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% testXsens_2sensors_P.Extract_correction_b
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% testXsens_2sensors_P.Extract_correction_c
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% testXsens_2sensors_P.Datastorage_InitialValue
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% testXsens_2sensors_P.Datastorage1_InitialValue
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 21;
	
	  ;% testXsens_2sensors_P.Datastorage2_InitialValue
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 30;
	
	  ;% testXsens_2sensors_P.Datastorage_InitialValue_c
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 39;
	
	  ;% testXsens_2sensors_P.Datastorage1_InitialValue_d
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 48;
	
	  ;% testXsens_2sensors_P.Datastorage2_InitialValue_c
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 57;
	
	  ;% testXsens_2sensors_P.Out1_Y0
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 66;
	
	  ;% testXsens_2sensors_P.Out2_Y0
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 67;
	
	  ;% testXsens_2sensors_P.Out3_Y0
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 68;
	
	  ;% testXsens_2sensors_P.Datastorage2_InitialValue_n
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 69;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_P.Constant_Value
	  section.data(1).logicalSrcIdx = 22;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_P.Constant1_Value
	  section.data(2).logicalSrcIdx = 23;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(2) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_P.XsensIMUs_p12
	  section.data(1).logicalSrcIdx = 24;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p13
	  section.data(2).logicalSrcIdx = 25;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(3) = section;
      clear section
      
      section.nData     = 11;
      section.data(11)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_P.XsensIMUs_p1
	  section.data(1).logicalSrcIdx = 26;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p2
	  section.data(2).logicalSrcIdx = 27;
	  section.data(2).dtTransOffset = 10;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p3
	  section.data(3).logicalSrcIdx = 28;
	  section.data(3).dtTransOffset = 18;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p4
	  section.data(4).logicalSrcIdx = 29;
	  section.data(4).dtTransOffset = 26;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p5
	  section.data(5).logicalSrcIdx = 30;
	  section.data(5).dtTransOffset = 27;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p6
	  section.data(6).logicalSrcIdx = 31;
	  section.data(6).dtTransOffset = 28;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p7
	  section.data(7).logicalSrcIdx = 32;
	  section.data(7).dtTransOffset = 29;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p8
	  section.data(8).logicalSrcIdx = 33;
	  section.data(8).dtTransOffset = 30;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p9
	  section.data(9).logicalSrcIdx = 34;
	  section.data(9).dtTransOffset = 31;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p10
	  section.data(10).logicalSrcIdx = 35;
	  section.data(10).dtTransOffset = 32;
	
	  ;% testXsens_2sensors_P.XsensIMUs_p11
	  section.data(11).logicalSrcIdx = 36;
	  section.data(11).dtTransOffset = 33;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(4) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 4;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (testXsens_2sensors_B)
    ;%
      section.nData     = 11;
      section.data(11)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_B.TmpSignalConversionAtToWorkspac
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_B.OutportBufferForOut1
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 3;
	
	  ;% testXsens_2sensors_B.OutportBufferForOut2
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 4;
	
	  ;% testXsens_2sensors_B.OutportBufferForOut3
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 5;
	
	  ;% testXsens_2sensors_B.flex_ext
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 6;
	
	  ;% testXsens_2sensors_B.lat_bend
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 7;
	
	  ;% testXsens_2sensors_B.twist
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 8;
	
	  ;% testXsens_2sensors_B.a
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 9;
	
	  ;% testXsens_2sensors_B.FlagAvailable
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 12;
	
	  ;% testXsens_2sensors_B.RotMatrix_out
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 13;
	
	  ;% testXsens_2sensors_B.RotMatrix_out_m
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 22;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_B.Constant
	  section.data(1).logicalSrcIdx = 11;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_B.Constant1
	  section.data(2).logicalSrcIdx = 12;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_B.sf_Extractor_l.a
	  section.data(1).logicalSrcIdx = 13;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_B.sf_Extractor_l.rotmat
	  section.data(2).logicalSrcIdx = 14;
	  section.data(2).dtTransOffset = 3;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(3) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_B.sf_Extractor_m.a
	  section.data(1).logicalSrcIdx = 15;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_B.sf_Extractor_m.rotmat
	  section.data(2).logicalSrcIdx = 16;
	  section.data(2).dtTransOffset = 3;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(4) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 8;
    sectIdxOffset = 4;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (testXsens_2sensors_DW)
    ;%
      section.nData     = 32;
      section.data(32)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_DW.RotMatrix0
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_DW.lastSampleNumber
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 9;
	
	  ;% testXsens_2sensors_DW.lastFactor
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 10;
	
	  ;% testXsens_2sensors_DW.do_transition
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 11;
	
	  ;% testXsens_2sensors_DW.gRf
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 12;
	
	  ;% testXsens_2sensors_DW.sRb
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 21;
	
	  ;% testXsens_2sensors_DW.RotMatrix_init
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 30;
	
	  ;% testXsens_2sensors_DW.Accelerationbuffer
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 39;
	
	  ;% testXsens_2sensors_DW.mean_accel_b
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 54;
	
	  ;% testXsens_2sensors_DW.mean_accel
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 57;
	
	  ;% testXsens_2sensors_DW.mean_rotmat
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 60;
	
	  ;% testXsens_2sensors_DW.gamma
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 69;
	
	  ;% testXsens_2sensors_DW.beta
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 70;
	
	  ;% testXsens_2sensors_DW.gRb
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 71;
	
	  ;% testXsens_2sensors_DW.RotMatbuffer
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 80;
	
	  ;% testXsens_2sensors_DW.samples
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 125;
	
	  ;% testXsens_2sensors_DW.Calib_performed
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 126;
	
	  ;% testXsens_2sensors_DW.data_received
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 127;
	
	  ;% testXsens_2sensors_DW.gRf_g
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 128;
	
	  ;% testXsens_2sensors_DW.sRb_n
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 137;
	
	  ;% testXsens_2sensors_DW.RotMatrix_init_m
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 146;
	
	  ;% testXsens_2sensors_DW.Accelerationbuffer_h
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 155;
	
	  ;% testXsens_2sensors_DW.mean_accel_b_g
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 170;
	
	  ;% testXsens_2sensors_DW.mean_accel_f
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 173;
	
	  ;% testXsens_2sensors_DW.mean_rotmat_l
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 176;
	
	  ;% testXsens_2sensors_DW.gamma_b
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 185;
	
	  ;% testXsens_2sensors_DW.beta_k
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 186;
	
	  ;% testXsens_2sensors_DW.gRb_i
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 187;
	
	  ;% testXsens_2sensors_DW.RotMatbuffer_n
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 196;
	
	  ;% testXsens_2sensors_DW.samples_j
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 241;
	
	  ;% testXsens_2sensors_DW.Calib_performed_m
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 242;
	
	  ;% testXsens_2sensors_DW.data_received_i
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 243;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 4;
      section.data(4)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_DW.XsensIMUs_PWORK
	  section.data(1).logicalSrcIdx = 32;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_DW.Scope_PWORK.LoggedData
	  section.data(2).logicalSrcIdx = 33;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testXsens_2sensors_DW.ToWorkspace1_PWORK.LoggedData
	  section.data(3).logicalSrcIdx = 34;
	  section.data(3).dtTransOffset = 4;
	
	  ;% testXsens_2sensors_DW.ToWorkspace3_PWORK.LoggedData
	  section.data(4).logicalSrcIdx = 35;
	  section.data(4).dtTransOffset = 5;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_DW.sfEvent
	  section.data(1).logicalSrcIdx = 36;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_DW.sfEvent_n
	  section.data(2).logicalSrcIdx = 37;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testXsens_2sensors_DW.sfEvent_l
	  section.data(3).logicalSrcIdx = 38;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_DW.AlignmentCalibration1_SubsysRan
	  section.data(1).logicalSrcIdx = 39;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_DW.AlignmentCalibration2_SubsysRan
	  section.data(2).logicalSrcIdx = 40;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testXsens_2sensors_DW.Extractangles_SubsysRanBC
	  section.data(3).logicalSrcIdx = 41;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 6;
      section.data(6)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_DW.is_active_c4_XsensLibrary2
	  section.data(1).logicalSrcIdx = 42;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_DW.is_c4_XsensLibrary2
	  section.data(2).logicalSrcIdx = 43;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testXsens_2sensors_DW.is_active_c3_XsensLibrary2
	  section.data(3).logicalSrcIdx = 44;
	  section.data(3).dtTransOffset = 2;
	
	  ;% testXsens_2sensors_DW.is_c3_XsensLibrary2
	  section.data(4).logicalSrcIdx = 45;
	  section.data(4).dtTransOffset = 3;
	
	  ;% testXsens_2sensors_DW.is_active_c3_XsensLibrary2_o
	  section.data(5).logicalSrcIdx = 46;
	  section.data(5).dtTransOffset = 4;
	
	  ;% testXsens_2sensors_DW.is_c3_XsensLibrary2_a
	  section.data(6).logicalSrcIdx = 47;
	  section.data(6).dtTransOffset = 5;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_DW.isStable
	  section.data(1).logicalSrcIdx = 48;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_DW.isStable_d
	  section.data(2).logicalSrcIdx = 49;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testXsens_2sensors_DW.isStable_dk
	  section.data(3).logicalSrcIdx = 50;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_DW.sf_Extractor_l.lastSampleNumber
	  section.data(1).logicalSrcIdx = 51;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_DW.sf_Extractor_l.lastFactor
	  section.data(2).logicalSrcIdx = 52;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(7) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testXsens_2sensors_DW.sf_Extractor_m.lastSampleNumber
	  section.data(1).logicalSrcIdx = 53;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testXsens_2sensors_DW.sf_Extractor_m.lastFactor
	  section.data(2).logicalSrcIdx = 54;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(8) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 1815717519;
  targMap.checksum1 = 2284886422;
  targMap.checksum2 = 3121621023;
  targMap.checksum3 = 2609378783;

