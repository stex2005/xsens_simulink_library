//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: multiword_types.h
//
// Code generated for Simulink model 'testXsens_2sensors'.
//
// Model version                  : 1.158
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Fri Oct 28 17:24:10 2016
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//

#ifndef __MULTIWORD_TYPES_H__
#define __MULTIWORD_TYPES_H__
#include "rtwtypes.h"

//
//  Definitions supporting external data access
typedef int32_T chunk_T;
typedef uint32_T uchunk_T;

#endif                                 // __MULTIWORD_TYPES_H__

//
// File trailer for generated code.
//
// [EOF]
//
