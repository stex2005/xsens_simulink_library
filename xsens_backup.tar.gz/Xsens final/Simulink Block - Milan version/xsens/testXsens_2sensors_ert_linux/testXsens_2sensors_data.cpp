//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: testXsens_2sensors_data.cpp
//
// Code generated for Simulink model 'testXsens_2sensors'.
//
// Model version                  : 1.158
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Fri Oct 28 17:24:10 2016
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "testXsens_2sensors.h"
#include "testXsens_2sensors_private.h"

// Block parameters (auto storage)
P_testXsens_2sensors_T testXsens_2sensors_P = {
  1.0,                                 // Mask Parameter: AlignmentCalibration1_RotationT
                                       //  Referenced by: '<S1>/Chart'

  1.0,                                 // Mask Parameter: AlignmentCalibration2_RotationT
                                       //  Referenced by: '<S2>/Chart'

  1.0,                                 // Mask Parameter: Extractangles_TwistCorrection
                                       //  Referenced by: '<S4>/ExtractAngles'

  3.0,                                 // Mask Parameter: AlignmentCalibration1_XAxis
                                       //  Referenced by: '<S1>/Chart'

  3.0,                                 // Mask Parameter: AlignmentCalibration2_XAxis
                                       //  Referenced by: '<S2>/Chart'

  6.0,                                 // Mask Parameter: AlignmentCalibration1_YAxis
                                       //  Referenced by: '<S1>/Chart'

  1.0,                                 // Mask Parameter: AlignmentCalibration2_YAxis
                                       //  Referenced by: '<S2>/Chart'

  1.0,                                 // Mask Parameter: AlignmentCalibration1_ZAxis
                                       //  Referenced by: '<S1>/Chart'

  5.0,                                 // Mask Parameter: AlignmentCalibration2_ZAxis
                                       //  Referenced by: '<S2>/Chart'

  1.0,                                 // Mask Parameter: Extract_correction
                                       //  Referenced by: '<S6>/Extractor'

  1.0,                                 // Mask Parameter: Extract_correction_b
                                       //  Referenced by: '<S9>/Extractor'

  1.0,                                 // Mask Parameter: Extract_correction_c
                                       //  Referenced by: '<S12>/Extractor'


  //  Expression: eye(3)
  //  Referenced by: '<S1>/Data storage'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  //  Expression: eye(3)
  //  Referenced by: '<S1>/Data storage1'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  //  Expression: eye(3)
  //  Referenced by: '<S1>/Data storage2'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  //  Expression: eye(3)
  //  Referenced by: '<S2>/Data storage'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  //  Expression: eye(3)
  //  Referenced by: '<S2>/Data storage1'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },

  //  Expression: eye(3)
  //  Referenced by: '<S2>/Data storage2'

  { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0 },
  0.0,                                 // Computed Parameter: Out1_Y0
                                       //  Referenced by: '<S4>/Out1'

  0.0,                                 // Computed Parameter: Out2_Y0
                                       //  Referenced by: '<S4>/Out2'

  0.0,                                 // Computed Parameter: Out3_Y0
                                       //  Referenced by: '<S4>/Out3'


  //  Expression: [0 0 0; 0 0 0; 0 0 0]
  //  Referenced by: '<S4>/Data storage2'

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
  1.0F,                                // Computed Parameter: Constant_Value
                                       //  Referenced by: '<Root>/Constant'

  2.0F,                                // Computed Parameter: Constant1_Value
                                       //  Referenced by: '<Root>/Constant1'

  100U,                                // Expression: uint32(Freq)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  1U,                                  // Expression: uint32(UseCalibratedValues)
                                       //  Referenced by: '<Root>/Xsens IMUs'


  //  Expression: uint8(SID00)'
  //  Referenced by: '<Root>/Xsens IMUs'

  { 47U, 100U, 101U, 118U, 47U, 88U, 115U, 101U, 110U, 115U },

  //  Expression: uint8(SID01)'
  //  Referenced by: '<Root>/Xsens IMUs'

  { 48U, 48U, 66U, 52U, 49U, 56U, 67U, 57U },

  //  Expression: uint8(SID02)'
  //  Referenced by: '<Root>/Xsens IMUs'

  { 48U, 48U, 66U, 52U, 49U, 57U, 65U, 67U },
  48U,                                 // Expression: uint8(SID03)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID04)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID05)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID06)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID07)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID08)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U,                                 // Expression: uint8(SID09)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  48U                                  // Expression: uint8(SID10)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

};

//
// File trailer for generated code.
//
// [EOF]
//
