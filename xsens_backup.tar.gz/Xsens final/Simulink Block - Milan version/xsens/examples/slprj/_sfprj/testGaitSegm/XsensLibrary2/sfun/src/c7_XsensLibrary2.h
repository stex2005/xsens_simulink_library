#ifndef __c7_XsensLibrary2_h__
#define __c7_XsensLibrary2_h__

/* Include files */
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/sfc_mex.h"
#include "rtwtypes.h"
#include "multiword_types.h"

/* Type Definitions */
#ifndef struct_bus_datastruct_tag
#define struct_bus_datastruct_tag

struct bus_datastruct_tag
{
  real32_T VelRShank[200];
  real32_T VelLShank[200];
  real32_T AngRShank[200];
  real32_T AngLShank[200];
  real32_T VelRShank_filt[200];
  real32_T VelLShank_filt[200];
  real32_T AngRShank_filt[200];
  real32_T AngLShank_filt[200];
  real32_T VelRShank_LPF[200];
  real32_T VelLShank_LPF[200];
  real32_T AngRShank_LPF[200];
  real32_T AngLShank_LPF[200];
  real32_T AngRShank_LPF2Hz[200];
  real32_T AngLShank_LPF2Hz[200];
  uint16_T counter_stop;
  uint8_T counter;
  uint16_T index_start_calib;
  uint16_T index_stop_calib;
  boolean_T initial_leg;
  boolean_T flag_calib;
  int8_T calibrating;
  int8_T state;
  int8_T prevstate;
  real32_T MA_maxs_right[5];
  real32_T MA_maxs_left[5];
  real32_T MA_LPF_maxs_right[5];
  real32_T MA_LPF_maxs_left[5];
  uint8_T MA_LPF_index_right;
  uint8_T MA_LPF_index_left;
  uint8_T MA_index_right;
  uint8_T MA_index_left;
  real32_T IC_mins_right[5];
  real32_T IC_mins_left[5];
  real32_T IC_LPF_mins_right[5];
  real32_T IC_LPF_mins_left[5];
  uint8_T IC_LPF_index_right;
  uint8_T IC_LPF_index_left;
  uint8_T IC_index_right;
  uint8_T IC_index_left;
  real32_T EC_events_mins_right[5];
  real32_T EC_events_mins_left[5];
  real32_T EC_peaks_mins_right[5];
  real32_T EC_peaks_mins_left[5];
  uint8_T EC_events_index_right;
  uint8_T EC_events_index_left;
  uint8_T EC_peaks_index_right;
  uint8_T EC_peaks_index_left;
  real32_T AN_events_right[5];
  real32_T AN_events_left[5];
  real32_T AN_peaks_right[5];
  real32_T AN_peaks_left[5];
  uint8_T stop_DS_index;
  uint16_T stop_DS[10];
  boolean_T MS_event_left;
  boolean_T MS_event_right;
  boolean_T EC_event_left;
  boolean_T EC_event_right;
  boolean_T IC_event_left;
  boolean_T IC_event_right;
  boolean_T AN_event_left;
  boolean_T AN_event_right;
  boolean_T MA_event_left;
  boolean_T MA_event_right;
  boolean_T stop_Vel_event_left;
  boolean_T stop_Vel_event_right;
  boolean_T stop_MA_event_left;
  boolean_T stop_MA_event_right;
  boolean_T stop_IC_event_left;
  boolean_T stop_IC_event_right;
  boolean_T MA_flag_right;
  boolean_T MA_flag_left;
  uint16_T last_EC;
  uint16_T last_IC;
  real32_T IC_buffer_left[200];
  real32_T IC_buffer_right[200];
  real32_T EC_buffer_left[200];
  real32_T EC_buffer_right[200];
  real32_T MS_buffer_left[200];
  real32_T MS_buffer_right[200];
  uint8_T IC_buffer_index_left;
  uint8_T IC_buffer_index_right;
  uint8_T EC_buffer_index_left;
  uint8_T EC_buffer_index_right;
  uint8_T MS_buffer_index_left;
  uint8_T MS_buffer_index_right;
  real32_T MA_th_left;
  real32_T MA_th_right;
  real32_T IC_th_left;
  real32_T IC_th_right;
  real32_T AN_th_right;
  real32_T AN_th_left;
  real32_T EC_th_right;
  real32_T EC_th_left;
  real32_T stop_Vel_th_left;
  real32_T stop_Vel_th_right;
  real32_T stop_MA_th_left;
  real32_T stop_MA_th_right;
  real32_T stop_IC_th_right;
  real32_T stop_IC_th_left;
  uint16_T stop_DS_th;
  real32_T MA_LPF_th_left;
  real32_T MA_LPF_th_right;
  real32_T IC_LPF_th_left;
  real32_T IC_LPF_th_right;
};

#endif                                 /*struct_bus_datastruct_tag*/

#ifndef typedef_c7_bus_datastruct
#define typedef_c7_bus_datastruct

typedef struct bus_datastruct_tag c7_bus_datastruct;

#endif                                 /*typedef_c7_bus_datastruct*/

#ifndef typedef_SFc7_XsensLibrary2InstanceStruct
#define typedef_SFc7_XsensLibrary2InstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  boolean_T c7_dataWrittenToVector[6];
  uint8_T c7_doSetSimStateSideEffects;
  const mxArray *c7_setSimStateSideEffectsInfo;
  c7_bus_datastruct *c7_A_address;
  int32_T c7__index;
  int32_T *c7_sfEvent;
  boolean_T *c7_isStable;
  uint8_T *c7_is_active_c7_XsensLibrary2;
  uint8_T *c7_is_c7_XsensLibrary2;
  real_T *c7_time;
  real_T *c7_value_VelRShank;
  real32_T *c7_value_VelLShank;
  real32_T *c7_value_AngRShank;
  real32_T *c7_value_AngLShank;
  int8_T *c7_state;
  c7_bus_datastruct *c7_data_struct_out;
  c7_bus_datastruct *c7_data_struct;
} SFc7_XsensLibrary2InstanceStruct;

#endif                                 /*typedef_SFc7_XsensLibrary2InstanceStruct*/

/* Named Constants */

/* Variable Declarations */
extern struct SfDebugInstanceStruct *sfGlobalDebugInstanceStruct;

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c7_XsensLibrary2_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c7_XsensLibrary2_get_check_sum(mxArray *plhs[]);
extern void c7_XsensLibrary2_method_dispatcher(SimStruct *S, int_T method, void *
  data);

#endif
