/* Include files */

#include <stddef.h>
#include "blas.h"
#include "XsensLibrary2_sfun.h"
#include "c7_XsensLibrary2.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "XsensLibrary2_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c_with_debugger(S, sfGlobalDebugInstanceStruct);

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization);
static void chart_debug_initialize_data_addresses(SimStruct *S);
static const mxArray* sf_opaque_get_hover_data_for_msg(void *chartInstance,
  int32_T msgSSID);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)
#define c7_IN_NO_ACTIVE_CHILD          ((uint8_T)0U)
#define c7_IN_SEGMENTATION             ((uint8_T)1U)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static const char * c7_debug_family_names[2] = { "nargin", "nargout" };

static const char * c7_b_debug_family_names[4] = { "nargin", "nargout",
  "data_struct_in", "data_struct_new" };

static const char * c7_c_debug_family_names[2] = { "nargin", "nargout" };

static const char * c7_d_debug_family_names[29] = { "left_limit", "found",
  "index", "MS_inds_left", "EC_events_inds_left", "EC_distance_left", "EC_peaks",
  "AN_peaks", "EC_peaks_index", "MS_inds_right", "EC_events_inds_right",
  "EC_distance_right", "MS_inds_index_right", "MS_inds_index_left",
  "IC_LPF_inds_right", "IC_LPF_inds_left", "IC_inds_right", "IC_inds_left", "i",
  "DS_min", "temp", "data_struct_input", "timestamp", "newVelRShank",
  "newVelLShank", "newAngRShank", "newAngLShank", "data_struct_output",
  "state_out" };

/* Function Declarations */
static void c7_durationReferenceTimeUpdater(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void initialize_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void initialize_params_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct *
  chartInstance);
static void enable_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void disable_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void c7_update_debugger_state_c7_XsensLibrary2
  (SFc7_XsensLibrary2InstanceStruct *chartInstance);
static void ext_mode_exec_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static const mxArray *get_sim_state_c7_XsensLibrary2
  (SFc7_XsensLibrary2InstanceStruct *chartInstance);
static void set_sim_state_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_st);
static void c7_set_sim_state_side_effects_c7_XsensLibrary2
  (SFc7_XsensLibrary2InstanceStruct *chartInstance);
static void finalize_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void sf_gateway_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void mdl_start_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void initSimStructsc7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void c7_SEGMENTATION(SFc7_XsensLibrary2InstanceStruct *chartInstance);
static real_T c7_mean(SFc7_XsensLibrary2InstanceStruct *chartInstance, uint16_T
                      c7_x_data[], int32_T c7_x_sizes[2]);
static boolean_T c7_isequal(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  uint16_T c7_varargin_1_data[], int32_T c7_varargin_1_sizes[2]);
static real_T c7_rdivide(SFc7_XsensLibrary2InstanceStruct *chartInstance, real_T
  c7_x, real_T c7_y);
static real32_T c7_b_mean(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real32_T c7_x_data[], int32_T c7_x_sizes[2]);
static void c7_scalarEg(SFc7_XsensLibrary2InstanceStruct *chartInstance);
static boolean_T c7_b_isequal(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real32_T c7_varargin_1_data[], int32_T c7_varargin_1_sizes[2]);
static real32_T c7_b_rdivide(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real32_T c7_x, real_T c7_y);
static real32_T c7_std(SFc7_XsensLibrary2InstanceStruct *chartInstance, real32_T
  c7_varargin_1_data[], int32_T c7_varargin_1_sizes[2]);
static real32_T c7_vector_variance(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, real32_T c7_x_data[], int32_T c7_x_sizes[2], real32_T c7_w,
  int32_T c7_ixstart, int32_T c7_stride, int32_T c7_n);
static void c7_error(SFc7_XsensLibrary2InstanceStruct *chartInstance);
static real32_T c7_sign(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real32_T c7_x);
static real_T c7_c_mean(SFc7_XsensLibrary2InstanceStruct *chartInstance, real_T
  c7_x_data[], int32_T c7_x_sizes);
static void c7_b_scalarEg(SFc7_XsensLibrary2InstanceStruct *chartInstance);
static boolean_T c7_c_isequal(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real_T c7_varargin_1_data[], int32_T c7_varargin_1_sizes);
static void c7_dimagree(SFc7_XsensLibrary2InstanceStruct *chartInstance);
static uint16_T c7_ceil(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  uint16_T c7_x);
static void init_script_number_translation(uint32_T c7_machineNumber, uint32_T
  c7_chartNumber, uint32_T c7_instanceNumber);
static const mxArray *c7_sf_marshallOut(void *chartInstanceVoid, void *c7_inData);
static real_T c7_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId);
static void c7_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static const mxArray *c7_b_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static void c7_b_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_data_struct_new, const char_T *c7_identifier,
  c7_bus_datastruct *c7_y);
static void c7_c_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  c7_bus_datastruct *c7_y);
static void c7_d_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real32_T c7_y[200]);
static uint16_T c7_e_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId);
static uint8_T c7_f_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId);
static boolean_T c7_g_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId);
static int8_T c7_h_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId);
static void c7_i_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real32_T c7_y[5]);
static void c7_j_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  uint16_T c7_y[10]);
static real32_T c7_k_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId);
static void c7_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static const mxArray *c7_c_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static int8_T c7_l_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_state_out, const char_T *c7_identifier);
static void c7_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static const mxArray *c7_d_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static void c7_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static const mxArray *c7_e_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static void c7_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static const mxArray *c7_f_sf_marshallOut(void *chartInstanceVoid, real_T
  c7_inData_data[], int32_T c7_inData_sizes[2]);
static void c7_m_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real_T c7_y_data[], int32_T c7_y_sizes[2]);
static void c7_f_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, real_T c7_outData_data[], int32_T
  c7_outData_sizes[2]);
static const mxArray *c7_g_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static uint8_T c7_n_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_i, const char_T *c7_identifier);
static void c7_g_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static const mxArray *c7_h_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static void c7_o_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real_T c7_y[5]);
static void c7_h_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static const mxArray *c7_i_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static void c7_p_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real_T c7_y[50]);
static void c7_i_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static void c7_data_struct_creation(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, c7_bus_datastruct *c7_data_struct_in, c7_bus_datastruct
  *c7_data_struct_new);
static void c7_RTDetection(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  c7_bus_datastruct *c7_data_struct_input, real_T c7_timestamp, real_T
  c7_newVelRShank, real32_T c7_newVelLShank, real32_T c7_newAngRShank, real32_T
  c7_newAngLShank, c7_bus_datastruct *c7_data_struct_output, int8_T
  *c7_state_out);
static const mxArray *c7_j_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData);
static int32_T c7_q_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId);
static void c7_j_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData);
static const mxArray *c7_data_struct_out_bus_io(void *chartInstanceVoid, void
  *c7_pData);
static void c7_r_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_b_dataWrittenToVector, const char_T
  *c7_identifier, boolean_T c7_y[6]);
static void c7_s_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  boolean_T c7_y[6]);
static const mxArray *c7_t_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_b_setSimStateSideEffectsInfo, const char_T
  *c7_identifier);
static const mxArray *c7_u_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId);
static const mxArray *sf_get_hover_data_for_msg(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, int32_T c7_ssid);
static void c7_init_sf_message_store_memory(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void c7_b_sign(SFc7_XsensLibrary2InstanceStruct *chartInstance, real32_T *
                      c7_x);
static void c7_b_ceil(SFc7_XsensLibrary2InstanceStruct *chartInstance, uint16_T *
                      c7_x);
static void c7_bus_rd_access_A_2(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  int32_T c7_u0, int32_T c7_u1, int32_T c7_u2, int32_T c7_u3);
static c7_bus_datastruct c7_get_A(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, uint32_T c7_elementIndex);
static void c7_set_A(SFc7_XsensLibrary2InstanceStruct *chartInstance, uint32_T
                     c7_elementIndex, c7_bus_datastruct c7_elementValue);
static c7_bus_datastruct *c7_access_A(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, uint32_T c7_rdOnly);
static void init_dsm_address_info(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);
static void init_simulink_io_address(SFc7_XsensLibrary2InstanceStruct
  *chartInstance);

/* Function Definitions */
static void c7_durationReferenceTimeUpdater(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void initialize_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  if (sf_is_first_init_cond(chartInstance->S)) {
    initSimStructsc7_XsensLibrary2(chartInstance);
    chart_debug_initialize_data_addresses(chartInstance->S);
  }

  *chartInstance->c7_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c7_doSetSimStateSideEffects = 0U;
  chartInstance->c7_setSimStateSideEffectsInfo = NULL;
  *chartInstance->c7_is_active_c7_XsensLibrary2 = 0U;
  *chartInstance->c7_is_c7_XsensLibrary2 = c7_IN_NO_ACTIVE_CHILD;
}

static void initialize_params_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct *
  chartInstance)
{
  (void)chartInstance;
}

static void enable_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c7_update_debugger_state_c7_XsensLibrary2
  (SFc7_XsensLibrary2InstanceStruct *chartInstance)
{
  uint32_T c7_prevAniVal;
  c7_prevAniVal = _SFD_GET_ANIMATION();
  _SFD_SET_ANIMATION(0U);
  _SFD_SET_HONOR_BREAKPOINTS(0U);
  if (*chartInstance->c7_is_active_c7_XsensLibrary2 == 1U) {
    _SFD_CC_CALL(CHART_ACTIVE_TAG, 2U, *chartInstance->c7_sfEvent);
  }

  if (*chartInstance->c7_is_c7_XsensLibrary2 == c7_IN_SEGMENTATION) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 1U, *chartInstance->c7_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 1U, *chartInstance->c7_sfEvent);
  }

  _SFD_SET_ANIMATION(c7_prevAniVal);
  _SFD_SET_HONOR_BREAKPOINTS(1U);
  _SFD_ANIMATE();
}

static void ext_mode_exec_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  c7_update_debugger_state_c7_XsensLibrary2(chartInstance);
}

static const mxArray *get_sim_state_c7_XsensLibrary2
  (SFc7_XsensLibrary2InstanceStruct *chartInstance)
{
  const mxArray *c7_st;
  const mxArray *c7_y = NULL;
  const mxArray *c7_b_y = NULL;
  int32_T c7_i0;
  real32_T c7_u[200];
  const mxArray *c7_c_y = NULL;
  int32_T c7_i1;
  const mxArray *c7_d_y = NULL;
  int32_T c7_i2;
  const mxArray *c7_e_y = NULL;
  int32_T c7_i3;
  const mxArray *c7_f_y = NULL;
  int32_T c7_i4;
  const mxArray *c7_g_y = NULL;
  int32_T c7_i5;
  const mxArray *c7_h_y = NULL;
  int32_T c7_i6;
  const mxArray *c7_i_y = NULL;
  int32_T c7_i7;
  const mxArray *c7_j_y = NULL;
  int32_T c7_i8;
  const mxArray *c7_k_y = NULL;
  int32_T c7_i9;
  const mxArray *c7_l_y = NULL;
  int32_T c7_i10;
  const mxArray *c7_m_y = NULL;
  int32_T c7_i11;
  const mxArray *c7_n_y = NULL;
  int32_T c7_i12;
  const mxArray *c7_o_y = NULL;
  int32_T c7_i13;
  const mxArray *c7_p_y = NULL;
  uint16_T c7_b_u;
  const mxArray *c7_q_y = NULL;
  uint8_T c7_c_u;
  const mxArray *c7_r_y = NULL;
  uint16_T c7_d_u;
  const mxArray *c7_s_y = NULL;
  uint16_T c7_e_u;
  const mxArray *c7_t_y = NULL;
  boolean_T c7_f_u;
  const mxArray *c7_u_y = NULL;
  boolean_T c7_g_u;
  const mxArray *c7_v_y = NULL;
  int8_T c7_h_u;
  const mxArray *c7_w_y = NULL;
  int8_T c7_i_u;
  const mxArray *c7_x_y = NULL;
  int8_T c7_j_u;
  const mxArray *c7_y_y = NULL;
  int32_T c7_i14;
  real32_T c7_k_u[5];
  const mxArray *c7_ab_y = NULL;
  int32_T c7_i15;
  const mxArray *c7_bb_y = NULL;
  int32_T c7_i16;
  const mxArray *c7_cb_y = NULL;
  int32_T c7_i17;
  const mxArray *c7_db_y = NULL;
  uint8_T c7_l_u;
  const mxArray *c7_eb_y = NULL;
  uint8_T c7_m_u;
  const mxArray *c7_fb_y = NULL;
  uint8_T c7_n_u;
  const mxArray *c7_gb_y = NULL;
  uint8_T c7_o_u;
  const mxArray *c7_hb_y = NULL;
  int32_T c7_i18;
  const mxArray *c7_ib_y = NULL;
  int32_T c7_i19;
  const mxArray *c7_jb_y = NULL;
  int32_T c7_i20;
  const mxArray *c7_kb_y = NULL;
  int32_T c7_i21;
  const mxArray *c7_lb_y = NULL;
  uint8_T c7_p_u;
  const mxArray *c7_mb_y = NULL;
  uint8_T c7_q_u;
  const mxArray *c7_nb_y = NULL;
  uint8_T c7_r_u;
  const mxArray *c7_ob_y = NULL;
  uint8_T c7_s_u;
  const mxArray *c7_pb_y = NULL;
  int32_T c7_i22;
  const mxArray *c7_qb_y = NULL;
  int32_T c7_i23;
  const mxArray *c7_rb_y = NULL;
  int32_T c7_i24;
  const mxArray *c7_sb_y = NULL;
  int32_T c7_i25;
  const mxArray *c7_tb_y = NULL;
  uint8_T c7_t_u;
  const mxArray *c7_ub_y = NULL;
  uint8_T c7_u_u;
  const mxArray *c7_vb_y = NULL;
  uint8_T c7_v_u;
  const mxArray *c7_wb_y = NULL;
  uint8_T c7_w_u;
  const mxArray *c7_xb_y = NULL;
  int32_T c7_i26;
  const mxArray *c7_yb_y = NULL;
  int32_T c7_i27;
  const mxArray *c7_ac_y = NULL;
  int32_T c7_i28;
  const mxArray *c7_bc_y = NULL;
  int32_T c7_i29;
  const mxArray *c7_cc_y = NULL;
  uint8_T c7_x_u;
  const mxArray *c7_dc_y = NULL;
  int32_T c7_i30;
  uint16_T c7_y_u[10];
  const mxArray *c7_ec_y = NULL;
  boolean_T c7_ab_u;
  const mxArray *c7_fc_y = NULL;
  boolean_T c7_bb_u;
  const mxArray *c7_gc_y = NULL;
  boolean_T c7_cb_u;
  const mxArray *c7_hc_y = NULL;
  boolean_T c7_db_u;
  const mxArray *c7_ic_y = NULL;
  boolean_T c7_eb_u;
  const mxArray *c7_jc_y = NULL;
  boolean_T c7_fb_u;
  const mxArray *c7_kc_y = NULL;
  boolean_T c7_gb_u;
  const mxArray *c7_lc_y = NULL;
  boolean_T c7_hb_u;
  const mxArray *c7_mc_y = NULL;
  boolean_T c7_ib_u;
  const mxArray *c7_nc_y = NULL;
  boolean_T c7_jb_u;
  const mxArray *c7_oc_y = NULL;
  boolean_T c7_kb_u;
  const mxArray *c7_pc_y = NULL;
  boolean_T c7_lb_u;
  const mxArray *c7_qc_y = NULL;
  boolean_T c7_mb_u;
  const mxArray *c7_rc_y = NULL;
  boolean_T c7_nb_u;
  const mxArray *c7_sc_y = NULL;
  boolean_T c7_ob_u;
  const mxArray *c7_tc_y = NULL;
  boolean_T c7_pb_u;
  const mxArray *c7_uc_y = NULL;
  boolean_T c7_qb_u;
  const mxArray *c7_vc_y = NULL;
  boolean_T c7_rb_u;
  const mxArray *c7_wc_y = NULL;
  uint16_T c7_sb_u;
  const mxArray *c7_xc_y = NULL;
  uint16_T c7_tb_u;
  const mxArray *c7_yc_y = NULL;
  int32_T c7_i31;
  const mxArray *c7_ad_y = NULL;
  int32_T c7_i32;
  const mxArray *c7_bd_y = NULL;
  int32_T c7_i33;
  const mxArray *c7_cd_y = NULL;
  int32_T c7_i34;
  const mxArray *c7_dd_y = NULL;
  int32_T c7_i35;
  const mxArray *c7_ed_y = NULL;
  int32_T c7_i36;
  const mxArray *c7_fd_y = NULL;
  uint8_T c7_ub_u;
  const mxArray *c7_gd_y = NULL;
  uint8_T c7_vb_u;
  const mxArray *c7_hd_y = NULL;
  uint8_T c7_wb_u;
  const mxArray *c7_id_y = NULL;
  uint8_T c7_xb_u;
  const mxArray *c7_jd_y = NULL;
  uint8_T c7_yb_u;
  const mxArray *c7_kd_y = NULL;
  uint8_T c7_ac_u;
  const mxArray *c7_ld_y = NULL;
  real32_T c7_bc_u;
  const mxArray *c7_md_y = NULL;
  real32_T c7_cc_u;
  const mxArray *c7_nd_y = NULL;
  real32_T c7_dc_u;
  const mxArray *c7_od_y = NULL;
  real32_T c7_ec_u;
  const mxArray *c7_pd_y = NULL;
  real32_T c7_fc_u;
  const mxArray *c7_qd_y = NULL;
  real32_T c7_gc_u;
  const mxArray *c7_rd_y = NULL;
  real32_T c7_hc_u;
  const mxArray *c7_sd_y = NULL;
  real32_T c7_ic_u;
  const mxArray *c7_td_y = NULL;
  real32_T c7_jc_u;
  const mxArray *c7_ud_y = NULL;
  real32_T c7_kc_u;
  const mxArray *c7_vd_y = NULL;
  real32_T c7_lc_u;
  const mxArray *c7_wd_y = NULL;
  real32_T c7_mc_u;
  const mxArray *c7_xd_y = NULL;
  real32_T c7_nc_u;
  const mxArray *c7_yd_y = NULL;
  real32_T c7_oc_u;
  const mxArray *c7_ae_y = NULL;
  uint16_T c7_pc_u;
  const mxArray *c7_be_y = NULL;
  real32_T c7_qc_u;
  const mxArray *c7_ce_y = NULL;
  real32_T c7_rc_u;
  const mxArray *c7_de_y = NULL;
  real32_T c7_sc_u;
  const mxArray *c7_ee_y = NULL;
  real32_T c7_tc_u;
  const mxArray *c7_fe_y = NULL;
  int8_T c7_hoistedGlobal;
  int8_T c7_uc_u;
  const mxArray *c7_ge_y = NULL;
  const mxArray *c7_he_y = NULL;
  int32_T c7_i37;
  const mxArray *c7_ie_y = NULL;
  int32_T c7_i38;
  const mxArray *c7_je_y = NULL;
  int32_T c7_i39;
  const mxArray *c7_ke_y = NULL;
  int32_T c7_i40;
  const mxArray *c7_le_y = NULL;
  int32_T c7_i41;
  const mxArray *c7_me_y = NULL;
  int32_T c7_i42;
  const mxArray *c7_ne_y = NULL;
  int32_T c7_i43;
  const mxArray *c7_oe_y = NULL;
  int32_T c7_i44;
  const mxArray *c7_pe_y = NULL;
  int32_T c7_i45;
  const mxArray *c7_qe_y = NULL;
  int32_T c7_i46;
  const mxArray *c7_re_y = NULL;
  int32_T c7_i47;
  const mxArray *c7_se_y = NULL;
  int32_T c7_i48;
  const mxArray *c7_te_y = NULL;
  int32_T c7_i49;
  const mxArray *c7_ue_y = NULL;
  int32_T c7_i50;
  const mxArray *c7_ve_y = NULL;
  uint16_T c7_vc_u;
  const mxArray *c7_we_y = NULL;
  uint8_T c7_wc_u;
  const mxArray *c7_xe_y = NULL;
  uint16_T c7_xc_u;
  const mxArray *c7_ye_y = NULL;
  uint16_T c7_yc_u;
  const mxArray *c7_af_y = NULL;
  boolean_T c7_ad_u;
  const mxArray *c7_bf_y = NULL;
  boolean_T c7_bd_u;
  const mxArray *c7_cf_y = NULL;
  int8_T c7_cd_u;
  const mxArray *c7_df_y = NULL;
  int8_T c7_dd_u;
  const mxArray *c7_ef_y = NULL;
  int8_T c7_ed_u;
  const mxArray *c7_ff_y = NULL;
  int32_T c7_i51;
  const mxArray *c7_gf_y = NULL;
  int32_T c7_i52;
  const mxArray *c7_hf_y = NULL;
  int32_T c7_i53;
  const mxArray *c7_if_y = NULL;
  int32_T c7_i54;
  const mxArray *c7_jf_y = NULL;
  uint8_T c7_fd_u;
  const mxArray *c7_kf_y = NULL;
  uint8_T c7_gd_u;
  const mxArray *c7_lf_y = NULL;
  uint8_T c7_hd_u;
  const mxArray *c7_mf_y = NULL;
  uint8_T c7_id_u;
  const mxArray *c7_nf_y = NULL;
  int32_T c7_i55;
  const mxArray *c7_of_y = NULL;
  int32_T c7_i56;
  const mxArray *c7_pf_y = NULL;
  int32_T c7_i57;
  const mxArray *c7_qf_y = NULL;
  int32_T c7_i58;
  const mxArray *c7_rf_y = NULL;
  uint8_T c7_jd_u;
  const mxArray *c7_sf_y = NULL;
  uint8_T c7_kd_u;
  const mxArray *c7_tf_y = NULL;
  uint8_T c7_ld_u;
  const mxArray *c7_uf_y = NULL;
  uint8_T c7_md_u;
  const mxArray *c7_vf_y = NULL;
  int32_T c7_i59;
  const mxArray *c7_wf_y = NULL;
  int32_T c7_i60;
  const mxArray *c7_xf_y = NULL;
  int32_T c7_i61;
  const mxArray *c7_yf_y = NULL;
  int32_T c7_i62;
  const mxArray *c7_ag_y = NULL;
  uint8_T c7_nd_u;
  const mxArray *c7_bg_y = NULL;
  uint8_T c7_od_u;
  const mxArray *c7_cg_y = NULL;
  uint8_T c7_pd_u;
  const mxArray *c7_dg_y = NULL;
  uint8_T c7_qd_u;
  const mxArray *c7_eg_y = NULL;
  int32_T c7_i63;
  const mxArray *c7_fg_y = NULL;
  int32_T c7_i64;
  const mxArray *c7_gg_y = NULL;
  int32_T c7_i65;
  const mxArray *c7_hg_y = NULL;
  int32_T c7_i66;
  const mxArray *c7_ig_y = NULL;
  uint8_T c7_rd_u;
  const mxArray *c7_jg_y = NULL;
  int32_T c7_i67;
  const mxArray *c7_kg_y = NULL;
  boolean_T c7_sd_u;
  const mxArray *c7_lg_y = NULL;
  boolean_T c7_td_u;
  const mxArray *c7_mg_y = NULL;
  boolean_T c7_ud_u;
  const mxArray *c7_ng_y = NULL;
  boolean_T c7_vd_u;
  const mxArray *c7_og_y = NULL;
  boolean_T c7_wd_u;
  const mxArray *c7_pg_y = NULL;
  boolean_T c7_xd_u;
  const mxArray *c7_qg_y = NULL;
  boolean_T c7_yd_u;
  const mxArray *c7_rg_y = NULL;
  boolean_T c7_ae_u;
  const mxArray *c7_sg_y = NULL;
  boolean_T c7_be_u;
  const mxArray *c7_tg_y = NULL;
  boolean_T c7_ce_u;
  const mxArray *c7_ug_y = NULL;
  boolean_T c7_de_u;
  const mxArray *c7_vg_y = NULL;
  boolean_T c7_ee_u;
  const mxArray *c7_wg_y = NULL;
  boolean_T c7_fe_u;
  const mxArray *c7_xg_y = NULL;
  boolean_T c7_ge_u;
  const mxArray *c7_yg_y = NULL;
  boolean_T c7_he_u;
  const mxArray *c7_ah_y = NULL;
  boolean_T c7_ie_u;
  const mxArray *c7_bh_y = NULL;
  boolean_T c7_je_u;
  const mxArray *c7_ch_y = NULL;
  boolean_T c7_ke_u;
  const mxArray *c7_dh_y = NULL;
  uint16_T c7_le_u;
  const mxArray *c7_eh_y = NULL;
  uint16_T c7_me_u;
  const mxArray *c7_fh_y = NULL;
  int32_T c7_i68;
  const mxArray *c7_gh_y = NULL;
  int32_T c7_i69;
  const mxArray *c7_hh_y = NULL;
  int32_T c7_i70;
  const mxArray *c7_ih_y = NULL;
  int32_T c7_i71;
  const mxArray *c7_jh_y = NULL;
  int32_T c7_i72;
  const mxArray *c7_kh_y = NULL;
  int32_T c7_i73;
  const mxArray *c7_lh_y = NULL;
  uint8_T c7_ne_u;
  const mxArray *c7_mh_y = NULL;
  uint8_T c7_oe_u;
  const mxArray *c7_nh_y = NULL;
  uint8_T c7_pe_u;
  const mxArray *c7_oh_y = NULL;
  uint8_T c7_qe_u;
  const mxArray *c7_ph_y = NULL;
  uint8_T c7_re_u;
  const mxArray *c7_qh_y = NULL;
  uint8_T c7_se_u;
  const mxArray *c7_rh_y = NULL;
  real32_T c7_te_u;
  const mxArray *c7_sh_y = NULL;
  real32_T c7_ue_u;
  const mxArray *c7_th_y = NULL;
  real32_T c7_ve_u;
  const mxArray *c7_uh_y = NULL;
  real32_T c7_we_u;
  const mxArray *c7_vh_y = NULL;
  real32_T c7_xe_u;
  const mxArray *c7_wh_y = NULL;
  real32_T c7_ye_u;
  const mxArray *c7_xh_y = NULL;
  real32_T c7_af_u;
  const mxArray *c7_yh_y = NULL;
  real32_T c7_bf_u;
  const mxArray *c7_ai_y = NULL;
  real32_T c7_cf_u;
  const mxArray *c7_bi_y = NULL;
  real32_T c7_df_u;
  const mxArray *c7_ci_y = NULL;
  real32_T c7_ef_u;
  const mxArray *c7_di_y = NULL;
  real32_T c7_ff_u;
  const mxArray *c7_ei_y = NULL;
  real32_T c7_gf_u;
  const mxArray *c7_fi_y = NULL;
  real32_T c7_hf_u;
  const mxArray *c7_gi_y = NULL;
  uint16_T c7_if_u;
  const mxArray *c7_hi_y = NULL;
  real32_T c7_jf_u;
  const mxArray *c7_ii_y = NULL;
  real32_T c7_kf_u;
  const mxArray *c7_ji_y = NULL;
  real32_T c7_lf_u;
  const mxArray *c7_ki_y = NULL;
  real32_T c7_mf_u;
  const mxArray *c7_li_y = NULL;
  uint8_T c7_b_hoistedGlobal;
  uint8_T c7_nf_u;
  const mxArray *c7_mi_y = NULL;
  uint8_T c7_c_hoistedGlobal;
  uint8_T c7_of_u;
  const mxArray *c7_ni_y = NULL;
  const mxArray *c7_oi_y = NULL;
  c7_st = NULL;
  c7_st = NULL;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_createcellmatrix(6, 1), false);
  c7_b_y = NULL;
  sf_mex_assign(&c7_b_y, sf_mex_createstruct("structure", 2, 1, 1), false);
  for (c7_i0 = 0; c7_i0 < 200; c7_i0++) {
    c7_u[c7_i0] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[0])
      [c7_i0];
  }

  c7_c_y = NULL;
  sf_mex_assign(&c7_c_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_c_y, "VelRShank", "VelRShank", 0);
  for (c7_i1 = 0; c7_i1 < 200; c7_i1++) {
    c7_u[c7_i1] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [800])[c7_i1];
  }

  c7_d_y = NULL;
  sf_mex_assign(&c7_d_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_d_y, "VelLShank", "VelLShank", 0);
  for (c7_i2 = 0; c7_i2 < 200; c7_i2++) {
    c7_u[c7_i2] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [1600])[c7_i2];
  }

  c7_e_y = NULL;
  sf_mex_assign(&c7_e_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_e_y, "AngRShank", "AngRShank", 0);
  for (c7_i3 = 0; c7_i3 < 200; c7_i3++) {
    c7_u[c7_i3] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [2400])[c7_i3];
  }

  c7_f_y = NULL;
  sf_mex_assign(&c7_f_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_f_y, "AngLShank", "AngLShank", 0);
  for (c7_i4 = 0; c7_i4 < 200; c7_i4++) {
    c7_u[c7_i4] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [3200])[c7_i4];
  }

  c7_g_y = NULL;
  sf_mex_assign(&c7_g_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_g_y, "VelRShank_filt", "VelRShank_filt", 0);
  for (c7_i5 = 0; c7_i5 < 200; c7_i5++) {
    c7_u[c7_i5] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [4000])[c7_i5];
  }

  c7_h_y = NULL;
  sf_mex_assign(&c7_h_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_h_y, "VelLShank_filt", "VelLShank_filt", 0);
  for (c7_i6 = 0; c7_i6 < 200; c7_i6++) {
    c7_u[c7_i6] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [4800])[c7_i6];
  }

  c7_i_y = NULL;
  sf_mex_assign(&c7_i_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_i_y, "AngRShank_filt", "AngRShank_filt", 0);
  for (c7_i7 = 0; c7_i7 < 200; c7_i7++) {
    c7_u[c7_i7] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [5600])[c7_i7];
  }

  c7_j_y = NULL;
  sf_mex_assign(&c7_j_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_j_y, "AngLShank_filt", "AngLShank_filt", 0);
  for (c7_i8 = 0; c7_i8 < 200; c7_i8++) {
    c7_u[c7_i8] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [6400])[c7_i8];
  }

  c7_k_y = NULL;
  sf_mex_assign(&c7_k_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_k_y, "VelRShank_LPF", "VelRShank_LPF", 0);
  for (c7_i9 = 0; c7_i9 < 200; c7_i9++) {
    c7_u[c7_i9] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                   [7200])[c7_i9];
  }

  c7_l_y = NULL;
  sf_mex_assign(&c7_l_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_l_y, "VelLShank_LPF", "VelLShank_LPF", 0);
  for (c7_i10 = 0; c7_i10 < 200; c7_i10++) {
    c7_u[c7_i10] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [8000])[c7_i10];
  }

  c7_m_y = NULL;
  sf_mex_assign(&c7_m_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_m_y, "AngRShank_LPF", "AngRShank_LPF", 0);
  for (c7_i11 = 0; c7_i11 < 200; c7_i11++) {
    c7_u[c7_i11] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [8800])[c7_i11];
  }

  c7_n_y = NULL;
  sf_mex_assign(&c7_n_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_n_y, "AngLShank_LPF", "AngLShank_LPF", 0);
  for (c7_i12 = 0; c7_i12 < 200; c7_i12++) {
    c7_u[c7_i12] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [9600])[c7_i12];
  }

  c7_o_y = NULL;
  sf_mex_assign(&c7_o_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_o_y, "AngRShank_LPF2Hz", "AngRShank_LPF2Hz", 0);
  for (c7_i13 = 0; c7_i13 < 200; c7_i13++) {
    c7_u[c7_i13] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [10400])[c7_i13];
  }

  c7_p_y = NULL;
  sf_mex_assign(&c7_p_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_p_y, "AngLShank_LPF2Hz", "AngLShank_LPF2Hz", 0);
  c7_b_u = *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11200];
  c7_q_y = NULL;
  sf_mex_assign(&c7_q_y, sf_mex_create("y", &c7_b_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_q_y, "counter_stop", "counter_stop", 0);
  c7_c_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11202];
  c7_r_y = NULL;
  sf_mex_assign(&c7_r_y, sf_mex_create("y", &c7_c_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_r_y, "counter", "counter", 0);
  c7_d_u = *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11204];
  c7_s_y = NULL;
  sf_mex_assign(&c7_s_y, sf_mex_create("y", &c7_d_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_s_y, "index_start_calib", "index_start_calib", 0);
  c7_e_u = *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11206];
  c7_t_y = NULL;
  sf_mex_assign(&c7_t_y, sf_mex_create("y", &c7_e_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_t_y, "index_stop_calib", "index_stop_calib", 0);
  c7_f_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11208];
  c7_u_y = NULL;
  sf_mex_assign(&c7_u_y, sf_mex_create("y", &c7_f_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_u_y, "initial_leg", "initial_leg", 0);
  c7_g_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11209];
  c7_v_y = NULL;
  sf_mex_assign(&c7_v_y, sf_mex_create("y", &c7_g_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_v_y, "flag_calib", "flag_calib", 0);
  c7_h_u = *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11210];
  c7_w_y = NULL;
  sf_mex_assign(&c7_w_y, sf_mex_create("y", &c7_h_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_w_y, "calibrating", "calibrating", 0);
  c7_i_u = *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11211];
  c7_x_y = NULL;
  sf_mex_assign(&c7_x_y, sf_mex_create("y", &c7_i_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_x_y, "state", "state", 0);
  c7_j_u = *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11212];
  c7_y_y = NULL;
  sf_mex_assign(&c7_y_y, sf_mex_create("y", &c7_j_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_y_y, "prevstate", "prevstate", 0);
  for (c7_i14 = 0; c7_i14 < 5; c7_i14++) {
    c7_k_u[c7_i14] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11216])[c7_i14];
  }

  c7_ab_y = NULL;
  sf_mex_assign(&c7_ab_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_ab_y, "MA_maxs_right", "MA_maxs_right", 0);
  for (c7_i15 = 0; c7_i15 < 5; c7_i15++) {
    c7_k_u[c7_i15] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11236])[c7_i15];
  }

  c7_bb_y = NULL;
  sf_mex_assign(&c7_bb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_bb_y, "MA_maxs_left", "MA_maxs_left", 0);
  for (c7_i16 = 0; c7_i16 < 5; c7_i16++) {
    c7_k_u[c7_i16] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11256])[c7_i16];
  }

  c7_cb_y = NULL;
  sf_mex_assign(&c7_cb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_cb_y, "MA_LPF_maxs_right", "MA_LPF_maxs_right", 0);
  for (c7_i17 = 0; c7_i17 < 5; c7_i17++) {
    c7_k_u[c7_i17] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11276])[c7_i17];
  }

  c7_db_y = NULL;
  sf_mex_assign(&c7_db_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_db_y, "MA_LPF_maxs_left", "MA_LPF_maxs_left", 0);
  c7_l_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11296];
  c7_eb_y = NULL;
  sf_mex_assign(&c7_eb_y, sf_mex_create("y", &c7_l_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_eb_y, "MA_LPF_index_right", "MA_LPF_index_right", 0);
  c7_m_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11297];
  c7_fb_y = NULL;
  sf_mex_assign(&c7_fb_y, sf_mex_create("y", &c7_m_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_fb_y, "MA_LPF_index_left", "MA_LPF_index_left", 0);
  c7_n_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11298];
  c7_gb_y = NULL;
  sf_mex_assign(&c7_gb_y, sf_mex_create("y", &c7_n_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_gb_y, "MA_index_right", "MA_index_right", 0);
  c7_o_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11299];
  c7_hb_y = NULL;
  sf_mex_assign(&c7_hb_y, sf_mex_create("y", &c7_o_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_hb_y, "MA_index_left", "MA_index_left", 0);
  for (c7_i18 = 0; c7_i18 < 5; c7_i18++) {
    c7_k_u[c7_i18] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11300])[c7_i18];
  }

  c7_ib_y = NULL;
  sf_mex_assign(&c7_ib_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_ib_y, "IC_mins_right", "IC_mins_right", 0);
  for (c7_i19 = 0; c7_i19 < 5; c7_i19++) {
    c7_k_u[c7_i19] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11320])[c7_i19];
  }

  c7_jb_y = NULL;
  sf_mex_assign(&c7_jb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_jb_y, "IC_mins_left", "IC_mins_left", 0);
  for (c7_i20 = 0; c7_i20 < 5; c7_i20++) {
    c7_k_u[c7_i20] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11340])[c7_i20];
  }

  c7_kb_y = NULL;
  sf_mex_assign(&c7_kb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_kb_y, "IC_LPF_mins_right", "IC_LPF_mins_right", 0);
  for (c7_i21 = 0; c7_i21 < 5; c7_i21++) {
    c7_k_u[c7_i21] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11360])[c7_i21];
  }

  c7_lb_y = NULL;
  sf_mex_assign(&c7_lb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_lb_y, "IC_LPF_mins_left", "IC_LPF_mins_left", 0);
  c7_p_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11380];
  c7_mb_y = NULL;
  sf_mex_assign(&c7_mb_y, sf_mex_create("y", &c7_p_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_mb_y, "IC_LPF_index_right", "IC_LPF_index_right", 0);
  c7_q_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11381];
  c7_nb_y = NULL;
  sf_mex_assign(&c7_nb_y, sf_mex_create("y", &c7_q_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_nb_y, "IC_LPF_index_left", "IC_LPF_index_left", 0);
  c7_r_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11382];
  c7_ob_y = NULL;
  sf_mex_assign(&c7_ob_y, sf_mex_create("y", &c7_r_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_ob_y, "IC_index_right", "IC_index_right", 0);
  c7_s_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11383];
  c7_pb_y = NULL;
  sf_mex_assign(&c7_pb_y, sf_mex_create("y", &c7_s_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_pb_y, "IC_index_left", "IC_index_left", 0);
  for (c7_i22 = 0; c7_i22 < 5; c7_i22++) {
    c7_k_u[c7_i22] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11384])[c7_i22];
  }

  c7_qb_y = NULL;
  sf_mex_assign(&c7_qb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_qb_y, "EC_events_mins_right",
                  "EC_events_mins_right", 0);
  for (c7_i23 = 0; c7_i23 < 5; c7_i23++) {
    c7_k_u[c7_i23] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11404])[c7_i23];
  }

  c7_rb_y = NULL;
  sf_mex_assign(&c7_rb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_rb_y, "EC_events_mins_left", "EC_events_mins_left",
                  0);
  for (c7_i24 = 0; c7_i24 < 5; c7_i24++) {
    c7_k_u[c7_i24] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11424])[c7_i24];
  }

  c7_sb_y = NULL;
  sf_mex_assign(&c7_sb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_sb_y, "EC_peaks_mins_right", "EC_peaks_mins_right",
                  0);
  for (c7_i25 = 0; c7_i25 < 5; c7_i25++) {
    c7_k_u[c7_i25] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11444])[c7_i25];
  }

  c7_tb_y = NULL;
  sf_mex_assign(&c7_tb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_tb_y, "EC_peaks_mins_left", "EC_peaks_mins_left", 0);
  c7_t_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11464];
  c7_ub_y = NULL;
  sf_mex_assign(&c7_ub_y, sf_mex_create("y", &c7_t_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_ub_y, "EC_events_index_right",
                  "EC_events_index_right", 0);
  c7_u_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11465];
  c7_vb_y = NULL;
  sf_mex_assign(&c7_vb_y, sf_mex_create("y", &c7_u_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_vb_y, "EC_events_index_left",
                  "EC_events_index_left", 0);
  c7_v_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11466];
  c7_wb_y = NULL;
  sf_mex_assign(&c7_wb_y, sf_mex_create("y", &c7_v_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_wb_y, "EC_peaks_index_right",
                  "EC_peaks_index_right", 0);
  c7_w_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11467];
  c7_xb_y = NULL;
  sf_mex_assign(&c7_xb_y, sf_mex_create("y", &c7_w_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_xb_y, "EC_peaks_index_left", "EC_peaks_index_left",
                  0);
  for (c7_i26 = 0; c7_i26 < 5; c7_i26++) {
    c7_k_u[c7_i26] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11468])[c7_i26];
  }

  c7_yb_y = NULL;
  sf_mex_assign(&c7_yb_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_yb_y, "AN_events_right", "AN_events_right", 0);
  for (c7_i27 = 0; c7_i27 < 5; c7_i27++) {
    c7_k_u[c7_i27] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11488])[c7_i27];
  }

  c7_ac_y = NULL;
  sf_mex_assign(&c7_ac_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_ac_y, "AN_events_left", "AN_events_left", 0);
  for (c7_i28 = 0; c7_i28 < 5; c7_i28++) {
    c7_k_u[c7_i28] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11508])[c7_i28];
  }

  c7_bc_y = NULL;
  sf_mex_assign(&c7_bc_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_bc_y, "AN_peaks_right", "AN_peaks_right", 0);
  for (c7_i29 = 0; c7_i29 < 5; c7_i29++) {
    c7_k_u[c7_i29] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11528])[c7_i29];
  }

  c7_cc_y = NULL;
  sf_mex_assign(&c7_cc_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_b_y, c7_cc_y, "AN_peaks_left", "AN_peaks_left", 0);
  c7_x_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11548];
  c7_dc_y = NULL;
  sf_mex_assign(&c7_dc_y, sf_mex_create("y", &c7_x_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_dc_y, "stop_DS_index", "stop_DS_index", 0);
  for (c7_i30 = 0; c7_i30 < 10; c7_i30++) {
    c7_y_u[c7_i30] = ((uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)
                      [11550])[c7_i30];
  }

  c7_ec_y = NULL;
  sf_mex_assign(&c7_ec_y, sf_mex_create("y", c7_y_u, 5, 0U, 1U, 0U, 2, 1, 10),
                false);
  sf_mex_addfield(c7_b_y, c7_ec_y, "stop_DS", "stop_DS", 0);
  c7_ab_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11570];
  c7_fc_y = NULL;
  sf_mex_assign(&c7_fc_y, sf_mex_create("y", &c7_ab_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_fc_y, "MS_event_left", "MS_event_left", 0);
  c7_bb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11571];
  c7_gc_y = NULL;
  sf_mex_assign(&c7_gc_y, sf_mex_create("y", &c7_bb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_gc_y, "MS_event_right", "MS_event_right", 0);
  c7_cb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11572];
  c7_hc_y = NULL;
  sf_mex_assign(&c7_hc_y, sf_mex_create("y", &c7_cb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_hc_y, "EC_event_left", "EC_event_left", 0);
  c7_db_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11573];
  c7_ic_y = NULL;
  sf_mex_assign(&c7_ic_y, sf_mex_create("y", &c7_db_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_ic_y, "EC_event_right", "EC_event_right", 0);
  c7_eb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11574];
  c7_jc_y = NULL;
  sf_mex_assign(&c7_jc_y, sf_mex_create("y", &c7_eb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_jc_y, "IC_event_left", "IC_event_left", 0);
  c7_fb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11575];
  c7_kc_y = NULL;
  sf_mex_assign(&c7_kc_y, sf_mex_create("y", &c7_fb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_kc_y, "IC_event_right", "IC_event_right", 0);
  c7_gb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11576];
  c7_lc_y = NULL;
  sf_mex_assign(&c7_lc_y, sf_mex_create("y", &c7_gb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_lc_y, "AN_event_left", "AN_event_left", 0);
  c7_hb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11577];
  c7_mc_y = NULL;
  sf_mex_assign(&c7_mc_y, sf_mex_create("y", &c7_hb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_mc_y, "AN_event_right", "AN_event_right", 0);
  c7_ib_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11578];
  c7_nc_y = NULL;
  sf_mex_assign(&c7_nc_y, sf_mex_create("y", &c7_ib_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_nc_y, "MA_event_left", "MA_event_left", 0);
  c7_jb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11579];
  c7_oc_y = NULL;
  sf_mex_assign(&c7_oc_y, sf_mex_create("y", &c7_jb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_oc_y, "MA_event_right", "MA_event_right", 0);
  c7_kb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11580];
  c7_pc_y = NULL;
  sf_mex_assign(&c7_pc_y, sf_mex_create("y", &c7_kb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_pc_y, "stop_Vel_event_left", "stop_Vel_event_left",
                  0);
  c7_lb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11581];
  c7_qc_y = NULL;
  sf_mex_assign(&c7_qc_y, sf_mex_create("y", &c7_lb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_qc_y, "stop_Vel_event_right",
                  "stop_Vel_event_right", 0);
  c7_mb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11582];
  c7_rc_y = NULL;
  sf_mex_assign(&c7_rc_y, sf_mex_create("y", &c7_mb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_rc_y, "stop_MA_event_left", "stop_MA_event_left", 0);
  c7_nb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11583];
  c7_sc_y = NULL;
  sf_mex_assign(&c7_sc_y, sf_mex_create("y", &c7_nb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_sc_y, "stop_MA_event_right", "stop_MA_event_right",
                  0);
  c7_ob_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11584];
  c7_tc_y = NULL;
  sf_mex_assign(&c7_tc_y, sf_mex_create("y", &c7_ob_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_tc_y, "stop_IC_event_left", "stop_IC_event_left", 0);
  c7_pb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11585];
  c7_uc_y = NULL;
  sf_mex_assign(&c7_uc_y, sf_mex_create("y", &c7_pb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_uc_y, "stop_IC_event_right", "stop_IC_event_right",
                  0);
  c7_qb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11586];
  c7_vc_y = NULL;
  sf_mex_assign(&c7_vc_y, sf_mex_create("y", &c7_qb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_vc_y, "MA_flag_right", "MA_flag_right", 0);
  c7_rb_u = *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11587];
  c7_wc_y = NULL;
  sf_mex_assign(&c7_wc_y, sf_mex_create("y", &c7_rb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_wc_y, "MA_flag_left", "MA_flag_left", 0);
  c7_sb_u = *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11588];
  c7_xc_y = NULL;
  sf_mex_assign(&c7_xc_y, sf_mex_create("y", &c7_sb_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_xc_y, "last_EC", "last_EC", 0);
  c7_tb_u = *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11590];
  c7_yc_y = NULL;
  sf_mex_assign(&c7_yc_y, sf_mex_create("y", &c7_tb_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_yc_y, "last_IC", "last_IC", 0);
  for (c7_i31 = 0; c7_i31 < 200; c7_i31++) {
    c7_u[c7_i31] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [11592])[c7_i31];
  }

  c7_ad_y = NULL;
  sf_mex_assign(&c7_ad_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_ad_y, "IC_buffer_left", "IC_buffer_left", 0);
  for (c7_i32 = 0; c7_i32 < 200; c7_i32++) {
    c7_u[c7_i32] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [12392])[c7_i32];
  }

  c7_bd_y = NULL;
  sf_mex_assign(&c7_bd_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_bd_y, "IC_buffer_right", "IC_buffer_right", 0);
  for (c7_i33 = 0; c7_i33 < 200; c7_i33++) {
    c7_u[c7_i33] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [13192])[c7_i33];
  }

  c7_cd_y = NULL;
  sf_mex_assign(&c7_cd_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_cd_y, "EC_buffer_left", "EC_buffer_left", 0);
  for (c7_i34 = 0; c7_i34 < 200; c7_i34++) {
    c7_u[c7_i34] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [13992])[c7_i34];
  }

  c7_dd_y = NULL;
  sf_mex_assign(&c7_dd_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_dd_y, "EC_buffer_right", "EC_buffer_right", 0);
  for (c7_i35 = 0; c7_i35 < 200; c7_i35++) {
    c7_u[c7_i35] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [14792])[c7_i35];
  }

  c7_ed_y = NULL;
  sf_mex_assign(&c7_ed_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_ed_y, "MS_buffer_left", "MS_buffer_left", 0);
  for (c7_i36 = 0; c7_i36 < 200; c7_i36++) {
    c7_u[c7_i36] = ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)
                    [15592])[c7_i36];
  }

  c7_fd_y = NULL;
  sf_mex_assign(&c7_fd_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_b_y, c7_fd_y, "MS_buffer_right", "MS_buffer_right", 0);
  c7_ub_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16392];
  c7_gd_y = NULL;
  sf_mex_assign(&c7_gd_y, sf_mex_create("y", &c7_ub_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_gd_y, "IC_buffer_index_left",
                  "IC_buffer_index_left", 0);
  c7_vb_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16393];
  c7_hd_y = NULL;
  sf_mex_assign(&c7_hd_y, sf_mex_create("y", &c7_vb_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_hd_y, "IC_buffer_index_right",
                  "IC_buffer_index_right", 0);
  c7_wb_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16394];
  c7_id_y = NULL;
  sf_mex_assign(&c7_id_y, sf_mex_create("y", &c7_wb_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_id_y, "EC_buffer_index_left",
                  "EC_buffer_index_left", 0);
  c7_xb_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16395];
  c7_jd_y = NULL;
  sf_mex_assign(&c7_jd_y, sf_mex_create("y", &c7_xb_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_jd_y, "EC_buffer_index_right",
                  "EC_buffer_index_right", 0);
  c7_yb_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16396];
  c7_kd_y = NULL;
  sf_mex_assign(&c7_kd_y, sf_mex_create("y", &c7_yb_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_kd_y, "MS_buffer_index_left",
                  "MS_buffer_index_left", 0);
  c7_ac_u = *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16397];
  c7_ld_y = NULL;
  sf_mex_assign(&c7_ld_y, sf_mex_create("y", &c7_ac_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_ld_y, "MS_buffer_index_right",
                  "MS_buffer_index_right", 0);
  c7_bc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16400];
  c7_md_y = NULL;
  sf_mex_assign(&c7_md_y, sf_mex_create("y", &c7_bc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_md_y, "MA_th_left", "MA_th_left", 0);
  c7_cc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16404];
  c7_nd_y = NULL;
  sf_mex_assign(&c7_nd_y, sf_mex_create("y", &c7_cc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_nd_y, "MA_th_right", "MA_th_right", 0);
  c7_dc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16408];
  c7_od_y = NULL;
  sf_mex_assign(&c7_od_y, sf_mex_create("y", &c7_dc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_od_y, "IC_th_left", "IC_th_left", 0);
  c7_ec_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16412];
  c7_pd_y = NULL;
  sf_mex_assign(&c7_pd_y, sf_mex_create("y", &c7_ec_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_pd_y, "IC_th_right", "IC_th_right", 0);
  c7_fc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16416];
  c7_qd_y = NULL;
  sf_mex_assign(&c7_qd_y, sf_mex_create("y", &c7_fc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_qd_y, "AN_th_right", "AN_th_right", 0);
  c7_gc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16420];
  c7_rd_y = NULL;
  sf_mex_assign(&c7_rd_y, sf_mex_create("y", &c7_gc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_rd_y, "AN_th_left", "AN_th_left", 0);
  c7_hc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16424];
  c7_sd_y = NULL;
  sf_mex_assign(&c7_sd_y, sf_mex_create("y", &c7_hc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_sd_y, "EC_th_right", "EC_th_right", 0);
  c7_ic_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16428];
  c7_td_y = NULL;
  sf_mex_assign(&c7_td_y, sf_mex_create("y", &c7_ic_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_td_y, "EC_th_left", "EC_th_left", 0);
  c7_jc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16432];
  c7_ud_y = NULL;
  sf_mex_assign(&c7_ud_y, sf_mex_create("y", &c7_jc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_ud_y, "stop_Vel_th_left", "stop_Vel_th_left", 0);
  c7_kc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16436];
  c7_vd_y = NULL;
  sf_mex_assign(&c7_vd_y, sf_mex_create("y", &c7_kc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_vd_y, "stop_Vel_th_right", "stop_Vel_th_right", 0);
  c7_lc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16440];
  c7_wd_y = NULL;
  sf_mex_assign(&c7_wd_y, sf_mex_create("y", &c7_lc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_wd_y, "stop_MA_th_left", "stop_MA_th_left", 0);
  c7_mc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16444];
  c7_xd_y = NULL;
  sf_mex_assign(&c7_xd_y, sf_mex_create("y", &c7_mc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_xd_y, "stop_MA_th_right", "stop_MA_th_right", 0);
  c7_nc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16448];
  c7_yd_y = NULL;
  sf_mex_assign(&c7_yd_y, sf_mex_create("y", &c7_nc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_yd_y, "stop_IC_th_right", "stop_IC_th_right", 0);
  c7_oc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16452];
  c7_ae_y = NULL;
  sf_mex_assign(&c7_ae_y, sf_mex_create("y", &c7_oc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_ae_y, "stop_IC_th_left", "stop_IC_th_left", 0);
  c7_pc_u = *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[16456];
  c7_be_y = NULL;
  sf_mex_assign(&c7_be_y, sf_mex_create("y", &c7_pc_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_be_y, "stop_DS_th", "stop_DS_th", 0);
  c7_qc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16460];
  c7_ce_y = NULL;
  sf_mex_assign(&c7_ce_y, sf_mex_create("y", &c7_qc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_ce_y, "MA_LPF_th_left", "MA_LPF_th_left", 0);
  c7_rc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16464];
  c7_de_y = NULL;
  sf_mex_assign(&c7_de_y, sf_mex_create("y", &c7_rc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_de_y, "MA_LPF_th_right", "MA_LPF_th_right", 0);
  c7_sc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16468];
  c7_ee_y = NULL;
  sf_mex_assign(&c7_ee_y, sf_mex_create("y", &c7_sc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_ee_y, "IC_LPF_th_left", "IC_LPF_th_left", 0);
  c7_tc_u = *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16472];
  c7_fe_y = NULL;
  sf_mex_assign(&c7_fe_y, sf_mex_create("y", &c7_tc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_b_y, c7_fe_y, "IC_LPF_th_right", "IC_LPF_th_right", 0);
  sf_mex_setcell(c7_y, 0, c7_b_y);
  c7_hoistedGlobal = *chartInstance->c7_state;
  c7_uc_u = c7_hoistedGlobal;
  c7_ge_y = NULL;
  sf_mex_assign(&c7_ge_y, sf_mex_create("y", &c7_uc_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c7_y, 1, c7_ge_y);
  c7_he_y = NULL;
  sf_mex_assign(&c7_he_y, sf_mex_createstruct("structure", 2, 1, 1), false);
  for (c7_i37 = 0; c7_i37 < 200; c7_i37++) {
    c7_u[c7_i37] = chartInstance->c7_data_struct->VelRShank[c7_i37];
  }

  c7_ie_y = NULL;
  sf_mex_assign(&c7_ie_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_ie_y, "VelRShank", "VelRShank", 0);
  for (c7_i38 = 0; c7_i38 < 200; c7_i38++) {
    c7_u[c7_i38] = chartInstance->c7_data_struct->VelLShank[c7_i38];
  }

  c7_je_y = NULL;
  sf_mex_assign(&c7_je_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_je_y, "VelLShank", "VelLShank", 0);
  for (c7_i39 = 0; c7_i39 < 200; c7_i39++) {
    c7_u[c7_i39] = chartInstance->c7_data_struct->AngRShank[c7_i39];
  }

  c7_ke_y = NULL;
  sf_mex_assign(&c7_ke_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_ke_y, "AngRShank", "AngRShank", 0);
  for (c7_i40 = 0; c7_i40 < 200; c7_i40++) {
    c7_u[c7_i40] = chartInstance->c7_data_struct->AngLShank[c7_i40];
  }

  c7_le_y = NULL;
  sf_mex_assign(&c7_le_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_le_y, "AngLShank", "AngLShank", 0);
  for (c7_i41 = 0; c7_i41 < 200; c7_i41++) {
    c7_u[c7_i41] = chartInstance->c7_data_struct->VelRShank_filt[c7_i41];
  }

  c7_me_y = NULL;
  sf_mex_assign(&c7_me_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_me_y, "VelRShank_filt", "VelRShank_filt", 0);
  for (c7_i42 = 0; c7_i42 < 200; c7_i42++) {
    c7_u[c7_i42] = chartInstance->c7_data_struct->VelLShank_filt[c7_i42];
  }

  c7_ne_y = NULL;
  sf_mex_assign(&c7_ne_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_ne_y, "VelLShank_filt", "VelLShank_filt", 0);
  for (c7_i43 = 0; c7_i43 < 200; c7_i43++) {
    c7_u[c7_i43] = chartInstance->c7_data_struct->AngRShank_filt[c7_i43];
  }

  c7_oe_y = NULL;
  sf_mex_assign(&c7_oe_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_oe_y, "AngRShank_filt", "AngRShank_filt", 0);
  for (c7_i44 = 0; c7_i44 < 200; c7_i44++) {
    c7_u[c7_i44] = chartInstance->c7_data_struct->AngLShank_filt[c7_i44];
  }

  c7_pe_y = NULL;
  sf_mex_assign(&c7_pe_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_pe_y, "AngLShank_filt", "AngLShank_filt", 0);
  for (c7_i45 = 0; c7_i45 < 200; c7_i45++) {
    c7_u[c7_i45] = chartInstance->c7_data_struct->VelRShank_LPF[c7_i45];
  }

  c7_qe_y = NULL;
  sf_mex_assign(&c7_qe_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_qe_y, "VelRShank_LPF", "VelRShank_LPF", 0);
  for (c7_i46 = 0; c7_i46 < 200; c7_i46++) {
    c7_u[c7_i46] = chartInstance->c7_data_struct->VelLShank_LPF[c7_i46];
  }

  c7_re_y = NULL;
  sf_mex_assign(&c7_re_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_re_y, "VelLShank_LPF", "VelLShank_LPF", 0);
  for (c7_i47 = 0; c7_i47 < 200; c7_i47++) {
    c7_u[c7_i47] = chartInstance->c7_data_struct->AngRShank_LPF[c7_i47];
  }

  c7_se_y = NULL;
  sf_mex_assign(&c7_se_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_se_y, "AngRShank_LPF", "AngRShank_LPF", 0);
  for (c7_i48 = 0; c7_i48 < 200; c7_i48++) {
    c7_u[c7_i48] = chartInstance->c7_data_struct->AngLShank_LPF[c7_i48];
  }

  c7_te_y = NULL;
  sf_mex_assign(&c7_te_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_te_y, "AngLShank_LPF", "AngLShank_LPF", 0);
  for (c7_i49 = 0; c7_i49 < 200; c7_i49++) {
    c7_u[c7_i49] = chartInstance->c7_data_struct->AngRShank_LPF2Hz[c7_i49];
  }

  c7_ue_y = NULL;
  sf_mex_assign(&c7_ue_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_ue_y, "AngRShank_LPF2Hz", "AngRShank_LPF2Hz", 0);
  for (c7_i50 = 0; c7_i50 < 200; c7_i50++) {
    c7_u[c7_i50] = chartInstance->c7_data_struct->AngLShank_LPF2Hz[c7_i50];
  }

  c7_ve_y = NULL;
  sf_mex_assign(&c7_ve_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_ve_y, "AngLShank_LPF2Hz", "AngLShank_LPF2Hz", 0);
  c7_vc_u = chartInstance->c7_data_struct->counter_stop;
  c7_we_y = NULL;
  sf_mex_assign(&c7_we_y, sf_mex_create("y", &c7_vc_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_we_y, "counter_stop", "counter_stop", 0);
  c7_wc_u = chartInstance->c7_data_struct->counter;
  c7_xe_y = NULL;
  sf_mex_assign(&c7_xe_y, sf_mex_create("y", &c7_wc_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_xe_y, "counter", "counter", 0);
  c7_xc_u = chartInstance->c7_data_struct->index_start_calib;
  c7_ye_y = NULL;
  sf_mex_assign(&c7_ye_y, sf_mex_create("y", &c7_xc_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ye_y, "index_start_calib", "index_start_calib", 0);
  c7_yc_u = chartInstance->c7_data_struct->index_stop_calib;
  c7_af_y = NULL;
  sf_mex_assign(&c7_af_y, sf_mex_create("y", &c7_yc_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_af_y, "index_stop_calib", "index_stop_calib", 0);
  c7_ad_u = chartInstance->c7_data_struct->initial_leg;
  c7_bf_y = NULL;
  sf_mex_assign(&c7_bf_y, sf_mex_create("y", &c7_ad_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_bf_y, "initial_leg", "initial_leg", 0);
  c7_bd_u = chartInstance->c7_data_struct->flag_calib;
  c7_cf_y = NULL;
  sf_mex_assign(&c7_cf_y, sf_mex_create("y", &c7_bd_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_cf_y, "flag_calib", "flag_calib", 0);
  c7_cd_u = chartInstance->c7_data_struct->calibrating;
  c7_df_y = NULL;
  sf_mex_assign(&c7_df_y, sf_mex_create("y", &c7_cd_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_df_y, "calibrating", "calibrating", 0);
  c7_dd_u = chartInstance->c7_data_struct->state;
  c7_ef_y = NULL;
  sf_mex_assign(&c7_ef_y, sf_mex_create("y", &c7_dd_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ef_y, "state", "state", 0);
  c7_ed_u = chartInstance->c7_data_struct->prevstate;
  c7_ff_y = NULL;
  sf_mex_assign(&c7_ff_y, sf_mex_create("y", &c7_ed_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ff_y, "prevstate", "prevstate", 0);
  for (c7_i51 = 0; c7_i51 < 5; c7_i51++) {
    c7_k_u[c7_i51] = chartInstance->c7_data_struct->MA_maxs_right[c7_i51];
  }

  c7_gf_y = NULL;
  sf_mex_assign(&c7_gf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_gf_y, "MA_maxs_right", "MA_maxs_right", 0);
  for (c7_i52 = 0; c7_i52 < 5; c7_i52++) {
    c7_k_u[c7_i52] = chartInstance->c7_data_struct->MA_maxs_left[c7_i52];
  }

  c7_hf_y = NULL;
  sf_mex_assign(&c7_hf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_hf_y, "MA_maxs_left", "MA_maxs_left", 0);
  for (c7_i53 = 0; c7_i53 < 5; c7_i53++) {
    c7_k_u[c7_i53] = chartInstance->c7_data_struct->MA_LPF_maxs_right[c7_i53];
  }

  c7_if_y = NULL;
  sf_mex_assign(&c7_if_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_if_y, "MA_LPF_maxs_right", "MA_LPF_maxs_right", 0);
  for (c7_i54 = 0; c7_i54 < 5; c7_i54++) {
    c7_k_u[c7_i54] = chartInstance->c7_data_struct->MA_LPF_maxs_left[c7_i54];
  }

  c7_jf_y = NULL;
  sf_mex_assign(&c7_jf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_jf_y, "MA_LPF_maxs_left", "MA_LPF_maxs_left", 0);
  c7_fd_u = chartInstance->c7_data_struct->MA_LPF_index_right;
  c7_kf_y = NULL;
  sf_mex_assign(&c7_kf_y, sf_mex_create("y", &c7_fd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_kf_y, "MA_LPF_index_right", "MA_LPF_index_right",
                  0);
  c7_gd_u = chartInstance->c7_data_struct->MA_LPF_index_left;
  c7_lf_y = NULL;
  sf_mex_assign(&c7_lf_y, sf_mex_create("y", &c7_gd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_lf_y, "MA_LPF_index_left", "MA_LPF_index_left", 0);
  c7_hd_u = chartInstance->c7_data_struct->MA_index_right;
  c7_mf_y = NULL;
  sf_mex_assign(&c7_mf_y, sf_mex_create("y", &c7_hd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_mf_y, "MA_index_right", "MA_index_right", 0);
  c7_id_u = chartInstance->c7_data_struct->MA_index_left;
  c7_nf_y = NULL;
  sf_mex_assign(&c7_nf_y, sf_mex_create("y", &c7_id_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_nf_y, "MA_index_left", "MA_index_left", 0);
  for (c7_i55 = 0; c7_i55 < 5; c7_i55++) {
    c7_k_u[c7_i55] = chartInstance->c7_data_struct->IC_mins_right[c7_i55];
  }

  c7_of_y = NULL;
  sf_mex_assign(&c7_of_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_of_y, "IC_mins_right", "IC_mins_right", 0);
  for (c7_i56 = 0; c7_i56 < 5; c7_i56++) {
    c7_k_u[c7_i56] = chartInstance->c7_data_struct->IC_mins_left[c7_i56];
  }

  c7_pf_y = NULL;
  sf_mex_assign(&c7_pf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_pf_y, "IC_mins_left", "IC_mins_left", 0);
  for (c7_i57 = 0; c7_i57 < 5; c7_i57++) {
    c7_k_u[c7_i57] = chartInstance->c7_data_struct->IC_LPF_mins_right[c7_i57];
  }

  c7_qf_y = NULL;
  sf_mex_assign(&c7_qf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_qf_y, "IC_LPF_mins_right", "IC_LPF_mins_right", 0);
  for (c7_i58 = 0; c7_i58 < 5; c7_i58++) {
    c7_k_u[c7_i58] = chartInstance->c7_data_struct->IC_LPF_mins_left[c7_i58];
  }

  c7_rf_y = NULL;
  sf_mex_assign(&c7_rf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_rf_y, "IC_LPF_mins_left", "IC_LPF_mins_left", 0);
  c7_jd_u = chartInstance->c7_data_struct->IC_LPF_index_right;
  c7_sf_y = NULL;
  sf_mex_assign(&c7_sf_y, sf_mex_create("y", &c7_jd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_sf_y, "IC_LPF_index_right", "IC_LPF_index_right",
                  0);
  c7_kd_u = chartInstance->c7_data_struct->IC_LPF_index_left;
  c7_tf_y = NULL;
  sf_mex_assign(&c7_tf_y, sf_mex_create("y", &c7_kd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_tf_y, "IC_LPF_index_left", "IC_LPF_index_left", 0);
  c7_ld_u = chartInstance->c7_data_struct->IC_index_right;
  c7_uf_y = NULL;
  sf_mex_assign(&c7_uf_y, sf_mex_create("y", &c7_ld_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_uf_y, "IC_index_right", "IC_index_right", 0);
  c7_md_u = chartInstance->c7_data_struct->IC_index_left;
  c7_vf_y = NULL;
  sf_mex_assign(&c7_vf_y, sf_mex_create("y", &c7_md_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_vf_y, "IC_index_left", "IC_index_left", 0);
  for (c7_i59 = 0; c7_i59 < 5; c7_i59++) {
    c7_k_u[c7_i59] = chartInstance->c7_data_struct->EC_events_mins_right[c7_i59];
  }

  c7_wf_y = NULL;
  sf_mex_assign(&c7_wf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_wf_y, "EC_events_mins_right",
                  "EC_events_mins_right", 0);
  for (c7_i60 = 0; c7_i60 < 5; c7_i60++) {
    c7_k_u[c7_i60] = chartInstance->c7_data_struct->EC_events_mins_left[c7_i60];
  }

  c7_xf_y = NULL;
  sf_mex_assign(&c7_xf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_xf_y, "EC_events_mins_left", "EC_events_mins_left",
                  0);
  for (c7_i61 = 0; c7_i61 < 5; c7_i61++) {
    c7_k_u[c7_i61] = chartInstance->c7_data_struct->EC_peaks_mins_right[c7_i61];
  }

  c7_yf_y = NULL;
  sf_mex_assign(&c7_yf_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_yf_y, "EC_peaks_mins_right", "EC_peaks_mins_right",
                  0);
  for (c7_i62 = 0; c7_i62 < 5; c7_i62++) {
    c7_k_u[c7_i62] = chartInstance->c7_data_struct->EC_peaks_mins_left[c7_i62];
  }

  c7_ag_y = NULL;
  sf_mex_assign(&c7_ag_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_ag_y, "EC_peaks_mins_left", "EC_peaks_mins_left",
                  0);
  c7_nd_u = chartInstance->c7_data_struct->EC_events_index_right;
  c7_bg_y = NULL;
  sf_mex_assign(&c7_bg_y, sf_mex_create("y", &c7_nd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_bg_y, "EC_events_index_right",
                  "EC_events_index_right", 0);
  c7_od_u = chartInstance->c7_data_struct->EC_events_index_left;
  c7_cg_y = NULL;
  sf_mex_assign(&c7_cg_y, sf_mex_create("y", &c7_od_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_cg_y, "EC_events_index_left",
                  "EC_events_index_left", 0);
  c7_pd_u = chartInstance->c7_data_struct->EC_peaks_index_right;
  c7_dg_y = NULL;
  sf_mex_assign(&c7_dg_y, sf_mex_create("y", &c7_pd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_dg_y, "EC_peaks_index_right",
                  "EC_peaks_index_right", 0);
  c7_qd_u = chartInstance->c7_data_struct->EC_peaks_index_left;
  c7_eg_y = NULL;
  sf_mex_assign(&c7_eg_y, sf_mex_create("y", &c7_qd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_eg_y, "EC_peaks_index_left", "EC_peaks_index_left",
                  0);
  for (c7_i63 = 0; c7_i63 < 5; c7_i63++) {
    c7_k_u[c7_i63] = chartInstance->c7_data_struct->AN_events_right[c7_i63];
  }

  c7_fg_y = NULL;
  sf_mex_assign(&c7_fg_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_fg_y, "AN_events_right", "AN_events_right", 0);
  for (c7_i64 = 0; c7_i64 < 5; c7_i64++) {
    c7_k_u[c7_i64] = chartInstance->c7_data_struct->AN_events_left[c7_i64];
  }

  c7_gg_y = NULL;
  sf_mex_assign(&c7_gg_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_gg_y, "AN_events_left", "AN_events_left", 0);
  for (c7_i65 = 0; c7_i65 < 5; c7_i65++) {
    c7_k_u[c7_i65] = chartInstance->c7_data_struct->AN_peaks_right[c7_i65];
  }

  c7_hg_y = NULL;
  sf_mex_assign(&c7_hg_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_hg_y, "AN_peaks_right", "AN_peaks_right", 0);
  for (c7_i66 = 0; c7_i66 < 5; c7_i66++) {
    c7_k_u[c7_i66] = chartInstance->c7_data_struct->AN_peaks_left[c7_i66];
  }

  c7_ig_y = NULL;
  sf_mex_assign(&c7_ig_y, sf_mex_create("y", c7_k_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_he_y, c7_ig_y, "AN_peaks_left", "AN_peaks_left", 0);
  c7_rd_u = chartInstance->c7_data_struct->stop_DS_index;
  c7_jg_y = NULL;
  sf_mex_assign(&c7_jg_y, sf_mex_create("y", &c7_rd_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_jg_y, "stop_DS_index", "stop_DS_index", 0);
  for (c7_i67 = 0; c7_i67 < 10; c7_i67++) {
    c7_y_u[c7_i67] = chartInstance->c7_data_struct->stop_DS[c7_i67];
  }

  c7_kg_y = NULL;
  sf_mex_assign(&c7_kg_y, sf_mex_create("y", c7_y_u, 5, 0U, 1U, 0U, 2, 1, 10),
                false);
  sf_mex_addfield(c7_he_y, c7_kg_y, "stop_DS", "stop_DS", 0);
  c7_sd_u = chartInstance->c7_data_struct->MS_event_left;
  c7_lg_y = NULL;
  sf_mex_assign(&c7_lg_y, sf_mex_create("y", &c7_sd_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_lg_y, "MS_event_left", "MS_event_left", 0);
  c7_td_u = chartInstance->c7_data_struct->MS_event_right;
  c7_mg_y = NULL;
  sf_mex_assign(&c7_mg_y, sf_mex_create("y", &c7_td_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_mg_y, "MS_event_right", "MS_event_right", 0);
  c7_ud_u = chartInstance->c7_data_struct->EC_event_left;
  c7_ng_y = NULL;
  sf_mex_assign(&c7_ng_y, sf_mex_create("y", &c7_ud_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ng_y, "EC_event_left", "EC_event_left", 0);
  c7_vd_u = chartInstance->c7_data_struct->EC_event_right;
  c7_og_y = NULL;
  sf_mex_assign(&c7_og_y, sf_mex_create("y", &c7_vd_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_og_y, "EC_event_right", "EC_event_right", 0);
  c7_wd_u = chartInstance->c7_data_struct->IC_event_left;
  c7_pg_y = NULL;
  sf_mex_assign(&c7_pg_y, sf_mex_create("y", &c7_wd_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_pg_y, "IC_event_left", "IC_event_left", 0);
  c7_xd_u = chartInstance->c7_data_struct->IC_event_right;
  c7_qg_y = NULL;
  sf_mex_assign(&c7_qg_y, sf_mex_create("y", &c7_xd_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_qg_y, "IC_event_right", "IC_event_right", 0);
  c7_yd_u = chartInstance->c7_data_struct->AN_event_left;
  c7_rg_y = NULL;
  sf_mex_assign(&c7_rg_y, sf_mex_create("y", &c7_yd_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_rg_y, "AN_event_left", "AN_event_left", 0);
  c7_ae_u = chartInstance->c7_data_struct->AN_event_right;
  c7_sg_y = NULL;
  sf_mex_assign(&c7_sg_y, sf_mex_create("y", &c7_ae_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_sg_y, "AN_event_right", "AN_event_right", 0);
  c7_be_u = chartInstance->c7_data_struct->MA_event_left;
  c7_tg_y = NULL;
  sf_mex_assign(&c7_tg_y, sf_mex_create("y", &c7_be_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_tg_y, "MA_event_left", "MA_event_left", 0);
  c7_ce_u = chartInstance->c7_data_struct->MA_event_right;
  c7_ug_y = NULL;
  sf_mex_assign(&c7_ug_y, sf_mex_create("y", &c7_ce_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ug_y, "MA_event_right", "MA_event_right", 0);
  c7_de_u = chartInstance->c7_data_struct->stop_Vel_event_left;
  c7_vg_y = NULL;
  sf_mex_assign(&c7_vg_y, sf_mex_create("y", &c7_de_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_vg_y, "stop_Vel_event_left", "stop_Vel_event_left",
                  0);
  c7_ee_u = chartInstance->c7_data_struct->stop_Vel_event_right;
  c7_wg_y = NULL;
  sf_mex_assign(&c7_wg_y, sf_mex_create("y", &c7_ee_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_wg_y, "stop_Vel_event_right",
                  "stop_Vel_event_right", 0);
  c7_fe_u = chartInstance->c7_data_struct->stop_MA_event_left;
  c7_xg_y = NULL;
  sf_mex_assign(&c7_xg_y, sf_mex_create("y", &c7_fe_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_xg_y, "stop_MA_event_left", "stop_MA_event_left",
                  0);
  c7_ge_u = chartInstance->c7_data_struct->stop_MA_event_right;
  c7_yg_y = NULL;
  sf_mex_assign(&c7_yg_y, sf_mex_create("y", &c7_ge_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_yg_y, "stop_MA_event_right", "stop_MA_event_right",
                  0);
  c7_he_u = chartInstance->c7_data_struct->stop_IC_event_left;
  c7_ah_y = NULL;
  sf_mex_assign(&c7_ah_y, sf_mex_create("y", &c7_he_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ah_y, "stop_IC_event_left", "stop_IC_event_left",
                  0);
  c7_ie_u = chartInstance->c7_data_struct->stop_IC_event_right;
  c7_bh_y = NULL;
  sf_mex_assign(&c7_bh_y, sf_mex_create("y", &c7_ie_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_bh_y, "stop_IC_event_right", "stop_IC_event_right",
                  0);
  c7_je_u = chartInstance->c7_data_struct->MA_flag_right;
  c7_ch_y = NULL;
  sf_mex_assign(&c7_ch_y, sf_mex_create("y", &c7_je_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ch_y, "MA_flag_right", "MA_flag_right", 0);
  c7_ke_u = chartInstance->c7_data_struct->MA_flag_left;
  c7_dh_y = NULL;
  sf_mex_assign(&c7_dh_y, sf_mex_create("y", &c7_ke_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_dh_y, "MA_flag_left", "MA_flag_left", 0);
  c7_le_u = chartInstance->c7_data_struct->last_EC;
  c7_eh_y = NULL;
  sf_mex_assign(&c7_eh_y, sf_mex_create("y", &c7_le_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_eh_y, "last_EC", "last_EC", 0);
  c7_me_u = chartInstance->c7_data_struct->last_IC;
  c7_fh_y = NULL;
  sf_mex_assign(&c7_fh_y, sf_mex_create("y", &c7_me_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_fh_y, "last_IC", "last_IC", 0);
  for (c7_i68 = 0; c7_i68 < 200; c7_i68++) {
    c7_u[c7_i68] = chartInstance->c7_data_struct->IC_buffer_left[c7_i68];
  }

  c7_gh_y = NULL;
  sf_mex_assign(&c7_gh_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_gh_y, "IC_buffer_left", "IC_buffer_left", 0);
  for (c7_i69 = 0; c7_i69 < 200; c7_i69++) {
    c7_u[c7_i69] = chartInstance->c7_data_struct->IC_buffer_right[c7_i69];
  }

  c7_hh_y = NULL;
  sf_mex_assign(&c7_hh_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_hh_y, "IC_buffer_right", "IC_buffer_right", 0);
  for (c7_i70 = 0; c7_i70 < 200; c7_i70++) {
    c7_u[c7_i70] = chartInstance->c7_data_struct->EC_buffer_left[c7_i70];
  }

  c7_ih_y = NULL;
  sf_mex_assign(&c7_ih_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_ih_y, "EC_buffer_left", "EC_buffer_left", 0);
  for (c7_i71 = 0; c7_i71 < 200; c7_i71++) {
    c7_u[c7_i71] = chartInstance->c7_data_struct->EC_buffer_right[c7_i71];
  }

  c7_jh_y = NULL;
  sf_mex_assign(&c7_jh_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_jh_y, "EC_buffer_right", "EC_buffer_right", 0);
  for (c7_i72 = 0; c7_i72 < 200; c7_i72++) {
    c7_u[c7_i72] = chartInstance->c7_data_struct->MS_buffer_left[c7_i72];
  }

  c7_kh_y = NULL;
  sf_mex_assign(&c7_kh_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_kh_y, "MS_buffer_left", "MS_buffer_left", 0);
  for (c7_i73 = 0; c7_i73 < 200; c7_i73++) {
    c7_u[c7_i73] = chartInstance->c7_data_struct->MS_buffer_right[c7_i73];
  }

  c7_lh_y = NULL;
  sf_mex_assign(&c7_lh_y, sf_mex_create("y", c7_u, 1, 0U, 1U, 0U, 1, 200), false);
  sf_mex_addfield(c7_he_y, c7_lh_y, "MS_buffer_right", "MS_buffer_right", 0);
  c7_ne_u = chartInstance->c7_data_struct->IC_buffer_index_left;
  c7_mh_y = NULL;
  sf_mex_assign(&c7_mh_y, sf_mex_create("y", &c7_ne_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_mh_y, "IC_buffer_index_left",
                  "IC_buffer_index_left", 0);
  c7_oe_u = chartInstance->c7_data_struct->IC_buffer_index_right;
  c7_nh_y = NULL;
  sf_mex_assign(&c7_nh_y, sf_mex_create("y", &c7_oe_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_nh_y, "IC_buffer_index_right",
                  "IC_buffer_index_right", 0);
  c7_pe_u = chartInstance->c7_data_struct->EC_buffer_index_left;
  c7_oh_y = NULL;
  sf_mex_assign(&c7_oh_y, sf_mex_create("y", &c7_pe_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_oh_y, "EC_buffer_index_left",
                  "EC_buffer_index_left", 0);
  c7_qe_u = chartInstance->c7_data_struct->EC_buffer_index_right;
  c7_ph_y = NULL;
  sf_mex_assign(&c7_ph_y, sf_mex_create("y", &c7_qe_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ph_y, "EC_buffer_index_right",
                  "EC_buffer_index_right", 0);
  c7_re_u = chartInstance->c7_data_struct->MS_buffer_index_left;
  c7_qh_y = NULL;
  sf_mex_assign(&c7_qh_y, sf_mex_create("y", &c7_re_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_qh_y, "MS_buffer_index_left",
                  "MS_buffer_index_left", 0);
  c7_se_u = chartInstance->c7_data_struct->MS_buffer_index_right;
  c7_rh_y = NULL;
  sf_mex_assign(&c7_rh_y, sf_mex_create("y", &c7_se_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_rh_y, "MS_buffer_index_right",
                  "MS_buffer_index_right", 0);
  c7_te_u = chartInstance->c7_data_struct->MA_th_left;
  c7_sh_y = NULL;
  sf_mex_assign(&c7_sh_y, sf_mex_create("y", &c7_te_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_sh_y, "MA_th_left", "MA_th_left", 0);
  c7_ue_u = chartInstance->c7_data_struct->MA_th_right;
  c7_th_y = NULL;
  sf_mex_assign(&c7_th_y, sf_mex_create("y", &c7_ue_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_th_y, "MA_th_right", "MA_th_right", 0);
  c7_ve_u = chartInstance->c7_data_struct->IC_th_left;
  c7_uh_y = NULL;
  sf_mex_assign(&c7_uh_y, sf_mex_create("y", &c7_ve_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_uh_y, "IC_th_left", "IC_th_left", 0);
  c7_we_u = chartInstance->c7_data_struct->IC_th_right;
  c7_vh_y = NULL;
  sf_mex_assign(&c7_vh_y, sf_mex_create("y", &c7_we_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_vh_y, "IC_th_right", "IC_th_right", 0);
  c7_xe_u = chartInstance->c7_data_struct->AN_th_right;
  c7_wh_y = NULL;
  sf_mex_assign(&c7_wh_y, sf_mex_create("y", &c7_xe_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_wh_y, "AN_th_right", "AN_th_right", 0);
  c7_ye_u = chartInstance->c7_data_struct->AN_th_left;
  c7_xh_y = NULL;
  sf_mex_assign(&c7_xh_y, sf_mex_create("y", &c7_ye_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_xh_y, "AN_th_left", "AN_th_left", 0);
  c7_af_u = chartInstance->c7_data_struct->EC_th_right;
  c7_yh_y = NULL;
  sf_mex_assign(&c7_yh_y, sf_mex_create("y", &c7_af_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_yh_y, "EC_th_right", "EC_th_right", 0);
  c7_bf_u = chartInstance->c7_data_struct->EC_th_left;
  c7_ai_y = NULL;
  sf_mex_assign(&c7_ai_y, sf_mex_create("y", &c7_bf_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ai_y, "EC_th_left", "EC_th_left", 0);
  c7_cf_u = chartInstance->c7_data_struct->stop_Vel_th_left;
  c7_bi_y = NULL;
  sf_mex_assign(&c7_bi_y, sf_mex_create("y", &c7_cf_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_bi_y, "stop_Vel_th_left", "stop_Vel_th_left", 0);
  c7_df_u = chartInstance->c7_data_struct->stop_Vel_th_right;
  c7_ci_y = NULL;
  sf_mex_assign(&c7_ci_y, sf_mex_create("y", &c7_df_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ci_y, "stop_Vel_th_right", "stop_Vel_th_right", 0);
  c7_ef_u = chartInstance->c7_data_struct->stop_MA_th_left;
  c7_di_y = NULL;
  sf_mex_assign(&c7_di_y, sf_mex_create("y", &c7_ef_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_di_y, "stop_MA_th_left", "stop_MA_th_left", 0);
  c7_ff_u = chartInstance->c7_data_struct->stop_MA_th_right;
  c7_ei_y = NULL;
  sf_mex_assign(&c7_ei_y, sf_mex_create("y", &c7_ff_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ei_y, "stop_MA_th_right", "stop_MA_th_right", 0);
  c7_gf_u = chartInstance->c7_data_struct->stop_IC_th_right;
  c7_fi_y = NULL;
  sf_mex_assign(&c7_fi_y, sf_mex_create("y", &c7_gf_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_fi_y, "stop_IC_th_right", "stop_IC_th_right", 0);
  c7_hf_u = chartInstance->c7_data_struct->stop_IC_th_left;
  c7_gi_y = NULL;
  sf_mex_assign(&c7_gi_y, sf_mex_create("y", &c7_hf_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_gi_y, "stop_IC_th_left", "stop_IC_th_left", 0);
  c7_if_u = chartInstance->c7_data_struct->stop_DS_th;
  c7_hi_y = NULL;
  sf_mex_assign(&c7_hi_y, sf_mex_create("y", &c7_if_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_hi_y, "stop_DS_th", "stop_DS_th", 0);
  c7_jf_u = chartInstance->c7_data_struct->MA_LPF_th_left;
  c7_ii_y = NULL;
  sf_mex_assign(&c7_ii_y, sf_mex_create("y", &c7_jf_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ii_y, "MA_LPF_th_left", "MA_LPF_th_left", 0);
  c7_kf_u = chartInstance->c7_data_struct->MA_LPF_th_right;
  c7_ji_y = NULL;
  sf_mex_assign(&c7_ji_y, sf_mex_create("y", &c7_kf_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ji_y, "MA_LPF_th_right", "MA_LPF_th_right", 0);
  c7_lf_u = chartInstance->c7_data_struct->IC_LPF_th_left;
  c7_ki_y = NULL;
  sf_mex_assign(&c7_ki_y, sf_mex_create("y", &c7_lf_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_ki_y, "IC_LPF_th_left", "IC_LPF_th_left", 0);
  c7_mf_u = chartInstance->c7_data_struct->IC_LPF_th_right;
  c7_li_y = NULL;
  sf_mex_assign(&c7_li_y, sf_mex_create("y", &c7_mf_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_he_y, c7_li_y, "IC_LPF_th_right", "IC_LPF_th_right", 0);
  sf_mex_setcell(c7_y, 2, c7_he_y);
  c7_b_hoistedGlobal = *chartInstance->c7_is_active_c7_XsensLibrary2;
  c7_nf_u = c7_b_hoistedGlobal;
  c7_mi_y = NULL;
  sf_mex_assign(&c7_mi_y, sf_mex_create("y", &c7_nf_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c7_y, 3, c7_mi_y);
  c7_c_hoistedGlobal = *chartInstance->c7_is_c7_XsensLibrary2;
  c7_of_u = c7_c_hoistedGlobal;
  c7_ni_y = NULL;
  sf_mex_assign(&c7_ni_y, sf_mex_create("y", &c7_of_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c7_y, 4, c7_ni_y);
  c7_oi_y = NULL;
  sf_mex_assign(&c7_oi_y, sf_mex_create("y",
    chartInstance->c7_dataWrittenToVector, 11, 0U, 1U, 0U, 1, 6), false);
  sf_mex_setcell(c7_y, 5, c7_oi_y);
  sf_mex_assign(&c7_st, c7_y, false);
  return c7_st;
}

static void set_sim_state_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_st)
{
  const mxArray *c7_u;
  c7_bus_datastruct c7_r0;
  int32_T c7_i74;
  int32_T c7_i75;
  int32_T c7_i76;
  int32_T c7_i77;
  int32_T c7_i78;
  int32_T c7_i79;
  int32_T c7_i80;
  int32_T c7_i81;
  int32_T c7_i82;
  int32_T c7_i83;
  int32_T c7_i84;
  int32_T c7_i85;
  int32_T c7_i86;
  int32_T c7_i87;
  int32_T c7_i88;
  int32_T c7_i89;
  int32_T c7_i90;
  int32_T c7_i91;
  int32_T c7_i92;
  int32_T c7_i93;
  int32_T c7_i94;
  int32_T c7_i95;
  int32_T c7_i96;
  int32_T c7_i97;
  int32_T c7_i98;
  int32_T c7_i99;
  int32_T c7_i100;
  int32_T c7_i101;
  int32_T c7_i102;
  int32_T c7_i103;
  int32_T c7_i104;
  int32_T c7_i105;
  int32_T c7_i106;
  int32_T c7_i107;
  int32_T c7_i108;
  int32_T c7_i109;
  int32_T c7_i110;
  c7_bus_datastruct c7_r1;
  boolean_T c7_bv0[6];
  int32_T c7_i111;
  c7_u = sf_mex_dup(c7_st);
  c7_b_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(
    "data_struct_out", c7_u, 0)), "data_struct_out", &c7_r0);
  for (c7_i74 = 0; c7_i74 < 200; c7_i74++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[0])[c7_i74] =
      c7_r0.VelRShank[c7_i74];
  }

  for (c7_i75 = 0; c7_i75 < 200; c7_i75++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[800])[c7_i75] =
      c7_r0.VelLShank[c7_i75];
  }

  for (c7_i76 = 0; c7_i76 < 200; c7_i76++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[1600])[c7_i76] =
      c7_r0.AngRShank[c7_i76];
  }

  for (c7_i77 = 0; c7_i77 < 200; c7_i77++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[2400])[c7_i77] =
      c7_r0.AngLShank[c7_i77];
  }

  for (c7_i78 = 0; c7_i78 < 200; c7_i78++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[3200])[c7_i78] =
      c7_r0.VelRShank_filt[c7_i78];
  }

  for (c7_i79 = 0; c7_i79 < 200; c7_i79++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[4000])[c7_i79] =
      c7_r0.VelLShank_filt[c7_i79];
  }

  for (c7_i80 = 0; c7_i80 < 200; c7_i80++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[4800])[c7_i80] =
      c7_r0.AngRShank_filt[c7_i80];
  }

  for (c7_i81 = 0; c7_i81 < 200; c7_i81++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[5600])[c7_i81] =
      c7_r0.AngLShank_filt[c7_i81];
  }

  for (c7_i82 = 0; c7_i82 < 200; c7_i82++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[6400])[c7_i82] =
      c7_r0.VelRShank_LPF[c7_i82];
  }

  for (c7_i83 = 0; c7_i83 < 200; c7_i83++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[7200])[c7_i83] =
      c7_r0.VelLShank_LPF[c7_i83];
  }

  for (c7_i84 = 0; c7_i84 < 200; c7_i84++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[8000])[c7_i84] =
      c7_r0.AngRShank_LPF[c7_i84];
  }

  for (c7_i85 = 0; c7_i85 < 200; c7_i85++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[8800])[c7_i85] =
      c7_r0.AngLShank_LPF[c7_i85];
  }

  for (c7_i86 = 0; c7_i86 < 200; c7_i86++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[9600])[c7_i86] =
      c7_r0.AngRShank_LPF2Hz[c7_i86];
  }

  for (c7_i87 = 0; c7_i87 < 200; c7_i87++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[10400])[c7_i87] =
      c7_r0.AngLShank_LPF2Hz[c7_i87];
  }

  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11200] =
    c7_r0.counter_stop;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11202] =
    c7_r0.counter;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11204] =
    c7_r0.index_start_calib;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11206] =
    c7_r0.index_stop_calib;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11208] =
    c7_r0.initial_leg;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11209] =
    c7_r0.flag_calib;
  *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11210] =
    c7_r0.calibrating;
  *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11211] = c7_r0.state;
  *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11212] =
    c7_r0.prevstate;
  for (c7_i88 = 0; c7_i88 < 5; c7_i88++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11216])[c7_i88] =
      c7_r0.MA_maxs_right[c7_i88];
  }

  for (c7_i89 = 0; c7_i89 < 5; c7_i89++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11236])[c7_i89] =
      c7_r0.MA_maxs_left[c7_i89];
  }

  for (c7_i90 = 0; c7_i90 < 5; c7_i90++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11256])[c7_i90] =
      c7_r0.MA_LPF_maxs_right[c7_i90];
  }

  for (c7_i91 = 0; c7_i91 < 5; c7_i91++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11276])[c7_i91] =
      c7_r0.MA_LPF_maxs_left[c7_i91];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11296] =
    c7_r0.MA_LPF_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11297] =
    c7_r0.MA_LPF_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11298] =
    c7_r0.MA_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11299] =
    c7_r0.MA_index_left;
  for (c7_i92 = 0; c7_i92 < 5; c7_i92++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11300])[c7_i92] =
      c7_r0.IC_mins_right[c7_i92];
  }

  for (c7_i93 = 0; c7_i93 < 5; c7_i93++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11320])[c7_i93] =
      c7_r0.IC_mins_left[c7_i93];
  }

  for (c7_i94 = 0; c7_i94 < 5; c7_i94++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11340])[c7_i94] =
      c7_r0.IC_LPF_mins_right[c7_i94];
  }

  for (c7_i95 = 0; c7_i95 < 5; c7_i95++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11360])[c7_i95] =
      c7_r0.IC_LPF_mins_left[c7_i95];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11380] =
    c7_r0.IC_LPF_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11381] =
    c7_r0.IC_LPF_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11382] =
    c7_r0.IC_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11383] =
    c7_r0.IC_index_left;
  for (c7_i96 = 0; c7_i96 < 5; c7_i96++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11384])[c7_i96] =
      c7_r0.EC_events_mins_right[c7_i96];
  }

  for (c7_i97 = 0; c7_i97 < 5; c7_i97++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11404])[c7_i97] =
      c7_r0.EC_events_mins_left[c7_i97];
  }

  for (c7_i98 = 0; c7_i98 < 5; c7_i98++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11424])[c7_i98] =
      c7_r0.EC_peaks_mins_right[c7_i98];
  }

  for (c7_i99 = 0; c7_i99 < 5; c7_i99++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11444])[c7_i99] =
      c7_r0.EC_peaks_mins_left[c7_i99];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11464] =
    c7_r0.EC_events_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11465] =
    c7_r0.EC_events_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11466] =
    c7_r0.EC_peaks_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11467] =
    c7_r0.EC_peaks_index_left;
  for (c7_i100 = 0; c7_i100 < 5; c7_i100++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11468])[c7_i100]
      = c7_r0.AN_events_right[c7_i100];
  }

  for (c7_i101 = 0; c7_i101 < 5; c7_i101++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11488])[c7_i101]
      = c7_r0.AN_events_left[c7_i101];
  }

  for (c7_i102 = 0; c7_i102 < 5; c7_i102++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11508])[c7_i102]
      = c7_r0.AN_peaks_right[c7_i102];
  }

  for (c7_i103 = 0; c7_i103 < 5; c7_i103++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11528])[c7_i103]
      = c7_r0.AN_peaks_left[c7_i103];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11548] =
    c7_r0.stop_DS_index;
  for (c7_i104 = 0; c7_i104 < 10; c7_i104++) {
    ((uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11550])[c7_i104]
      = c7_r0.stop_DS[c7_i104];
  }

  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11570] =
    c7_r0.MS_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11571] =
    c7_r0.MS_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11572] =
    c7_r0.EC_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11573] =
    c7_r0.EC_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11574] =
    c7_r0.IC_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11575] =
    c7_r0.IC_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11576] =
    c7_r0.AN_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11577] =
    c7_r0.AN_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11578] =
    c7_r0.MA_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11579] =
    c7_r0.MA_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11580] =
    c7_r0.stop_Vel_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11581] =
    c7_r0.stop_Vel_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11582] =
    c7_r0.stop_MA_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11583] =
    c7_r0.stop_MA_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11584] =
    c7_r0.stop_IC_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11585] =
    c7_r0.stop_IC_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11586] =
    c7_r0.MA_flag_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11587] =
    c7_r0.MA_flag_left;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11588] =
    c7_r0.last_EC;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11590] =
    c7_r0.last_IC;
  for (c7_i105 = 0; c7_i105 < 200; c7_i105++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11592])[c7_i105]
      = c7_r0.IC_buffer_left[c7_i105];
  }

  for (c7_i106 = 0; c7_i106 < 200; c7_i106++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[12392])[c7_i106]
      = c7_r0.IC_buffer_right[c7_i106];
  }

  for (c7_i107 = 0; c7_i107 < 200; c7_i107++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[13192])[c7_i107]
      = c7_r0.EC_buffer_left[c7_i107];
  }

  for (c7_i108 = 0; c7_i108 < 200; c7_i108++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[13992])[c7_i108]
      = c7_r0.EC_buffer_right[c7_i108];
  }

  for (c7_i109 = 0; c7_i109 < 200; c7_i109++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[14792])[c7_i109]
      = c7_r0.MS_buffer_left[c7_i109];
  }

  for (c7_i110 = 0; c7_i110 < 200; c7_i110++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[15592])[c7_i110]
      = c7_r0.MS_buffer_right[c7_i110];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16392] =
    c7_r0.IC_buffer_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16393] =
    c7_r0.IC_buffer_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16394] =
    c7_r0.EC_buffer_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16395] =
    c7_r0.EC_buffer_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16396] =
    c7_r0.MS_buffer_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16397] =
    c7_r0.MS_buffer_index_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16400] =
    c7_r0.MA_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16404] =
    c7_r0.MA_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16408] =
    c7_r0.IC_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16412] =
    c7_r0.IC_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16416] =
    c7_r0.AN_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16420] =
    c7_r0.AN_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16424] =
    c7_r0.EC_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16428] =
    c7_r0.EC_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16432] =
    c7_r0.stop_Vel_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16436] =
    c7_r0.stop_Vel_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16440] =
    c7_r0.stop_MA_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16444] =
    c7_r0.stop_MA_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16448] =
    c7_r0.stop_IC_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16452] =
    c7_r0.stop_IC_th_left;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[16456] =
    c7_r0.stop_DS_th;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16460] =
    c7_r0.MA_LPF_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16464] =
    c7_r0.MA_LPF_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16468] =
    c7_r0.IC_LPF_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16472] =
    c7_r0.IC_LPF_th_right;
  *chartInstance->c7_state = c7_l_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell("state", c7_u, 1)), "state");
  c7_b_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell("data_struct",
    c7_u, 2)), "data_struct", &c7_r1);
  *chartInstance->c7_data_struct = c7_r1;
  *chartInstance->c7_is_active_c7_XsensLibrary2 = c7_n_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell("is_active_c7_XsensLibrary2", c7_u,
       3)), "is_active_c7_XsensLibrary2");
  *chartInstance->c7_is_c7_XsensLibrary2 = c7_n_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell("is_c7_XsensLibrary2", c7_u, 4)),
    "is_c7_XsensLibrary2");
  c7_r_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(
    "dataWrittenToVector", c7_u, 5)), "dataWrittenToVector", c7_bv0);
  for (c7_i111 = 0; c7_i111 < 6; c7_i111++) {
    chartInstance->c7_dataWrittenToVector[c7_i111] = c7_bv0[c7_i111];
  }

  sf_mex_assign(&chartInstance->c7_setSimStateSideEffectsInfo,
                c7_t_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(
    "setSimStateSideEffectsInfo", c7_u, 6)), "setSimStateSideEffectsInfo"), true);
  sf_mex_destroy(&c7_u);
  chartInstance->c7_doSetSimStateSideEffects = 1U;
  c7_update_debugger_state_c7_XsensLibrary2(chartInstance);
  sf_mex_destroy(&c7_st);
}

static void c7_set_sim_state_side_effects_c7_XsensLibrary2
  (SFc7_XsensLibrary2InstanceStruct *chartInstance)
{
  if (chartInstance->c7_doSetSimStateSideEffects != 0) {
    chartInstance->c7_doSetSimStateSideEffects = 0U;
  }
}

static void finalize_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  sf_mex_destroy(&chartInstance->c7_setSimStateSideEffectsInfo);
}

static void sf_gateway_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  uint32_T c7_debug_family_var_map[2];
  real_T c7_nargin = 0.0;
  real_T c7_nargout = 0.0;
  int32_T c7_i112;
  c7_bus_datastruct c7_r2;
  int32_T c7_i113;
  int32_T c7_i114;
  int32_T c7_i115;
  int32_T c7_i116;
  int32_T c7_i117;
  int32_T c7_i118;
  int32_T c7_i119;
  int32_T c7_i120;
  int32_T c7_i121;
  int32_T c7_i122;
  int32_T c7_i123;
  int32_T c7_i124;
  int32_T c7_i125;
  int32_T c7_i126;
  int32_T c7_i127;
  int32_T c7_i128;
  int32_T c7_i129;
  int32_T c7_i130;
  int32_T c7_i131;
  int32_T c7_i132;
  int32_T c7_i133;
  int32_T c7_i134;
  int32_T c7_i135;
  int32_T c7_i136;
  int32_T c7_i137;
  int32_T c7_i138;
  int32_T c7_i139;
  int32_T c7_i140;
  int32_T c7_i141;
  int32_T c7_i142;
  int32_T c7_i143;
  int32_T c7_i144;
  int32_T c7_i145;
  int32_T c7_i146;
  int32_T c7_i147;
  int32_T c7_i148;
  c7_bus_datastruct c7_r3;
  c7_set_sim_state_side_effects_c7_XsensLibrary2(chartInstance);
  _SFD_SYMBOL_SCOPE_PUSH(0U, 0U);
  _sfTime_ = sf_get_time(chartInstance->S);
  c7_durationReferenceTimeUpdater(chartInstance);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 2U, *chartInstance->c7_sfEvent);
  _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c7_value_AngLShank, 5U, 1U, 0U, *
                        chartInstance->c7_sfEvent, false);
  _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c7_value_AngRShank, 4U, 1U, 0U, *
                        chartInstance->c7_sfEvent, false);
  _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c7_value_VelLShank, 3U, 1U, 0U, *
                        chartInstance->c7_sfEvent, false);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c7_value_VelRShank, 2U, 1U, 0U,
                        *chartInstance->c7_sfEvent, false);
  _SFD_DATA_RANGE_CHECK(*chartInstance->c7_time, 1U, 1U, 0U,
                        *chartInstance->c7_sfEvent, false);
  *chartInstance->c7_sfEvent = CALL_EVENT;
  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 2U, *chartInstance->c7_sfEvent);
  if (*chartInstance->c7_is_active_c7_XsensLibrary2 == 0U) {
    _SFD_CC_CALL(CHART_ENTER_ENTRY_FUNCTION_TAG, 2U, *chartInstance->c7_sfEvent);
    *chartInstance->c7_is_active_c7_XsensLibrary2 = 1U;
    _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 2U, *chartInstance->c7_sfEvent);
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 0U, *chartInstance->c7_sfEvent);
    *chartInstance->c7_is_c7_XsensLibrary2 = c7_IN_SEGMENTATION;
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 1U, *chartInstance->c7_sfEvent);
    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c7_debug_family_names,
      c7_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_nargin, 0U, c7_sf_marshallOut,
      c7_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_nargout, 1U, c7_sf_marshallOut,
      c7_sf_marshallIn);
    for (c7_i112 = 0; c7_i112 < 200; c7_i112++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 0, c7_i112);
      c7_r2.VelRShank[c7_i112] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[0])[c7_i112];
    }

    for (c7_i113 = 0; c7_i113 < 200; c7_i113++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 1, c7_i113);
      c7_r2.VelLShank[c7_i113] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[800])[c7_i113];
    }

    for (c7_i114 = 0; c7_i114 < 200; c7_i114++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 2, c7_i114);
      c7_r2.AngRShank[c7_i114] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[1600])[c7_i114];
    }

    for (c7_i115 = 0; c7_i115 < 200; c7_i115++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 3, c7_i115);
      c7_r2.AngLShank[c7_i115] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[2400])[c7_i115];
    }

    for (c7_i116 = 0; c7_i116 < 200; c7_i116++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 4, c7_i116);
      c7_r2.VelRShank_filt[c7_i116] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[3200])[c7_i116];
    }

    for (c7_i117 = 0; c7_i117 < 200; c7_i117++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 5, c7_i117);
      c7_r2.VelLShank_filt[c7_i117] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[4000])[c7_i117];
    }

    for (c7_i118 = 0; c7_i118 < 200; c7_i118++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 6, c7_i118);
      c7_r2.AngRShank_filt[c7_i118] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[4800])[c7_i118];
    }

    for (c7_i119 = 0; c7_i119 < 200; c7_i119++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 7, c7_i119);
      c7_r2.AngLShank_filt[c7_i119] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[5600])[c7_i119];
    }

    for (c7_i120 = 0; c7_i120 < 200; c7_i120++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 8, c7_i120);
      c7_r2.VelRShank_LPF[c7_i120] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[6400])[c7_i120];
    }

    for (c7_i121 = 0; c7_i121 < 200; c7_i121++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 9, c7_i121);
      c7_r2.VelLShank_LPF[c7_i121] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[7200])[c7_i121];
    }

    for (c7_i122 = 0; c7_i122 < 200; c7_i122++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 10, c7_i122);
      c7_r2.AngRShank_LPF[c7_i122] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[8000])[c7_i122];
    }

    for (c7_i123 = 0; c7_i123 < 200; c7_i123++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 11, c7_i123);
      c7_r2.AngLShank_LPF[c7_i123] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[8800])[c7_i123];
    }

    for (c7_i124 = 0; c7_i124 < 200; c7_i124++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 12, c7_i124);
      c7_r2.AngRShank_LPF2Hz[c7_i124] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[9600])[c7_i124];
    }

    for (c7_i125 = 0; c7_i125 < 200; c7_i125++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 13, c7_i125);
      c7_r2.AngLShank_LPF2Hz[c7_i125] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[10400])[c7_i125];
    }

    c7_bus_rd_access_A_2(chartInstance, -1, 0, 14, 0);
    c7_r2.counter_stop = *(uint16_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11200];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 15, 0);
    c7_r2.counter = *(uint8_T *)&((char_T *)c7_access_A(chartInstance, true))
      [11202];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 16, 0);
    c7_r2.index_start_calib = *(uint16_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11204];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 17, 0);
    c7_r2.index_stop_calib = *(uint16_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11206];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 18, 0);
    c7_r2.initial_leg = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11208];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 19, 0);
    c7_r2.flag_calib = *(boolean_T *)&((char_T *)c7_access_A(chartInstance, true))
      [11209];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 20, 0);
    c7_r2.calibrating = *(int8_T *)&((char_T *)c7_access_A(chartInstance, true))
      [11210];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 21, 0);
    c7_r2.state = *(int8_T *)&((char_T *)c7_access_A(chartInstance, true))[11211];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 22, 0);
    c7_r2.prevstate = *(int8_T *)&((char_T *)c7_access_A(chartInstance, true))
      [11212];
    for (c7_i126 = 0; c7_i126 < 5; c7_i126++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 23, c7_i126);
      c7_r2.MA_maxs_right[c7_i126] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11216])[c7_i126];
    }

    for (c7_i127 = 0; c7_i127 < 5; c7_i127++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 24, c7_i127);
      c7_r2.MA_maxs_left[c7_i127] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11236])[c7_i127];
    }

    for (c7_i128 = 0; c7_i128 < 5; c7_i128++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 25, c7_i128);
      c7_r2.MA_LPF_maxs_right[c7_i128] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11256])[c7_i128];
    }

    for (c7_i129 = 0; c7_i129 < 5; c7_i129++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 26, c7_i129);
      c7_r2.MA_LPF_maxs_left[c7_i129] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11276])[c7_i129];
    }

    c7_bus_rd_access_A_2(chartInstance, -1, 0, 27, 0);
    c7_r2.MA_LPF_index_right = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11296];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 28, 0);
    c7_r2.MA_LPF_index_left = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11297];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 29, 0);
    c7_r2.MA_index_right = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11298];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 30, 0);
    c7_r2.MA_index_left = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11299];
    for (c7_i130 = 0; c7_i130 < 5; c7_i130++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 31, c7_i130);
      c7_r2.IC_mins_right[c7_i130] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11300])[c7_i130];
    }

    for (c7_i131 = 0; c7_i131 < 5; c7_i131++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 32, c7_i131);
      c7_r2.IC_mins_left[c7_i131] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11320])[c7_i131];
    }

    for (c7_i132 = 0; c7_i132 < 5; c7_i132++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 33, c7_i132);
      c7_r2.IC_LPF_mins_right[c7_i132] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11340])[c7_i132];
    }

    for (c7_i133 = 0; c7_i133 < 5; c7_i133++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 34, c7_i133);
      c7_r2.IC_LPF_mins_left[c7_i133] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11360])[c7_i133];
    }

    c7_bus_rd_access_A_2(chartInstance, -1, 0, 35, 0);
    c7_r2.IC_LPF_index_right = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11380];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 36, 0);
    c7_r2.IC_LPF_index_left = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11381];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 37, 0);
    c7_r2.IC_index_right = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11382];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 38, 0);
    c7_r2.IC_index_left = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11383];
    for (c7_i134 = 0; c7_i134 < 5; c7_i134++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 39, c7_i134);
      c7_r2.EC_events_mins_right[c7_i134] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11384])[c7_i134];
    }

    for (c7_i135 = 0; c7_i135 < 5; c7_i135++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 40, c7_i135);
      c7_r2.EC_events_mins_left[c7_i135] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11404])[c7_i135];
    }

    for (c7_i136 = 0; c7_i136 < 5; c7_i136++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 41, c7_i136);
      c7_r2.EC_peaks_mins_right[c7_i136] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11424])[c7_i136];
    }

    for (c7_i137 = 0; c7_i137 < 5; c7_i137++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 42, c7_i137);
      c7_r2.EC_peaks_mins_left[c7_i137] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11444])[c7_i137];
    }

    c7_bus_rd_access_A_2(chartInstance, -1, 0, 43, 0);
    c7_r2.EC_events_index_right = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11464];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 44, 0);
    c7_r2.EC_events_index_left = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11465];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 45, 0);
    c7_r2.EC_peaks_index_right = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11466];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 46, 0);
    c7_r2.EC_peaks_index_left = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11467];
    for (c7_i138 = 0; c7_i138 < 5; c7_i138++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 47, c7_i138);
      c7_r2.AN_events_right[c7_i138] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11468])[c7_i138];
    }

    for (c7_i139 = 0; c7_i139 < 5; c7_i139++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 48, c7_i139);
      c7_r2.AN_events_left[c7_i139] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11488])[c7_i139];
    }

    for (c7_i140 = 0; c7_i140 < 5; c7_i140++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 49, c7_i140);
      c7_r2.AN_peaks_right[c7_i140] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11508])[c7_i140];
    }

    for (c7_i141 = 0; c7_i141 < 5; c7_i141++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 50, c7_i141);
      c7_r2.AN_peaks_left[c7_i141] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11528])[c7_i141];
    }

    c7_bus_rd_access_A_2(chartInstance, -1, 0, 51, 0);
    c7_r2.stop_DS_index = *(uint8_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11548];
    for (c7_i142 = 0; c7_i142 < 10; c7_i142++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 52, c7_i142);
      c7_r2.stop_DS[c7_i142] = ((uint16_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11550])[c7_i142];
    }

    c7_bus_rd_access_A_2(chartInstance, -1, 0, 53, 0);
    c7_r2.MS_event_left = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11570];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 54, 0);
    c7_r2.MS_event_right = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11571];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 55, 0);
    c7_r2.EC_event_left = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11572];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 56, 0);
    c7_r2.EC_event_right = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11573];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 57, 0);
    c7_r2.IC_event_left = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11574];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 58, 0);
    c7_r2.IC_event_right = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11575];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 59, 0);
    c7_r2.AN_event_left = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11576];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 60, 0);
    c7_r2.AN_event_right = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11577];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 61, 0);
    c7_r2.MA_event_left = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11578];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 62, 0);
    c7_r2.MA_event_right = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11579];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 63, 0);
    c7_r2.stop_Vel_event_left = *(boolean_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11580];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 64, 0);
    c7_r2.stop_Vel_event_right = *(boolean_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11581];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 65, 0);
    c7_r2.stop_MA_event_left = *(boolean_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11582];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 66, 0);
    c7_r2.stop_MA_event_right = *(boolean_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11583];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 67, 0);
    c7_r2.stop_IC_event_left = *(boolean_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11584];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 68, 0);
    c7_r2.stop_IC_event_right = *(boolean_T *)&((char_T *)c7_access_A
      (chartInstance, true))[11585];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 69, 0);
    c7_r2.MA_flag_right = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11586];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 70, 0);
    c7_r2.MA_flag_left = *(boolean_T *)&((char_T *)c7_access_A(chartInstance,
      true))[11587];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 71, 0);
    c7_r2.last_EC = *(uint16_T *)&((char_T *)c7_access_A(chartInstance, true))
      [11588];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 72, 0);
    c7_r2.last_IC = *(uint16_T *)&((char_T *)c7_access_A(chartInstance, true))
      [11590];
    for (c7_i143 = 0; c7_i143 < 200; c7_i143++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 73, c7_i143);
      c7_r2.IC_buffer_left[c7_i143] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[11592])[c7_i143];
    }

    for (c7_i144 = 0; c7_i144 < 200; c7_i144++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 74, c7_i144);
      c7_r2.IC_buffer_right[c7_i144] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[12392])[c7_i144];
    }

    for (c7_i145 = 0; c7_i145 < 200; c7_i145++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 75, c7_i145);
      c7_r2.EC_buffer_left[c7_i145] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[13192])[c7_i145];
    }

    for (c7_i146 = 0; c7_i146 < 200; c7_i146++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 76, c7_i146);
      c7_r2.EC_buffer_right[c7_i146] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[13992])[c7_i146];
    }

    for (c7_i147 = 0; c7_i147 < 200; c7_i147++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 77, c7_i147);
      c7_r2.MS_buffer_left[c7_i147] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[14792])[c7_i147];
    }

    for (c7_i148 = 0; c7_i148 < 200; c7_i148++) {
      c7_bus_rd_access_A_2(chartInstance, -1, 0, 78, c7_i148);
      c7_r2.MS_buffer_right[c7_i148] = ((real32_T *)&((char_T *)c7_access_A
        (chartInstance, true))[15592])[c7_i148];
    }

    c7_bus_rd_access_A_2(chartInstance, -1, 0, 79, 0);
    c7_r2.IC_buffer_index_left = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[16392];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 80, 0);
    c7_r2.IC_buffer_index_right = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[16393];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 81, 0);
    c7_r2.EC_buffer_index_left = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[16394];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 82, 0);
    c7_r2.EC_buffer_index_right = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[16395];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 83, 0);
    c7_r2.MS_buffer_index_left = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[16396];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 84, 0);
    c7_r2.MS_buffer_index_right = *(uint8_T *)&((char_T *)c7_access_A
      (chartInstance, true))[16397];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 85, 0);
    c7_r2.MA_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16400];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 86, 0);
    c7_r2.MA_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16404];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 87, 0);
    c7_r2.IC_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16408];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 88, 0);
    c7_r2.IC_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16412];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 89, 0);
    c7_r2.AN_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16416];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 90, 0);
    c7_r2.AN_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16420];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 91, 0);
    c7_r2.EC_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16424];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 92, 0);
    c7_r2.EC_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16428];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 93, 0);
    c7_r2.stop_Vel_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16432];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 94, 0);
    c7_r2.stop_Vel_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16436];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 95, 0);
    c7_r2.stop_MA_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16440];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 96, 0);
    c7_r2.stop_MA_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16444];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 97, 0);
    c7_r2.stop_IC_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16448];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 98, 0);
    c7_r2.stop_IC_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16452];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 99, 0);
    c7_r2.stop_DS_th = *(uint16_T *)&((char_T *)c7_access_A(chartInstance, true))
      [16456];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 100, 0);
    c7_r2.MA_LPF_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16460];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 101, 0);
    c7_r2.MA_LPF_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16464];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 102, 0);
    c7_r2.IC_LPF_th_left = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16468];
    c7_bus_rd_access_A_2(chartInstance, -1, 0, 103, 0);
    c7_r2.IC_LPF_th_right = *(real32_T *)&((char_T *)c7_access_A(chartInstance,
      true))[16472];
    c7_data_struct_creation(chartInstance, &c7_r2, &c7_r3);
    *chartInstance->c7_data_struct = c7_r3;
    chartInstance->c7_dataWrittenToVector[2U] = true;
    _SFD_SYMBOL_SCOPE_POP();
  } else {
    c7_SEGMENTATION(chartInstance);
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 2U, *chartInstance->c7_sfEvent);
  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_XsensLibrary2MachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void mdl_start_c7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  c7_init_sf_message_store_memory(chartInstance);
}

static void initSimStructsc7_XsensLibrary2(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c7_SEGMENTATION(SFc7_XsensLibrary2InstanceStruct *chartInstance)
{
  uint32_T c7_debug_family_var_map[2];
  real_T c7_nargin = 0.0;
  real_T c7_nargout = 0.0;
  c7_bus_datastruct c7_r4;
  int8_T c7_b_state;
  c7_bus_datastruct c7_b_data_struct;
  int32_T c7_i149;
  int32_T c7_i150;
  int32_T c7_i151;
  int32_T c7_i152;
  int32_T c7_i153;
  int32_T c7_i154;
  int32_T c7_i155;
  int32_T c7_i156;
  int32_T c7_i157;
  int32_T c7_i158;
  int32_T c7_i159;
  int32_T c7_i160;
  int32_T c7_i161;
  int32_T c7_i162;
  int32_T c7_i163;
  int32_T c7_i164;
  int32_T c7_i165;
  int32_T c7_i166;
  int32_T c7_i167;
  int32_T c7_i168;
  int32_T c7_i169;
  int32_T c7_i170;
  int32_T c7_i171;
  int32_T c7_i172;
  int32_T c7_i173;
  int32_T c7_i174;
  int32_T c7_i175;
  int32_T c7_i176;
  int32_T c7_i177;
  int32_T c7_i178;
  int32_T c7_i179;
  int32_T c7_i180;
  int32_T c7_i181;
  int32_T c7_i182;
  int32_T c7_i183;
  int32_T c7_i184;
  int32_T c7_i185;
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 1U, *chartInstance->c7_sfEvent);
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c7_c_debug_family_names,
    c7_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_nargin, 0U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_nargout, 1U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  if (!chartInstance->c7_dataWrittenToVector[2U]) {
    _SFD_DATA_READ_BEFORE_WRITE_ERROR(0U, 4U, 1U, *chartInstance->c7_sfEvent,
      false);
  }

  c7_r4 = *chartInstance->c7_data_struct;
  c7_RTDetection(chartInstance, &c7_r4, *chartInstance->c7_time,
                 *chartInstance->c7_value_VelRShank,
                 *chartInstance->c7_value_VelLShank,
                 *chartInstance->c7_value_AngRShank,
                 *chartInstance->c7_value_AngLShank, &c7_b_data_struct,
                 &c7_b_state);
  *chartInstance->c7_data_struct = c7_b_data_struct;
  chartInstance->c7_dataWrittenToVector[2U] = true;
  *chartInstance->c7_state = c7_b_state;
  chartInstance->c7_dataWrittenToVector[0U] = true;
  _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c7_state, 6U, 4U, 1U,
                        *chartInstance->c7_sfEvent, false);
  if (!chartInstance->c7_dataWrittenToVector[2U]) {
    _SFD_DATA_READ_BEFORE_WRITE_ERROR(0U, 4U, 1U, *chartInstance->c7_sfEvent,
      false);
  }

  for (c7_i149 = 0; c7_i149 < 200; c7_i149++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[0])[c7_i149] =
      chartInstance->c7_data_struct->VelRShank[c7_i149];
  }

  for (c7_i150 = 0; c7_i150 < 200; c7_i150++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[800])[c7_i150] =
      chartInstance->c7_data_struct->VelLShank[c7_i150];
  }

  for (c7_i151 = 0; c7_i151 < 200; c7_i151++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[1600])[c7_i151] =
      chartInstance->c7_data_struct->AngRShank[c7_i151];
  }

  for (c7_i152 = 0; c7_i152 < 200; c7_i152++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[2400])[c7_i152] =
      chartInstance->c7_data_struct->AngLShank[c7_i152];
  }

  for (c7_i153 = 0; c7_i153 < 200; c7_i153++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[3200])[c7_i153] =
      chartInstance->c7_data_struct->VelRShank_filt[c7_i153];
  }

  for (c7_i154 = 0; c7_i154 < 200; c7_i154++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[4000])[c7_i154] =
      chartInstance->c7_data_struct->VelLShank_filt[c7_i154];
  }

  for (c7_i155 = 0; c7_i155 < 200; c7_i155++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[4800])[c7_i155] =
      chartInstance->c7_data_struct->AngRShank_filt[c7_i155];
  }

  for (c7_i156 = 0; c7_i156 < 200; c7_i156++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[5600])[c7_i156] =
      chartInstance->c7_data_struct->AngLShank_filt[c7_i156];
  }

  for (c7_i157 = 0; c7_i157 < 200; c7_i157++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[6400])[c7_i157] =
      chartInstance->c7_data_struct->VelRShank_LPF[c7_i157];
  }

  for (c7_i158 = 0; c7_i158 < 200; c7_i158++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[7200])[c7_i158] =
      chartInstance->c7_data_struct->VelLShank_LPF[c7_i158];
  }

  for (c7_i159 = 0; c7_i159 < 200; c7_i159++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[8000])[c7_i159] =
      chartInstance->c7_data_struct->AngRShank_LPF[c7_i159];
  }

  for (c7_i160 = 0; c7_i160 < 200; c7_i160++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[8800])[c7_i160] =
      chartInstance->c7_data_struct->AngLShank_LPF[c7_i160];
  }

  for (c7_i161 = 0; c7_i161 < 200; c7_i161++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[9600])[c7_i161] =
      chartInstance->c7_data_struct->AngRShank_LPF2Hz[c7_i161];
  }

  for (c7_i162 = 0; c7_i162 < 200; c7_i162++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[10400])[c7_i162]
      = chartInstance->c7_data_struct->AngLShank_LPF2Hz[c7_i162];
  }

  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11200] =
    chartInstance->c7_data_struct->counter_stop;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11202] =
    chartInstance->c7_data_struct->counter;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11204] =
    chartInstance->c7_data_struct->index_start_calib;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11206] =
    chartInstance->c7_data_struct->index_stop_calib;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11208] =
    chartInstance->c7_data_struct->initial_leg;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11209] =
    chartInstance->c7_data_struct->flag_calib;
  *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11210] =
    chartInstance->c7_data_struct->calibrating;
  *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11211] =
    chartInstance->c7_data_struct->state;
  *(int8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11212] =
    chartInstance->c7_data_struct->prevstate;
  for (c7_i163 = 0; c7_i163 < 5; c7_i163++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11216])[c7_i163]
      = chartInstance->c7_data_struct->MA_maxs_right[c7_i163];
  }

  for (c7_i164 = 0; c7_i164 < 5; c7_i164++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11236])[c7_i164]
      = chartInstance->c7_data_struct->MA_maxs_left[c7_i164];
  }

  for (c7_i165 = 0; c7_i165 < 5; c7_i165++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11256])[c7_i165]
      = chartInstance->c7_data_struct->MA_LPF_maxs_right[c7_i165];
  }

  for (c7_i166 = 0; c7_i166 < 5; c7_i166++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11276])[c7_i166]
      = chartInstance->c7_data_struct->MA_LPF_maxs_left[c7_i166];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11296] =
    chartInstance->c7_data_struct->MA_LPF_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11297] =
    chartInstance->c7_data_struct->MA_LPF_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11298] =
    chartInstance->c7_data_struct->MA_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11299] =
    chartInstance->c7_data_struct->MA_index_left;
  for (c7_i167 = 0; c7_i167 < 5; c7_i167++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11300])[c7_i167]
      = chartInstance->c7_data_struct->IC_mins_right[c7_i167];
  }

  for (c7_i168 = 0; c7_i168 < 5; c7_i168++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11320])[c7_i168]
      = chartInstance->c7_data_struct->IC_mins_left[c7_i168];
  }

  for (c7_i169 = 0; c7_i169 < 5; c7_i169++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11340])[c7_i169]
      = chartInstance->c7_data_struct->IC_LPF_mins_right[c7_i169];
  }

  for (c7_i170 = 0; c7_i170 < 5; c7_i170++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11360])[c7_i170]
      = chartInstance->c7_data_struct->IC_LPF_mins_left[c7_i170];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11380] =
    chartInstance->c7_data_struct->IC_LPF_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11381] =
    chartInstance->c7_data_struct->IC_LPF_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11382] =
    chartInstance->c7_data_struct->IC_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11383] =
    chartInstance->c7_data_struct->IC_index_left;
  for (c7_i171 = 0; c7_i171 < 5; c7_i171++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11384])[c7_i171]
      = chartInstance->c7_data_struct->EC_events_mins_right[c7_i171];
  }

  for (c7_i172 = 0; c7_i172 < 5; c7_i172++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11404])[c7_i172]
      = chartInstance->c7_data_struct->EC_events_mins_left[c7_i172];
  }

  for (c7_i173 = 0; c7_i173 < 5; c7_i173++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11424])[c7_i173]
      = chartInstance->c7_data_struct->EC_peaks_mins_right[c7_i173];
  }

  for (c7_i174 = 0; c7_i174 < 5; c7_i174++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11444])[c7_i174]
      = chartInstance->c7_data_struct->EC_peaks_mins_left[c7_i174];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11464] =
    chartInstance->c7_data_struct->EC_events_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11465] =
    chartInstance->c7_data_struct->EC_events_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11466] =
    chartInstance->c7_data_struct->EC_peaks_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11467] =
    chartInstance->c7_data_struct->EC_peaks_index_left;
  for (c7_i175 = 0; c7_i175 < 5; c7_i175++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11468])[c7_i175]
      = chartInstance->c7_data_struct->AN_events_right[c7_i175];
  }

  for (c7_i176 = 0; c7_i176 < 5; c7_i176++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11488])[c7_i176]
      = chartInstance->c7_data_struct->AN_events_left[c7_i176];
  }

  for (c7_i177 = 0; c7_i177 < 5; c7_i177++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11508])[c7_i177]
      = chartInstance->c7_data_struct->AN_peaks_right[c7_i177];
  }

  for (c7_i178 = 0; c7_i178 < 5; c7_i178++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11528])[c7_i178]
      = chartInstance->c7_data_struct->AN_peaks_left[c7_i178];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[11548] =
    chartInstance->c7_data_struct->stop_DS_index;
  for (c7_i179 = 0; c7_i179 < 10; c7_i179++) {
    ((uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11550])[c7_i179]
      = chartInstance->c7_data_struct->stop_DS[c7_i179];
  }

  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11570] =
    chartInstance->c7_data_struct->MS_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11571] =
    chartInstance->c7_data_struct->MS_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11572] =
    chartInstance->c7_data_struct->EC_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11573] =
    chartInstance->c7_data_struct->EC_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11574] =
    chartInstance->c7_data_struct->IC_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11575] =
    chartInstance->c7_data_struct->IC_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11576] =
    chartInstance->c7_data_struct->AN_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11577] =
    chartInstance->c7_data_struct->AN_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11578] =
    chartInstance->c7_data_struct->MA_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11579] =
    chartInstance->c7_data_struct->MA_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11580] =
    chartInstance->c7_data_struct->stop_Vel_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11581] =
    chartInstance->c7_data_struct->stop_Vel_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11582] =
    chartInstance->c7_data_struct->stop_MA_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11583] =
    chartInstance->c7_data_struct->stop_MA_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11584] =
    chartInstance->c7_data_struct->stop_IC_event_left;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11585] =
    chartInstance->c7_data_struct->stop_IC_event_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11586] =
    chartInstance->c7_data_struct->MA_flag_right;
  *(boolean_T *)&((char_T *)chartInstance->c7_data_struct_out)[11587] =
    chartInstance->c7_data_struct->MA_flag_left;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11588] =
    chartInstance->c7_data_struct->last_EC;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[11590] =
    chartInstance->c7_data_struct->last_IC;
  for (c7_i180 = 0; c7_i180 < 200; c7_i180++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[11592])[c7_i180]
      = chartInstance->c7_data_struct->IC_buffer_left[c7_i180];
  }

  for (c7_i181 = 0; c7_i181 < 200; c7_i181++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[12392])[c7_i181]
      = chartInstance->c7_data_struct->IC_buffer_right[c7_i181];
  }

  for (c7_i182 = 0; c7_i182 < 200; c7_i182++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[13192])[c7_i182]
      = chartInstance->c7_data_struct->EC_buffer_left[c7_i182];
  }

  for (c7_i183 = 0; c7_i183 < 200; c7_i183++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[13992])[c7_i183]
      = chartInstance->c7_data_struct->EC_buffer_right[c7_i183];
  }

  for (c7_i184 = 0; c7_i184 < 200; c7_i184++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[14792])[c7_i184]
      = chartInstance->c7_data_struct->MS_buffer_left[c7_i184];
  }

  for (c7_i185 = 0; c7_i185 < 200; c7_i185++) {
    ((real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[15592])[c7_i185]
      = chartInstance->c7_data_struct->MS_buffer_right[c7_i185];
  }

  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16392] =
    chartInstance->c7_data_struct->IC_buffer_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16393] =
    chartInstance->c7_data_struct->IC_buffer_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16394] =
    chartInstance->c7_data_struct->EC_buffer_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16395] =
    chartInstance->c7_data_struct->EC_buffer_index_right;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16396] =
    chartInstance->c7_data_struct->MS_buffer_index_left;
  *(uint8_T *)&((char_T *)chartInstance->c7_data_struct_out)[16397] =
    chartInstance->c7_data_struct->MS_buffer_index_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16400] =
    chartInstance->c7_data_struct->MA_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16404] =
    chartInstance->c7_data_struct->MA_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16408] =
    chartInstance->c7_data_struct->IC_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16412] =
    chartInstance->c7_data_struct->IC_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16416] =
    chartInstance->c7_data_struct->AN_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16420] =
    chartInstance->c7_data_struct->AN_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16424] =
    chartInstance->c7_data_struct->EC_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16428] =
    chartInstance->c7_data_struct->EC_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16432] =
    chartInstance->c7_data_struct->stop_Vel_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16436] =
    chartInstance->c7_data_struct->stop_Vel_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16440] =
    chartInstance->c7_data_struct->stop_MA_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16444] =
    chartInstance->c7_data_struct->stop_MA_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16448] =
    chartInstance->c7_data_struct->stop_IC_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16452] =
    chartInstance->c7_data_struct->stop_IC_th_left;
  *(uint16_T *)&((char_T *)chartInstance->c7_data_struct_out)[16456] =
    chartInstance->c7_data_struct->stop_DS_th;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16460] =
    chartInstance->c7_data_struct->MA_LPF_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16464] =
    chartInstance->c7_data_struct->MA_LPF_th_right;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16468] =
    chartInstance->c7_data_struct->IC_LPF_th_left;
  *(real32_T *)&((char_T *)chartInstance->c7_data_struct_out)[16472] =
    chartInstance->c7_data_struct->IC_LPF_th_right;
  chartInstance->c7_dataWrittenToVector[1U] = true;
  if (!chartInstance->c7_dataWrittenToVector[1U]) {
    _SFD_DATA_READ_BEFORE_WRITE_ERROR(7U, 4U, 1U, *chartInstance->c7_sfEvent,
      false);
  }

  *chartInstance->c7_state = *(int8_T *)&((char_T *)
    chartInstance->c7_data_struct_out)[11211];
  chartInstance->c7_dataWrittenToVector[0U] = true;
  _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c7_state, 6U, 4U, 1U,
                        *chartInstance->c7_sfEvent, false);
  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 1U, *chartInstance->c7_sfEvent);
}

static real_T c7_mean(SFc7_XsensLibrary2InstanceStruct *chartInstance, uint16_T
                      c7_x_data[], int32_T c7_x_sizes[2])
{
  boolean_T c7_b0;
  boolean_T c7_b1;
  const mxArray *c7_b_y = NULL;
  static char_T c7_u[36] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'a', 'u', 't', 'o', 'D', 'i', 'm', 'I', 'n', 'c', 'o',
    'm', 'p', 'a', 't', 'i', 'b', 'i', 'l', 'i', 't', 'y' };

  int32_T c7_b_x_sizes[2];
  int32_T c7_x;
  int32_T c7_b_x;
  int32_T c7_loop_ub;
  int32_T c7_i186;
  uint16_T c7_b_x_data[10];
  boolean_T c7_b2;
  const mxArray *c7_c_y = NULL;
  static char_T c7_b_u[37] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'U', 'n', 's', 'u', 'p', 'p', 'o', 'r', 't', 'e', 'd',
    'S', 'p', 'e', 'c', 'i', 'a', 'l', 'E', 'm', 'p', 't', 'y' };

  int32_T c7_c_x_sizes[2];
  int32_T c7_c_x;
  int32_T c7_d_x;
  int32_T c7_b_loop_ub;
  int32_T c7_i187;
  uint16_T c7_c_x_data[10];
  boolean_T c7_b3;
  const mxArray *c7_d_y = NULL;
  boolean_T c7_b4;
  real_T c7_e_y;
  int32_T c7_vlen;
  int32_T c7_b_vlen;
  int32_T c7_k;
  int32_T c7_b_k;
  boolean_T guard1 = false;
  c7_b0 = (c7_x_sizes[1] == 1);
  guard1 = false;
  if (c7_b0) {
    guard1 = true;
  } else if ((real_T)c7_x_sizes[1] != 1.0) {
    guard1 = true;
  } else {
    c7_b1 = false;
  }

  if (guard1 == true) {
    c7_b1 = true;
  }

  if (c7_b1) {
  } else {
    c7_b_y = NULL;
    sf_mex_assign(&c7_b_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_b_y));
  }

  c7_b_x_sizes[0] = 1;
  c7_b_x_sizes[1] = c7_x_sizes[1];
  c7_x = c7_b_x_sizes[0];
  c7_b_x = c7_b_x_sizes[1];
  c7_loop_ub = c7_x_sizes[0] * c7_x_sizes[1] - 1;
  for (c7_i186 = 0; c7_i186 <= c7_loop_ub; c7_i186++) {
    c7_b_x_data[c7_i186] = c7_x_data[c7_i186];
  }

  c7_b2 = !c7_isequal(chartInstance, c7_b_x_data, c7_b_x_sizes);
  if (c7_b2) {
  } else {
    c7_c_y = NULL;
    sf_mex_assign(&c7_c_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 37),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_c_y));
  }

  c7_c_x_sizes[0] = 1;
  c7_c_x_sizes[1] = c7_x_sizes[1];
  c7_c_x = c7_c_x_sizes[0];
  c7_d_x = c7_c_x_sizes[1];
  c7_b_loop_ub = c7_x_sizes[0] * c7_x_sizes[1] - 1;
  for (c7_i187 = 0; c7_i187 <= c7_b_loop_ub; c7_i187++) {
    c7_c_x_data[c7_i187] = c7_x_data[c7_i187];
  }

  c7_b3 = !c7_isequal(chartInstance, c7_c_x_data, c7_c_x_sizes);
  if (c7_b3) {
  } else {
    c7_d_y = NULL;
    sf_mex_assign(&c7_d_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 37),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_d_y));
  }

  c7_b4 = (c7_x_sizes[1] == 0);
  if (c7_b4) {
    c7_e_y = 0.0;
  } else {
    c7_vlen = c7_x_sizes[1];
    c7_e_y = (real_T)c7_x_data[0];
    c7_b_vlen = c7_vlen;
    for (c7_k = 2; c7_k <= c7_b_vlen; c7_k++) {
      c7_b_k = c7_k - 1;
      c7_e_y += (real_T)c7_x_data[c7_b_k];
    }
  }

  return c7_rdivide(chartInstance, c7_e_y, (real_T)c7_x_sizes[1]);
}

static boolean_T c7_isequal(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  uint16_T c7_varargin_1_data[], int32_T c7_varargin_1_sizes[2])
{
  boolean_T c7_p;
  boolean_T c7_b_p;
  int32_T c7_k;
  real_T c7_b_k;
  real_T c7_d0;
  real_T c7_d1;
  boolean_T c7_b5;
  boolean_T c7_c_p;
  int32_T exitg1;
  (void)chartInstance;
  (void)c7_varargin_1_data;
  c7_p = false;
  c7_b_p = false;
  c7_k = 0;
  do {
    exitg1 = 0;
    if (c7_k < 2) {
      c7_b_k = 1.0 + (real_T)c7_k;
      c7_d0 = c7_b_k;
      c7_d1 = (real_T)c7_varargin_1_sizes[(int32_T)c7_d0 - 1];
      if (c7_d1 != 0.0) {
        exitg1 = 1;
      } else {
        c7_k++;
      }
    } else {
      c7_b_p = true;
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  c7_b5 = c7_b_p;
  c7_c_p = c7_b5;
  if (!c7_c_p) {
  } else {
    c7_p = true;
  }

  return c7_p;
}

static real_T c7_rdivide(SFc7_XsensLibrary2InstanceStruct *chartInstance, real_T
  c7_x, real_T c7_y)
{
  real_T c7_b_x;
  real_T c7_b_y;
  (void)chartInstance;
  c7_b_x = c7_x;
  c7_b_y = c7_y;
  return c7_b_x / c7_b_y;
}

static real32_T c7_b_mean(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real32_T c7_x_data[], int32_T c7_x_sizes[2])
{
  boolean_T c7_b6;
  boolean_T c7_b7;
  const mxArray *c7_b_y = NULL;
  static char_T c7_u[36] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'a', 'u', 't', 'o', 'D', 'i', 'm', 'I', 'n', 'c', 'o',
    'm', 'p', 'a', 't', 'i', 'b', 'i', 'l', 'i', 't', 'y' };

  int32_T c7_b_x_sizes[2];
  int32_T c7_x;
  int32_T c7_b_x;
  int32_T c7_loop_ub;
  int32_T c7_i188;
  real32_T c7_b_x_data[5];
  boolean_T c7_b8;
  const mxArray *c7_c_y = NULL;
  static char_T c7_b_u[37] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'U', 'n', 's', 'u', 'p', 'p', 'o', 'r', 't', 'e', 'd',
    'S', 'p', 'e', 'c', 'i', 'a', 'l', 'E', 'm', 'p', 't', 'y' };

  int32_T c7_c_x_sizes[2];
  int32_T c7_c_x;
  int32_T c7_d_x;
  int32_T c7_b_loop_ub;
  int32_T c7_i189;
  real32_T c7_c_x_data[5];
  boolean_T c7_b9;
  const mxArray *c7_d_y = NULL;
  boolean_T c7_b10;
  real32_T c7_e_y;
  int32_T c7_vlen;
  int32_T c7_b_vlen;
  int32_T c7_k;
  int32_T c7_b_k;
  boolean_T guard1 = false;
  c7_b6 = (c7_x_sizes[1] == 1);
  guard1 = false;
  if (c7_b6) {
    guard1 = true;
  } else if ((real_T)c7_x_sizes[1] != 1.0) {
    guard1 = true;
  } else {
    c7_b7 = false;
  }

  if (guard1 == true) {
    c7_b7 = true;
  }

  if (c7_b7) {
  } else {
    c7_b_y = NULL;
    sf_mex_assign(&c7_b_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_b_y));
  }

  c7_b_x_sizes[0] = 1;
  c7_b_x_sizes[1] = c7_x_sizes[1];
  c7_x = c7_b_x_sizes[0];
  c7_b_x = c7_b_x_sizes[1];
  c7_loop_ub = c7_x_sizes[0] * c7_x_sizes[1] - 1;
  for (c7_i188 = 0; c7_i188 <= c7_loop_ub; c7_i188++) {
    c7_b_x_data[c7_i188] = c7_x_data[c7_i188];
  }

  c7_b8 = !c7_b_isequal(chartInstance, c7_b_x_data, c7_b_x_sizes);
  if (c7_b8) {
  } else {
    c7_c_y = NULL;
    sf_mex_assign(&c7_c_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 37),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_c_y));
  }

  c7_c_x_sizes[0] = 1;
  c7_c_x_sizes[1] = c7_x_sizes[1];
  c7_c_x = c7_c_x_sizes[0];
  c7_d_x = c7_c_x_sizes[1];
  c7_b_loop_ub = c7_x_sizes[0] * c7_x_sizes[1] - 1;
  for (c7_i189 = 0; c7_i189 <= c7_b_loop_ub; c7_i189++) {
    c7_c_x_data[c7_i189] = c7_x_data[c7_i189];
  }

  c7_b9 = !c7_b_isequal(chartInstance, c7_c_x_data, c7_c_x_sizes);
  if (c7_b9) {
  } else {
    c7_d_y = NULL;
    sf_mex_assign(&c7_d_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 37),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_d_y));
  }

  c7_b10 = (c7_x_sizes[1] == 0);
  if (c7_b10) {
    c7_e_y = 0.0F;
  } else {
    c7_vlen = c7_x_sizes[1];
    c7_e_y = c7_x_data[0];
    c7_b_vlen = c7_vlen;
    for (c7_k = 2; c7_k <= c7_b_vlen; c7_k++) {
      c7_b_k = c7_k - 1;
      c7_e_y += c7_x_data[c7_b_k];
    }
  }

  return c7_b_rdivide(chartInstance, c7_e_y, (real_T)c7_x_sizes[1]);
}

static void c7_scalarEg(SFc7_XsensLibrary2InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static boolean_T c7_b_isequal(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real32_T c7_varargin_1_data[], int32_T c7_varargin_1_sizes[2])
{
  boolean_T c7_p;
  boolean_T c7_b_p;
  int32_T c7_k;
  real_T c7_b_k;
  real_T c7_d2;
  real_T c7_d3;
  boolean_T c7_b11;
  boolean_T c7_c_p;
  int32_T exitg1;
  (void)chartInstance;
  (void)c7_varargin_1_data;
  c7_p = false;
  c7_b_p = false;
  c7_k = 0;
  do {
    exitg1 = 0;
    if (c7_k < 2) {
      c7_b_k = 1.0 + (real_T)c7_k;
      c7_d2 = c7_b_k;
      c7_d3 = (real_T)c7_varargin_1_sizes[(int32_T)c7_d2 - 1];
      if (c7_d3 != 0.0) {
        exitg1 = 1;
      } else {
        c7_k++;
      }
    } else {
      c7_b_p = true;
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  c7_b11 = c7_b_p;
  c7_c_p = c7_b11;
  if (!c7_c_p) {
  } else {
    c7_p = true;
  }

  return c7_p;
}

static real32_T c7_b_rdivide(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real32_T c7_x, real_T c7_y)
{
  real32_T c7_b_x;
  real_T c7_b_y;
  (void)chartInstance;
  c7_b_x = c7_x;
  c7_b_y = c7_y;
  return c7_b_x / (real32_T)c7_b_y;
}

static real32_T c7_std(SFc7_XsensLibrary2InstanceStruct *chartInstance, real32_T
  c7_varargin_1_data[], int32_T c7_varargin_1_sizes[2])
{
  real32_T c7_y;
  int32_T c7_b_varargin_1_sizes[2];
  int32_T c7_varargin_1;
  int32_T c7_b_varargin_1;
  int32_T c7_loop_ub;
  int32_T c7_i190;
  real32_T c7_b_varargin_1_data[5];
  boolean_T c7_b12;
  const mxArray *c7_b_y = NULL;
  static char_T c7_u[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'v', 'a', 'r', '_', 's', 'p', 'e', 'c', 'i', 'a', 'l',
    'E', 'm', 'p', 't', 'y' };

  boolean_T c7_b13;
  boolean_T c7_b14;
  const mxArray *c7_c_y = NULL;
  static char_T c7_b_u[36] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'a', 'u', 't', 'o', 'D', 'i', 'm', 'I', 'n', 'c', 'o',
    'm', 'p', 'a', 't', 'i', 'b', 'i', 'l', 'i', 't', 'y' };

  int32_T c7_n;
  real32_T c7_d;
  boolean_T c7_b15;
  real32_T c7_d_y;
  int32_T c7_c_varargin_1_sizes[2];
  int32_T c7_c_varargin_1;
  int32_T c7_d_varargin_1;
  int32_T c7_b_loop_ub;
  int32_T c7_i191;
  real32_T c7_c_varargin_1_data[5];
  real32_T c7_x;
  real32_T c7_b_x;
  boolean_T c7_b16;
  boolean_T c7_p;
  boolean_T guard1 = false;
  c7_b_varargin_1_sizes[0] = 1;
  c7_b_varargin_1_sizes[1] = c7_varargin_1_sizes[1];
  c7_varargin_1 = c7_b_varargin_1_sizes[0];
  c7_b_varargin_1 = c7_b_varargin_1_sizes[1];
  c7_loop_ub = c7_varargin_1_sizes[0] * c7_varargin_1_sizes[1] - 1;
  for (c7_i190 = 0; c7_i190 <= c7_loop_ub; c7_i190++) {
    c7_b_varargin_1_data[c7_i190] = c7_varargin_1_data[c7_i190];
  }

  c7_b12 = !c7_b_isequal(chartInstance, c7_b_varargin_1_data,
    c7_b_varargin_1_sizes);
  if (c7_b12) {
  } else {
    c7_b_y = NULL;
    sf_mex_assign(&c7_b_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1, 30),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_b_y));
  }

  c7_b13 = (c7_varargin_1_sizes[1] == 1);
  guard1 = false;
  if (c7_b13) {
    guard1 = true;
  } else if ((real_T)c7_varargin_1_sizes[1] != 1.0) {
    guard1 = true;
  } else {
    c7_b14 = false;
  }

  if (guard1 == true) {
    c7_b14 = true;
  }

  if (c7_b14) {
  } else {
    c7_c_y = NULL;
    sf_mex_assign(&c7_c_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_c_y));
  }

  c7_n = c7_varargin_1_sizes[1];
  if (c7_n > 1) {
    c7_d = (real32_T)(c7_n - 1);
  } else {
    c7_d = (real32_T)c7_n;
  }

  c7_b15 = (c7_varargin_1_sizes[1] == 0);
  if (c7_b15) {
    c7_d_y = 0.0F;
  } else {
    c7_c_varargin_1_sizes[0] = 1;
    c7_c_varargin_1_sizes[1] = c7_varargin_1_sizes[1];
    c7_c_varargin_1 = c7_c_varargin_1_sizes[0];
    c7_d_varargin_1 = c7_c_varargin_1_sizes[1];
    c7_b_loop_ub = c7_varargin_1_sizes[0] * c7_varargin_1_sizes[1] - 1;
    for (c7_i191 = 0; c7_i191 <= c7_b_loop_ub; c7_i191++) {
      c7_c_varargin_1_data[c7_i191] = c7_varargin_1_data[c7_i191];
    }

    c7_d_y = c7_vector_variance(chartInstance, c7_c_varargin_1_data,
      c7_c_varargin_1_sizes, c7_d, 1, 1, c7_n);
  }

  c7_x = c7_d_y;
  c7_y = c7_x;
  c7_b_x = c7_y;
  c7_b16 = (c7_b_x < 0.0F);
  c7_p = c7_b16;
  if (c7_p) {
    c7_error(chartInstance);
  }

  return muSingleScalarSqrt(c7_y);
}

static real32_T c7_vector_variance(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, real32_T c7_x_data[], int32_T c7_x_sizes[2], real32_T c7_w,
  int32_T c7_ixstart, int32_T c7_stride, int32_T c7_n)
{
  real32_T c7_y;
  boolean_T c7_b17;
  int32_T c7_ix;
  real32_T c7_xbar;
  int32_T c7_b_n;
  int32_T c7_k;
  real32_T c7_x;
  real32_T c7_b_y;
  real32_T c7_b_x;
  real32_T c7_b_xbar;
  real32_T c7_r;
  int32_T c7_c_n;
  int32_T c7_b_k;
  real32_T c7_c_x;
  real32_T c7_c_xbar;
  real32_T c7_b_r;
  real32_T c7_c_y;
  real32_T c7_d_x;
  real32_T c7_d_y;
  (void)chartInstance;
  (void)c7_ixstart;
  (void)c7_stride;
  c7_b17 = (c7_x_sizes[1] == 0);
  if (c7_b17) {
    c7_y = ((real32_T)rtNaN);
  } else {
    c7_ix = 0;
    c7_xbar = c7_x_data[0];
    c7_b_n = c7_n;
    for (c7_k = 2; c7_k <= c7_b_n; c7_k++) {
      c7_ix++;
      c7_xbar += c7_x_data[c7_ix];
    }

    c7_x = c7_xbar;
    c7_b_y = (real32_T)c7_n;
    c7_xbar = c7_x / c7_b_y;
    c7_ix = 0;
    c7_b_x = c7_x_data[0];
    c7_b_xbar = c7_xbar;
    c7_r = c7_b_x - c7_b_xbar;
    c7_y = c7_r * c7_r;
    c7_c_n = c7_n;
    for (c7_b_k = 2; c7_b_k <= c7_c_n; c7_b_k++) {
      c7_ix++;
      c7_c_x = c7_x_data[c7_ix];
      c7_c_xbar = c7_xbar;
      c7_b_r = c7_c_x - c7_c_xbar;
      c7_c_y = c7_b_r * c7_b_r;
      c7_y += c7_c_y;
    }

    c7_d_x = c7_y;
    c7_d_y = c7_w;
    c7_y = c7_d_x / c7_d_y;
  }

  return c7_y;
}

static void c7_error(SFc7_XsensLibrary2InstanceStruct *chartInstance)
{
  const mxArray *c7_y = NULL;
  static char_T c7_u[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  const mxArray *c7_b_y = NULL;
  static char_T c7_b_u[4] = { 's', 'q', 'r', 't' };

  (void)chartInstance;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1, 30), false);
  c7_b_y = NULL;
  sf_mex_assign(&c7_b_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 4),
                false);
  sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message", 1U,
    2U, 14, c7_y, 14, c7_b_y));
}

static real32_T c7_sign(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real32_T c7_x)
{
  real32_T c7_b_x;
  c7_b_x = c7_x;
  c7_b_sign(chartInstance, &c7_b_x);
  return c7_b_x;
}

static real_T c7_c_mean(SFc7_XsensLibrary2InstanceStruct *chartInstance, real_T
  c7_x_data[], int32_T c7_x_sizes)
{
  boolean_T c7_b18;
  const mxArray *c7_b_y = NULL;
  static char_T c7_u[36] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'a', 'u', 't', 'o', 'D', 'i', 'm', 'I', 'n', 'c', 'o',
    'm', 'p', 'a', 't', 'i', 'b', 'i', 'l', 'i', 't', 'y' };

  int32_T c7_b_x_sizes;
  int32_T c7_loop_ub;
  int32_T c7_i192;
  real_T c7_b_x_data[50];
  boolean_T c7_b19;
  const mxArray *c7_c_y = NULL;
  static char_T c7_b_u[37] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'U', 'n', 's', 'u', 'p', 'p', 'o', 'r', 't', 'e', 'd',
    'S', 'p', 'e', 'c', 'i', 'a', 'l', 'E', 'm', 'p', 't', 'y' };

  int32_T c7_c_x_sizes;
  int32_T c7_b_loop_ub;
  int32_T c7_i193;
  real_T c7_c_x_data[50];
  boolean_T c7_b20;
  const mxArray *c7_d_y = NULL;
  real_T c7_e_y;
  int32_T c7_vlen;
  int32_T c7_b_vlen;
  int32_T c7_k;
  int32_T c7_b_k;
  boolean_T guard1 = false;
  guard1 = false;
  if (c7_x_sizes == 1) {
    guard1 = true;
  } else if ((real_T)c7_x_sizes != 1.0) {
    guard1 = true;
  } else {
    c7_b18 = false;
  }

  if (guard1 == true) {
    c7_b18 = true;
  }

  if (c7_b18) {
  } else {
    c7_b_y = NULL;
    sf_mex_assign(&c7_b_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_b_y));
  }

  c7_b_x_sizes = c7_x_sizes;
  c7_loop_ub = c7_x_sizes - 1;
  for (c7_i192 = 0; c7_i192 <= c7_loop_ub; c7_i192++) {
    c7_b_x_data[c7_i192] = c7_x_data[c7_i192];
  }

  c7_b19 = !c7_c_isequal(chartInstance, c7_b_x_data, c7_b_x_sizes);
  if (c7_b19) {
  } else {
    c7_c_y = NULL;
    sf_mex_assign(&c7_c_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 37),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_c_y));
  }

  c7_c_x_sizes = c7_x_sizes;
  c7_b_loop_ub = c7_x_sizes - 1;
  for (c7_i193 = 0; c7_i193 <= c7_b_loop_ub; c7_i193++) {
    c7_c_x_data[c7_i193] = c7_x_data[c7_i193];
  }

  c7_b20 = !c7_c_isequal(chartInstance, c7_c_x_data, c7_c_x_sizes);
  if (c7_b20) {
  } else {
    c7_d_y = NULL;
    sf_mex_assign(&c7_d_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1, 37),
                  false);
    sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                      sf_mex_call_debug(sfGlobalDebugInstanceStruct, "message",
      1U, 1U, 14, c7_d_y));
  }

  if (c7_x_sizes == 0) {
    c7_e_y = 0.0;
  } else {
    c7_vlen = c7_x_sizes;
    c7_e_y = c7_x_data[0];
    c7_b_vlen = c7_vlen;
    for (c7_k = 2; c7_k <= c7_b_vlen; c7_k++) {
      c7_b_k = c7_k - 1;
      c7_e_y += c7_x_data[c7_b_k];
    }
  }

  return c7_rdivide(chartInstance, c7_e_y, (real_T)c7_x_sizes);
}

static void c7_b_scalarEg(SFc7_XsensLibrary2InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static boolean_T c7_c_isequal(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  real_T c7_varargin_1_data[], int32_T c7_varargin_1_sizes)
{
  boolean_T c7_p;
  boolean_T c7_b_p;
  int32_T c7_k;
  real_T c7_b_k;
  real_T c7_d4;
  real_T c7_d5;
  boolean_T c7_b21;
  boolean_T c7_c_p;
  int32_T exitg1;
  (void)chartInstance;
  (void)c7_varargin_1_data;
  c7_p = false;
  c7_b_p = false;
  c7_k = 0;
  do {
    exitg1 = 0;
    if (c7_k < 2) {
      c7_b_k = 1.0 + (real_T)c7_k;
      c7_d4 = c7_b_k;
      if (c7_d4 <= 1.0) {
        c7_d5 = (real_T)c7_varargin_1_sizes;
      } else {
        c7_d5 = 1.0;
      }

      if (c7_d5 != 0.0) {
        exitg1 = 1;
      } else {
        c7_k++;
      }
    } else {
      c7_b_p = true;
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  c7_b21 = c7_b_p;
  c7_c_p = c7_b21;
  if (!c7_c_p) {
  } else {
    c7_p = true;
  }

  return c7_p;
}

static void c7_dimagree(SFc7_XsensLibrary2InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static uint16_T c7_ceil(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  uint16_T c7_x)
{
  uint16_T c7_b_x;
  c7_b_x = c7_x;
  c7_b_ceil(chartInstance, &c7_b_x);
  return c7_b_x;
}

static void init_script_number_translation(uint32_T c7_machineNumber, uint32_T
  c7_chartNumber, uint32_T c7_instanceNumber)
{
  (void)c7_machineNumber;
  (void)c7_chartNumber;
  (void)c7_instanceNumber;
}

static const mxArray *c7_sf_marshallOut(void *chartInstanceVoid, void *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  real_T c7_u;
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u = *(real_T *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static real_T c7_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  real_T c7_y;
  real_T c7_d6;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_d6, 1, 0, 0U, 0, 0U, 0);
  c7_y = c7_d6;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static void c7_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_nargout;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  real_T c7_y;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_nargout = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_y = c7_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_nargout), &c7_thisId);
  sf_mex_destroy(&c7_nargout);
  *(real_T *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_b_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData;
  c7_bus_datastruct c7_u;
  const mxArray *c7_y = NULL;
  int32_T c7_i194;
  real32_T c7_b_u[200];
  const mxArray *c7_b_y = NULL;
  int32_T c7_i195;
  const mxArray *c7_c_y = NULL;
  int32_T c7_i196;
  const mxArray *c7_d_y = NULL;
  int32_T c7_i197;
  const mxArray *c7_e_y = NULL;
  int32_T c7_i198;
  const mxArray *c7_f_y = NULL;
  int32_T c7_i199;
  const mxArray *c7_g_y = NULL;
  int32_T c7_i200;
  const mxArray *c7_h_y = NULL;
  int32_T c7_i201;
  const mxArray *c7_i_y = NULL;
  int32_T c7_i202;
  const mxArray *c7_j_y = NULL;
  int32_T c7_i203;
  const mxArray *c7_k_y = NULL;
  int32_T c7_i204;
  const mxArray *c7_l_y = NULL;
  int32_T c7_i205;
  const mxArray *c7_m_y = NULL;
  int32_T c7_i206;
  const mxArray *c7_n_y = NULL;
  int32_T c7_i207;
  const mxArray *c7_o_y = NULL;
  uint16_T c7_c_u;
  const mxArray *c7_p_y = NULL;
  uint8_T c7_d_u;
  const mxArray *c7_q_y = NULL;
  uint16_T c7_e_u;
  const mxArray *c7_r_y = NULL;
  uint16_T c7_f_u;
  const mxArray *c7_s_y = NULL;
  boolean_T c7_g_u;
  const mxArray *c7_t_y = NULL;
  boolean_T c7_h_u;
  const mxArray *c7_u_y = NULL;
  int8_T c7_i_u;
  const mxArray *c7_v_y = NULL;
  int8_T c7_j_u;
  const mxArray *c7_w_y = NULL;
  int8_T c7_k_u;
  const mxArray *c7_x_y = NULL;
  int32_T c7_i208;
  real32_T c7_l_u[5];
  const mxArray *c7_y_y = NULL;
  int32_T c7_i209;
  const mxArray *c7_ab_y = NULL;
  int32_T c7_i210;
  const mxArray *c7_bb_y = NULL;
  int32_T c7_i211;
  const mxArray *c7_cb_y = NULL;
  uint8_T c7_m_u;
  const mxArray *c7_db_y = NULL;
  uint8_T c7_n_u;
  const mxArray *c7_eb_y = NULL;
  uint8_T c7_o_u;
  const mxArray *c7_fb_y = NULL;
  uint8_T c7_p_u;
  const mxArray *c7_gb_y = NULL;
  int32_T c7_i212;
  const mxArray *c7_hb_y = NULL;
  int32_T c7_i213;
  const mxArray *c7_ib_y = NULL;
  int32_T c7_i214;
  const mxArray *c7_jb_y = NULL;
  int32_T c7_i215;
  const mxArray *c7_kb_y = NULL;
  uint8_T c7_q_u;
  const mxArray *c7_lb_y = NULL;
  uint8_T c7_r_u;
  const mxArray *c7_mb_y = NULL;
  uint8_T c7_s_u;
  const mxArray *c7_nb_y = NULL;
  uint8_T c7_t_u;
  const mxArray *c7_ob_y = NULL;
  int32_T c7_i216;
  const mxArray *c7_pb_y = NULL;
  int32_T c7_i217;
  const mxArray *c7_qb_y = NULL;
  int32_T c7_i218;
  const mxArray *c7_rb_y = NULL;
  int32_T c7_i219;
  const mxArray *c7_sb_y = NULL;
  uint8_T c7_u_u;
  const mxArray *c7_tb_y = NULL;
  uint8_T c7_v_u;
  const mxArray *c7_ub_y = NULL;
  uint8_T c7_w_u;
  const mxArray *c7_vb_y = NULL;
  uint8_T c7_x_u;
  const mxArray *c7_wb_y = NULL;
  int32_T c7_i220;
  const mxArray *c7_xb_y = NULL;
  int32_T c7_i221;
  const mxArray *c7_yb_y = NULL;
  int32_T c7_i222;
  const mxArray *c7_ac_y = NULL;
  int32_T c7_i223;
  const mxArray *c7_bc_y = NULL;
  uint8_T c7_y_u;
  const mxArray *c7_cc_y = NULL;
  int32_T c7_i224;
  uint16_T c7_ab_u[10];
  const mxArray *c7_dc_y = NULL;
  boolean_T c7_bb_u;
  const mxArray *c7_ec_y = NULL;
  boolean_T c7_cb_u;
  const mxArray *c7_fc_y = NULL;
  boolean_T c7_db_u;
  const mxArray *c7_gc_y = NULL;
  boolean_T c7_eb_u;
  const mxArray *c7_hc_y = NULL;
  boolean_T c7_fb_u;
  const mxArray *c7_ic_y = NULL;
  boolean_T c7_gb_u;
  const mxArray *c7_jc_y = NULL;
  boolean_T c7_hb_u;
  const mxArray *c7_kc_y = NULL;
  boolean_T c7_ib_u;
  const mxArray *c7_lc_y = NULL;
  boolean_T c7_jb_u;
  const mxArray *c7_mc_y = NULL;
  boolean_T c7_kb_u;
  const mxArray *c7_nc_y = NULL;
  boolean_T c7_lb_u;
  const mxArray *c7_oc_y = NULL;
  boolean_T c7_mb_u;
  const mxArray *c7_pc_y = NULL;
  boolean_T c7_nb_u;
  const mxArray *c7_qc_y = NULL;
  boolean_T c7_ob_u;
  const mxArray *c7_rc_y = NULL;
  boolean_T c7_pb_u;
  const mxArray *c7_sc_y = NULL;
  boolean_T c7_qb_u;
  const mxArray *c7_tc_y = NULL;
  boolean_T c7_rb_u;
  const mxArray *c7_uc_y = NULL;
  boolean_T c7_sb_u;
  const mxArray *c7_vc_y = NULL;
  uint16_T c7_tb_u;
  const mxArray *c7_wc_y = NULL;
  uint16_T c7_ub_u;
  const mxArray *c7_xc_y = NULL;
  int32_T c7_i225;
  const mxArray *c7_yc_y = NULL;
  int32_T c7_i226;
  const mxArray *c7_ad_y = NULL;
  int32_T c7_i227;
  const mxArray *c7_bd_y = NULL;
  int32_T c7_i228;
  const mxArray *c7_cd_y = NULL;
  int32_T c7_i229;
  const mxArray *c7_dd_y = NULL;
  int32_T c7_i230;
  const mxArray *c7_ed_y = NULL;
  uint8_T c7_vb_u;
  const mxArray *c7_fd_y = NULL;
  uint8_T c7_wb_u;
  const mxArray *c7_gd_y = NULL;
  uint8_T c7_xb_u;
  const mxArray *c7_hd_y = NULL;
  uint8_T c7_yb_u;
  const mxArray *c7_id_y = NULL;
  uint8_T c7_ac_u;
  const mxArray *c7_jd_y = NULL;
  uint8_T c7_bc_u;
  const mxArray *c7_kd_y = NULL;
  real32_T c7_cc_u;
  const mxArray *c7_ld_y = NULL;
  real32_T c7_dc_u;
  const mxArray *c7_md_y = NULL;
  real32_T c7_ec_u;
  const mxArray *c7_nd_y = NULL;
  real32_T c7_fc_u;
  const mxArray *c7_od_y = NULL;
  real32_T c7_gc_u;
  const mxArray *c7_pd_y = NULL;
  real32_T c7_hc_u;
  const mxArray *c7_qd_y = NULL;
  real32_T c7_ic_u;
  const mxArray *c7_rd_y = NULL;
  real32_T c7_jc_u;
  const mxArray *c7_sd_y = NULL;
  real32_T c7_kc_u;
  const mxArray *c7_td_y = NULL;
  real32_T c7_lc_u;
  const mxArray *c7_ud_y = NULL;
  real32_T c7_mc_u;
  const mxArray *c7_vd_y = NULL;
  real32_T c7_nc_u;
  const mxArray *c7_wd_y = NULL;
  real32_T c7_oc_u;
  const mxArray *c7_xd_y = NULL;
  real32_T c7_pc_u;
  const mxArray *c7_yd_y = NULL;
  uint16_T c7_qc_u;
  const mxArray *c7_ae_y = NULL;
  real32_T c7_rc_u;
  const mxArray *c7_be_y = NULL;
  real32_T c7_sc_u;
  const mxArray *c7_ce_y = NULL;
  real32_T c7_tc_u;
  const mxArray *c7_de_y = NULL;
  real32_T c7_uc_u;
  const mxArray *c7_ee_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_mxArrayOutData = NULL;
  c7_u = *(c7_bus_datastruct *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_createstruct("structure", 2, 1, 1), false);
  for (c7_i194 = 0; c7_i194 < 200; c7_i194++) {
    c7_b_u[c7_i194] = c7_u.VelRShank[c7_i194];
  }

  c7_b_y = NULL;
  sf_mex_assign(&c7_b_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_b_y, "VelRShank", "VelRShank", 0);
  for (c7_i195 = 0; c7_i195 < 200; c7_i195++) {
    c7_b_u[c7_i195] = c7_u.VelLShank[c7_i195];
  }

  c7_c_y = NULL;
  sf_mex_assign(&c7_c_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_c_y, "VelLShank", "VelLShank", 0);
  for (c7_i196 = 0; c7_i196 < 200; c7_i196++) {
    c7_b_u[c7_i196] = c7_u.AngRShank[c7_i196];
  }

  c7_d_y = NULL;
  sf_mex_assign(&c7_d_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_d_y, "AngRShank", "AngRShank", 0);
  for (c7_i197 = 0; c7_i197 < 200; c7_i197++) {
    c7_b_u[c7_i197] = c7_u.AngLShank[c7_i197];
  }

  c7_e_y = NULL;
  sf_mex_assign(&c7_e_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_e_y, "AngLShank", "AngLShank", 0);
  for (c7_i198 = 0; c7_i198 < 200; c7_i198++) {
    c7_b_u[c7_i198] = c7_u.VelRShank_filt[c7_i198];
  }

  c7_f_y = NULL;
  sf_mex_assign(&c7_f_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_f_y, "VelRShank_filt", "VelRShank_filt", 0);
  for (c7_i199 = 0; c7_i199 < 200; c7_i199++) {
    c7_b_u[c7_i199] = c7_u.VelLShank_filt[c7_i199];
  }

  c7_g_y = NULL;
  sf_mex_assign(&c7_g_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_g_y, "VelLShank_filt", "VelLShank_filt", 0);
  for (c7_i200 = 0; c7_i200 < 200; c7_i200++) {
    c7_b_u[c7_i200] = c7_u.AngRShank_filt[c7_i200];
  }

  c7_h_y = NULL;
  sf_mex_assign(&c7_h_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_h_y, "AngRShank_filt", "AngRShank_filt", 0);
  for (c7_i201 = 0; c7_i201 < 200; c7_i201++) {
    c7_b_u[c7_i201] = c7_u.AngLShank_filt[c7_i201];
  }

  c7_i_y = NULL;
  sf_mex_assign(&c7_i_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_i_y, "AngLShank_filt", "AngLShank_filt", 0);
  for (c7_i202 = 0; c7_i202 < 200; c7_i202++) {
    c7_b_u[c7_i202] = c7_u.VelRShank_LPF[c7_i202];
  }

  c7_j_y = NULL;
  sf_mex_assign(&c7_j_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_j_y, "VelRShank_LPF", "VelRShank_LPF", 0);
  for (c7_i203 = 0; c7_i203 < 200; c7_i203++) {
    c7_b_u[c7_i203] = c7_u.VelLShank_LPF[c7_i203];
  }

  c7_k_y = NULL;
  sf_mex_assign(&c7_k_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_k_y, "VelLShank_LPF", "VelLShank_LPF", 0);
  for (c7_i204 = 0; c7_i204 < 200; c7_i204++) {
    c7_b_u[c7_i204] = c7_u.AngRShank_LPF[c7_i204];
  }

  c7_l_y = NULL;
  sf_mex_assign(&c7_l_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_l_y, "AngRShank_LPF", "AngRShank_LPF", 0);
  for (c7_i205 = 0; c7_i205 < 200; c7_i205++) {
    c7_b_u[c7_i205] = c7_u.AngLShank_LPF[c7_i205];
  }

  c7_m_y = NULL;
  sf_mex_assign(&c7_m_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_m_y, "AngLShank_LPF", "AngLShank_LPF", 0);
  for (c7_i206 = 0; c7_i206 < 200; c7_i206++) {
    c7_b_u[c7_i206] = c7_u.AngRShank_LPF2Hz[c7_i206];
  }

  c7_n_y = NULL;
  sf_mex_assign(&c7_n_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_n_y, "AngRShank_LPF2Hz", "AngRShank_LPF2Hz", 0);
  for (c7_i207 = 0; c7_i207 < 200; c7_i207++) {
    c7_b_u[c7_i207] = c7_u.AngLShank_LPF2Hz[c7_i207];
  }

  c7_o_y = NULL;
  sf_mex_assign(&c7_o_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_o_y, "AngLShank_LPF2Hz", "AngLShank_LPF2Hz", 0);
  c7_c_u = c7_u.counter_stop;
  c7_p_y = NULL;
  sf_mex_assign(&c7_p_y, sf_mex_create("y", &c7_c_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_p_y, "counter_stop", "counter_stop", 0);
  c7_d_u = c7_u.counter;
  c7_q_y = NULL;
  sf_mex_assign(&c7_q_y, sf_mex_create("y", &c7_d_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_q_y, "counter", "counter", 0);
  c7_e_u = c7_u.index_start_calib;
  c7_r_y = NULL;
  sf_mex_assign(&c7_r_y, sf_mex_create("y", &c7_e_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_r_y, "index_start_calib", "index_start_calib", 0);
  c7_f_u = c7_u.index_stop_calib;
  c7_s_y = NULL;
  sf_mex_assign(&c7_s_y, sf_mex_create("y", &c7_f_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_s_y, "index_stop_calib", "index_stop_calib", 0);
  c7_g_u = c7_u.initial_leg;
  c7_t_y = NULL;
  sf_mex_assign(&c7_t_y, sf_mex_create("y", &c7_g_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_t_y, "initial_leg", "initial_leg", 0);
  c7_h_u = c7_u.flag_calib;
  c7_u_y = NULL;
  sf_mex_assign(&c7_u_y, sf_mex_create("y", &c7_h_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_u_y, "flag_calib", "flag_calib", 0);
  c7_i_u = c7_u.calibrating;
  c7_v_y = NULL;
  sf_mex_assign(&c7_v_y, sf_mex_create("y", &c7_i_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_v_y, "calibrating", "calibrating", 0);
  c7_j_u = c7_u.state;
  c7_w_y = NULL;
  sf_mex_assign(&c7_w_y, sf_mex_create("y", &c7_j_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_w_y, "state", "state", 0);
  c7_k_u = c7_u.prevstate;
  c7_x_y = NULL;
  sf_mex_assign(&c7_x_y, sf_mex_create("y", &c7_k_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_x_y, "prevstate", "prevstate", 0);
  for (c7_i208 = 0; c7_i208 < 5; c7_i208++) {
    c7_l_u[c7_i208] = c7_u.MA_maxs_right[c7_i208];
  }

  c7_y_y = NULL;
  sf_mex_assign(&c7_y_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_y_y, "MA_maxs_right", "MA_maxs_right", 0);
  for (c7_i209 = 0; c7_i209 < 5; c7_i209++) {
    c7_l_u[c7_i209] = c7_u.MA_maxs_left[c7_i209];
  }

  c7_ab_y = NULL;
  sf_mex_assign(&c7_ab_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_ab_y, "MA_maxs_left", "MA_maxs_left", 0);
  for (c7_i210 = 0; c7_i210 < 5; c7_i210++) {
    c7_l_u[c7_i210] = c7_u.MA_LPF_maxs_right[c7_i210];
  }

  c7_bb_y = NULL;
  sf_mex_assign(&c7_bb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_bb_y, "MA_LPF_maxs_right", "MA_LPF_maxs_right", 0);
  for (c7_i211 = 0; c7_i211 < 5; c7_i211++) {
    c7_l_u[c7_i211] = c7_u.MA_LPF_maxs_left[c7_i211];
  }

  c7_cb_y = NULL;
  sf_mex_assign(&c7_cb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_cb_y, "MA_LPF_maxs_left", "MA_LPF_maxs_left", 0);
  c7_m_u = c7_u.MA_LPF_index_right;
  c7_db_y = NULL;
  sf_mex_assign(&c7_db_y, sf_mex_create("y", &c7_m_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_db_y, "MA_LPF_index_right", "MA_LPF_index_right", 0);
  c7_n_u = c7_u.MA_LPF_index_left;
  c7_eb_y = NULL;
  sf_mex_assign(&c7_eb_y, sf_mex_create("y", &c7_n_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_eb_y, "MA_LPF_index_left", "MA_LPF_index_left", 0);
  c7_o_u = c7_u.MA_index_right;
  c7_fb_y = NULL;
  sf_mex_assign(&c7_fb_y, sf_mex_create("y", &c7_o_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_fb_y, "MA_index_right", "MA_index_right", 0);
  c7_p_u = c7_u.MA_index_left;
  c7_gb_y = NULL;
  sf_mex_assign(&c7_gb_y, sf_mex_create("y", &c7_p_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_gb_y, "MA_index_left", "MA_index_left", 0);
  for (c7_i212 = 0; c7_i212 < 5; c7_i212++) {
    c7_l_u[c7_i212] = c7_u.IC_mins_right[c7_i212];
  }

  c7_hb_y = NULL;
  sf_mex_assign(&c7_hb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_hb_y, "IC_mins_right", "IC_mins_right", 0);
  for (c7_i213 = 0; c7_i213 < 5; c7_i213++) {
    c7_l_u[c7_i213] = c7_u.IC_mins_left[c7_i213];
  }

  c7_ib_y = NULL;
  sf_mex_assign(&c7_ib_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_ib_y, "IC_mins_left", "IC_mins_left", 0);
  for (c7_i214 = 0; c7_i214 < 5; c7_i214++) {
    c7_l_u[c7_i214] = c7_u.IC_LPF_mins_right[c7_i214];
  }

  c7_jb_y = NULL;
  sf_mex_assign(&c7_jb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_jb_y, "IC_LPF_mins_right", "IC_LPF_mins_right", 0);
  for (c7_i215 = 0; c7_i215 < 5; c7_i215++) {
    c7_l_u[c7_i215] = c7_u.IC_LPF_mins_left[c7_i215];
  }

  c7_kb_y = NULL;
  sf_mex_assign(&c7_kb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_kb_y, "IC_LPF_mins_left", "IC_LPF_mins_left", 0);
  c7_q_u = c7_u.IC_LPF_index_right;
  c7_lb_y = NULL;
  sf_mex_assign(&c7_lb_y, sf_mex_create("y", &c7_q_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_lb_y, "IC_LPF_index_right", "IC_LPF_index_right", 0);
  c7_r_u = c7_u.IC_LPF_index_left;
  c7_mb_y = NULL;
  sf_mex_assign(&c7_mb_y, sf_mex_create("y", &c7_r_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_mb_y, "IC_LPF_index_left", "IC_LPF_index_left", 0);
  c7_s_u = c7_u.IC_index_right;
  c7_nb_y = NULL;
  sf_mex_assign(&c7_nb_y, sf_mex_create("y", &c7_s_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_nb_y, "IC_index_right", "IC_index_right", 0);
  c7_t_u = c7_u.IC_index_left;
  c7_ob_y = NULL;
  sf_mex_assign(&c7_ob_y, sf_mex_create("y", &c7_t_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ob_y, "IC_index_left", "IC_index_left", 0);
  for (c7_i216 = 0; c7_i216 < 5; c7_i216++) {
    c7_l_u[c7_i216] = c7_u.EC_events_mins_right[c7_i216];
  }

  c7_pb_y = NULL;
  sf_mex_assign(&c7_pb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_pb_y, "EC_events_mins_right", "EC_events_mins_right",
                  0);
  for (c7_i217 = 0; c7_i217 < 5; c7_i217++) {
    c7_l_u[c7_i217] = c7_u.EC_events_mins_left[c7_i217];
  }

  c7_qb_y = NULL;
  sf_mex_assign(&c7_qb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_qb_y, "EC_events_mins_left", "EC_events_mins_left", 0);
  for (c7_i218 = 0; c7_i218 < 5; c7_i218++) {
    c7_l_u[c7_i218] = c7_u.EC_peaks_mins_right[c7_i218];
  }

  c7_rb_y = NULL;
  sf_mex_assign(&c7_rb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_rb_y, "EC_peaks_mins_right", "EC_peaks_mins_right", 0);
  for (c7_i219 = 0; c7_i219 < 5; c7_i219++) {
    c7_l_u[c7_i219] = c7_u.EC_peaks_mins_left[c7_i219];
  }

  c7_sb_y = NULL;
  sf_mex_assign(&c7_sb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_sb_y, "EC_peaks_mins_left", "EC_peaks_mins_left", 0);
  c7_u_u = c7_u.EC_events_index_right;
  c7_tb_y = NULL;
  sf_mex_assign(&c7_tb_y, sf_mex_create("y", &c7_u_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_tb_y, "EC_events_index_right",
                  "EC_events_index_right", 0);
  c7_v_u = c7_u.EC_events_index_left;
  c7_ub_y = NULL;
  sf_mex_assign(&c7_ub_y, sf_mex_create("y", &c7_v_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ub_y, "EC_events_index_left", "EC_events_index_left",
                  0);
  c7_w_u = c7_u.EC_peaks_index_right;
  c7_vb_y = NULL;
  sf_mex_assign(&c7_vb_y, sf_mex_create("y", &c7_w_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_vb_y, "EC_peaks_index_right", "EC_peaks_index_right",
                  0);
  c7_x_u = c7_u.EC_peaks_index_left;
  c7_wb_y = NULL;
  sf_mex_assign(&c7_wb_y, sf_mex_create("y", &c7_x_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_wb_y, "EC_peaks_index_left", "EC_peaks_index_left", 0);
  for (c7_i220 = 0; c7_i220 < 5; c7_i220++) {
    c7_l_u[c7_i220] = c7_u.AN_events_right[c7_i220];
  }

  c7_xb_y = NULL;
  sf_mex_assign(&c7_xb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_xb_y, "AN_events_right", "AN_events_right", 0);
  for (c7_i221 = 0; c7_i221 < 5; c7_i221++) {
    c7_l_u[c7_i221] = c7_u.AN_events_left[c7_i221];
  }

  c7_yb_y = NULL;
  sf_mex_assign(&c7_yb_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_yb_y, "AN_events_left", "AN_events_left", 0);
  for (c7_i222 = 0; c7_i222 < 5; c7_i222++) {
    c7_l_u[c7_i222] = c7_u.AN_peaks_right[c7_i222];
  }

  c7_ac_y = NULL;
  sf_mex_assign(&c7_ac_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_ac_y, "AN_peaks_right", "AN_peaks_right", 0);
  for (c7_i223 = 0; c7_i223 < 5; c7_i223++) {
    c7_l_u[c7_i223] = c7_u.AN_peaks_left[c7_i223];
  }

  c7_bc_y = NULL;
  sf_mex_assign(&c7_bc_y, sf_mex_create("y", c7_l_u, 1, 0U, 1U, 0U, 2, 1, 5),
                false);
  sf_mex_addfield(c7_y, c7_bc_y, "AN_peaks_left", "AN_peaks_left", 0);
  c7_y_u = c7_u.stop_DS_index;
  c7_cc_y = NULL;
  sf_mex_assign(&c7_cc_y, sf_mex_create("y", &c7_y_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_cc_y, "stop_DS_index", "stop_DS_index", 0);
  for (c7_i224 = 0; c7_i224 < 10; c7_i224++) {
    c7_ab_u[c7_i224] = c7_u.stop_DS[c7_i224];
  }

  c7_dc_y = NULL;
  sf_mex_assign(&c7_dc_y, sf_mex_create("y", c7_ab_u, 5, 0U, 1U, 0U, 2, 1, 10),
                false);
  sf_mex_addfield(c7_y, c7_dc_y, "stop_DS", "stop_DS", 0);
  c7_bb_u = c7_u.MS_event_left;
  c7_ec_y = NULL;
  sf_mex_assign(&c7_ec_y, sf_mex_create("y", &c7_bb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ec_y, "MS_event_left", "MS_event_left", 0);
  c7_cb_u = c7_u.MS_event_right;
  c7_fc_y = NULL;
  sf_mex_assign(&c7_fc_y, sf_mex_create("y", &c7_cb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_fc_y, "MS_event_right", "MS_event_right", 0);
  c7_db_u = c7_u.EC_event_left;
  c7_gc_y = NULL;
  sf_mex_assign(&c7_gc_y, sf_mex_create("y", &c7_db_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_gc_y, "EC_event_left", "EC_event_left", 0);
  c7_eb_u = c7_u.EC_event_right;
  c7_hc_y = NULL;
  sf_mex_assign(&c7_hc_y, sf_mex_create("y", &c7_eb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_hc_y, "EC_event_right", "EC_event_right", 0);
  c7_fb_u = c7_u.IC_event_left;
  c7_ic_y = NULL;
  sf_mex_assign(&c7_ic_y, sf_mex_create("y", &c7_fb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ic_y, "IC_event_left", "IC_event_left", 0);
  c7_gb_u = c7_u.IC_event_right;
  c7_jc_y = NULL;
  sf_mex_assign(&c7_jc_y, sf_mex_create("y", &c7_gb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_jc_y, "IC_event_right", "IC_event_right", 0);
  c7_hb_u = c7_u.AN_event_left;
  c7_kc_y = NULL;
  sf_mex_assign(&c7_kc_y, sf_mex_create("y", &c7_hb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_kc_y, "AN_event_left", "AN_event_left", 0);
  c7_ib_u = c7_u.AN_event_right;
  c7_lc_y = NULL;
  sf_mex_assign(&c7_lc_y, sf_mex_create("y", &c7_ib_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_lc_y, "AN_event_right", "AN_event_right", 0);
  c7_jb_u = c7_u.MA_event_left;
  c7_mc_y = NULL;
  sf_mex_assign(&c7_mc_y, sf_mex_create("y", &c7_jb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_mc_y, "MA_event_left", "MA_event_left", 0);
  c7_kb_u = c7_u.MA_event_right;
  c7_nc_y = NULL;
  sf_mex_assign(&c7_nc_y, sf_mex_create("y", &c7_kb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_nc_y, "MA_event_right", "MA_event_right", 0);
  c7_lb_u = c7_u.stop_Vel_event_left;
  c7_oc_y = NULL;
  sf_mex_assign(&c7_oc_y, sf_mex_create("y", &c7_lb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_oc_y, "stop_Vel_event_left", "stop_Vel_event_left", 0);
  c7_mb_u = c7_u.stop_Vel_event_right;
  c7_pc_y = NULL;
  sf_mex_assign(&c7_pc_y, sf_mex_create("y", &c7_mb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_pc_y, "stop_Vel_event_right", "stop_Vel_event_right",
                  0);
  c7_nb_u = c7_u.stop_MA_event_left;
  c7_qc_y = NULL;
  sf_mex_assign(&c7_qc_y, sf_mex_create("y", &c7_nb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_qc_y, "stop_MA_event_left", "stop_MA_event_left", 0);
  c7_ob_u = c7_u.stop_MA_event_right;
  c7_rc_y = NULL;
  sf_mex_assign(&c7_rc_y, sf_mex_create("y", &c7_ob_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_rc_y, "stop_MA_event_right", "stop_MA_event_right", 0);
  c7_pb_u = c7_u.stop_IC_event_left;
  c7_sc_y = NULL;
  sf_mex_assign(&c7_sc_y, sf_mex_create("y", &c7_pb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_sc_y, "stop_IC_event_left", "stop_IC_event_left", 0);
  c7_qb_u = c7_u.stop_IC_event_right;
  c7_tc_y = NULL;
  sf_mex_assign(&c7_tc_y, sf_mex_create("y", &c7_qb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_tc_y, "stop_IC_event_right", "stop_IC_event_right", 0);
  c7_rb_u = c7_u.MA_flag_right;
  c7_uc_y = NULL;
  sf_mex_assign(&c7_uc_y, sf_mex_create("y", &c7_rb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_uc_y, "MA_flag_right", "MA_flag_right", 0);
  c7_sb_u = c7_u.MA_flag_left;
  c7_vc_y = NULL;
  sf_mex_assign(&c7_vc_y, sf_mex_create("y", &c7_sb_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_vc_y, "MA_flag_left", "MA_flag_left", 0);
  c7_tb_u = c7_u.last_EC;
  c7_wc_y = NULL;
  sf_mex_assign(&c7_wc_y, sf_mex_create("y", &c7_tb_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_wc_y, "last_EC", "last_EC", 0);
  c7_ub_u = c7_u.last_IC;
  c7_xc_y = NULL;
  sf_mex_assign(&c7_xc_y, sf_mex_create("y", &c7_ub_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_xc_y, "last_IC", "last_IC", 0);
  for (c7_i225 = 0; c7_i225 < 200; c7_i225++) {
    c7_b_u[c7_i225] = c7_u.IC_buffer_left[c7_i225];
  }

  c7_yc_y = NULL;
  sf_mex_assign(&c7_yc_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_yc_y, "IC_buffer_left", "IC_buffer_left", 0);
  for (c7_i226 = 0; c7_i226 < 200; c7_i226++) {
    c7_b_u[c7_i226] = c7_u.IC_buffer_right[c7_i226];
  }

  c7_ad_y = NULL;
  sf_mex_assign(&c7_ad_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_ad_y, "IC_buffer_right", "IC_buffer_right", 0);
  for (c7_i227 = 0; c7_i227 < 200; c7_i227++) {
    c7_b_u[c7_i227] = c7_u.EC_buffer_left[c7_i227];
  }

  c7_bd_y = NULL;
  sf_mex_assign(&c7_bd_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_bd_y, "EC_buffer_left", "EC_buffer_left", 0);
  for (c7_i228 = 0; c7_i228 < 200; c7_i228++) {
    c7_b_u[c7_i228] = c7_u.EC_buffer_right[c7_i228];
  }

  c7_cd_y = NULL;
  sf_mex_assign(&c7_cd_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_cd_y, "EC_buffer_right", "EC_buffer_right", 0);
  for (c7_i229 = 0; c7_i229 < 200; c7_i229++) {
    c7_b_u[c7_i229] = c7_u.MS_buffer_left[c7_i229];
  }

  c7_dd_y = NULL;
  sf_mex_assign(&c7_dd_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_dd_y, "MS_buffer_left", "MS_buffer_left", 0);
  for (c7_i230 = 0; c7_i230 < 200; c7_i230++) {
    c7_b_u[c7_i230] = c7_u.MS_buffer_right[c7_i230];
  }

  c7_ed_y = NULL;
  sf_mex_assign(&c7_ed_y, sf_mex_create("y", c7_b_u, 1, 0U, 1U, 0U, 1, 200),
                false);
  sf_mex_addfield(c7_y, c7_ed_y, "MS_buffer_right", "MS_buffer_right", 0);
  c7_vb_u = c7_u.IC_buffer_index_left;
  c7_fd_y = NULL;
  sf_mex_assign(&c7_fd_y, sf_mex_create("y", &c7_vb_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_fd_y, "IC_buffer_index_left", "IC_buffer_index_left",
                  0);
  c7_wb_u = c7_u.IC_buffer_index_right;
  c7_gd_y = NULL;
  sf_mex_assign(&c7_gd_y, sf_mex_create("y", &c7_wb_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_gd_y, "IC_buffer_index_right",
                  "IC_buffer_index_right", 0);
  c7_xb_u = c7_u.EC_buffer_index_left;
  c7_hd_y = NULL;
  sf_mex_assign(&c7_hd_y, sf_mex_create("y", &c7_xb_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_hd_y, "EC_buffer_index_left", "EC_buffer_index_left",
                  0);
  c7_yb_u = c7_u.EC_buffer_index_right;
  c7_id_y = NULL;
  sf_mex_assign(&c7_id_y, sf_mex_create("y", &c7_yb_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_id_y, "EC_buffer_index_right",
                  "EC_buffer_index_right", 0);
  c7_ac_u = c7_u.MS_buffer_index_left;
  c7_jd_y = NULL;
  sf_mex_assign(&c7_jd_y, sf_mex_create("y", &c7_ac_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_jd_y, "MS_buffer_index_left", "MS_buffer_index_left",
                  0);
  c7_bc_u = c7_u.MS_buffer_index_right;
  c7_kd_y = NULL;
  sf_mex_assign(&c7_kd_y, sf_mex_create("y", &c7_bc_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_kd_y, "MS_buffer_index_right",
                  "MS_buffer_index_right", 0);
  c7_cc_u = c7_u.MA_th_left;
  c7_ld_y = NULL;
  sf_mex_assign(&c7_ld_y, sf_mex_create("y", &c7_cc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ld_y, "MA_th_left", "MA_th_left", 0);
  c7_dc_u = c7_u.MA_th_right;
  c7_md_y = NULL;
  sf_mex_assign(&c7_md_y, sf_mex_create("y", &c7_dc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_md_y, "MA_th_right", "MA_th_right", 0);
  c7_ec_u = c7_u.IC_th_left;
  c7_nd_y = NULL;
  sf_mex_assign(&c7_nd_y, sf_mex_create("y", &c7_ec_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_nd_y, "IC_th_left", "IC_th_left", 0);
  c7_fc_u = c7_u.IC_th_right;
  c7_od_y = NULL;
  sf_mex_assign(&c7_od_y, sf_mex_create("y", &c7_fc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_od_y, "IC_th_right", "IC_th_right", 0);
  c7_gc_u = c7_u.AN_th_right;
  c7_pd_y = NULL;
  sf_mex_assign(&c7_pd_y, sf_mex_create("y", &c7_gc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_pd_y, "AN_th_right", "AN_th_right", 0);
  c7_hc_u = c7_u.AN_th_left;
  c7_qd_y = NULL;
  sf_mex_assign(&c7_qd_y, sf_mex_create("y", &c7_hc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_qd_y, "AN_th_left", "AN_th_left", 0);
  c7_ic_u = c7_u.EC_th_right;
  c7_rd_y = NULL;
  sf_mex_assign(&c7_rd_y, sf_mex_create("y", &c7_ic_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_rd_y, "EC_th_right", "EC_th_right", 0);
  c7_jc_u = c7_u.EC_th_left;
  c7_sd_y = NULL;
  sf_mex_assign(&c7_sd_y, sf_mex_create("y", &c7_jc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_sd_y, "EC_th_left", "EC_th_left", 0);
  c7_kc_u = c7_u.stop_Vel_th_left;
  c7_td_y = NULL;
  sf_mex_assign(&c7_td_y, sf_mex_create("y", &c7_kc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_td_y, "stop_Vel_th_left", "stop_Vel_th_left", 0);
  c7_lc_u = c7_u.stop_Vel_th_right;
  c7_ud_y = NULL;
  sf_mex_assign(&c7_ud_y, sf_mex_create("y", &c7_lc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ud_y, "stop_Vel_th_right", "stop_Vel_th_right", 0);
  c7_mc_u = c7_u.stop_MA_th_left;
  c7_vd_y = NULL;
  sf_mex_assign(&c7_vd_y, sf_mex_create("y", &c7_mc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_vd_y, "stop_MA_th_left", "stop_MA_th_left", 0);
  c7_nc_u = c7_u.stop_MA_th_right;
  c7_wd_y = NULL;
  sf_mex_assign(&c7_wd_y, sf_mex_create("y", &c7_nc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_wd_y, "stop_MA_th_right", "stop_MA_th_right", 0);
  c7_oc_u = c7_u.stop_IC_th_right;
  c7_xd_y = NULL;
  sf_mex_assign(&c7_xd_y, sf_mex_create("y", &c7_oc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_xd_y, "stop_IC_th_right", "stop_IC_th_right", 0);
  c7_pc_u = c7_u.stop_IC_th_left;
  c7_yd_y = NULL;
  sf_mex_assign(&c7_yd_y, sf_mex_create("y", &c7_pc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_yd_y, "stop_IC_th_left", "stop_IC_th_left", 0);
  c7_qc_u = c7_u.stop_DS_th;
  c7_ae_y = NULL;
  sf_mex_assign(&c7_ae_y, sf_mex_create("y", &c7_qc_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ae_y, "stop_DS_th", "stop_DS_th", 0);
  c7_rc_u = c7_u.MA_LPF_th_left;
  c7_be_y = NULL;
  sf_mex_assign(&c7_be_y, sf_mex_create("y", &c7_rc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_be_y, "MA_LPF_th_left", "MA_LPF_th_left", 0);
  c7_sc_u = c7_u.MA_LPF_th_right;
  c7_ce_y = NULL;
  sf_mex_assign(&c7_ce_y, sf_mex_create("y", &c7_sc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ce_y, "MA_LPF_th_right", "MA_LPF_th_right", 0);
  c7_tc_u = c7_u.IC_LPF_th_left;
  c7_de_y = NULL;
  sf_mex_assign(&c7_de_y, sf_mex_create("y", &c7_tc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_de_y, "IC_LPF_th_left", "IC_LPF_th_left", 0);
  c7_uc_u = c7_u.IC_LPF_th_right;
  c7_ee_y = NULL;
  sf_mex_assign(&c7_ee_y, sf_mex_create("y", &c7_uc_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c7_y, c7_ee_y, "IC_LPF_th_right", "IC_LPF_th_right", 0);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static void c7_b_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_data_struct_new, const char_T *c7_identifier,
  c7_bus_datastruct *c7_y)
{
  emlrtMsgIdentifier c7_thisId;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_data_struct_new),
                        &c7_thisId, c7_y);
  sf_mex_destroy(&c7_data_struct_new);
}

static void c7_c_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  c7_bus_datastruct *c7_y)
{
  emlrtMsgIdentifier c7_thisId;
  static const char * c7_fieldNames[104] = { "VelRShank", "VelLShank",
    "AngRShank", "AngLShank", "VelRShank_filt", "VelLShank_filt",
    "AngRShank_filt", "AngLShank_filt", "VelRShank_LPF", "VelLShank_LPF",
    "AngRShank_LPF", "AngLShank_LPF", "AngRShank_LPF2Hz", "AngLShank_LPF2Hz",
    "counter_stop", "counter", "index_start_calib", "index_stop_calib",
    "initial_leg", "flag_calib", "calibrating", "state", "prevstate",
    "MA_maxs_right", "MA_maxs_left", "MA_LPF_maxs_right", "MA_LPF_maxs_left",
    "MA_LPF_index_right", "MA_LPF_index_left", "MA_index_right", "MA_index_left",
    "IC_mins_right", "IC_mins_left", "IC_LPF_mins_right", "IC_LPF_mins_left",
    "IC_LPF_index_right", "IC_LPF_index_left", "IC_index_right", "IC_index_left",
    "EC_events_mins_right", "EC_events_mins_left", "EC_peaks_mins_right",
    "EC_peaks_mins_left", "EC_events_index_right", "EC_events_index_left",
    "EC_peaks_index_right", "EC_peaks_index_left", "AN_events_right",
    "AN_events_left", "AN_peaks_right", "AN_peaks_left", "stop_DS_index",
    "stop_DS", "MS_event_left", "MS_event_right", "EC_event_left",
    "EC_event_right", "IC_event_left", "IC_event_right", "AN_event_left",
    "AN_event_right", "MA_event_left", "MA_event_right", "stop_Vel_event_left",
    "stop_Vel_event_right", "stop_MA_event_left", "stop_MA_event_right",
    "stop_IC_event_left", "stop_IC_event_right", "MA_flag_right", "MA_flag_left",
    "last_EC", "last_IC", "IC_buffer_left", "IC_buffer_right", "EC_buffer_left",
    "EC_buffer_right", "MS_buffer_left", "MS_buffer_right",
    "IC_buffer_index_left", "IC_buffer_index_right", "EC_buffer_index_left",
    "EC_buffer_index_right", "MS_buffer_index_left", "MS_buffer_index_right",
    "MA_th_left", "MA_th_right", "IC_th_left", "IC_th_right", "AN_th_right",
    "AN_th_left", "EC_th_right", "EC_th_left", "stop_Vel_th_left",
    "stop_Vel_th_right", "stop_MA_th_left", "stop_MA_th_right",
    "stop_IC_th_right", "stop_IC_th_left", "stop_DS_th", "MA_LPF_th_left",
    "MA_LPF_th_right", "IC_LPF_th_left", "IC_LPF_th_right" };

  c7_thisId.fParent = c7_parentId;
  c7_thisId.bParentIsCell = false;
  sf_mex_check_struct(c7_parentId, c7_u, 104, c7_fieldNames, 0U, NULL);
  c7_thisId.fIdentifier = "VelRShank";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "VelRShank", "VelRShank", 0)), &c7_thisId, c7_y->VelRShank);
  c7_thisId.fIdentifier = "VelLShank";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "VelLShank", "VelLShank", 0)), &c7_thisId, c7_y->VelLShank);
  c7_thisId.fIdentifier = "AngRShank";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AngRShank", "AngRShank", 0)), &c7_thisId, c7_y->AngRShank);
  c7_thisId.fIdentifier = "AngLShank";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AngLShank", "AngLShank", 0)), &c7_thisId, c7_y->AngLShank);
  c7_thisId.fIdentifier = "VelRShank_filt";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "VelRShank_filt", "VelRShank_filt", 0)), &c7_thisId, c7_y->VelRShank_filt);
  c7_thisId.fIdentifier = "VelLShank_filt";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "VelLShank_filt", "VelLShank_filt", 0)), &c7_thisId, c7_y->VelLShank_filt);
  c7_thisId.fIdentifier = "AngRShank_filt";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AngRShank_filt", "AngRShank_filt", 0)), &c7_thisId, c7_y->AngRShank_filt);
  c7_thisId.fIdentifier = "AngLShank_filt";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AngLShank_filt", "AngLShank_filt", 0)), &c7_thisId, c7_y->AngLShank_filt);
  c7_thisId.fIdentifier = "VelRShank_LPF";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "VelRShank_LPF", "VelRShank_LPF", 0)), &c7_thisId, c7_y->VelRShank_LPF);
  c7_thisId.fIdentifier = "VelLShank_LPF";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "VelLShank_LPF", "VelLShank_LPF", 0)), &c7_thisId, c7_y->VelLShank_LPF);
  c7_thisId.fIdentifier = "AngRShank_LPF";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AngRShank_LPF", "AngRShank_LPF", 0)), &c7_thisId, c7_y->AngRShank_LPF);
  c7_thisId.fIdentifier = "AngLShank_LPF";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AngLShank_LPF", "AngLShank_LPF", 0)), &c7_thisId, c7_y->AngLShank_LPF);
  c7_thisId.fIdentifier = "AngRShank_LPF2Hz";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AngRShank_LPF2Hz", "AngRShank_LPF2Hz", 0)), &c7_thisId,
                        c7_y->AngRShank_LPF2Hz);
  c7_thisId.fIdentifier = "AngLShank_LPF2Hz";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AngLShank_LPF2Hz", "AngLShank_LPF2Hz", 0)), &c7_thisId,
                        c7_y->AngLShank_LPF2Hz);
  c7_thisId.fIdentifier = "counter_stop";
  c7_y->counter_stop = c7_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "counter_stop", "counter_stop", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "counter";
  c7_y->counter = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "counter", "counter", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "index_start_calib";
  c7_y->index_start_calib = c7_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "index_start_calib", "index_start_calib", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "index_stop_calib";
  c7_y->index_stop_calib = c7_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "index_stop_calib", "index_stop_calib", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "initial_leg";
  c7_y->initial_leg = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "initial_leg", "initial_leg", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "flag_calib";
  c7_y->flag_calib = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "flag_calib", "flag_calib", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "calibrating";
  c7_y->calibrating = c7_h_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "calibrating", "calibrating", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "state";
  c7_y->state = c7_h_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield
    (c7_u, "state", "state", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "prevstate";
  c7_y->prevstate = c7_h_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "prevstate", "prevstate", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MA_maxs_right";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "MA_maxs_right", "MA_maxs_right", 0)), &c7_thisId, c7_y->MA_maxs_right);
  c7_thisId.fIdentifier = "MA_maxs_left";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "MA_maxs_left", "MA_maxs_left", 0)), &c7_thisId, c7_y->MA_maxs_left);
  c7_thisId.fIdentifier = "MA_LPF_maxs_right";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "MA_LPF_maxs_right", "MA_LPF_maxs_right", 0)), &c7_thisId,
                        c7_y->MA_LPF_maxs_right);
  c7_thisId.fIdentifier = "MA_LPF_maxs_left";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "MA_LPF_maxs_left", "MA_LPF_maxs_left", 0)), &c7_thisId,
                        c7_y->MA_LPF_maxs_left);
  c7_thisId.fIdentifier = "MA_LPF_index_right";
  c7_y->MA_LPF_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_LPF_index_right", "MA_LPF_index_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "MA_LPF_index_left";
  c7_y->MA_LPF_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_LPF_index_left", "MA_LPF_index_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "MA_index_right";
  c7_y->MA_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_index_right", "MA_index_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MA_index_left";
  c7_y->MA_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_index_left", "MA_index_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_mins_right";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "IC_mins_right", "IC_mins_right", 0)), &c7_thisId, c7_y->IC_mins_right);
  c7_thisId.fIdentifier = "IC_mins_left";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "IC_mins_left", "IC_mins_left", 0)), &c7_thisId, c7_y->IC_mins_left);
  c7_thisId.fIdentifier = "IC_LPF_mins_right";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "IC_LPF_mins_right", "IC_LPF_mins_right", 0)), &c7_thisId,
                        c7_y->IC_LPF_mins_right);
  c7_thisId.fIdentifier = "IC_LPF_mins_left";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "IC_LPF_mins_left", "IC_LPF_mins_left", 0)), &c7_thisId,
                        c7_y->IC_LPF_mins_left);
  c7_thisId.fIdentifier = "IC_LPF_index_right";
  c7_y->IC_LPF_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_LPF_index_right", "IC_LPF_index_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "IC_LPF_index_left";
  c7_y->IC_LPF_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_LPF_index_left", "IC_LPF_index_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "IC_index_right";
  c7_y->IC_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_index_right", "IC_index_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_index_left";
  c7_y->IC_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_index_left", "IC_index_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "EC_events_mins_right";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "EC_events_mins_right", "EC_events_mins_right", 0)), &c7_thisId,
                        c7_y->EC_events_mins_right);
  c7_thisId.fIdentifier = "EC_events_mins_left";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "EC_events_mins_left", "EC_events_mins_left", 0)), &c7_thisId,
                        c7_y->EC_events_mins_left);
  c7_thisId.fIdentifier = "EC_peaks_mins_right";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "EC_peaks_mins_right", "EC_peaks_mins_right", 0)), &c7_thisId,
                        c7_y->EC_peaks_mins_right);
  c7_thisId.fIdentifier = "EC_peaks_mins_left";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "EC_peaks_mins_left", "EC_peaks_mins_left", 0)), &c7_thisId,
                        c7_y->EC_peaks_mins_left);
  c7_thisId.fIdentifier = "EC_events_index_right";
  c7_y->EC_events_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_events_index_right", "EC_events_index_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "EC_events_index_left";
  c7_y->EC_events_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_events_index_left", "EC_events_index_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "EC_peaks_index_right";
  c7_y->EC_peaks_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_peaks_index_right", "EC_peaks_index_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "EC_peaks_index_left";
  c7_y->EC_peaks_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_peaks_index_left", "EC_peaks_index_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "AN_events_right";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AN_events_right", "AN_events_right", 0)), &c7_thisId, c7_y->AN_events_right);
  c7_thisId.fIdentifier = "AN_events_left";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AN_events_left", "AN_events_left", 0)), &c7_thisId, c7_y->AN_events_left);
  c7_thisId.fIdentifier = "AN_peaks_right";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AN_peaks_right", "AN_peaks_right", 0)), &c7_thisId, c7_y->AN_peaks_right);
  c7_thisId.fIdentifier = "AN_peaks_left";
  c7_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "AN_peaks_left", "AN_peaks_left", 0)), &c7_thisId, c7_y->AN_peaks_left);
  c7_thisId.fIdentifier = "stop_DS_index";
  c7_y->stop_DS_index = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_DS_index", "stop_DS_index", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "stop_DS";
  c7_j_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "stop_DS", "stop_DS", 0)), &c7_thisId, c7_y->stop_DS);
  c7_thisId.fIdentifier = "MS_event_left";
  c7_y->MS_event_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MS_event_left", "MS_event_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MS_event_right";
  c7_y->MS_event_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MS_event_right", "MS_event_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "EC_event_left";
  c7_y->EC_event_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_event_left", "EC_event_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "EC_event_right";
  c7_y->EC_event_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_event_right", "EC_event_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_event_left";
  c7_y->IC_event_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_event_left", "IC_event_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_event_right";
  c7_y->IC_event_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_event_right", "IC_event_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "AN_event_left";
  c7_y->AN_event_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "AN_event_left", "AN_event_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "AN_event_right";
  c7_y->AN_event_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "AN_event_right", "AN_event_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MA_event_left";
  c7_y->MA_event_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_event_left", "MA_event_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MA_event_right";
  c7_y->MA_event_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_event_right", "MA_event_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "stop_Vel_event_left";
  c7_y->stop_Vel_event_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_Vel_event_left", "stop_Vel_event_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_Vel_event_right";
  c7_y->stop_Vel_event_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_Vel_event_right", "stop_Vel_event_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_MA_event_left";
  c7_y->stop_MA_event_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_MA_event_left", "stop_MA_event_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_MA_event_right";
  c7_y->stop_MA_event_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_MA_event_right", "stop_MA_event_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_IC_event_left";
  c7_y->stop_IC_event_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_IC_event_left", "stop_IC_event_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_IC_event_right";
  c7_y->stop_IC_event_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_IC_event_right", "stop_IC_event_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "MA_flag_right";
  c7_y->MA_flag_right = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_flag_right", "MA_flag_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MA_flag_left";
  c7_y->MA_flag_left = c7_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_flag_left", "MA_flag_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "last_EC";
  c7_y->last_EC = c7_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "last_EC", "last_EC", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "last_IC";
  c7_y->last_IC = c7_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "last_IC", "last_IC", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_buffer_left";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "IC_buffer_left", "IC_buffer_left", 0)), &c7_thisId, c7_y->IC_buffer_left);
  c7_thisId.fIdentifier = "IC_buffer_right";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "IC_buffer_right", "IC_buffer_right", 0)), &c7_thisId, c7_y->IC_buffer_right);
  c7_thisId.fIdentifier = "EC_buffer_left";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "EC_buffer_left", "EC_buffer_left", 0)), &c7_thisId, c7_y->EC_buffer_left);
  c7_thisId.fIdentifier = "EC_buffer_right";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "EC_buffer_right", "EC_buffer_right", 0)), &c7_thisId, c7_y->EC_buffer_right);
  c7_thisId.fIdentifier = "MS_buffer_left";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "MS_buffer_left", "MS_buffer_left", 0)), &c7_thisId, c7_y->MS_buffer_left);
  c7_thisId.fIdentifier = "MS_buffer_right";
  c7_d_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c7_u,
    "MS_buffer_right", "MS_buffer_right", 0)), &c7_thisId, c7_y->MS_buffer_right);
  c7_thisId.fIdentifier = "IC_buffer_index_left";
  c7_y->IC_buffer_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_buffer_index_left", "IC_buffer_index_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "IC_buffer_index_right";
  c7_y->IC_buffer_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_buffer_index_right", "IC_buffer_index_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "EC_buffer_index_left";
  c7_y->EC_buffer_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_buffer_index_left", "EC_buffer_index_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "EC_buffer_index_right";
  c7_y->EC_buffer_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_buffer_index_right", "EC_buffer_index_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "MS_buffer_index_left";
  c7_y->MS_buffer_index_left = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MS_buffer_index_left", "MS_buffer_index_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "MS_buffer_index_right";
  c7_y->MS_buffer_index_right = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MS_buffer_index_right", "MS_buffer_index_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "MA_th_left";
  c7_y->MA_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_th_left", "MA_th_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MA_th_right";
  c7_y->MA_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_th_right", "MA_th_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_th_left";
  c7_y->IC_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_th_left", "IC_th_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_th_right";
  c7_y->IC_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_th_right", "IC_th_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "AN_th_right";
  c7_y->AN_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "AN_th_right", "AN_th_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "AN_th_left";
  c7_y->AN_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "AN_th_left", "AN_th_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "EC_th_right";
  c7_y->EC_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_th_right", "EC_th_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "EC_th_left";
  c7_y->EC_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "EC_th_left", "EC_th_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "stop_Vel_th_left";
  c7_y->stop_Vel_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_Vel_th_left", "stop_Vel_th_left", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_Vel_th_right";
  c7_y->stop_Vel_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_Vel_th_right", "stop_Vel_th_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_MA_th_left";
  c7_y->stop_MA_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_MA_th_left", "stop_MA_th_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "stop_MA_th_right";
  c7_y->stop_MA_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_MA_th_right", "stop_MA_th_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_IC_th_right";
  c7_y->stop_IC_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_IC_th_right", "stop_IC_th_right", 0)),
    &c7_thisId);
  c7_thisId.fIdentifier = "stop_IC_th_left";
  c7_y->stop_IC_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_IC_th_left", "stop_IC_th_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "stop_DS_th";
  c7_y->stop_DS_th = c7_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "stop_DS_th", "stop_DS_th", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MA_LPF_th_left";
  c7_y->MA_LPF_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_LPF_th_left", "MA_LPF_th_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "MA_LPF_th_right";
  c7_y->MA_LPF_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "MA_LPF_th_right", "MA_LPF_th_right", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_LPF_th_left";
  c7_y->IC_LPF_th_left = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_LPF_th_left", "IC_LPF_th_left", 0)), &c7_thisId);
  c7_thisId.fIdentifier = "IC_LPF_th_right";
  c7_y->IC_LPF_th_right = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c7_u, "IC_LPF_th_right", "IC_LPF_th_right", 0)), &c7_thisId);
  sf_mex_destroy(&c7_u);
}

static void c7_d_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real32_T c7_y[200])
{
  real32_T c7_fv0[200];
  int32_T c7_i231;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), c7_fv0, 1, 1, 0U, 1, 0U, 1, 200);
  for (c7_i231 = 0; c7_i231 < 200; c7_i231++) {
    c7_y[c7_i231] = c7_fv0[c7_i231];
  }

  sf_mex_destroy(&c7_u);
}

static uint16_T c7_e_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  uint16_T c7_y;
  uint16_T c7_u0;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_u0, 1, 5, 0U, 0, 0U, 0);
  c7_y = c7_u0;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static uint8_T c7_f_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  uint8_T c7_y;
  uint8_T c7_u1;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_u1, 1, 3, 0U, 0, 0U, 0);
  c7_y = c7_u1;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static boolean_T c7_g_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  boolean_T c7_y;
  boolean_T c7_b22;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_b22, 1, 11, 0U, 0, 0U, 0);
  c7_y = c7_b22;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static int8_T c7_h_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  int8_T c7_y;
  int8_T c7_i232;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_i232, 1, 2, 0U, 0, 0U, 0);
  c7_y = c7_i232;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static void c7_i_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real32_T c7_y[5])
{
  real32_T c7_fv1[5];
  int32_T c7_i233;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), c7_fv1, 1, 1, 0U, 1, 0U, 2, 1, 5);
  for (c7_i233 = 0; c7_i233 < 5; c7_i233++) {
    c7_y[c7_i233] = c7_fv1[c7_i233];
  }

  sf_mex_destroy(&c7_u);
}

static void c7_j_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  uint16_T c7_y[10])
{
  uint16_T c7_uv0[10];
  int32_T c7_i234;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), c7_uv0, 1, 5, 0U, 1, 0U, 2, 1, 10);
  for (c7_i234 = 0; c7_i234 < 10; c7_i234++) {
    c7_y[c7_i234] = c7_uv0[c7_i234];
  }

  sf_mex_destroy(&c7_u);
}

static real32_T c7_k_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  real32_T c7_y;
  real32_T c7_f0;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_f0, 1, 1, 0U, 0, 0U, 0);
  c7_y = c7_f0;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static void c7_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_data_struct_new;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  c7_bus_datastruct c7_y;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_data_struct_new = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_c_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_data_struct_new),
                        &c7_thisId, &c7_y);
  sf_mex_destroy(&c7_data_struct_new);
  *(c7_bus_datastruct *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_c_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  int8_T c7_u;
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u = *(int8_T *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 2, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static int8_T c7_l_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_state_out, const char_T *c7_identifier)
{
  int8_T c7_y;
  emlrtMsgIdentifier c7_thisId;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_y = c7_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_state_out),
    &c7_thisId);
  sf_mex_destroy(&c7_state_out);
  return c7_y;
}

static void c7_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_state_out;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  int8_T c7_y;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_state_out = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_y = c7_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_state_out),
    &c7_thisId);
  sf_mex_destroy(&c7_state_out);
  *(int8_T *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_d_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  real32_T c7_u;
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u = *(real32_T *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 1, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static void c7_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_newAngLShank;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  real32_T c7_y;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_newAngLShank = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_y = c7_k_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_newAngLShank),
    &c7_thisId);
  sf_mex_destroy(&c7_newAngLShank);
  *(real32_T *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_e_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  uint16_T c7_u;
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u = *(uint16_T *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 5, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static void c7_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_index;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  uint16_T c7_y;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_index = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_y = c7_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_index), &c7_thisId);
  sf_mex_destroy(&c7_index);
  *(uint16_T *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_f_sf_marshallOut(void *chartInstanceVoid, real_T
  c7_inData_data[], int32_T c7_inData_sizes[2])
{
  const mxArray *c7_mxArrayOutData = NULL;
  int32_T c7_u_sizes[2];
  int32_T c7_u;
  int32_T c7_b_u;
  int32_T c7_loop_ub;
  int32_T c7_i235;
  real_T c7_u_data[5];
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u_sizes[0] = c7_inData_sizes[0];
  c7_u_sizes[1] = 1;
  c7_u = c7_u_sizes[0];
  c7_b_u = c7_u_sizes[1];
  c7_loop_ub = c7_inData_sizes[0] * c7_inData_sizes[1] - 1;
  for (c7_i235 = 0; c7_i235 <= c7_loop_ub; c7_i235++) {
    c7_u_data[c7_i235] = c7_inData_data[c7_i235];
  }

  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", c7_u_data, 0, 0U, 1U, 0U, 2,
    c7_u_sizes[0], c7_u_sizes[1]), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static void c7_m_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real_T c7_y_data[], int32_T c7_y_sizes[2])
{
  int32_T c7_i236;
  uint32_T c7_uv1[2];
  int32_T c7_i237;
  static boolean_T c7_bv1[2] = { true, false };

  boolean_T c7_bv2[2];
  int32_T c7_tmp_sizes[2];
  real_T c7_tmp_data[5];
  int32_T c7_y;
  int32_T c7_b_y;
  int32_T c7_loop_ub;
  int32_T c7_i238;
  (void)chartInstance;
  for (c7_i236 = 0; c7_i236 < 2; c7_i236++) {
    c7_uv1[c7_i236] = 5U + (uint32_T)(-4 * c7_i236);
  }

  for (c7_i237 = 0; c7_i237 < 2; c7_i237++) {
    c7_bv2[c7_i237] = c7_bv1[c7_i237];
  }

  sf_mex_import_vs(c7_parentId, sf_mex_dup(c7_u), c7_tmp_data, 1, 0, 0U, 1, 0U,
                   2, c7_bv2, c7_uv1, c7_tmp_sizes);
  c7_y_sizes[0] = c7_tmp_sizes[0];
  c7_y_sizes[1] = 1;
  c7_y = c7_y_sizes[0];
  c7_b_y = c7_y_sizes[1];
  c7_loop_ub = c7_tmp_sizes[0] * c7_tmp_sizes[1] - 1;
  for (c7_i238 = 0; c7_i238 <= c7_loop_ub; c7_i238++) {
    c7_y_data[c7_i238] = c7_tmp_data[c7_i238];
  }

  sf_mex_destroy(&c7_u);
}

static void c7_f_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, real_T c7_outData_data[], int32_T
  c7_outData_sizes[2])
{
  const mxArray *c7_temp;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  int32_T c7_y_sizes[2];
  real_T c7_y_data[5];
  int32_T c7_loop_ub;
  int32_T c7_i239;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_temp = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_m_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_temp), &c7_thisId,
                        c7_y_data, c7_y_sizes);
  sf_mex_destroy(&c7_temp);
  c7_outData_sizes[0] = c7_y_sizes[0];
  c7_outData_sizes[1] = 1;
  c7_loop_ub = c7_y_sizes[0] - 1;
  for (c7_i239 = 0; c7_i239 <= c7_loop_ub; c7_i239++) {
    c7_outData_data[c7_i239] = c7_y_data[c7_i239];
  }

  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_g_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  uint8_T c7_u;
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u = *(uint8_T *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static uint8_T c7_n_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_i, const char_T *c7_identifier)
{
  uint8_T c7_y;
  emlrtMsgIdentifier c7_thisId;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_y = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_i), &c7_thisId);
  sf_mex_destroy(&c7_i);
  return c7_y;
}

static void c7_g_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_i;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  uint8_T c7_y;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_i = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_y = c7_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_i), &c7_thisId);
  sf_mex_destroy(&c7_i);
  *(uint8_T *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_h_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  int32_T c7_i240;
  real_T c7_u[5];
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  for (c7_i240 = 0; c7_i240 < 5; c7_i240++) {
    c7_u[c7_i240] = (*(real_T (*)[5])c7_inData)[c7_i240];
  }

  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", c7_u, 0, 0U, 1U, 0U, 1, 5), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static void c7_o_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real_T c7_y[5])
{
  real_T c7_dv0[5];
  int32_T c7_i241;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), c7_dv0, 1, 0, 0U, 1, 0U, 1, 5);
  for (c7_i241 = 0; c7_i241 < 5; c7_i241++) {
    c7_y[c7_i241] = c7_dv0[c7_i241];
  }

  sf_mex_destroy(&c7_u);
}

static void c7_h_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_EC_events_inds_left;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  real_T c7_y[5];
  int32_T c7_i242;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_EC_events_inds_left = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_o_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_EC_events_inds_left),
                        &c7_thisId, c7_y);
  sf_mex_destroy(&c7_EC_events_inds_left);
  for (c7_i242 = 0; c7_i242 < 5; c7_i242++) {
    (*(real_T (*)[5])c7_outData)[c7_i242] = c7_y[c7_i242];
  }

  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_i_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  int32_T c7_i243;
  real_T c7_u[50];
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  for (c7_i243 = 0; c7_i243 < 50; c7_i243++) {
    c7_u[c7_i243] = (*(real_T (*)[50])c7_inData)[c7_i243];
  }

  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", c7_u, 0, 0U, 1U, 0U, 1, 50), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static void c7_p_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  real_T c7_y[50])
{
  real_T c7_dv1[50];
  int32_T c7_i244;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), c7_dv1, 1, 0, 0U, 1, 0U, 1, 50);
  for (c7_i244 = 0; c7_i244 < 50; c7_i244++) {
    c7_y[c7_i244] = c7_dv1[c7_i244];
  }

  sf_mex_destroy(&c7_u);
}

static void c7_i_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_AN_peaks;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  real_T c7_y[50];
  int32_T c7_i245;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_AN_peaks = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_p_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_AN_peaks), &c7_thisId, c7_y);
  sf_mex_destroy(&c7_AN_peaks);
  for (c7_i245 = 0; c7_i245 < 50; c7_i245++) {
    (*(real_T (*)[50])c7_outData)[c7_i245] = c7_y[c7_i245];
  }

  sf_mex_destroy(&c7_mxArrayInData);
}

const mxArray *sf_c7_XsensLibrary2_get_eml_resolved_functions_info(void)
{
  const mxArray *c7_nameCaptureInfo = NULL;
  c7_nameCaptureInfo = NULL;
  sf_mex_assign(&c7_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c7_nameCaptureInfo;
}

static void c7_data_struct_creation(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, c7_bus_datastruct *c7_data_struct_in, c7_bus_datastruct
  *c7_data_struct_new)
{
  uint32_T c7_debug_family_var_map[4];
  real_T c7_nargin = 1.0;
  real_T c7_nargout = 1.0;
  int32_T c7_i246;
  int32_T c7_i247;
  int32_T c7_i248;
  int32_T c7_i249;
  int32_T c7_i250;
  int32_T c7_i251;
  int32_T c7_i252;
  int32_T c7_i253;
  int32_T c7_i254;
  int32_T c7_i255;
  int32_T c7_i256;
  int32_T c7_i257;
  int32_T c7_i258;
  int32_T c7_i259;
  int32_T c7_i260;
  int32_T c7_i261;
  int32_T c7_i262;
  int32_T c7_i263;
  int32_T c7_i264;
  int32_T c7_i265;
  int32_T c7_i266;
  int32_T c7_i267;
  int32_T c7_i268;
  int32_T c7_i269;
  int32_T c7_i270;
  int32_T c7_i271;
  int32_T c7_i272;
  int32_T c7_i273;
  int32_T c7_i274;
  int32_T c7_i275;
  int32_T c7_i276;
  int32_T c7_i277;
  int32_T c7_i278;
  int32_T c7_i279;
  int32_T c7_i280;
  int32_T c7_i281;
  int32_T c7_i282;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 4U, 4U, c7_b_debug_family_names,
    c7_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_nargin, 0U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_nargout, 1U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_data_struct_in, 2U,
    c7_b_sf_marshallOut, c7_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_data_struct_new, 3U,
    c7_b_sf_marshallOut, c7_b_sf_marshallIn);
  CV_EML_FCN(2, 0);
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 5);
  for (c7_i246 = 0; c7_i246 < 200; c7_i246++) {
    c7_data_struct_in->VelRShank[c7_i246] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 6);
  for (c7_i247 = 0; c7_i247 < 200; c7_i247++) {
    c7_data_struct_in->VelLShank[c7_i247] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 7);
  for (c7_i248 = 0; c7_i248 < 200; c7_i248++) {
    c7_data_struct_in->AngRShank[c7_i248] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 8);
  for (c7_i249 = 0; c7_i249 < 200; c7_i249++) {
    c7_data_struct_in->AngLShank[c7_i249] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 10);
  for (c7_i250 = 0; c7_i250 < 200; c7_i250++) {
    c7_data_struct_in->VelRShank_filt[c7_i250] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 11);
  for (c7_i251 = 0; c7_i251 < 200; c7_i251++) {
    c7_data_struct_in->VelLShank_filt[c7_i251] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 12);
  for (c7_i252 = 0; c7_i252 < 200; c7_i252++) {
    c7_data_struct_in->AngRShank_filt[c7_i252] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 13);
  for (c7_i253 = 0; c7_i253 < 200; c7_i253++) {
    c7_data_struct_in->AngLShank_filt[c7_i253] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 15);
  for (c7_i254 = 0; c7_i254 < 200; c7_i254++) {
    c7_data_struct_in->VelRShank_LPF[c7_i254] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 16);
  for (c7_i255 = 0; c7_i255 < 200; c7_i255++) {
    c7_data_struct_in->VelLShank_LPF[c7_i255] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 17);
  for (c7_i256 = 0; c7_i256 < 200; c7_i256++) {
    c7_data_struct_in->AngRShank_LPF[c7_i256] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 18);
  for (c7_i257 = 0; c7_i257 < 200; c7_i257++) {
    c7_data_struct_in->AngLShank_LPF[c7_i257] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 19);
  for (c7_i258 = 0; c7_i258 < 200; c7_i258++) {
    c7_data_struct_in->AngRShank_LPF2Hz[c7_i258] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 20);
  for (c7_i259 = 0; c7_i259 < 200; c7_i259++) {
    c7_data_struct_in->AngLShank_LPF2Hz[c7_i259] = 0.0F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 22);
  c7_data_struct_in->counter_stop = 0U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 23);
  c7_data_struct_in->counter = 0U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 24);
  c7_data_struct_in->index_start_calib = 0U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 25);
  c7_data_struct_in->index_stop_calib = 0U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 26);
  c7_data_struct_in->initial_leg = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 30);
  c7_data_struct_in->flag_calib = true;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 31);
  c7_data_struct_in->calibrating = 0;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 33);
  c7_data_struct_in->state = 0;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 34);
  c7_data_struct_in->prevstate = 0;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 37);
  for (c7_i260 = 0; c7_i260 < 5; c7_i260++) {
    c7_data_struct_in->MA_maxs_right[c7_i260] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 38);
  for (c7_i261 = 0; c7_i261 < 5; c7_i261++) {
    c7_data_struct_in->MA_maxs_left[c7_i261] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 39);
  for (c7_i262 = 0; c7_i262 < 5; c7_i262++) {
    c7_data_struct_in->MA_LPF_maxs_right[c7_i262] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 40);
  for (c7_i263 = 0; c7_i263 < 5; c7_i263++) {
    c7_data_struct_in->MA_LPF_maxs_left[c7_i263] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 41);
  c7_data_struct_in->MA_LPF_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 42);
  c7_data_struct_in->MA_LPF_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 43);
  c7_data_struct_in->MA_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 44);
  c7_data_struct_in->MA_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 51);
  for (c7_i264 = 0; c7_i264 < 5; c7_i264++) {
    c7_data_struct_in->IC_mins_right[c7_i264] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 52);
  for (c7_i265 = 0; c7_i265 < 5; c7_i265++) {
    c7_data_struct_in->IC_mins_left[c7_i265] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 53);
  for (c7_i266 = 0; c7_i266 < 5; c7_i266++) {
    c7_data_struct_in->IC_LPF_mins_right[c7_i266] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 54);
  for (c7_i267 = 0; c7_i267 < 5; c7_i267++) {
    c7_data_struct_in->IC_LPF_mins_left[c7_i267] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 55);
  c7_data_struct_in->IC_LPF_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 56);
  c7_data_struct_in->IC_LPF_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 57);
  c7_data_struct_in->IC_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 58);
  c7_data_struct_in->IC_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 65);
  for (c7_i268 = 0; c7_i268 < 5; c7_i268++) {
    c7_data_struct_in->EC_events_mins_right[c7_i268] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 66);
  for (c7_i269 = 0; c7_i269 < 5; c7_i269++) {
    c7_data_struct_in->EC_events_mins_left[c7_i269] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 67);
  for (c7_i270 = 0; c7_i270 < 5; c7_i270++) {
    c7_data_struct_in->EC_peaks_mins_right[c7_i270] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 68);
  for (c7_i271 = 0; c7_i271 < 5; c7_i271++) {
    c7_data_struct_in->EC_peaks_mins_left[c7_i271] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 69);
  c7_data_struct_in->EC_events_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 70);
  c7_data_struct_in->EC_peaks_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 71);
  c7_data_struct_in->EC_events_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 72);
  c7_data_struct_in->EC_peaks_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 77);
  for (c7_i272 = 0; c7_i272 < 5; c7_i272++) {
    c7_data_struct_in->AN_events_right[c7_i272] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 78);
  for (c7_i273 = 0; c7_i273 < 5; c7_i273++) {
    c7_data_struct_in->AN_peaks_right[c7_i273] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 79);
  for (c7_i274 = 0; c7_i274 < 5; c7_i274++) {
    c7_data_struct_in->AN_events_left[c7_i274] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 80);
  for (c7_i275 = 0; c7_i275 < 5; c7_i275++) {
    c7_data_struct_in->AN_peaks_left[c7_i275] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 86);
  c7_data_struct_in->stop_DS_index = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 87);
  for (c7_i276 = 0; c7_i276 < 10; c7_i276++) {
    c7_data_struct_in->stop_DS[c7_i276] = 20000U;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 97);
  c7_data_struct_in->MS_event_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 98);
  c7_data_struct_in->MS_event_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 99);
  c7_data_struct_in->EC_event_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 100);
  c7_data_struct_in->EC_event_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 101);
  c7_data_struct_in->IC_event_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 102);
  c7_data_struct_in->IC_event_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 103);
  c7_data_struct_in->AN_event_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 104);
  c7_data_struct_in->AN_event_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 105);
  c7_data_struct_in->MA_event_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 106);
  c7_data_struct_in->MA_event_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 107);
  c7_data_struct_in->stop_Vel_event_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 108);
  c7_data_struct_in->stop_Vel_event_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 109);
  c7_data_struct_in->stop_MA_event_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 110);
  c7_data_struct_in->stop_MA_event_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 111);
  c7_data_struct_in->stop_IC_event_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 112);
  c7_data_struct_in->stop_IC_event_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 113);
  c7_data_struct_in->MA_flag_right = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 114);
  c7_data_struct_in->MA_flag_left = false;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 116);
  c7_data_struct_in->last_EC = 0U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 117);
  c7_data_struct_in->last_IC = 0U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 120);
  for (c7_i277 = 0; c7_i277 < 200; c7_i277++) {
    c7_data_struct_in->IC_buffer_left[c7_i277] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 121);
  for (c7_i278 = 0; c7_i278 < 200; c7_i278++) {
    c7_data_struct_in->IC_buffer_right[c7_i278] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 122);
  for (c7_i279 = 0; c7_i279 < 200; c7_i279++) {
    c7_data_struct_in->EC_buffer_left[c7_i279] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 123);
  for (c7_i280 = 0; c7_i280 < 200; c7_i280++) {
    c7_data_struct_in->EC_buffer_right[c7_i280] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 124);
  for (c7_i281 = 0; c7_i281 < 200; c7_i281++) {
    c7_data_struct_in->MS_buffer_left[c7_i281] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 125);
  for (c7_i282 = 0; c7_i282 < 200; c7_i282++) {
    c7_data_struct_in->MS_buffer_right[c7_i282] = -2.0E+6F;
  }

  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, MAX_int8_T);
  c7_data_struct_in->IC_buffer_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 128U);
  c7_data_struct_in->IC_buffer_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 129U);
  c7_data_struct_in->EC_buffer_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 130U);
  c7_data_struct_in->EC_buffer_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 131U);
  c7_data_struct_in->MS_buffer_index_left = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 132U);
  c7_data_struct_in->MS_buffer_index_right = 1U;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, 134U);
  *c7_data_struct_new = *c7_data_struct_in;
  _SFD_EML_CALL(2U, *chartInstance->c7_sfEvent, -134);
  _SFD_SYMBOL_SCOPE_POP();
}

static void c7_RTDetection(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  c7_bus_datastruct *c7_data_struct_input, real_T c7_timestamp, real_T
  c7_newVelRShank, real32_T c7_newVelLShank, real32_T c7_newAngRShank, real32_T
  c7_newAngLShank, c7_bus_datastruct *c7_data_struct_output, int8_T
  *c7_state_out)
{
  uint32_T c7_debug_family_var_map[29];
  uint16_T c7_left_limit;
  real_T c7_found;
  real_T c7_index;
  real_T c7_MS_inds_left;
  real_T c7_EC_events_inds_left;
  real_T c7_EC_distance_left;
  real_T c7_EC_peaks[50];
  real_T c7_AN_peaks[50];
  real_T c7_EC_peaks_index;
  real_T c7_MS_inds_right;
  real_T c7_EC_events_inds_right;
  real_T c7_EC_distance_right;
  real_T c7_MS_inds_index_right;
  real_T c7_MS_inds_index_left;
  real_T c7_IC_LPF_inds_right[5];
  real_T c7_IC_LPF_inds_left[5];
  real_T c7_IC_inds_right[5];
  real_T c7_IC_inds_left[5];
  uint16_T c7_i;
  real_T c7_DS_min;
  real_T c7_b_MS_inds_right[5];
  real_T c7_b_MS_inds_left[5];
  real_T c7_b_EC_distance_right[5];
  real_T c7_b_EC_distance_left[5];
  real_T c7_b_EC_events_inds_right[5];
  real_T c7_b_EC_events_inds_left[5];
  real_T c7_b_i;
  uint8_T c7_c_i;
  int32_T c7_temp_sizes[2];
  real_T c7_temp_data[5];
  uint16_T c7_b_index;
  int32_T c7_i283;
  real32_T c7_b_data_struct_input[199];
  int32_T c7_i284;
  int32_T c7_i285;
  real32_T c7_c_data_struct_input[199];
  int32_T c7_i286;
  int32_T c7_i287;
  real32_T c7_d_data_struct_input[199];
  int32_T c7_i288;
  int32_T c7_i289;
  real32_T c7_e_data_struct_input[199];
  int32_T c7_i290;
  int32_T c7_i291;
  real32_T c7_f_data_struct_input[199];
  int32_T c7_i292;
  real32_T c7_b;
  real32_T c7_y;
  real32_T c7_b_b;
  real32_T c7_b_y;
  int32_T c7_i293;
  real32_T c7_g_data_struct_input[199];
  int32_T c7_i294;
  real32_T c7_c_b;
  real32_T c7_c_y;
  real32_T c7_d_b;
  real32_T c7_d_y;
  int32_T c7_i295;
  real32_T c7_h_data_struct_input[199];
  int32_T c7_i296;
  real32_T c7_e_b;
  real32_T c7_e_y;
  real32_T c7_f_b;
  real32_T c7_f_y;
  int32_T c7_i297;
  real32_T c7_i_data_struct_input[199];
  int32_T c7_i298;
  real32_T c7_g_b;
  real32_T c7_g_y;
  real32_T c7_h_b;
  real32_T c7_h_y;
  int32_T c7_i299;
  real32_T c7_j_data_struct_input[199];
  int32_T c7_i300;
  real32_T c7_i_b;
  real32_T c7_i_y;
  real32_T c7_j_b;
  real32_T c7_j_y;
  real32_T c7_k_b;
  real32_T c7_k_y;
  real32_T c7_l_b;
  real32_T c7_l_y;
  real32_T c7_m_b;
  real32_T c7_m_y;
  real32_T c7_n_b;
  real32_T c7_n_y;
  real32_T c7_o_b;
  real32_T c7_o_y;
  real32_T c7_p_b;
  real32_T c7_p_y;
  real32_T c7_q_b;
  real32_T c7_q_y;
  real32_T c7_r_b;
  real32_T c7_r_y;
  real32_T c7_s_b;
  real32_T c7_s_y;
  int32_T c7_i301;
  real32_T c7_k_data_struct_input[199];
  int32_T c7_i302;
  real32_T c7_t_b;
  real32_T c7_t_y;
  real32_T c7_u_b;
  real32_T c7_u_y;
  real32_T c7_v_b;
  real32_T c7_v_y;
  real32_T c7_w_b;
  real32_T c7_w_y;
  real32_T c7_x_b;
  real32_T c7_x_y;
  real32_T c7_y_b;
  real32_T c7_y_y;
  real32_T c7_ab_b;
  real32_T c7_ab_y;
  real32_T c7_bb_b;
  real32_T c7_bb_y;
  real32_T c7_cb_b;
  real32_T c7_cb_y;
  real32_T c7_db_b;
  real32_T c7_db_y;
  real32_T c7_eb_b;
  real32_T c7_eb_y;
  int32_T c7_i303;
  real32_T c7_l_data_struct_input[199];
  int32_T c7_i304;
  real32_T c7_fb_b;
  real32_T c7_fb_y;
  real32_T c7_gb_b;
  real32_T c7_gb_y;
  real32_T c7_hb_b;
  real32_T c7_hb_y;
  real32_T c7_ib_b;
  real32_T c7_ib_y;
  real32_T c7_jb_b;
  real32_T c7_jb_y;
  real32_T c7_kb_b;
  real32_T c7_kb_y;
  real32_T c7_lb_b;
  real32_T c7_lb_y;
  real32_T c7_mb_b;
  real32_T c7_mb_y;
  real32_T c7_nb_b;
  real32_T c7_nb_y;
  real32_T c7_ob_b;
  real32_T c7_ob_y;
  real32_T c7_pb_b;
  real32_T c7_pb_y;
  int32_T c7_i305;
  real32_T c7_m_data_struct_input[199];
  int32_T c7_i306;
  real32_T c7_qb_b;
  real32_T c7_qb_y;
  real32_T c7_rb_b;
  real32_T c7_rb_y;
  real32_T c7_sb_b;
  real32_T c7_sb_y;
  real32_T c7_tb_b;
  real32_T c7_tb_y;
  real32_T c7_ub_b;
  real32_T c7_ub_y;
  real32_T c7_vb_b;
  real32_T c7_vb_y;
  real32_T c7_wb_b;
  real32_T c7_wb_y;
  real32_T c7_xb_b;
  real32_T c7_xb_y;
  real32_T c7_yb_b;
  real32_T c7_yb_y;
  real32_T c7_ac_b;
  real32_T c7_ac_y;
  real32_T c7_bc_b;
  real32_T c7_bc_y;
  uint32_T c7_u2;
  uint32_T c7_u3;
  uint32_T c7_u4;
  uint16_T c7_varargin_1[2];
  uint16_T c7_mtmp;
  uint16_T c7_a;
  boolean_T c7_p;
  uint16_T c7_b_mtmp;
  uint32_T c7_u5;
  uint8_T c7_uv2[1];
  boolean_T c7_b23;
  int32_T c7_trueCount;
  int32_T c7_d_i;
  int32_T c7_partialTrueCount;
  int32_T c7_e_i;
  int32_T c7_iv0[2];
  int32_T c7_tmp_sizes[2];
  int32_T c7_i307;
  int32_T c7_i308;
  int32_T c7_loop_ub;
  int32_T c7_i309;
  uint8_T c7_tmp_data[1];
  uint32_T c7_u6;
  uint8_T c7_uv3[1];
  boolean_T c7_b24;
  int32_T c7_b_trueCount;
  int32_T c7_f_i;
  int32_T c7_b_partialTrueCount;
  int32_T c7_g_i;
  int32_T c7_i310;
  int32_T c7_i311;
  int32_T c7_b_loop_ub;
  int32_T c7_i312;
  uint32_T c7_q0;
  uint32_T c7_qY;
  uint32_T c7_u7;
  uint32_T c7_u8;
  uint8_T c7_uv4[1];
  boolean_T c7_b25;
  int32_T c7_c_trueCount;
  int32_T c7_h_i;
  int32_T c7_c_partialTrueCount;
  int32_T c7_i_i;
  int32_T c7_i313;
  int32_T c7_i314;
  int32_T c7_c_loop_ub;
  int32_T c7_i315;
  int32_T c7_i316;
  boolean_T c7_bv3[10];
  int32_T c7_d_trueCount;
  int32_T c7_j_i;
  int32_T c7_b_tmp_sizes[2];
  int32_T c7_d_partialTrueCount;
  int32_T c7_k_i;
  int32_T c7_b_tmp_data[10];
  int32_T c7_data_struct_input_sizes[2];
  int32_T c7_n_data_struct_input;
  int32_T c7_o_data_struct_input;
  int32_T c7_d_loop_ub;
  int32_T c7_i317;
  uint16_T c7_data_struct_input_data[10];
  real_T c7_d7;
  uint16_T c7_u9;
  uint32_T c7_u10;
  uint8_T c7_uv5[1];
  boolean_T c7_b26;
  int32_T c7_e_trueCount;
  int32_T c7_l_i;
  int32_T c7_e_partialTrueCount;
  int32_T c7_m_i;
  int32_T c7_i318;
  int32_T c7_i319;
  int32_T c7_e_loop_ub;
  int32_T c7_i320;
  uint32_T c7_u11;
  uint8_T c7_uv6[1];
  boolean_T c7_b27;
  int32_T c7_f_trueCount;
  int32_T c7_n_i;
  int32_T c7_f_partialTrueCount;
  int32_T c7_o_i;
  int32_T c7_i321;
  int32_T c7_i322;
  int32_T c7_f_loop_ub;
  int32_T c7_i323;
  uint32_T c7_u12;
  uint8_T c7_uv7[1];
  boolean_T c7_b28;
  int32_T c7_g_trueCount;
  int32_T c7_p_i;
  int32_T c7_g_partialTrueCount;
  int32_T c7_q_i;
  int32_T c7_i324;
  int32_T c7_i325;
  int32_T c7_g_loop_ub;
  int32_T c7_i326;
  uint32_T c7_b_q0;
  uint32_T c7_b_qY;
  uint32_T c7_u13;
  uint32_T c7_u14;
  uint8_T c7_uv8[1];
  boolean_T c7_b29;
  int32_T c7_h_trueCount;
  int32_T c7_r_i;
  int32_T c7_h_partialTrueCount;
  int32_T c7_s_i;
  int32_T c7_i327;
  int32_T c7_i328;
  int32_T c7_h_loop_ub;
  int32_T c7_i329;
  int32_T c7_i330;
  int32_T c7_i_trueCount;
  int32_T c7_t_i;
  int32_T c7_i_partialTrueCount;
  int32_T c7_u_i;
  int32_T c7_b_data_struct_input_sizes[2];
  int32_T c7_p_data_struct_input;
  int32_T c7_q_data_struct_input;
  int32_T c7_i_loop_ub;
  int32_T c7_i331;
  uint16_T c7_b_data_struct_input_data[10];
  real_T c7_d8;
  uint16_T c7_u15;
  uint32_T c7_u16;
  uint8_T c7_uv9[1];
  boolean_T c7_b30;
  int32_T c7_j_trueCount;
  int32_T c7_v_i;
  int32_T c7_j_partialTrueCount;
  int32_T c7_w_i;
  int32_T c7_i332;
  int32_T c7_i333;
  int32_T c7_j_loop_ub;
  int32_T c7_i334;
  uint16_T c7_cc_b;
  uint32_T c7_u17;
  uint16_T c7_cc_y;
  uint16_T c7_dc_b;
  uint32_T c7_u18;
  uint16_T c7_dc_y;
  uint16_T c7_ec_b;
  uint32_T c7_u19;
  uint16_T c7_ec_y;
  uint16_T c7_fc_b;
  uint32_T c7_u20;
  uint16_T c7_fc_y;
  uint16_T c7_gc_b;
  uint32_T c7_u21;
  uint16_T c7_gc_y;
  uint16_T c7_hc_b;
  uint32_T c7_u22;
  uint16_T c7_hc_y;
  uint16_T c7_ic_b;
  uint32_T c7_u23;
  uint16_T c7_ic_y;
  uint16_T c7_jc_b;
  uint32_T c7_u24;
  uint16_T c7_jc_y;
  uint16_T c7_kc_b;
  uint32_T c7_u25;
  uint16_T c7_kc_y;
  uint16_T c7_lc_b;
  uint32_T c7_u26;
  uint16_T c7_lc_y;
  uint16_T c7_mc_b;
  uint32_T c7_u27;
  uint16_T c7_mc_y;
  uint16_T c7_nc_b;
  uint32_T c7_u28;
  uint16_T c7_nc_y;
  uint16_T c7_oc_b;
  uint32_T c7_u29;
  uint16_T c7_oc_y;
  uint16_T c7_pc_b;
  uint32_T c7_u30;
  uint16_T c7_pc_y;
  uint32_T c7_u31;
  uint8_T c7_uv10[1];
  boolean_T c7_b31;
  int32_T c7_k_trueCount;
  int32_T c7_x_i;
  int32_T c7_k_partialTrueCount;
  int32_T c7_y_i;
  int32_T c7_i335;
  int32_T c7_i336;
  int32_T c7_k_loop_ub;
  int32_T c7_i337;
  uint32_T c7_u32;
  uint8_T c7_uv11[1];
  boolean_T c7_b32;
  int32_T c7_l_trueCount;
  int32_T c7_ab_i;
  int32_T c7_l_partialTrueCount;
  int32_T c7_bb_i;
  int32_T c7_i338;
  int32_T c7_i339;
  int32_T c7_l_loop_ub;
  int32_T c7_i340;
  uint32_T c7_u33;
  uint8_T c7_uv12[1];
  boolean_T c7_b33;
  int32_T c7_m_trueCount;
  int32_T c7_cb_i;
  int32_T c7_m_partialTrueCount;
  int32_T c7_db_i;
  int32_T c7_i341;
  int32_T c7_i342;
  int32_T c7_m_loop_ub;
  int32_T c7_i343;
  int32_T c7_i344;
  boolean_T c7_bv4[5];
  int32_T c7_n_trueCount;
  int32_T c7_eb_i;
  int32_T c7_c_tmp_sizes[2];
  int32_T c7_n_partialTrueCount;
  int32_T c7_fb_i;
  int32_T c7_c_tmp_data[5];
  int32_T c7_c_data_struct_input_sizes[2];
  int32_T c7_r_data_struct_input;
  int32_T c7_s_data_struct_input;
  int32_T c7_n_loop_ub;
  int32_T c7_i345;
  real32_T c7_c_data_struct_input_data[5];
  real32_T c7_qc_b;
  real32_T c7_qc_y;
  int32_T c7_d_data_struct_input_sizes[2];
  int32_T c7_t_data_struct_input;
  int32_T c7_u_data_struct_input;
  int32_T c7_o_loop_ub;
  int32_T c7_i346;
  real32_T c7_d_data_struct_input_data[5];
  real32_T c7_f1;
  real32_T c7_f2;
  real32_T c7_f3;
  real32_T c7_f4;
  uint32_T c7_u34;
  uint8_T c7_uv13[1];
  boolean_T c7_b34;
  int32_T c7_o_trueCount;
  int32_T c7_gb_i;
  int32_T c7_o_partialTrueCount;
  int32_T c7_hb_i;
  int32_T c7_i347;
  int32_T c7_i348;
  int32_T c7_p_loop_ub;
  int32_T c7_i349;
  int32_T c7_i350;
  int32_T c7_p_trueCount;
  int32_T c7_ib_i;
  int32_T c7_p_partialTrueCount;
  int32_T c7_jb_i;
  int32_T c7_e_data_struct_input_sizes[2];
  int32_T c7_v_data_struct_input;
  int32_T c7_w_data_struct_input;
  int32_T c7_q_loop_ub;
  int32_T c7_i351;
  real32_T c7_e_data_struct_input_data[5];
  real32_T c7_rc_b;
  real32_T c7_rc_y;
  int32_T c7_f_data_struct_input_sizes[2];
  int32_T c7_x_data_struct_input;
  int32_T c7_y_data_struct_input;
  int32_T c7_r_loop_ub;
  int32_T c7_i352;
  real32_T c7_f_data_struct_input_data[5];
  int32_T c7_i353;
  int32_T c7_q_trueCount;
  int32_T c7_kb_i;
  int32_T c7_q_partialTrueCount;
  int32_T c7_lb_i;
  int32_T c7_g_data_struct_input_sizes[2];
  int32_T c7_ab_data_struct_input;
  int32_T c7_bb_data_struct_input;
  int32_T c7_s_loop_ub;
  int32_T c7_i354;
  real32_T c7_g_data_struct_input_data[5];
  real32_T c7_A;
  real32_T c7_sc_y;
  real_T c7_d9;
  real_T c7_d10;
  real32_T c7_f5;
  real32_T c7_f6;
  real32_T c7_f7;
  real32_T c7_f8;
  real_T c7_d11;
  uint32_T c7_u35;
  uint8_T c7_uv14[1];
  boolean_T c7_b35;
  int32_T c7_r_trueCount;
  int32_T c7_mb_i;
  int32_T c7_r_partialTrueCount;
  int32_T c7_nb_i;
  int32_T c7_i355;
  int32_T c7_i356;
  int32_T c7_t_loop_ub;
  int32_T c7_i357;
  int32_T c7_i358;
  int32_T c7_i359;
  real_T c7_d12;
  real_T c7_d13;
  int32_T c7_i360;
  int32_T c7_c_index;
  real32_T c7_f9;
  real32_T c7_f10;
  real32_T c7_f11;
  real32_T c7_f12;
  real_T c7_d14;
  real_T c7_dv2[1];
  int32_T c7_s_trueCount;
  int32_T c7_ob_i;
  int32_T c7_s_partialTrueCount;
  int32_T c7_pb_i;
  int32_T c7_d_tmp_sizes[2];
  int32_T c7_i361;
  int32_T c7_i362;
  int32_T c7_u_loop_ub;
  int32_T c7_i363;
  real_T c7_d_tmp_data[1];
  real32_T c7_f13;
  real32_T c7_b_A;
  real32_T c7_tc_y;
  int32_T c7_t_trueCount;
  int32_T c7_qb_i;
  int32_T c7_e_tmp_sizes;
  int32_T c7_t_partialTrueCount;
  int32_T c7_rb_i;
  int32_T c7_e_tmp_data[50];
  int32_T c7_EC_peaks_sizes;
  int32_T c7_v_loop_ub;
  int32_T c7_i364;
  real_T c7_EC_peaks_data[50];
  int32_T c7_i365;
  real_T c7_b_varargin_1[50];
  int32_T c7_ixstart;
  real_T c7_c_mtmp;
  real_T c7_x;
  boolean_T c7_sc_b;
  int32_T c7_ix;
  int32_T c7_b_ix;
  real_T c7_b_x;
  boolean_T c7_tc_b;
  int32_T c7_i366;
  int32_T c7_c_ix;
  real_T c7_b_a;
  real_T c7_uc_b;
  boolean_T c7_b_p;
  real_T c7_d_mtmp;
  real_T c7_minval;
  uint32_T c7_u36;
  uint8_T c7_uv15[1];
  boolean_T c7_b36;
  int32_T c7_u_trueCount;
  int32_T c7_sb_i;
  int32_T c7_u_partialTrueCount;
  int32_T c7_tb_i;
  int32_T c7_i367;
  int32_T c7_i368;
  int32_T c7_w_loop_ub;
  int32_T c7_i369;
  int32_T c7_i370;
  int32_T c7_i371;
  boolean_T c7_bv5[5];
  int32_T c7_v_trueCount;
  int32_T c7_ub_i;
  int32_T c7_v_partialTrueCount;
  int32_T c7_vb_i;
  int32_T c7_w_trueCount;
  int32_T c7_wb_i;
  int32_T c7_f_tmp_sizes[2];
  int32_T c7_w_partialTrueCount;
  int32_T c7_xb_i;
  int32_T c7_f_tmp_data[5];
  int32_T c7_h_data_struct_input_sizes[2];
  int32_T c7_cb_data_struct_input;
  int32_T c7_db_data_struct_input;
  int32_T c7_x_loop_ub;
  int32_T c7_i372;
  real32_T c7_h_data_struct_input_data[5];
  int32_T c7_i_data_struct_input_sizes[2];
  int32_T c7_eb_data_struct_input;
  int32_T c7_fb_data_struct_input;
  int32_T c7_y_loop_ub;
  int32_T c7_i373;
  real32_T c7_i_data_struct_input_data[5];
  real32_T c7_c_A;
  real32_T c7_uc_y;
  int32_T c7_i374;
  int32_T c7_i375;
  int32_T c7_x_trueCount;
  int32_T c7_yb_i;
  int32_T c7_x_partialTrueCount;
  int32_T c7_ac_i;
  int32_T c7_y_trueCount;
  int32_T c7_bc_i;
  int32_T c7_y_partialTrueCount;
  int32_T c7_cc_i;
  int32_T c7_j_data_struct_input_sizes[2];
  int32_T c7_gb_data_struct_input;
  int32_T c7_hb_data_struct_input;
  int32_T c7_ab_loop_ub;
  int32_T c7_i376;
  real32_T c7_j_data_struct_input_data[5];
  int32_T c7_k_data_struct_input_sizes[2];
  int32_T c7_ib_data_struct_input;
  int32_T c7_jb_data_struct_input;
  int32_T c7_bb_loop_ub;
  int32_T c7_i377;
  real32_T c7_k_data_struct_input_data[5];
  real32_T c7_d_A;
  real32_T c7_vc_y;
  int32_T c7_i378;
  int32_T c7_ab_trueCount;
  int32_T c7_dc_i;
  int32_T c7_ab_partialTrueCount;
  int32_T c7_ec_i;
  int32_T c7_l_data_struct_input_sizes[2];
  int32_T c7_kb_data_struct_input;
  int32_T c7_lb_data_struct_input;
  int32_T c7_cb_loop_ub;
  int32_T c7_i379;
  real32_T c7_l_data_struct_input_data[5];
  real32_T c7_e_A;
  real32_T c7_wc_y;
  uint32_T c7_u37;
  uint8_T c7_uv16[1];
  boolean_T c7_b37;
  int32_T c7_bb_trueCount;
  int32_T c7_fc_i;
  int32_T c7_bb_partialTrueCount;
  int32_T c7_gc_i;
  int32_T c7_i380;
  int32_T c7_i381;
  int32_T c7_db_loop_ub;
  int32_T c7_i382;
  int32_T c7_i383;
  int32_T c7_cb_trueCount;
  int32_T c7_hc_i;
  int32_T c7_cb_partialTrueCount;
  int32_T c7_ic_i;
  int32_T c7_m_data_struct_input_sizes[2];
  int32_T c7_mb_data_struct_input;
  int32_T c7_nb_data_struct_input;
  int32_T c7_eb_loop_ub;
  int32_T c7_i384;
  real32_T c7_m_data_struct_input_data[5];
  real32_T c7_vc_b;
  real32_T c7_xc_y;
  int32_T c7_n_data_struct_input_sizes[2];
  int32_T c7_ob_data_struct_input;
  int32_T c7_pb_data_struct_input;
  int32_T c7_fb_loop_ub;
  int32_T c7_i385;
  real32_T c7_n_data_struct_input_data[5];
  real32_T c7_f14;
  real32_T c7_f15;
  real32_T c7_f16;
  real32_T c7_f17;
  uint32_T c7_u38;
  uint8_T c7_uv17[1];
  boolean_T c7_b38;
  int32_T c7_db_trueCount;
  int32_T c7_jc_i;
  int32_T c7_db_partialTrueCount;
  int32_T c7_kc_i;
  int32_T c7_i386;
  int32_T c7_i387;
  int32_T c7_gb_loop_ub;
  int32_T c7_i388;
  int32_T c7_i389;
  int32_T c7_eb_trueCount;
  int32_T c7_lc_i;
  int32_T c7_eb_partialTrueCount;
  int32_T c7_mc_i;
  int32_T c7_o_data_struct_input_sizes[2];
  int32_T c7_qb_data_struct_input;
  int32_T c7_rb_data_struct_input;
  int32_T c7_hb_loop_ub;
  int32_T c7_i390;
  real32_T c7_o_data_struct_input_data[5];
  real32_T c7_wc_b;
  real32_T c7_yc_y;
  int32_T c7_p_data_struct_input_sizes[2];
  int32_T c7_sb_data_struct_input;
  int32_T c7_tb_data_struct_input;
  int32_T c7_ib_loop_ub;
  int32_T c7_i391;
  real32_T c7_p_data_struct_input_data[5];
  int32_T c7_i392;
  int32_T c7_fb_trueCount;
  int32_T c7_nc_i;
  int32_T c7_fb_partialTrueCount;
  int32_T c7_oc_i;
  int32_T c7_q_data_struct_input_sizes[2];
  int32_T c7_ub_data_struct_input;
  int32_T c7_vb_data_struct_input;
  int32_T c7_jb_loop_ub;
  int32_T c7_i393;
  real32_T c7_q_data_struct_input_data[5];
  real32_T c7_f_A;
  real32_T c7_ad_y;
  uint32_T c7_u39;
  uint8_T c7_uv18[1];
  boolean_T c7_b39;
  int32_T c7_gb_trueCount;
  int32_T c7_pc_i;
  int32_T c7_gb_partialTrueCount;
  int32_T c7_qc_i;
  int32_T c7_i394;
  int32_T c7_i395;
  int32_T c7_kb_loop_ub;
  int32_T c7_i396;
  int32_T c7_i397;
  int32_T c7_hb_trueCount;
  int32_T c7_rc_i;
  int32_T c7_hb_partialTrueCount;
  int32_T c7_sc_i;
  int32_T c7_r_data_struct_input_sizes[2];
  int32_T c7_wb_data_struct_input;
  int32_T c7_xb_data_struct_input;
  int32_T c7_lb_loop_ub;
  int32_T c7_i398;
  real32_T c7_r_data_struct_input_data[5];
  real32_T c7_xc_b;
  real32_T c7_bd_y;
  int32_T c7_s_data_struct_input_sizes[2];
  int32_T c7_yb_data_struct_input;
  int32_T c7_ac_data_struct_input;
  int32_T c7_mb_loop_ub;
  int32_T c7_i399;
  real32_T c7_s_data_struct_input_data[5];
  real32_T c7_f18;
  real32_T c7_f19;
  real32_T c7_f20;
  real32_T c7_f21;
  uint32_T c7_u40;
  uint8_T c7_uv19[1];
  boolean_T c7_b40;
  int32_T c7_ib_trueCount;
  int32_T c7_tc_i;
  int32_T c7_ib_partialTrueCount;
  int32_T c7_uc_i;
  int32_T c7_i400;
  int32_T c7_i401;
  int32_T c7_nb_loop_ub;
  int32_T c7_i402;
  int32_T c7_i403;
  int32_T c7_jb_trueCount;
  int32_T c7_vc_i;
  int32_T c7_jb_partialTrueCount;
  int32_T c7_wc_i;
  int32_T c7_t_data_struct_input_sizes[2];
  int32_T c7_bc_data_struct_input;
  int32_T c7_cc_data_struct_input;
  int32_T c7_ob_loop_ub;
  int32_T c7_i404;
  real32_T c7_t_data_struct_input_data[5];
  real32_T c7_yc_b;
  real32_T c7_cd_y;
  int32_T c7_u_data_struct_input_sizes[2];
  int32_T c7_dc_data_struct_input;
  int32_T c7_ec_data_struct_input;
  int32_T c7_pb_loop_ub;
  int32_T c7_i405;
  real32_T c7_u_data_struct_input_data[5];
  int32_T c7_i406;
  int32_T c7_kb_trueCount;
  int32_T c7_xc_i;
  int32_T c7_kb_partialTrueCount;
  int32_T c7_yc_i;
  int32_T c7_v_data_struct_input_sizes[2];
  int32_T c7_fc_data_struct_input;
  int32_T c7_gc_data_struct_input;
  int32_T c7_qb_loop_ub;
  int32_T c7_i407;
  real32_T c7_v_data_struct_input_data[5];
  real32_T c7_g_A;
  real32_T c7_dd_y;
  real_T c7_d15;
  real_T c7_d16;
  real32_T c7_f22;
  real32_T c7_f23;
  real32_T c7_f24;
  real32_T c7_f25;
  real_T c7_d17;
  uint32_T c7_u41;
  uint8_T c7_uv20[1];
  boolean_T c7_b41;
  int32_T c7_lb_trueCount;
  int32_T c7_ad_i;
  int32_T c7_lb_partialTrueCount;
  int32_T c7_bd_i;
  int32_T c7_i408;
  int32_T c7_i409;
  int32_T c7_rb_loop_ub;
  int32_T c7_i410;
  int32_T c7_i411;
  int32_T c7_i412;
  real_T c7_d18;
  real_T c7_d19;
  int32_T c7_i413;
  int32_T c7_d_index;
  real32_T c7_f26;
  real32_T c7_f27;
  real32_T c7_f28;
  real32_T c7_f29;
  real_T c7_d20;
  real_T c7_dv3[1];
  int32_T c7_mb_trueCount;
  int32_T c7_cd_i;
  int32_T c7_mb_partialTrueCount;
  int32_T c7_dd_i;
  int32_T c7_i414;
  int32_T c7_i415;
  int32_T c7_sb_loop_ub;
  int32_T c7_i416;
  real32_T c7_f30;
  real32_T c7_h_A;
  real32_T c7_ed_y;
  int32_T c7_nb_trueCount;
  int32_T c7_ed_i;
  int32_T c7_nb_partialTrueCount;
  int32_T c7_fd_i;
  int32_T c7_b_EC_peaks_sizes;
  int32_T c7_tb_loop_ub;
  int32_T c7_i417;
  real_T c7_b_EC_peaks_data[50];
  int32_T c7_i418;
  int32_T c7_b_ixstart;
  real_T c7_e_mtmp;
  real_T c7_c_x;
  boolean_T c7_ad_b;
  int32_T c7_d_ix;
  int32_T c7_e_ix;
  real_T c7_d_x;
  boolean_T c7_bd_b;
  int32_T c7_i419;
  int32_T c7_f_ix;
  real_T c7_c_a;
  real_T c7_cd_b;
  boolean_T c7_c_p;
  real_T c7_f_mtmp;
  real_T c7_b_minval;
  uint32_T c7_u42;
  uint8_T c7_uv21[1];
  boolean_T c7_b42;
  int32_T c7_ob_trueCount;
  int32_T c7_gd_i;
  int32_T c7_ob_partialTrueCount;
  int32_T c7_hd_i;
  int32_T c7_i420;
  int32_T c7_i421;
  int32_T c7_ub_loop_ub;
  int32_T c7_i422;
  int32_T c7_i423;
  int32_T c7_i424;
  int32_T c7_pb_trueCount;
  int32_T c7_id_i;
  int32_T c7_pb_partialTrueCount;
  int32_T c7_jd_i;
  int32_T c7_qb_trueCount;
  int32_T c7_kd_i;
  int32_T c7_qb_partialTrueCount;
  int32_T c7_ld_i;
  int32_T c7_w_data_struct_input_sizes[2];
  int32_T c7_hc_data_struct_input;
  int32_T c7_ic_data_struct_input;
  int32_T c7_vb_loop_ub;
  int32_T c7_i425;
  real32_T c7_w_data_struct_input_data[5];
  int32_T c7_x_data_struct_input_sizes[2];
  int32_T c7_jc_data_struct_input;
  int32_T c7_kc_data_struct_input;
  int32_T c7_wb_loop_ub;
  int32_T c7_i426;
  real32_T c7_x_data_struct_input_data[5];
  real32_T c7_i_A;
  real32_T c7_fd_y;
  int32_T c7_i427;
  int32_T c7_i428;
  int32_T c7_rb_trueCount;
  int32_T c7_md_i;
  int32_T c7_rb_partialTrueCount;
  int32_T c7_nd_i;
  int32_T c7_sb_trueCount;
  int32_T c7_od_i;
  int32_T c7_sb_partialTrueCount;
  int32_T c7_pd_i;
  int32_T c7_y_data_struct_input_sizes[2];
  int32_T c7_lc_data_struct_input;
  int32_T c7_mc_data_struct_input;
  int32_T c7_xb_loop_ub;
  int32_T c7_i429;
  real32_T c7_y_data_struct_input_data[5];
  int32_T c7_ab_data_struct_input_sizes[2];
  int32_T c7_nc_data_struct_input;
  int32_T c7_oc_data_struct_input;
  int32_T c7_yb_loop_ub;
  int32_T c7_i430;
  real32_T c7_ab_data_struct_input_data[5];
  real32_T c7_j_A;
  real32_T c7_gd_y;
  int32_T c7_i431;
  int32_T c7_tb_trueCount;
  int32_T c7_qd_i;
  int32_T c7_tb_partialTrueCount;
  int32_T c7_rd_i;
  int32_T c7_bb_data_struct_input_sizes[2];
  int32_T c7_pc_data_struct_input;
  int32_T c7_qc_data_struct_input;
  int32_T c7_ac_loop_ub;
  int32_T c7_i432;
  real32_T c7_bb_data_struct_input_data[5];
  real32_T c7_k_A;
  real32_T c7_hd_y;
  uint32_T c7_u43;
  uint8_T c7_uv22[1];
  boolean_T c7_b43;
  int32_T c7_ub_trueCount;
  int32_T c7_sd_i;
  int32_T c7_ub_partialTrueCount;
  int32_T c7_td_i;
  int32_T c7_i433;
  int32_T c7_i434;
  int32_T c7_bc_loop_ub;
  int32_T c7_i435;
  int32_T c7_i436;
  int32_T c7_vb_trueCount;
  int32_T c7_ud_i;
  int32_T c7_vb_partialTrueCount;
  int32_T c7_vd_i;
  int32_T c7_cb_data_struct_input_sizes[2];
  int32_T c7_rc_data_struct_input;
  int32_T c7_sc_data_struct_input;
  int32_T c7_cc_loop_ub;
  int32_T c7_i437;
  real32_T c7_cb_data_struct_input_data[5];
  real32_T c7_dd_b;
  real32_T c7_id_y;
  int32_T c7_db_data_struct_input_sizes[2];
  int32_T c7_tc_data_struct_input;
  int32_T c7_uc_data_struct_input;
  int32_T c7_dc_loop_ub;
  int32_T c7_i438;
  real32_T c7_db_data_struct_input_data[5];
  real32_T c7_f31;
  real32_T c7_f32;
  real32_T c7_f33;
  real32_T c7_f34;
  uint32_T c7_u44;
  uint8_T c7_uv23[1];
  boolean_T c7_b44;
  int32_T c7_wb_trueCount;
  int32_T c7_wd_i;
  int32_T c7_wb_partialTrueCount;
  int32_T c7_xd_i;
  int32_T c7_i439;
  int32_T c7_i440;
  int32_T c7_ec_loop_ub;
  int32_T c7_i441;
  int32_T c7_i442;
  int32_T c7_xb_trueCount;
  int32_T c7_yd_i;
  int32_T c7_xb_partialTrueCount;
  int32_T c7_ae_i;
  int32_T c7_eb_data_struct_input_sizes[2];
  int32_T c7_vc_data_struct_input;
  int32_T c7_wc_data_struct_input;
  int32_T c7_fc_loop_ub;
  int32_T c7_i443;
  real32_T c7_eb_data_struct_input_data[5];
  real32_T c7_ed_b;
  real32_T c7_jd_y;
  int32_T c7_fb_data_struct_input_sizes[2];
  int32_T c7_xc_data_struct_input;
  int32_T c7_yc_data_struct_input;
  int32_T c7_gc_loop_ub;
  int32_T c7_i444;
  real32_T c7_fb_data_struct_input_data[5];
  int32_T c7_i445;
  int32_T c7_yb_trueCount;
  int32_T c7_be_i;
  int32_T c7_yb_partialTrueCount;
  int32_T c7_ce_i;
  int32_T c7_gb_data_struct_input_sizes[2];
  int32_T c7_ad_data_struct_input;
  int32_T c7_bd_data_struct_input;
  int32_T c7_hc_loop_ub;
  int32_T c7_i446;
  real32_T c7_gb_data_struct_input_data[5];
  real32_T c7_l_A;
  real32_T c7_kd_y;
  uint32_T c7_u45;
  int32_T c7_i447;
  real32_T c7_cd_data_struct_input[199];
  int32_T c7_i448;
  real32_T c7_fd_b;
  real32_T c7_ld_y;
  real32_T c7_gd_b;
  real32_T c7_md_y;
  real32_T c7_hd_b;
  real32_T c7_nd_y;
  real32_T c7_id_b;
  real32_T c7_od_y;
  real32_T c7_jd_b;
  real32_T c7_pd_y;
  real32_T c7_kd_b;
  real32_T c7_qd_y;
  real32_T c7_ld_b;
  real32_T c7_rd_y;
  real32_T c7_md_b;
  real32_T c7_sd_y;
  real32_T c7_nd_b;
  real32_T c7_td_y;
  real32_T c7_od_b;
  real32_T c7_ud_y;
  real32_T c7_pd_b;
  real32_T c7_vd_y;
  int32_T c7_i449;
  real32_T c7_dd_data_struct_input[199];
  int32_T c7_i450;
  real32_T c7_qd_b;
  real32_T c7_wd_y;
  real32_T c7_rd_b;
  real32_T c7_xd_y;
  real32_T c7_sd_b;
  real32_T c7_yd_y;
  real32_T c7_td_b;
  real32_T c7_ae_y;
  real32_T c7_ud_b;
  real32_T c7_be_y;
  real32_T c7_vd_b;
  real32_T c7_ce_y;
  real32_T c7_wd_b;
  real32_T c7_de_y;
  real32_T c7_xd_b;
  real32_T c7_ee_y;
  real32_T c7_yd_b;
  real32_T c7_fe_y;
  real32_T c7_ae_b;
  real32_T c7_ge_y;
  real32_T c7_be_b;
  real32_T c7_he_y;
  uint32_T c7_u46;
  real32_T c7_f35;
  real_T c7_d21;
  uint16_T c7_u47;
  uint32_T c7_u48;
  real32_T c7_f36;
  real_T c7_d22;
  uint16_T c7_u49;
  uint32_T c7_u50;
  uint16_T c7_m_A;
  uint16_T c7_e_x;
  uint16_T c7_f_x;
  uint16_T c7_g_x;
  uint16_T c7_h_x;
  real_T c7_xk;
  real_T c7_d23;
  uint16_T c7_u51;
  uint16_T c7_ie_y;
  uint32_T c7_u52;
  uint16_T c7_u53;
  uint16_T c7_uv24[1];
  boolean_T c7_b45;
  int32_T c7_ac_trueCount;
  int32_T c7_de_i;
  int32_T c7_ac_partialTrueCount;
  int32_T c7_ee_i;
  int32_T c7_g_tmp_sizes[2];
  int32_T c7_i451;
  int32_T c7_i452;
  int32_T c7_ic_loop_ub;
  int32_T c7_i453;
  uint16_T c7_g_tmp_data[1];
  uint32_T c7_u54;
  uint16_T c7_uv25[1];
  boolean_T c7_b46;
  int32_T c7_bc_trueCount;
  int32_T c7_fe_i;
  int32_T c7_bc_partialTrueCount;
  int32_T c7_ge_i;
  int32_T c7_i454;
  int32_T c7_i455;
  int32_T c7_jc_loop_ub;
  int32_T c7_i456;
  int32_T c7_i457;
  int32_T c7_i458;
  int32_T c7_i459;
  int32_T c7_i460;
  int32_T c7_i461;
  int32_T c7_i462;
  int32_T c7_i463;
  int32_T c7_i464;
  int32_T c7_i465;
  int32_T c7_i466;
  uint32_T c7_c_q0;
  uint32_T c7_c_qY;
  uint32_T c7_u55;
  uint32_T c7_u56;
  uint16_T c7_u57;
  uint16_T c7_he_i;
  uint32_T c7_d_q0;
  uint32_T c7_d_qY;
  uint32_T c7_u58;
  real32_T c7_f37;
  uint32_T c7_u59;
  uint32_T c7_u60;
  uint32_T c7_u61;
  uint8_T c7_uv26[1];
  boolean_T c7_b47;
  int32_T c7_cc_trueCount;
  int32_T c7_ie_i;
  int32_T c7_cc_partialTrueCount;
  int32_T c7_je_i;
  int32_T c7_i467;
  int32_T c7_i468;
  int32_T c7_kc_loop_ub;
  int32_T c7_i469;
  uint32_T c7_e_q0;
  uint32_T c7_e_qY;
  uint32_T c7_u62;
  uint32_T c7_u63;
  uint32_T c7_f_q0;
  uint32_T c7_f_qY;
  uint32_T c7_u64;
  uint32_T c7_g_q0;
  uint32_T c7_g_qY;
  uint32_T c7_u65;
  uint32_T c7_u66;
  uint32_T c7_u67;
  uint32_T c7_u68;
  uint8_T c7_uv27[1];
  boolean_T c7_b48;
  int32_T c7_dc_trueCount;
  int32_T c7_ke_i;
  int32_T c7_dc_partialTrueCount;
  int32_T c7_le_i;
  int32_T c7_i470;
  int32_T c7_i471;
  int32_T c7_lc_loop_ub;
  int32_T c7_i472;
  uint32_T c7_h_q0;
  uint32_T c7_h_qY;
  uint32_T c7_u69;
  uint32_T c7_u70;
  uint32_T c7_i_q0;
  uint32_T c7_i_qY;
  uint32_T c7_u71;
  uint32_T c7_j_q0;
  uint32_T c7_j_qY;
  uint32_T c7_u72;
  real_T c7_dv4[1];
  int32_T c7_ec_trueCount;
  int32_T c7_me_i;
  int32_T c7_ec_partialTrueCount;
  int32_T c7_ne_i;
  int32_T c7_i473;
  int32_T c7_i474;
  int32_T c7_mc_loop_ub;
  int32_T c7_i475;
  uint32_T c7_u73;
  uint32_T c7_k_q0;
  uint32_T c7_k_qY;
  uint32_T c7_u74;
  real32_T c7_f38;
  uint32_T c7_u75;
  uint32_T c7_u76;
  uint32_T c7_u77;
  uint8_T c7_uv28[1];
  boolean_T c7_b49;
  int32_T c7_fc_trueCount;
  int32_T c7_oe_i;
  int32_T c7_fc_partialTrueCount;
  int32_T c7_pe_i;
  int32_T c7_i476;
  int32_T c7_i477;
  int32_T c7_nc_loop_ub;
  int32_T c7_i478;
  uint32_T c7_l_q0;
  uint32_T c7_l_qY;
  uint32_T c7_u78;
  uint32_T c7_u79;
  uint32_T c7_m_q0;
  uint32_T c7_m_qY;
  uint32_T c7_u80;
  uint32_T c7_n_q0;
  uint32_T c7_n_qY;
  uint32_T c7_u81;
  uint32_T c7_u82;
  uint32_T c7_u83;
  uint32_T c7_u84;
  uint8_T c7_uv29[1];
  boolean_T c7_b50;
  int32_T c7_gc_trueCount;
  int32_T c7_qe_i;
  int32_T c7_gc_partialTrueCount;
  int32_T c7_re_i;
  int32_T c7_i479;
  int32_T c7_i480;
  int32_T c7_oc_loop_ub;
  int32_T c7_i481;
  uint32_T c7_o_q0;
  uint32_T c7_o_qY;
  uint32_T c7_u85;
  uint32_T c7_u86;
  uint32_T c7_p_q0;
  uint32_T c7_p_qY;
  uint32_T c7_u87;
  uint32_T c7_q_q0;
  uint32_T c7_q_qY;
  uint32_T c7_u88;
  real_T c7_dv5[1];
  int32_T c7_hc_trueCount;
  int32_T c7_se_i;
  int32_T c7_hc_partialTrueCount;
  int32_T c7_te_i;
  int32_T c7_i482;
  int32_T c7_i483;
  int32_T c7_pc_loop_ub;
  int32_T c7_i484;
  uint32_T c7_u89;
  int32_T c7_i485;
  int32_T c7_ic_trueCount;
  int32_T c7_ue_i;
  int32_T c7_ic_partialTrueCount;
  int32_T c7_ve_i;
  int32_T c7_hb_data_struct_input_sizes[2];
  int32_T c7_ed_data_struct_input;
  int32_T c7_fd_data_struct_input;
  int32_T c7_qc_loop_ub;
  int32_T c7_i486;
  real32_T c7_hb_data_struct_input_data[5];
  int32_T c7_i487;
  int32_T c7_jc_trueCount;
  int32_T c7_we_i;
  int32_T c7_jc_partialTrueCount;
  int32_T c7_xe_i;
  int32_T c7_ib_data_struct_input_sizes[2];
  int32_T c7_gd_data_struct_input;
  int32_T c7_hd_data_struct_input;
  int32_T c7_rc_loop_ub;
  int32_T c7_i488;
  real32_T c7_ib_data_struct_input_data[5];
  real_T c7_d24;
  int32_T c7_i489;
  int32_T c7_ye_i;
  real32_T c7_f39;
  real32_T c7_f40;
  real32_T c7_f41;
  real32_T c7_f42;
  uint32_T c7_u90;
  uint8_T c7_uv30[1];
  boolean_T c7_b51;
  int32_T c7_kc_trueCount;
  int32_T c7_af_i;
  int32_T c7_kc_partialTrueCount;
  int32_T c7_bf_i;
  int32_T c7_i490;
  int32_T c7_i491;
  int32_T c7_sc_loop_ub;
  int32_T c7_i492;
  real_T c7_d25;
  int32_T c7_i493;
  int32_T c7_cf_i;
  real32_T c7_f43;
  real32_T c7_f44;
  real32_T c7_f45;
  real32_T c7_f46;
  uint32_T c7_u91;
  uint8_T c7_uv31[1];
  boolean_T c7_b52;
  int32_T c7_lc_trueCount;
  int32_T c7_df_i;
  int32_T c7_lc_partialTrueCount;
  int32_T c7_ef_i;
  int32_T c7_i494;
  int32_T c7_i495;
  int32_T c7_tc_loop_ub;
  int32_T c7_i496;
  uint32_T c7_r_q0;
  uint32_T c7_r_qY;
  uint32_T c7_u92;
  uint8_T c7_u93;
  uint8_T c7_ff_i;
  uint32_T c7_s_q0;
  uint32_T c7_s_qY;
  uint32_T c7_u94;
  uint32_T c7_u95;
  uint32_T c7_u96;
  uint8_T c7_uv32[1];
  boolean_T c7_b53;
  int32_T c7_mc_trueCount;
  int32_T c7_gf_i;
  int32_T c7_mc_partialTrueCount;
  int32_T c7_hf_i;
  int32_T c7_i497;
  int32_T c7_i498;
  int32_T c7_uc_loop_ub;
  int32_T c7_i499;
  uint32_T c7_t_q0;
  uint32_T c7_t_qY;
  uint32_T c7_u97;
  uint8_T c7_u98;
  uint8_T c7_if_i;
  uint32_T c7_u_q0;
  uint32_T c7_u_qY;
  uint32_T c7_u99;
  uint32_T c7_u100;
  uint32_T c7_u101;
  uint8_T c7_uv33[1];
  boolean_T c7_b54;
  int32_T c7_nc_trueCount;
  int32_T c7_jf_i;
  int32_T c7_nc_partialTrueCount;
  int32_T c7_kf_i;
  int32_T c7_i500;
  int32_T c7_i501;
  int32_T c7_vc_loop_ub;
  int32_T c7_i502;
  int32_T c7_i503;
  int32_T c7_oc_trueCount;
  int32_T c7_lf_i;
  int32_T c7_oc_partialTrueCount;
  int32_T c7_mf_i;
  int32_T c7_jb_data_struct_input_sizes[2];
  int32_T c7_id_data_struct_input;
  int32_T c7_jd_data_struct_input;
  int32_T c7_wc_loop_ub;
  int32_T c7_i504;
  real32_T c7_jb_data_struct_input_data[5];
  int32_T c7_i505;
  int32_T c7_pc_trueCount;
  int32_T c7_nf_i;
  int32_T c7_pc_partialTrueCount;
  int32_T c7_of_i;
  int32_T c7_kb_data_struct_input_sizes[2];
  int32_T c7_kd_data_struct_input;
  int32_T c7_ld_data_struct_input;
  int32_T c7_xc_loop_ub;
  int32_T c7_i506;
  real32_T c7_kb_data_struct_input_data[5];
  int32_T c7_i507;
  int32_T c7_qc_trueCount;
  int32_T c7_pf_i;
  int32_T c7_qc_partialTrueCount;
  int32_T c7_qf_i;
  int32_T c7_lb_data_struct_input_sizes[2];
  int32_T c7_md_data_struct_input;
  int32_T c7_nd_data_struct_input;
  int32_T c7_yc_loop_ub;
  int32_T c7_i508;
  real32_T c7_lb_data_struct_input_data[5];
  int32_T c7_i509;
  int32_T c7_rc_trueCount;
  int32_T c7_rf_i;
  int32_T c7_rc_partialTrueCount;
  int32_T c7_sf_i;
  int32_T c7_mb_data_struct_input_sizes[2];
  int32_T c7_od_data_struct_input;
  int32_T c7_pd_data_struct_input;
  int32_T c7_ad_loop_ub;
  int32_T c7_i510;
  real32_T c7_mb_data_struct_input_data[5];
  real_T c7_d26;
  int32_T c7_i511;
  int32_T c7_tf_i;
  uint32_T c7_v_q0;
  uint32_T c7_v_qY;
  uint32_T c7_u102;
  uint32_T c7_u103;
  real32_T c7_f47;
  real32_T c7_f48;
  real32_T c7_f49;
  real32_T c7_f50;
  real_T c7_d27;
  uint32_T c7_w_q0;
  uint32_T c7_w_qY;
  uint32_T c7_u104;
  uint32_T c7_u105;
  real32_T c7_f51;
  real32_T c7_f52;
  real32_T c7_f53;
  real32_T c7_f54;
  real_T c7_d28;
  uint32_T c7_u106;
  uint8_T c7_uv34[1];
  boolean_T c7_b55;
  int32_T c7_sc_trueCount;
  int32_T c7_uf_i;
  int32_T c7_sc_partialTrueCount;
  int32_T c7_vf_i;
  int32_T c7_i512;
  int32_T c7_i513;
  int32_T c7_bd_loop_ub;
  int32_T c7_i514;
  real_T c7_d29;
  int32_T c7_i515;
  int32_T c7_wf_i;
  uint32_T c7_x_q0;
  uint32_T c7_x_qY;
  uint32_T c7_u107;
  uint32_T c7_u108;
  real32_T c7_f55;
  real32_T c7_f56;
  real32_T c7_f57;
  real32_T c7_f58;
  real_T c7_d30;
  uint32_T c7_y_q0;
  uint32_T c7_y_qY;
  uint32_T c7_u109;
  uint32_T c7_u110;
  real32_T c7_f59;
  real32_T c7_f60;
  real32_T c7_f61;
  real32_T c7_f62;
  real_T c7_d31;
  uint32_T c7_u111;
  uint8_T c7_uv35[1];
  boolean_T c7_b56;
  int32_T c7_tc_trueCount;
  int32_T c7_xf_i;
  int32_T c7_tc_partialTrueCount;
  int32_T c7_yf_i;
  int32_T c7_i516;
  int32_T c7_i517;
  int32_T c7_cd_loop_ub;
  int32_T c7_i518;
  uint32_T c7_ab_q0;
  uint32_T c7_ab_qY;
  uint32_T c7_u112;
  uint8_T c7_u113;
  uint8_T c7_ag_i;
  int32_T c7_i519;
  int32_T c7_i520;
  real_T c7_dv6[1];
  int32_T c7_uc_trueCount;
  int32_T c7_bg_i;
  int32_T c7_uc_partialTrueCount;
  int32_T c7_cg_i;
  int32_T c7_i521;
  int32_T c7_i522;
  int32_T c7_dd_loop_ub;
  int32_T c7_i523;
  real32_T c7_f63;
  real32_T c7_n_A;
  real32_T c7_je_y;
  int32_T c7_vc_trueCount;
  int32_T c7_dg_i;
  int32_T c7_vc_partialTrueCount;
  int32_T c7_eg_i;
  int32_T c7_c_EC_peaks_sizes;
  int32_T c7_ed_loop_ub;
  int32_T c7_i524;
  real_T c7_c_EC_peaks_data[50];
  int32_T c7_i525;
  int32_T c7_c_ixstart;
  real_T c7_g_mtmp;
  real_T c7_i_x;
  boolean_T c7_ce_b;
  int32_T c7_g_ix;
  int32_T c7_h_ix;
  real_T c7_j_x;
  boolean_T c7_de_b;
  int32_T c7_i526;
  int32_T c7_i_ix;
  real_T c7_d_a;
  real_T c7_ee_b;
  boolean_T c7_d_p;
  real_T c7_h_mtmp;
  real_T c7_c_minval;
  uint32_T c7_u114;
  uint8_T c7_uv36[1];
  boolean_T c7_b57;
  int32_T c7_wc_trueCount;
  int32_T c7_fg_i;
  int32_T c7_wc_partialTrueCount;
  int32_T c7_gg_i;
  int32_T c7_i527;
  int32_T c7_i528;
  int32_T c7_fd_loop_ub;
  int32_T c7_i529;
  uint32_T c7_bb_q0;
  uint32_T c7_bb_qY;
  uint32_T c7_u115;
  uint8_T c7_u116;
  uint8_T c7_hg_i;
  int32_T c7_i530;
  int32_T c7_i531;
  real_T c7_dv7[1];
  int32_T c7_xc_trueCount;
  int32_T c7_ig_i;
  int32_T c7_xc_partialTrueCount;
  int32_T c7_jg_i;
  int32_T c7_i532;
  int32_T c7_i533;
  int32_T c7_gd_loop_ub;
  int32_T c7_i534;
  real32_T c7_f64;
  real32_T c7_o_A;
  real32_T c7_ke_y;
  int32_T c7_yc_trueCount;
  int32_T c7_kg_i;
  int32_T c7_yc_partialTrueCount;
  int32_T c7_lg_i;
  int32_T c7_d_EC_peaks_sizes;
  int32_T c7_hd_loop_ub;
  int32_T c7_i535;
  real_T c7_d_EC_peaks_data[50];
  int32_T c7_i536;
  int32_T c7_d_ixstart;
  real_T c7_i_mtmp;
  real_T c7_k_x;
  boolean_T c7_fe_b;
  int32_T c7_j_ix;
  int32_T c7_k_ix;
  real_T c7_l_x;
  boolean_T c7_ge_b;
  int32_T c7_i537;
  int32_T c7_l_ix;
  real_T c7_e_a;
  real_T c7_he_b;
  boolean_T c7_e_p;
  real_T c7_j_mtmp;
  real_T c7_d_minval;
  uint32_T c7_u117;
  uint8_T c7_uv37[1];
  boolean_T c7_b58;
  int32_T c7_ad_trueCount;
  int32_T c7_mg_i;
  int32_T c7_ad_partialTrueCount;
  int32_T c7_ng_i;
  int32_T c7_i538;
  int32_T c7_i539;
  int32_T c7_id_loop_ub;
  int32_T c7_i540;
  int32_T c7_i541;
  int32_T c7_i542;
  int32_T c7_bd_trueCount;
  int32_T c7_og_i;
  int32_T c7_bd_partialTrueCount;
  int32_T c7_pg_i;
  int32_T c7_cd_trueCount;
  int32_T c7_qg_i;
  int32_T c7_cd_partialTrueCount;
  int32_T c7_rg_i;
  int32_T c7_nb_data_struct_input_sizes[2];
  int32_T c7_qd_data_struct_input;
  int32_T c7_rd_data_struct_input;
  int32_T c7_jd_loop_ub;
  int32_T c7_i543;
  real32_T c7_nb_data_struct_input_data[5];
  int32_T c7_ob_data_struct_input_sizes[2];
  int32_T c7_sd_data_struct_input;
  int32_T c7_td_data_struct_input;
  int32_T c7_kd_loop_ub;
  int32_T c7_i544;
  real32_T c7_ob_data_struct_input_data[5];
  real32_T c7_p_A;
  real32_T c7_le_y;
  int32_T c7_i545;
  int32_T c7_i546;
  int32_T c7_dd_trueCount;
  int32_T c7_sg_i;
  int32_T c7_dd_partialTrueCount;
  int32_T c7_tg_i;
  int32_T c7_ed_trueCount;
  int32_T c7_ug_i;
  int32_T c7_ed_partialTrueCount;
  int32_T c7_vg_i;
  int32_T c7_pb_data_struct_input_sizes[2];
  int32_T c7_ud_data_struct_input;
  int32_T c7_vd_data_struct_input;
  int32_T c7_ld_loop_ub;
  int32_T c7_i547;
  real32_T c7_pb_data_struct_input_data[5];
  int32_T c7_qb_data_struct_input_sizes[2];
  int32_T c7_wd_data_struct_input;
  int32_T c7_xd_data_struct_input;
  int32_T c7_md_loop_ub;
  int32_T c7_i548;
  real32_T c7_qb_data_struct_input_data[5];
  real32_T c7_q_A;
  real32_T c7_me_y;
  int32_T c7_i549;
  int32_T c7_i550;
  int32_T c7_fd_trueCount;
  int32_T c7_wg_i;
  int32_T c7_fd_partialTrueCount;
  int32_T c7_xg_i;
  int32_T c7_gd_trueCount;
  int32_T c7_yg_i;
  int32_T c7_gd_partialTrueCount;
  int32_T c7_ah_i;
  int32_T c7_rb_data_struct_input_sizes[2];
  int32_T c7_yd_data_struct_input;
  int32_T c7_ae_data_struct_input;
  int32_T c7_nd_loop_ub;
  int32_T c7_i551;
  real32_T c7_rb_data_struct_input_data[5];
  int32_T c7_sb_data_struct_input_sizes[2];
  int32_T c7_be_data_struct_input;
  int32_T c7_ce_data_struct_input;
  int32_T c7_od_loop_ub;
  int32_T c7_i552;
  real32_T c7_sb_data_struct_input_data[5];
  real32_T c7_r_A;
  real32_T c7_ne_y;
  int32_T c7_i553;
  int32_T c7_i554;
  int32_T c7_hd_trueCount;
  int32_T c7_bh_i;
  int32_T c7_hd_partialTrueCount;
  int32_T c7_ch_i;
  int32_T c7_id_trueCount;
  int32_T c7_dh_i;
  int32_T c7_id_partialTrueCount;
  int32_T c7_eh_i;
  int32_T c7_tb_data_struct_input_sizes[2];
  int32_T c7_de_data_struct_input;
  int32_T c7_ee_data_struct_input;
  int32_T c7_pd_loop_ub;
  int32_T c7_i555;
  real32_T c7_tb_data_struct_input_data[5];
  int32_T c7_ub_data_struct_input_sizes[2];
  int32_T c7_fe_data_struct_input;
  int32_T c7_ge_data_struct_input;
  int32_T c7_qd_loop_ub;
  int32_T c7_i556;
  real32_T c7_ub_data_struct_input_data[5];
  real32_T c7_s_A;
  real32_T c7_oe_y;
  int32_T c7_i557;
  int32_T c7_jd_trueCount;
  int32_T c7_fh_i;
  int32_T c7_jd_partialTrueCount;
  int32_T c7_gh_i;
  int32_T c7_vb_data_struct_input_sizes[2];
  int32_T c7_he_data_struct_input;
  int32_T c7_ie_data_struct_input;
  int32_T c7_rd_loop_ub;
  int32_T c7_i558;
  real32_T c7_vb_data_struct_input_data[5];
  real32_T c7_t_A;
  real32_T c7_pe_y;
  int32_T c7_i559;
  int32_T c7_kd_trueCount;
  int32_T c7_hh_i;
  int32_T c7_kd_partialTrueCount;
  int32_T c7_ih_i;
  int32_T c7_wb_data_struct_input_sizes[2];
  int32_T c7_je_data_struct_input;
  int32_T c7_ke_data_struct_input;
  int32_T c7_sd_loop_ub;
  int32_T c7_i560;
  real32_T c7_wb_data_struct_input_data[5];
  real32_T c7_u_A;
  real32_T c7_qe_y;
  uint32_T c7_cb_q0;
  uint32_T c7_cb_qY;
  uint32_T c7_u118;
  uint8_T c7_u119;
  uint8_T c7_jh_i;
  int32_T c7_ld_trueCount;
  int32_T c7_kh_i;
  int32_T c7_h_tmp_sizes;
  int32_T c7_ld_partialTrueCount;
  int32_T c7_lh_i;
  int32_T c7_h_tmp_data[5];
  real_T c7_c_EC_events_inds_left;
  int32_T c7_EC_events_inds_right_sizes;
  int32_T c7_td_loop_ub;
  int32_T c7_i561;
  real_T c7_EC_events_inds_right_data[5];
  int32_T c7_temp;
  int32_T c7_b_temp;
  int32_T c7_ud_loop_ub;
  int32_T c7_i562;
  int32_T c7_end;
  int32_T c7_md_trueCount;
  int32_T c7_mh_i;
  int32_T c7_b_end;
  int32_T c7_md_partialTrueCount;
  int32_T c7_nh_i;
  int32_T c7_vd_loop_ub;
  int32_T c7_i563;
  int32_T c7_wd_loop_ub;
  int32_T c7_i564;
  boolean_T c7_b59;
  const mxArray *c7_re_y = NULL;
  static char_T c7_u[36] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'a', 'u', 't', 'o', 'D', 'i', 'm', 'I', 'n', 'c', 'o',
    'm', 'p', 'a', 't', 'i', 'b', 'i', 'l', 'i', 't', 'y' };

  const mxArray *c7_se_y = NULL;
  static char_T c7_b_u[39] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'e', 'm', 'l', '_', 'm', 'i', 'n', '_', 'o', 'r', '_',
    'm', 'a', 'x', '_', 'v', 'a', 'r', 'D', 'i', 'm', 'Z', 'e', 'r', 'o' };

  int32_T c7_e_ixstart;
  int32_T c7_n;
  int32_T c7_ixstop;
  real_T c7_k_mtmp;
  real_T c7_m_x;
  boolean_T c7_ie_b;
  int32_T c7_b_ixstop;
  int32_T c7_m_ix;
  int32_T c7_n_ix;
  real_T c7_n_x;
  boolean_T c7_je_b;
  int32_T c7_i565;
  int32_T c7_c_ixstop;
  int32_T c7_o_ix;
  real_T c7_f_a;
  real_T c7_ke_b;
  boolean_T c7_f_p;
  real_T c7_l_mtmp;
  real_T c7_d32;
  uint16_T c7_u120;
  uint32_T c7_u121;
  uint8_T c7_uv38[1];
  boolean_T c7_b60;
  int32_T c7_nd_trueCount;
  int32_T c7_oh_i;
  int32_T c7_nd_partialTrueCount;
  int32_T c7_ph_i;
  int32_T c7_i566;
  int32_T c7_i567;
  int32_T c7_xd_loop_ub;
  int32_T c7_i568;
  uint32_T c7_db_q0;
  uint32_T c7_db_qY;
  uint32_T c7_u122;
  uint8_T c7_u123;
  uint8_T c7_qh_i;
  int32_T c7_od_trueCount;
  int32_T c7_rh_i;
  int32_T c7_od_partialTrueCount;
  int32_T c7_sh_i;
  real_T c7_c_EC_events_inds_right;
  int32_T c7_yd_loop_ub;
  int32_T c7_i569;
  int32_T c7_c_temp;
  int32_T c7_d_temp;
  int32_T c7_ae_loop_ub;
  int32_T c7_i570;
  int32_T c7_c_end;
  int32_T c7_pd_trueCount;
  int32_T c7_th_i;
  int32_T c7_d_end;
  int32_T c7_pd_partialTrueCount;
  int32_T c7_uh_i;
  int32_T c7_be_loop_ub;
  int32_T c7_i571;
  int32_T c7_ce_loop_ub;
  int32_T c7_i572;
  boolean_T c7_b61;
  const mxArray *c7_te_y = NULL;
  const mxArray *c7_ue_y = NULL;
  int32_T c7_f_ixstart;
  int32_T c7_b_n;
  int32_T c7_d_ixstop;
  real_T c7_m_mtmp;
  real_T c7_o_x;
  boolean_T c7_le_b;
  int32_T c7_e_ixstop;
  int32_T c7_p_ix;
  int32_T c7_q_ix;
  real_T c7_p_x;
  boolean_T c7_me_b;
  int32_T c7_i573;
  int32_T c7_f_ixstop;
  int32_T c7_r_ix;
  real_T c7_g_a;
  real_T c7_ne_b;
  boolean_T c7_g_p;
  real_T c7_n_mtmp;
  real_T c7_d33;
  uint16_T c7_u124;
  uint32_T c7_u125;
  uint8_T c7_uv39[1];
  boolean_T c7_b62;
  int32_T c7_qd_trueCount;
  int32_T c7_vh_i;
  int32_T c7_qd_partialTrueCount;
  int32_T c7_wh_i;
  int32_T c7_i574;
  int32_T c7_i575;
  int32_T c7_de_loop_ub;
  int32_T c7_i576;
  int32_T c7_i577;
  int32_T c7_rd_trueCount;
  int32_T c7_xh_i;
  int32_T c7_rd_partialTrueCount;
  int32_T c7_yh_i;
  int32_T c7_xb_data_struct_input_sizes[2];
  int32_T c7_le_data_struct_input;
  int32_T c7_me_data_struct_input;
  int32_T c7_ee_loop_ub;
  int32_T c7_i578;
  uint16_T c7_xb_data_struct_input_data[10];
  real_T c7_d34;
  uint16_T c7_u126;
  int32_T c7_i579;
  int32_T c7_sd_trueCount;
  int32_T c7_ai_i;
  int32_T c7_sd_partialTrueCount;
  int32_T c7_bi_i;
  int32_T c7_yb_data_struct_input_sizes[2];
  int32_T c7_ne_data_struct_input;
  int32_T c7_oe_data_struct_input;
  int32_T c7_fe_loop_ub;
  int32_T c7_i580;
  real32_T c7_yb_data_struct_input_data[5];
  real32_T c7_v_A;
  real32_T c7_ve_y;
  int32_T c7_i581;
  int32_T c7_td_trueCount;
  int32_T c7_ci_i;
  int32_T c7_td_partialTrueCount;
  int32_T c7_di_i;
  int32_T c7_ac_data_struct_input_sizes[2];
  int32_T c7_pe_data_struct_input;
  int32_T c7_qe_data_struct_input;
  int32_T c7_ge_loop_ub;
  int32_T c7_i582;
  real32_T c7_ac_data_struct_input_data[5];
  real32_T c7_w_A;
  real32_T c7_we_y;
  int32_T c7_i583;
  int32_T c7_ud_trueCount;
  int32_T c7_ei_i;
  int32_T c7_ud_partialTrueCount;
  int32_T c7_fi_i;
  int32_T c7_bc_data_struct_input_sizes[2];
  int32_T c7_re_data_struct_input;
  int32_T c7_se_data_struct_input;
  int32_T c7_he_loop_ub;
  int32_T c7_i584;
  real32_T c7_bc_data_struct_input_data[5];
  real32_T c7_x_A;
  real32_T c7_xe_y;
  int32_T c7_i585;
  int32_T c7_vd_trueCount;
  int32_T c7_gi_i;
  int32_T c7_vd_partialTrueCount;
  int32_T c7_hi_i;
  int32_T c7_cc_data_struct_input_sizes[2];
  int32_T c7_te_data_struct_input;
  int32_T c7_ue_data_struct_input;
  int32_T c7_ie_loop_ub;
  int32_T c7_i586;
  real32_T c7_cc_data_struct_input_data[5];
  real32_T c7_y_A;
  real32_T c7_ye_y;
  uint8_T c7_uv40[1];
  boolean_T c7_b63;
  int32_T c7_wd_trueCount;
  int32_T c7_ii_i;
  int32_T c7_wd_partialTrueCount;
  int32_T c7_ji_i;
  int32_T c7_i587;
  int32_T c7_i588;
  int32_T c7_je_loop_ub;
  int32_T c7_i589;
  uint8_T c7_uv41[1];
  boolean_T c7_b64;
  int32_T c7_xd_trueCount;
  int32_T c7_ki_i;
  int32_T c7_xd_partialTrueCount;
  int32_T c7_li_i;
  int32_T c7_i590;
  int32_T c7_i591;
  int32_T c7_ke_loop_ub;
  int32_T c7_i592;
  uint8_T c7_uv42[1];
  boolean_T c7_b65;
  int32_T c7_yd_trueCount;
  int32_T c7_mi_i;
  int32_T c7_yd_partialTrueCount;
  int32_T c7_ni_i;
  int32_T c7_i593;
  int32_T c7_i594;
  int32_T c7_le_loop_ub;
  int32_T c7_i595;
  uint8_T c7_uv43[1];
  boolean_T c7_b66;
  int32_T c7_ae_trueCount;
  int32_T c7_oi_i;
  int32_T c7_ae_partialTrueCount;
  int32_T c7_pi_i;
  int32_T c7_i596;
  int32_T c7_i597;
  int32_T c7_me_loop_ub;
  int32_T c7_i598;
  uint8_T c7_uv44[1];
  boolean_T c7_b67;
  int32_T c7_be_trueCount;
  int32_T c7_qi_i;
  int32_T c7_be_partialTrueCount;
  int32_T c7_ri_i;
  int32_T c7_i599;
  int32_T c7_i600;
  int32_T c7_ne_loop_ub;
  int32_T c7_i601;
  uint8_T c7_uv45[1];
  boolean_T c7_b68;
  int32_T c7_ce_trueCount;
  int32_T c7_si_i;
  int32_T c7_ce_partialTrueCount;
  int32_T c7_ti_i;
  int32_T c7_i602;
  int32_T c7_i603;
  int32_T c7_oe_loop_ub;
  int32_T c7_i604;
  uint8_T c7_uv46[1];
  boolean_T c7_b69;
  int32_T c7_de_trueCount;
  int32_T c7_ui_i;
  int32_T c7_de_partialTrueCount;
  int32_T c7_vi_i;
  int32_T c7_i605;
  int32_T c7_i606;
  int32_T c7_pe_loop_ub;
  int32_T c7_i607;
  uint8_T c7_uv47[1];
  boolean_T c7_b70;
  int32_T c7_ee_trueCount;
  int32_T c7_wi_i;
  int32_T c7_ee_partialTrueCount;
  int32_T c7_xi_i;
  int32_T c7_i608;
  int32_T c7_i609;
  int32_T c7_qe_loop_ub;
  int32_T c7_i610;
  uint8_T c7_uv48[1];
  boolean_T c7_b71;
  int32_T c7_fe_trueCount;
  int32_T c7_yi_i;
  int32_T c7_fe_partialTrueCount;
  int32_T c7_aj_i;
  int32_T c7_i611;
  int32_T c7_i612;
  int32_T c7_re_loop_ub;
  int32_T c7_i613;
  uint8_T c7_uv49[1];
  boolean_T c7_b72;
  int32_T c7_ge_trueCount;
  int32_T c7_bj_i;
  int32_T c7_ge_partialTrueCount;
  int32_T c7_cj_i;
  int32_T c7_i614;
  int32_T c7_i615;
  int32_T c7_se_loop_ub;
  int32_T c7_i616;
  uint8_T c7_uv50[1];
  boolean_T c7_b73;
  int32_T c7_he_trueCount;
  int32_T c7_dj_i;
  int32_T c7_he_partialTrueCount;
  int32_T c7_ej_i;
  int32_T c7_i617;
  int32_T c7_i618;
  int32_T c7_te_loop_ub;
  int32_T c7_i619;
  uint8_T c7_uv51[1];
  boolean_T c7_b74;
  int32_T c7_ie_trueCount;
  int32_T c7_fj_i;
  int32_T c7_ie_partialTrueCount;
  int32_T c7_gj_i;
  int32_T c7_i620;
  int32_T c7_i621;
  int32_T c7_ue_loop_ub;
  int32_T c7_i622;
  uint8_T c7_uv52[1];
  boolean_T c7_b75;
  int32_T c7_je_trueCount;
  int32_T c7_hj_i;
  int32_T c7_je_partialTrueCount;
  int32_T c7_ij_i;
  int32_T c7_i623;
  int32_T c7_i624;
  int32_T c7_ve_loop_ub;
  int32_T c7_i625;
  int32_T c7_i626;
  real_T c7_c_varargin_1[5];
  int32_T c7_g_ixstart;
  real_T c7_o_mtmp;
  real_T c7_q_x;
  boolean_T c7_oe_b;
  int32_T c7_s_ix;
  int32_T c7_t_ix;
  real_T c7_r_x;
  boolean_T c7_pe_b;
  int32_T c7_i627;
  int32_T c7_u_ix;
  real_T c7_h_a;
  real_T c7_qe_b;
  boolean_T c7_h_p;
  real_T c7_p_mtmp;
  real_T c7_maxval;
  real_T c7_d35;
  uint16_T c7_u127;
  int32_T c7_i628;
  int32_T c7_h_ixstart;
  real_T c7_q_mtmp;
  real_T c7_s_x;
  boolean_T c7_re_b;
  int32_T c7_v_ix;
  int32_T c7_w_ix;
  real_T c7_t_x;
  boolean_T c7_se_b;
  int32_T c7_i629;
  int32_T c7_x_ix;
  real_T c7_i_a;
  real_T c7_te_b;
  boolean_T c7_i_p;
  real_T c7_r_mtmp;
  real_T c7_b_maxval;
  real_T c7_d36;
  uint16_T c7_u128;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  boolean_T guard4 = false;
  boolean_T guard5 = false;
  boolean_T guard6 = false;
  boolean_T guard7 = false;
  boolean_T guard8 = false;
  boolean_T guard9 = false;
  boolean_T guard10 = false;
  boolean_T guard11 = false;
  boolean_T guard12 = false;
  boolean_T guard13 = false;
  boolean_T guard14 = false;
  boolean_T guard15 = false;
  boolean_T guard16 = false;
  boolean_T guard17 = false;
  boolean_T guard18 = false;
  boolean_T guard19 = false;
  boolean_T guard20 = false;
  boolean_T guard21 = false;
  boolean_T guard22 = false;
  boolean_T guard23 = false;
  boolean_T guard24 = false;
  boolean_T guard25 = false;
  boolean_T guard26 = false;
  boolean_T guard27 = false;
  boolean_T guard28 = false;
  boolean_T guard29 = false;
  boolean_T guard30 = false;
  boolean_T guard31 = false;
  boolean_T guard32 = false;
  boolean_T guard33 = false;
  boolean_T guard34 = false;
  boolean_T guard35 = false;
  boolean_T guard36 = false;
  boolean_T guard37 = false;
  boolean_T guard38 = false;
  boolean_T guard39 = false;
  boolean_T guard40 = false;
  boolean_T guard41 = false;
  boolean_T guard42 = false;
  boolean_T guard43 = false;
  boolean_T guard44 = false;
  boolean_T guard45 = false;
  boolean_T guard46 = false;
  boolean_T guard47 = false;
  boolean_T guard48 = false;
  boolean_T guard49 = false;
  boolean_T guard50 = false;
  boolean_T guard51 = false;
  boolean_T guard52 = false;
  boolean_T guard53 = false;
  boolean_T guard54 = false;
  boolean_T guard55 = false;
  boolean_T guard56 = false;
  boolean_T guard57 = false;
  boolean_T guard58 = false;
  boolean_T guard59 = false;
  boolean_T guard60 = false;
  boolean_T guard61 = false;
  boolean_T guard62 = false;
  boolean_T guard63 = false;
  boolean_T guard64 = false;
  boolean_T guard65 = false;
  boolean_T guard66 = false;
  boolean_T guard67 = false;
  boolean_T guard68 = false;
  boolean_T guard69 = false;
  boolean_T guard70 = false;
  boolean_T guard71 = false;
  boolean_T guard72 = false;
  boolean_T guard73 = false;
  boolean_T guard74 = false;
  boolean_T guard75 = false;
  boolean_T guard76 = false;
  boolean_T guard77 = false;
  boolean_T guard78 = false;
  boolean_T guard79 = false;
  boolean_T guard80 = false;
  boolean_T guard81 = false;
  boolean_T guard82 = false;
  boolean_T guard83 = false;
  boolean_T guard84 = false;
  boolean_T guard85 = false;
  boolean_T guard86 = false;
  boolean_T guard87 = false;
  boolean_T guard88 = false;
  boolean_T guard89 = false;
  boolean_T guard90 = false;
  boolean_T guard91 = false;
  boolean_T guard92 = false;
  boolean_T guard93 = false;
  boolean_T guard94 = false;
  boolean_T guard95 = false;
  boolean_T guard96 = false;
  boolean_T guard97 = false;
  boolean_T guard98 = false;
  boolean_T guard99 = false;
  boolean_T guard100 = false;
  boolean_T guard101 = false;
  boolean_T guard102 = false;
  boolean_T guard103 = false;
  boolean_T guard104 = false;
  boolean_T guard105 = false;
  boolean_T guard106 = false;
  boolean_T guard107 = false;
  boolean_T guard108 = false;
  boolean_T guard109 = false;
  boolean_T guard110 = false;
  boolean_T guard111 = false;
  boolean_T guard112 = false;
  boolean_T guard113 = false;
  boolean_T guard114 = false;
  boolean_T guard115 = false;
  boolean_T guard116 = false;
  boolean_T guard117 = false;
  boolean_T guard118 = false;
  boolean_T guard119 = false;
  boolean_T guard120 = false;
  boolean_T guard121 = false;
  boolean_T guard122 = false;
  boolean_T guard123 = false;
  boolean_T guard124 = false;
  boolean_T guard125 = false;
  boolean_T guard126 = false;
  boolean_T guard127 = false;
  boolean_T guard128 = false;
  boolean_T guard129 = false;
  boolean_T guard130 = false;
  boolean_T guard131 = false;
  boolean_T guard132 = false;
  boolean_T guard133 = false;
  boolean_T guard134 = false;
  boolean_T guard135 = false;
  boolean_T guard136 = false;
  boolean_T guard137 = false;
  boolean_T guard138 = false;
  boolean_T guard139 = false;
  boolean_T guard140 = false;
  boolean_T guard141 = false;
  boolean_T guard142 = false;
  boolean_T guard143 = false;
  boolean_T guard144 = false;
  boolean_T guard145 = false;
  boolean_T guard146 = false;
  boolean_T guard147 = false;
  boolean_T guard148 = false;
  boolean_T guard149 = false;
  boolean_T guard150 = false;
  boolean_T guard151 = false;
  boolean_T guard152 = false;
  boolean_T exitg1;
  boolean_T exitg2;
  boolean_T exitg3;
  boolean_T exitg4;
  boolean_T exitg5;
  boolean_T exitg6;
  boolean_T exitg7;
  boolean_T exitg8;
  boolean_T exitg9;
  boolean_T exitg10;
  boolean_T exitg11;
  boolean_T exitg12;
  boolean_T exitg13;
  boolean_T exitg14;
  boolean_T exitg15;
  boolean_T exitg16;
  boolean_T exitg17;
  boolean_T exitg18;
  boolean_T exitg19;
  boolean_T exitg20;
  boolean_T exitg21;
  boolean_T exitg22;
  boolean_T exitg23;
  boolean_T exitg24;
  boolean_T exitg25;
  boolean_T exitg26;
  boolean_T exitg27;
  boolean_T exitg28;
  boolean_T exitg29;
  boolean_T exitg30;
  boolean_T exitg31;
  boolean_T exitg32;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 29U, 38U, c7_d_debug_family_names,
    c7_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_left_limit, 0U, c7_e_sf_marshallOut,
    c7_e_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_found, 1U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_index, MAX_uint32_T,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_MS_inds_left, MAX_uint32_T,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_EC_events_inds_left, MAX_uint32_T,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_EC_distance_left, MAX_uint32_T,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_EC_peaks, 6U, c7_i_sf_marshallOut,
    c7_i_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_AN_peaks, 7U, c7_i_sf_marshallOut,
    c7_i_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_EC_peaks_index, 8U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_MS_inds_right, MAX_uint32_T,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_EC_events_inds_right, MAX_uint32_T,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_EC_distance_right, MAX_uint32_T,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_MS_inds_index_right, 12U,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_MS_inds_index_left, 13U,
    c7_sf_marshallOut, c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_IC_LPF_inds_right, 14U,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_IC_LPF_inds_left, 15U,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_IC_inds_right, 16U,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_IC_inds_left, 17U, c7_h_sf_marshallOut,
    c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_i, MAX_uint32_T, c7_e_sf_marshallOut,
    c7_e_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_DS_min, 19U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_b_MS_inds_right, MAX_uint32_T,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_b_MS_inds_left, MAX_uint32_T,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_b_EC_distance_right, MAX_uint32_T,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_b_EC_distance_left, MAX_uint32_T,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_b_EC_events_inds_right, MAX_uint32_T,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_b_EC_events_inds_left, MAX_uint32_T,
    c7_h_sf_marshallOut, c7_h_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_b_i, MAX_uint32_T, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_c_i, MAX_uint32_T,
    c7_g_sf_marshallOut, c7_g_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_DYN_IMPORTABLE(c7_temp_data, (const int32_T *)
    &c7_temp_sizes, NULL, 0, 20, (void *)c7_f_sf_marshallOut, (void *)
    c7_f_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_b_index, MAX_uint32_T,
    c7_e_sf_marshallOut, c7_e_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_data_struct_input, 21U,
    c7_b_sf_marshallOut, c7_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_timestamp, 22U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_newVelRShank, 23U, c7_sf_marshallOut,
    c7_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_newVelLShank, 24U,
    c7_d_sf_marshallOut, c7_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_newAngRShank, 25U,
    c7_d_sf_marshallOut, c7_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c7_newAngLShank, 26U,
    c7_d_sf_marshallOut, c7_d_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_data_struct_output, 27U,
    c7_b_sf_marshallOut, c7_b_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(c7_state_out, 28U, c7_c_sf_marshallOut,
    c7_c_sf_marshallIn);
  CV_EML_FCN(0, 0);
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 6);
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 9);
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 16);
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 18);
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 22);
  for (c7_i283 = 0; c7_i283 < 199; c7_i283++) {
    c7_b_data_struct_input[c7_i283] = c7_data_struct_input->VelRShank[c7_i283 +
      1];
  }

  for (c7_i284 = 0; c7_i284 < 199; c7_i284++) {
    c7_data_struct_input->VelRShank[c7_i284] = c7_b_data_struct_input[c7_i284];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 23);
  c7_data_struct_input->VelRShank[199] = (real32_T)c7_newVelRShank;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 24);
  for (c7_i285 = 0; c7_i285 < 199; c7_i285++) {
    c7_c_data_struct_input[c7_i285] = c7_data_struct_input->VelLShank[c7_i285 +
      1];
  }

  for (c7_i286 = 0; c7_i286 < 199; c7_i286++) {
    c7_data_struct_input->VelLShank[c7_i286] = c7_c_data_struct_input[c7_i286];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 25);
  c7_data_struct_input->VelLShank[199] = c7_newVelLShank;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 26);
  for (c7_i287 = 0; c7_i287 < 199; c7_i287++) {
    c7_d_data_struct_input[c7_i287] = c7_data_struct_input->AngRShank[c7_i287 +
      1];
  }

  for (c7_i288 = 0; c7_i288 < 199; c7_i288++) {
    c7_data_struct_input->AngRShank[c7_i288] = c7_d_data_struct_input[c7_i288];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 27);
  c7_data_struct_input->AngRShank[199] = c7_newAngRShank;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 28);
  for (c7_i289 = 0; c7_i289 < 199; c7_i289++) {
    c7_e_data_struct_input[c7_i289] = c7_data_struct_input->AngLShank[c7_i289 +
      1];
  }

  for (c7_i290 = 0; c7_i290 < 199; c7_i290++) {
    c7_data_struct_input->AngLShank[c7_i290] = c7_e_data_struct_input[c7_i290];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 29);
  c7_data_struct_input->AngLShank[199] = c7_newAngLShank;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 32);
  for (c7_i291 = 0; c7_i291 < 199; c7_i291++) {
    c7_f_data_struct_input[c7_i291] = c7_data_struct_input->
      VelRShank_filt[c7_i291 + 1];
  }

  for (c7_i292 = 0; c7_i292 < 199; c7_i292++) {
    c7_data_struct_input->VelRShank_filt[c7_i292] =
      c7_f_data_struct_input[c7_i292];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 33);
  c7_b = c7_data_struct_input->VelRShank[199];
  c7_y = 0.7F * c7_b;
  c7_b_b = c7_data_struct_input->VelRShank[198];
  c7_b_y = 0.3F * c7_b_b;
  c7_data_struct_input->VelRShank_filt[199] = c7_y + c7_b_y;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 34);
  for (c7_i293 = 0; c7_i293 < 199; c7_i293++) {
    c7_g_data_struct_input[c7_i293] = c7_data_struct_input->
      VelLShank_filt[c7_i293 + 1];
  }

  for (c7_i294 = 0; c7_i294 < 199; c7_i294++) {
    c7_data_struct_input->VelLShank_filt[c7_i294] =
      c7_g_data_struct_input[c7_i294];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 35);
  c7_c_b = c7_data_struct_input->VelLShank[199];
  c7_c_y = 0.7F * c7_c_b;
  c7_d_b = c7_data_struct_input->VelLShank[198];
  c7_d_y = 0.3F * c7_d_b;
  c7_data_struct_input->VelLShank_filt[199] = c7_c_y + c7_d_y;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 36);
  for (c7_i295 = 0; c7_i295 < 199; c7_i295++) {
    c7_h_data_struct_input[c7_i295] = c7_data_struct_input->
      AngRShank_filt[c7_i295 + 1];
  }

  for (c7_i296 = 0; c7_i296 < 199; c7_i296++) {
    c7_data_struct_input->AngRShank_filt[c7_i296] =
      c7_h_data_struct_input[c7_i296];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 37);
  c7_e_b = c7_data_struct_input->AngRShank[199];
  c7_e_y = 0.7F * c7_e_b;
  c7_f_b = c7_data_struct_input->AngRShank[198];
  c7_f_y = 0.3F * c7_f_b;
  c7_data_struct_input->AngRShank_filt[199] = c7_e_y + c7_f_y;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 38);
  for (c7_i297 = 0; c7_i297 < 199; c7_i297++) {
    c7_i_data_struct_input[c7_i297] = c7_data_struct_input->
      AngLShank_filt[c7_i297 + 1];
  }

  for (c7_i298 = 0; c7_i298 < 199; c7_i298++) {
    c7_data_struct_input->AngLShank_filt[c7_i298] =
      c7_i_data_struct_input[c7_i298];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 39);
  c7_g_b = c7_data_struct_input->AngLShank[199];
  c7_g_y = 0.7F * c7_g_b;
  c7_h_b = c7_data_struct_input->AngLShank[198];
  c7_h_y = 0.3F * c7_h_b;
  c7_data_struct_input->AngLShank_filt[199] = c7_g_y + c7_h_y;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 42);
  for (c7_i299 = 0; c7_i299 < 199; c7_i299++) {
    c7_j_data_struct_input[c7_i299] = c7_data_struct_input->
      VelRShank_LPF[c7_i299 + 1];
  }

  for (c7_i300 = 0; c7_i300 < 199; c7_i300++) {
    c7_data_struct_input->VelRShank_LPF[c7_i300] =
      c7_j_data_struct_input[c7_i300];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 43);
  c7_i_b = c7_data_struct_input->VelRShank[199];
  c7_i_y = 0.00265183463F * c7_i_b;
  c7_j_b = c7_data_struct_input->VelRShank[198];
  c7_j_y = 0.0145335365F * c7_j_b;
  c7_k_b = c7_data_struct_input->VelRShank[197];
  c7_k_y = 0.0424117036F * c7_k_b;
  c7_l_b = c7_data_struct_input->VelRShank[196];
  c7_l_y = 0.0841515288F * c7_l_b;
  c7_m_b = c7_data_struct_input->VelRShank[195];
  c7_m_y = 0.123907335F * c7_m_b;
  c7_n_b = c7_data_struct_input->VelRShank[194];
  c7_n_y = 0.140471607F * c7_n_b;
  c7_o_b = c7_data_struct_input->VelRShank[193];
  c7_o_y = 0.123907335F * c7_o_b;
  c7_p_b = c7_data_struct_input->VelRShank[192];
  c7_p_y = 0.0841515288F * c7_p_b;
  c7_q_b = c7_data_struct_input->VelRShank[191];
  c7_q_y = 0.0424117036F * c7_q_b;
  c7_r_b = c7_data_struct_input->VelRShank[190];
  c7_r_y = 0.0145335365F * c7_r_b;
  c7_s_b = c7_data_struct_input->VelRShank[189];
  c7_s_y = 0.00265183463F * c7_s_b;
  c7_data_struct_input->VelRShank_LPF[199] = (((((((((c7_i_y + c7_j_y) + c7_k_y)
    + c7_l_y) + c7_m_y) + c7_n_y) + c7_o_y) + c7_p_y) + c7_q_y) + c7_r_y) +
    c7_s_y;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 46);
  for (c7_i301 = 0; c7_i301 < 199; c7_i301++) {
    c7_k_data_struct_input[c7_i301] = c7_data_struct_input->
      VelLShank_LPF[c7_i301 + 1];
  }

  for (c7_i302 = 0; c7_i302 < 199; c7_i302++) {
    c7_data_struct_input->VelLShank_LPF[c7_i302] =
      c7_k_data_struct_input[c7_i302];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 47);
  c7_t_b = c7_data_struct_input->VelLShank[199];
  c7_t_y = 0.00265183463F * c7_t_b;
  c7_u_b = c7_data_struct_input->VelLShank[198];
  c7_u_y = 0.0145335365F * c7_u_b;
  c7_v_b = c7_data_struct_input->VelLShank[197];
  c7_v_y = 0.0424117036F * c7_v_b;
  c7_w_b = c7_data_struct_input->VelLShank[196];
  c7_w_y = 0.0841515288F * c7_w_b;
  c7_x_b = c7_data_struct_input->VelLShank[195];
  c7_x_y = 0.123907335F * c7_x_b;
  c7_y_b = c7_data_struct_input->VelLShank[194];
  c7_y_y = 0.140471607F * c7_y_b;
  c7_ab_b = c7_data_struct_input->VelLShank[193];
  c7_ab_y = 0.123907335F * c7_ab_b;
  c7_bb_b = c7_data_struct_input->VelLShank[192];
  c7_bb_y = 0.0841515288F * c7_bb_b;
  c7_cb_b = c7_data_struct_input->VelLShank[191];
  c7_cb_y = 0.0424117036F * c7_cb_b;
  c7_db_b = c7_data_struct_input->VelLShank[190];
  c7_db_y = 0.0145335365F * c7_db_b;
  c7_eb_b = c7_data_struct_input->VelLShank[189];
  c7_eb_y = 0.00265183463F * c7_eb_b;
  c7_data_struct_input->VelLShank_LPF[199] = (((((((((c7_t_y + c7_u_y) + c7_v_y)
    + c7_w_y) + c7_x_y) + c7_y_y) + c7_ab_y) + c7_bb_y) + c7_cb_y) + c7_db_y) +
    c7_eb_y;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 50);
  for (c7_i303 = 0; c7_i303 < 199; c7_i303++) {
    c7_l_data_struct_input[c7_i303] = c7_data_struct_input->
      AngRShank_LPF[c7_i303 + 1];
  }

  for (c7_i304 = 0; c7_i304 < 199; c7_i304++) {
    c7_data_struct_input->AngRShank_LPF[c7_i304] =
      c7_l_data_struct_input[c7_i304];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 51);
  c7_fb_b = c7_data_struct_input->AngRShank[199];
  c7_fb_y = 0.00265183463F * c7_fb_b;
  c7_gb_b = c7_data_struct_input->AngRShank[198];
  c7_gb_y = 0.0145335365F * c7_gb_b;
  c7_hb_b = c7_data_struct_input->AngRShank[197];
  c7_hb_y = 0.0424117036F * c7_hb_b;
  c7_ib_b = c7_data_struct_input->AngRShank[196];
  c7_ib_y = 0.0841515288F * c7_ib_b;
  c7_jb_b = c7_data_struct_input->AngRShank[195];
  c7_jb_y = 0.123907335F * c7_jb_b;
  c7_kb_b = c7_data_struct_input->AngRShank[194];
  c7_kb_y = 0.140471607F * c7_kb_b;
  c7_lb_b = c7_data_struct_input->AngRShank[193];
  c7_lb_y = 0.123907335F * c7_lb_b;
  c7_mb_b = c7_data_struct_input->AngRShank[192];
  c7_mb_y = 0.0841515288F * c7_mb_b;
  c7_nb_b = c7_data_struct_input->AngRShank[191];
  c7_nb_y = 0.0424117036F * c7_nb_b;
  c7_ob_b = c7_data_struct_input->AngRShank[190];
  c7_ob_y = 0.0145335365F * c7_ob_b;
  c7_pb_b = c7_data_struct_input->AngRShank[189];
  c7_pb_y = 0.00265183463F * c7_pb_b;
  c7_data_struct_input->AngRShank_LPF[199] = (((((((((c7_fb_y + c7_gb_y) +
    c7_hb_y) + c7_ib_y) + c7_jb_y) + c7_kb_y) + c7_lb_y) + c7_mb_y) + c7_nb_y) +
    c7_ob_y) + c7_pb_y;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 54);
  for (c7_i305 = 0; c7_i305 < 199; c7_i305++) {
    c7_m_data_struct_input[c7_i305] = c7_data_struct_input->
      AngLShank_LPF[c7_i305 + 1];
  }

  for (c7_i306 = 0; c7_i306 < 199; c7_i306++) {
    c7_data_struct_input->AngLShank_LPF[c7_i306] =
      c7_m_data_struct_input[c7_i306];
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 55);
  c7_qb_b = c7_data_struct_input->AngLShank[199];
  c7_qb_y = 0.00265183463F * c7_qb_b;
  c7_rb_b = c7_data_struct_input->AngLShank[198];
  c7_rb_y = 0.0145335365F * c7_rb_b;
  c7_sb_b = c7_data_struct_input->AngLShank[197];
  c7_sb_y = 0.0424117036F * c7_sb_b;
  c7_tb_b = c7_data_struct_input->AngLShank[196];
  c7_tb_y = 0.0841515288F * c7_tb_b;
  c7_ub_b = c7_data_struct_input->AngLShank[195];
  c7_ub_y = 0.123907335F * c7_ub_b;
  c7_vb_b = c7_data_struct_input->AngLShank[194];
  c7_vb_y = 0.140471607F * c7_vb_b;
  c7_wb_b = c7_data_struct_input->AngLShank[193];
  c7_wb_y = 0.123907335F * c7_wb_b;
  c7_xb_b = c7_data_struct_input->AngLShank[192];
  c7_xb_y = 0.0841515288F * c7_xb_b;
  c7_yb_b = c7_data_struct_input->AngLShank[191];
  c7_yb_y = 0.0424117036F * c7_yb_b;
  c7_ac_b = c7_data_struct_input->AngLShank[190];
  c7_ac_y = 0.0145335365F * c7_ac_b;
  c7_bc_b = c7_data_struct_input->AngLShank[189];
  c7_bc_y = 0.00265183463F * c7_bc_b;
  c7_data_struct_input->AngLShank_LPF[199] = (((((((((c7_qb_y + c7_rb_y) +
    c7_sb_y) + c7_tb_y) + c7_ub_y) + c7_vb_y) + c7_wb_y) + c7_xb_y) + c7_yb_y) +
    c7_ac_y) + c7_bc_y;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 59);
  guard44 = false;
  if (CV_EML_COND(0, 1, 0, !c7_data_struct_input->flag_calib)) {
    if (CV_EML_COND(0, 1, 1, CV_RELATIONAL_EVAL(4U, 0U, -13, (real_T)
          c7_data_struct_input->calibrating, 0.0, 0, 0U,
          c7_data_struct_input->calibrating == 0))) {
      CV_EML_MCDC(0, 1, 0, true);
      CV_EML_IF(0, 1, 0, true);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 60);
      c7_u2 = (uint32_T)c7_data_struct_input->last_IC + 1U;
      if (CV_SATURATION_EVAL(4, 0, 89, 0, c7_u2 > 65535U)) {
        c7_u2 = 65535U;
      }

      c7_data_struct_input->last_IC = (uint16_T)c7_u2;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 61);
      c7_u3 = (uint32_T)c7_data_struct_input->last_EC + 1U;
      if (CV_SATURATION_EVAL(4, 0, 92, 0, c7_u3 > 65535U)) {
        c7_u3 = 65535U;
      }

      c7_data_struct_input->last_EC = (uint16_T)c7_u3;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 64);
      c7_data_struct_input->prevstate = c7_data_struct_input->state;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 66);
      c7_u4 = (uint32_T)c7_data_struct_input->index_start_calib + 1U;
      if (CV_SATURATION_EVAL(4, 0, 93, 0, c7_u4 > 65535U)) {
        c7_u4 = 65535U;
      }

      c7_data_struct_input->index_start_calib = (uint16_T)c7_u4;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 67);
      c7_varargin_1[0] = 199U;
      c7_varargin_1[1] = c7_data_struct_input->index_start_calib;
      c7_mtmp = 199U;
      c7_a = c7_varargin_1[1];
      c7_p = (c7_a < 199);
      if (c7_p) {
        c7_mtmp = c7_varargin_1[1];
      }

      c7_b_mtmp = c7_mtmp;
      c7_left_limit = c7_b_mtmp;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 73);
      guard149 = false;
      guard150 = false;
      guard151 = false;
      guard152 = false;
      if (CV_EML_COND(0, 1, 2, CV_RELATIONAL_EVAL(4U, 0U, -12, (real_T)
            c7_data_struct_input->state, 1.0, 0, 0U, c7_data_struct_input->state
            == 1))) {
        guard152 = true;
      } else if (CV_EML_COND(0, 1, 3, CV_RELATIONAL_EVAL(4U, 0U, -11, (real_T)
                   c7_data_struct_input->state, 2.0, 0, 0U,
                   c7_data_struct_input->state == 2))) {
        guard152 = true;
      } else {
        guard151 = true;
      }

      if (guard152 == true) {
        if (CV_EML_COND(0, 1, 4, CV_RELATIONAL_EVAL(4U, 0U, -10, (real_T)
              c7_data_struct_input->AngLShank_filt[198], (real_T)
              c7_data_struct_input->AngLShank_filt[197], -3, 4U,
              c7_data_struct_input->AngLShank_filt[198] >
              c7_data_struct_input->AngLShank_filt[197]))) {
          if (CV_EML_COND(0, 1, 5, CV_RELATIONAL_EVAL(4U, 0U, -9, (real_T)
                c7_data_struct_input->AngLShank_filt[198], (real_T)
                c7_data_struct_input->AngLShank_filt[199], -3, 4U,
                c7_data_struct_input->AngLShank_filt[198] >
                c7_data_struct_input->AngLShank_filt[199]))) {
            if (CV_EML_COND(0, 1, 6, CV_RELATIONAL_EVAL(4U, 0U, -8, (real_T)
                  c7_data_struct_input->AngLShank_filt[198], (real_T)
                  c7_data_struct_input->MA_th_left, -3, 4U,
                  c7_data_struct_input->AngLShank_filt[198] >
                  c7_data_struct_input->MA_th_left))) {
              CV_EML_MCDC(0, 1, 1, true);
              CV_EML_IF(0, 1, 1, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 74);
              c7_data_struct_input->MA_event_left = true;
            } else {
              guard149 = true;
            }
          } else {
            guard150 = true;
          }
        } else {
          guard151 = true;
        }
      }

      if (guard151 == true) {
        guard150 = true;
      }

      if (guard150 == true) {
        guard149 = true;
      }

      if (guard149 == true) {
        CV_EML_MCDC(0, 1, 1, false);
        CV_EML_IF(0, 1, 1, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 78);
      guard146 = false;
      guard147 = false;
      guard148 = false;
      if (CV_EML_COND(0, 1, 7, CV_RELATIONAL_EVAL(4U, 0U, -7, (real_T)
            c7_data_struct_input->state, 1.0, 0, 0U, c7_data_struct_input->state
            == 1))) {
        guard148 = true;
      } else if (CV_EML_COND(0, 1, 8, CV_RELATIONAL_EVAL(4U, 0U, -6, (real_T)
                   c7_data_struct_input->state, 2.0, 0, 0U,
                   c7_data_struct_input->state == 2))) {
        guard148 = true;
      } else {
        guard147 = true;
      }

      if (guard148 == true) {
        if (CV_EML_COND(0, 1, 9, CV_RELATIONAL_EVAL(4U, 0U, -5, (real_T)
              c7_data_struct_input->AngLShank_filt[198], 0.0, -1, 5U,
              c7_data_struct_input->AngLShank_filt[198] >= 0.0F))) {
          if (CV_EML_COND(0, 1, 10, CV_RELATIONAL_EVAL(4U, 0U, -4, (real_T)
                c7_data_struct_input->AngLShank_filt[199], 0.0, -1, 3U,
                c7_data_struct_input->AngLShank_filt[199] <= 0.0F))) {
            CV_EML_MCDC(0, 1, 2, true);
            CV_EML_IF(0, 1, 2, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 79);
            c7_data_struct_input->MS_event_left = true;
          } else {
            guard146 = true;
          }
        } else {
          guard147 = true;
        }
      }

      if (guard147 == true) {
        guard146 = true;
      }

      if (guard146 == true) {
        CV_EML_MCDC(0, 1, 2, false);
        CV_EML_IF(0, 1, 2, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 83);
      guard142 = false;
      guard143 = false;
      guard144 = false;
      guard145 = false;
      if (CV_EML_COND(0, 1, 11, CV_RELATIONAL_EVAL(4U, 0U, -3, (real_T)
            c7_data_struct_input->state, 2.0, 0, 0U, c7_data_struct_input->state
            == 2))) {
        guard145 = true;
      } else if (CV_EML_COND(0, 1, 12, CV_RELATIONAL_EVAL(4U, 0U, -2, (real_T)
                   c7_data_struct_input->state, 3.0, 0, 0U,
                   c7_data_struct_input->state == 3))) {
        guard145 = true;
      } else {
        guard144 = true;
      }

      if (guard145 == true) {
        if (CV_EML_COND(0, 1, 13, CV_RELATIONAL_EVAL(4U, 0U, -1, (real_T)
              c7_data_struct_input->AngLShank_filt[198], (real_T)
              c7_data_struct_input->AngLShank_filt[197], -3, 2U,
              c7_data_struct_input->AngLShank_filt[198] <
              c7_data_struct_input->AngLShank_filt[197]))) {
          if (CV_EML_COND(0, 1, 14, CV_RELATIONAL_EVAL(4U, 0U, 0, (real_T)
                c7_data_struct_input->AngLShank_filt[198], (real_T)
                c7_data_struct_input->AngLShank_filt[199], -3, 2U,
                c7_data_struct_input->AngLShank_filt[198] <
                c7_data_struct_input->AngLShank_filt[199]))) {
            if (CV_EML_COND(0, 1, 15, CV_RELATIONAL_EVAL(4U, 0U, 1, (real_T)
                  c7_data_struct_input->AngLShank_filt[198], (real_T)
                  c7_data_struct_input->IC_th_left, -3, 2U,
                  c7_data_struct_input->AngLShank_filt[198] <
                  c7_data_struct_input->IC_th_left))) {
              CV_EML_MCDC(0, 1, 3, true);
              CV_EML_IF(0, 1, 3, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 84);
              c7_data_struct_input->IC_event_left = true;
            } else {
              guard142 = true;
            }
          } else {
            guard143 = true;
          }
        } else {
          guard144 = true;
        }
      }

      if (guard144 == true) {
        guard143 = true;
      }

      if (guard143 == true) {
        guard142 = true;
      }

      if (guard142 == true) {
        CV_EML_MCDC(0, 1, 3, false);
        CV_EML_IF(0, 1, 3, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 88);
      guard140 = false;
      guard141 = false;
      if (CV_EML_COND(0, 1, 16, CV_RELATIONAL_EVAL(4U, 0U, 2, (real_T)
            c7_data_struct_input->state, 3.0, 0, 0U, c7_data_struct_input->state
            == 3))) {
        guard141 = true;
      } else if (CV_EML_COND(0, 1, 17, CV_RELATIONAL_EVAL(4U, 0U, 3, (real_T)
                   c7_data_struct_input->state, 4.0, 0, 0U,
                   c7_data_struct_input->state == 4))) {
        guard141 = true;
      } else {
        guard140 = true;
      }

      if (guard141 == true) {
        if (CV_EML_COND(0, 1, 18, CV_RELATIONAL_EVAL(4U, 0U, 4, (real_T)
              c7_data_struct_input->AngRShank_filt[199], (real_T)
              c7_data_struct_input->AN_th_right, -3, 4U,
              c7_data_struct_input->AngRShank_filt[199] >
              c7_data_struct_input->AN_th_right))) {
          CV_EML_MCDC(0, 1, 4, true);
          CV_EML_IF(0, 1, 4, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 89);
          c7_data_struct_input->AN_event_right = true;
        } else {
          guard140 = true;
        }
      }

      if (guard140 == true) {
        CV_EML_MCDC(0, 1, 4, false);
        CV_EML_IF(0, 1, 4, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 95);
      guard136 = false;
      guard137 = false;
      guard138 = false;
      guard139 = false;
      if (CV_EML_COND(0, 1, 19, CV_RELATIONAL_EVAL(4U, 0U, 5, (real_T)
            c7_data_struct_input->state, 3.0, 0, 0U, c7_data_struct_input->state
            == 3))) {
        guard139 = true;
      } else if (CV_EML_COND(0, 1, 20, CV_RELATIONAL_EVAL(4U, 0U, 6, (real_T)
                   c7_data_struct_input->state, 4.0, 0, 0U,
                   c7_data_struct_input->state == 4))) {
        guard139 = true;
      } else {
        guard138 = true;
      }

      if (guard139 == true) {
        if (CV_EML_COND(0, 1, 21, CV_RELATIONAL_EVAL(4U, 0U, 7, (real_T)
              c7_data_struct_input->VelRShank_filt[198], (real_T)
              c7_data_struct_input->EC_th_right, -3, 2U,
              c7_data_struct_input->VelRShank_filt[198] <
              c7_data_struct_input->EC_th_right))) {
          if (CV_EML_COND(0, 1, 22, CV_RELATIONAL_EVAL(4U, 0U, 8, (real_T)
                c7_data_struct_input->VelRShank_filt[198], (real_T)
                c7_data_struct_input->VelRShank_filt[197], -3, 2U,
                c7_data_struct_input->VelRShank_filt[198] <
                c7_data_struct_input->VelRShank_filt[197]))) {
            if (CV_EML_COND(0, 1, 23, CV_RELATIONAL_EVAL(4U, 0U, 9, (real_T)
                  c7_data_struct_input->VelRShank_filt[198], (real_T)
                  c7_data_struct_input->VelRShank_filt[199], -3, 3U,
                  c7_data_struct_input->VelRShank_filt[198] <=
                  c7_data_struct_input->VelRShank_filt[199]))) {
              CV_EML_MCDC(0, 1, 5, true);
              CV_EML_IF(0, 1, 5, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 96);
              c7_data_struct_input->EC_event_right = true;
            } else {
              guard136 = true;
            }
          } else {
            guard137 = true;
          }
        } else {
          guard138 = true;
        }
      }

      if (guard138 == true) {
        guard137 = true;
      }

      if (guard137 == true) {
        guard136 = true;
      }

      if (guard136 == true) {
        CV_EML_MCDC(0, 1, 5, false);
        CV_EML_IF(0, 1, 5, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 100);
      guard132 = false;
      guard133 = false;
      guard134 = false;
      guard135 = false;
      if (CV_EML_COND(0, 1, 24, CV_RELATIONAL_EVAL(4U, 0U, 10, (real_T)
            c7_data_struct_input->state, 4.0, 0, 0U, c7_data_struct_input->state
            == 4))) {
        guard135 = true;
      } else if (CV_EML_COND(0, 1, 25, CV_RELATIONAL_EVAL(4U, 0U, 11, (real_T)
                   c7_data_struct_input->state, 5.0, 0, 0U,
                   c7_data_struct_input->state == 5))) {
        guard135 = true;
      } else {
        guard134 = true;
      }

      if (guard135 == true) {
        if (CV_EML_COND(0, 1, 26, CV_RELATIONAL_EVAL(4U, 0U, 12, (real_T)
              c7_data_struct_input->AngRShank_filt[198], (real_T)
              c7_data_struct_input->AngRShank_filt[197], -3, 4U,
              c7_data_struct_input->AngRShank_filt[198] >
              c7_data_struct_input->AngRShank_filt[197]))) {
          if (CV_EML_COND(0, 1, 27, CV_RELATIONAL_EVAL(4U, 0U, 13, (real_T)
                c7_data_struct_input->AngRShank_filt[198], (real_T)
                c7_data_struct_input->AngRShank_filt[199], -3, 4U,
                c7_data_struct_input->AngRShank_filt[198] >
                c7_data_struct_input->AngRShank_filt[199]))) {
            if (CV_EML_COND(0, 1, 28, CV_RELATIONAL_EVAL(4U, 0U, 14, (real_T)
                  c7_data_struct_input->AngRShank_filt[198], (real_T)
                  c7_data_struct_input->MA_th_right, -3, 4U,
                  c7_data_struct_input->AngRShank_filt[198] >
                  c7_data_struct_input->MA_th_right))) {
              CV_EML_MCDC(0, 1, 6, true);
              CV_EML_IF(0, 1, 6, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 101);
              c7_data_struct_input->MA_event_right = true;
            } else {
              guard132 = true;
            }
          } else {
            guard133 = true;
          }
        } else {
          guard134 = true;
        }
      }

      if (guard134 == true) {
        guard133 = true;
      }

      if (guard133 == true) {
        guard132 = true;
      }

      if (guard132 == true) {
        CV_EML_MCDC(0, 1, 6, false);
        CV_EML_IF(0, 1, 6, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 105);
      guard129 = false;
      guard130 = false;
      guard131 = false;
      if (CV_EML_COND(0, 1, 29, CV_RELATIONAL_EVAL(4U, 0U, 15, (real_T)
            c7_data_struct_input->state, 4.0, 0, 0U, c7_data_struct_input->state
            == 4))) {
        guard131 = true;
      } else if (CV_EML_COND(0, 1, 30, CV_RELATIONAL_EVAL(4U, 0U, 16, (real_T)
                   c7_data_struct_input->state, 5.0, 0, 0U,
                   c7_data_struct_input->state == 5))) {
        guard131 = true;
      } else {
        guard130 = true;
      }

      if (guard131 == true) {
        if (CV_EML_COND(0, 1, 31, CV_RELATIONAL_EVAL(4U, 0U, 17, (real_T)
              c7_data_struct_input->AngRShank_filt[198], 0.0, -1, 5U,
              c7_data_struct_input->AngRShank_filt[198] >= 0.0F))) {
          if (CV_EML_COND(0, 1, 32, CV_RELATIONAL_EVAL(4U, 0U, 18, (real_T)
                c7_data_struct_input->AngRShank_filt[199], 0.0, -1, 3U,
                c7_data_struct_input->AngRShank_filt[199] <= 0.0F))) {
            CV_EML_MCDC(0, 1, 7, true);
            CV_EML_IF(0, 1, 7, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 106);
            c7_data_struct_input->MS_event_right = true;
          } else {
            guard129 = true;
          }
        } else {
          guard130 = true;
        }
      }

      if (guard130 == true) {
        guard129 = true;
      }

      if (guard129 == true) {
        CV_EML_MCDC(0, 1, 7, false);
        CV_EML_IF(0, 1, 7, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 110);
      guard125 = false;
      guard126 = false;
      guard127 = false;
      guard128 = false;
      if (CV_EML_COND(0, 1, 33, CV_RELATIONAL_EVAL(4U, 0U, 19, (real_T)
            c7_data_struct_input->state, 5.0, 0, 0U, c7_data_struct_input->state
            == 5))) {
        guard128 = true;
      } else if (CV_EML_COND(0, 1, 34, CV_RELATIONAL_EVAL(4U, 0U, 20, (real_T)
                   c7_data_struct_input->state, 6.0, 0, 0U,
                   c7_data_struct_input->state == 6))) {
        guard128 = true;
      } else {
        guard127 = true;
      }

      if (guard128 == true) {
        if (CV_EML_COND(0, 1, 35, CV_RELATIONAL_EVAL(4U, 0U, 21, (real_T)
              c7_data_struct_input->AngRShank_filt[198], (real_T)
              c7_data_struct_input->AngRShank_filt[197], -3, 2U,
              c7_data_struct_input->AngRShank_filt[198] <
              c7_data_struct_input->AngRShank_filt[197]))) {
          if (CV_EML_COND(0, 1, 36, CV_RELATIONAL_EVAL(4U, 0U, 22, (real_T)
                c7_data_struct_input->AngRShank_filt[198], (real_T)
                c7_data_struct_input->AngRShank_filt[199], -3, 2U,
                c7_data_struct_input->AngRShank_filt[198] <
                c7_data_struct_input->AngRShank_filt[199]))) {
            if (CV_EML_COND(0, 1, 37, CV_RELATIONAL_EVAL(4U, 0U, 23, (real_T)
                  c7_data_struct_input->AngRShank_filt[198], (real_T)
                  c7_data_struct_input->IC_th_right, -3, 2U,
                  c7_data_struct_input->AngRShank_filt[198] <
                  c7_data_struct_input->IC_th_right))) {
              CV_EML_MCDC(0, 1, 8, true);
              CV_EML_IF(0, 1, 8, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 111);
              c7_data_struct_input->IC_event_right = true;
            } else {
              guard125 = true;
            }
          } else {
            guard126 = true;
          }
        } else {
          guard127 = true;
        }
      }

      if (guard127 == true) {
        guard126 = true;
      }

      if (guard126 == true) {
        guard125 = true;
      }

      if (guard125 == true) {
        CV_EML_MCDC(0, 1, 8, false);
        CV_EML_IF(0, 1, 8, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 115);
      guard123 = false;
      guard124 = false;
      if (CV_EML_COND(0, 1, 38, CV_RELATIONAL_EVAL(4U, 0U, 24, (real_T)
            c7_data_struct_input->state, 6.0, 0, 0U, c7_data_struct_input->state
            == 6))) {
        guard124 = true;
      } else if (CV_EML_COND(0, 1, 39, CV_RELATIONAL_EVAL(4U, 0U, 25, (real_T)
                   c7_data_struct_input->state, 1.0, 0, 0U,
                   c7_data_struct_input->state == 1))) {
        guard124 = true;
      } else {
        guard123 = true;
      }

      if (guard124 == true) {
        if (CV_EML_COND(0, 1, 40, CV_RELATIONAL_EVAL(4U, 0U, 26, (real_T)
              c7_data_struct_input->AngLShank_filt[199], (real_T)
              c7_data_struct_input->AN_th_left, -3, 4U,
              c7_data_struct_input->AngLShank_filt[199] >
              c7_data_struct_input->AN_th_left))) {
          CV_EML_MCDC(0, 1, 9, true);
          CV_EML_IF(0, 1, 9, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 116);
          c7_data_struct_input->AN_event_left = true;
        } else {
          guard123 = true;
        }
      }

      if (guard123 == true) {
        CV_EML_MCDC(0, 1, 9, false);
        CV_EML_IF(0, 1, 9, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 122);
      guard119 = false;
      guard120 = false;
      guard121 = false;
      guard122 = false;
      if (CV_EML_COND(0, 1, 41, CV_RELATIONAL_EVAL(4U, 0U, 27, (real_T)
            c7_data_struct_input->state, 6.0, 0, 0U, c7_data_struct_input->state
            == 6))) {
        guard122 = true;
      } else if (CV_EML_COND(0, 1, 42, CV_RELATIONAL_EVAL(4U, 0U, 28, (real_T)
                   c7_data_struct_input->state, 1.0, 0, 0U,
                   c7_data_struct_input->state == 1))) {
        guard122 = true;
      } else {
        guard121 = true;
      }

      if (guard122 == true) {
        if (CV_EML_COND(0, 1, 43, CV_RELATIONAL_EVAL(4U, 0U, 29, (real_T)
              c7_data_struct_input->VelLShank_filt[198], (real_T)
              c7_data_struct_input->EC_th_left, -3, 2U,
              c7_data_struct_input->VelLShank_filt[198] <
              c7_data_struct_input->EC_th_left))) {
          if (CV_EML_COND(0, 1, 44, CV_RELATIONAL_EVAL(4U, 0U, 30, (real_T)
                c7_data_struct_input->VelLShank_filt[198], (real_T)
                c7_data_struct_input->VelLShank_filt[197], -3, 2U,
                c7_data_struct_input->VelLShank_filt[198] <
                c7_data_struct_input->VelLShank_filt[197]))) {
            if (CV_EML_COND(0, 1, 45, CV_RELATIONAL_EVAL(4U, 0U, 31, (real_T)
                  c7_data_struct_input->VelLShank_filt[198], (real_T)
                  c7_data_struct_input->VelLShank_filt[199], -3, 3U,
                  c7_data_struct_input->VelLShank_filt[198] <=
                  c7_data_struct_input->VelLShank_filt[199]))) {
              CV_EML_MCDC(0, 1, 10, true);
              CV_EML_IF(0, 1, 10, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 123);
              c7_data_struct_input->EC_event_left = true;
            } else {
              guard119 = true;
            }
          } else {
            guard120 = true;
          }
        } else {
          guard121 = true;
        }
      }

      if (guard121 == true) {
        guard120 = true;
      }

      if (guard120 == true) {
        guard119 = true;
      }

      if (guard119 == true) {
        CV_EML_MCDC(0, 1, 10, false);
        CV_EML_IF(0, 1, 10, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, MAX_int8_T);
      guard116 = false;
      guard117 = false;
      guard118 = false;
      if (CV_EML_COND(0, 1, 46, CV_RELATIONAL_EVAL(4U, 0U, 32, (real_T)
            c7_data_struct_input->state, 5.0, 0, 0U, c7_data_struct_input->state
            == 5))) {
        guard118 = true;
      } else if (CV_EML_COND(0, 1, 47, CV_RELATIONAL_EVAL(4U, 0U, 33, (real_T)
                   c7_data_struct_input->state, 6.0, 0, 0U,
                   c7_data_struct_input->state == 6))) {
        guard118 = true;
      } else if (CV_EML_COND(0, 1, 48, CV_RELATIONAL_EVAL(4U, 0U, 34, (real_T)
                   c7_data_struct_input->state, 1.0, 0, 0U,
                   c7_data_struct_input->state == 1))) {
        guard117 = true;
      } else {
        guard116 = true;
      }

      if (guard118 == true) {
        guard117 = true;
      }

      if (guard117 == true) {
        if (CV_EML_COND(0, 1, 49, CV_RELATIONAL_EVAL(4U, 0U, 35, (real_T)
              c7_data_struct_input->VelLShank_filt[199], (real_T)
              c7_data_struct_input->stop_Vel_th_left, -3, 2U,
              c7_data_struct_input->VelLShank_filt[199] <
              c7_data_struct_input->stop_Vel_th_left))) {
          CV_EML_MCDC(0, 1, 11, true);
          CV_EML_IF(0, 1, 11, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 128U);
          c7_data_struct_input->stop_Vel_event_left = true;
        } else {
          guard116 = true;
        }
      }

      if (guard116 == true) {
        CV_EML_MCDC(0, 1, 11, false);
        CV_EML_IF(0, 1, 11, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 132U);
      guard113 = false;
      guard114 = false;
      guard115 = false;
      if (CV_EML_COND(0, 1, 50, CV_RELATIONAL_EVAL(4U, 0U, 36, (real_T)
            c7_data_struct_input->state, 2.0, 0, 0U, c7_data_struct_input->state
            == 2))) {
        guard115 = true;
      } else if (CV_EML_COND(0, 1, 51, CV_RELATIONAL_EVAL(4U, 0U, 37, (real_T)
                   c7_data_struct_input->state, 3.0, 0, 0U,
                   c7_data_struct_input->state == 3))) {
        guard115 = true;
      } else if (CV_EML_COND(0, 1, 52, CV_RELATIONAL_EVAL(4U, 0U, 38, (real_T)
                   c7_data_struct_input->state, 4.0, 0, 0U,
                   c7_data_struct_input->state == 4))) {
        guard114 = true;
      } else {
        guard113 = true;
      }

      if (guard115 == true) {
        guard114 = true;
      }

      if (guard114 == true) {
        if (CV_EML_COND(0, 1, 53, CV_RELATIONAL_EVAL(4U, 0U, 39, (real_T)
              c7_data_struct_input->VelRShank_filt[199], (real_T)
              c7_data_struct_input->stop_Vel_th_right, -3, 2U,
              c7_data_struct_input->VelRShank_filt[199] <
              c7_data_struct_input->stop_Vel_th_right))) {
          CV_EML_MCDC(0, 1, 12, true);
          CV_EML_IF(0, 1, 12, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 133U);
          c7_data_struct_input->stop_Vel_event_right = true;
        } else {
          guard113 = true;
        }
      }

      if (guard113 == true) {
        CV_EML_MCDC(0, 1, 12, false);
        CV_EML_IF(0, 1, 12, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 137U);
      guard110 = false;
      guard111 = false;
      guard112 = false;
      if (CV_EML_COND(0, 1, 54, CV_RELATIONAL_EVAL(4U, 0U, 40, (real_T)
            c7_data_struct_input->state, 5.0, 0, 0U, c7_data_struct_input->state
            == 5))) {
        guard112 = true;
      } else if (CV_EML_COND(0, 1, 55, CV_RELATIONAL_EVAL(4U, 0U, 41, (real_T)
                   c7_data_struct_input->state, 6.0, 0, 0U,
                   c7_data_struct_input->state == 6))) {
        guard112 = true;
      } else if (CV_EML_COND(0, 1, 56, CV_RELATIONAL_EVAL(4U, 0U, 42, (real_T)
                   c7_data_struct_input->state, 1.0, 0, 0U,
                   c7_data_struct_input->state == 1))) {
        guard111 = true;
      } else {
        guard110 = true;
      }

      if (guard112 == true) {
        guard111 = true;
      }

      if (guard111 == true) {
        if (CV_EML_COND(0, 1, 57, CV_RELATIONAL_EVAL(4U, 0U, 43, (real_T)
              c7_data_struct_input->AngLShank_filt[199], (real_T)
              c7_data_struct_input->stop_MA_th_left, -3, 4U,
              c7_data_struct_input->AngLShank_filt[199] >
              c7_data_struct_input->stop_MA_th_left))) {
          CV_EML_MCDC(0, 1, 13, true);
          CV_EML_IF(0, 1, 13, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 138U);
          c7_data_struct_input->stop_MA_event_left = true;
        } else {
          guard110 = true;
        }
      }

      if (guard110 == true) {
        CV_EML_MCDC(0, 1, 13, false);
        CV_EML_IF(0, 1, 13, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 142U);
      guard107 = false;
      guard108 = false;
      guard109 = false;
      if (CV_EML_COND(0, 1, 58, CV_RELATIONAL_EVAL(4U, 0U, 44, (real_T)
            c7_data_struct_input->state, 2.0, 0, 0U, c7_data_struct_input->state
            == 2))) {
        guard109 = true;
      } else if (CV_EML_COND(0, 1, 59, CV_RELATIONAL_EVAL(4U, 0U, 45, (real_T)
                   c7_data_struct_input->state, 3.0, 0, 0U,
                   c7_data_struct_input->state == 3))) {
        guard109 = true;
      } else if (CV_EML_COND(0, 1, 60, CV_RELATIONAL_EVAL(4U, 0U, 46, (real_T)
                   c7_data_struct_input->state, 4.0, 0, 0U,
                   c7_data_struct_input->state == 4))) {
        guard108 = true;
      } else {
        guard107 = true;
      }

      if (guard109 == true) {
        guard108 = true;
      }

      if (guard108 == true) {
        if (CV_EML_COND(0, 1, 61, CV_RELATIONAL_EVAL(4U, 0U, 47, (real_T)
              c7_data_struct_input->AngRShank_filt[199], (real_T)
              c7_data_struct_input->stop_MA_th_right, -3, 4U,
              c7_data_struct_input->AngRShank_filt[199] >
              c7_data_struct_input->stop_MA_th_right))) {
          CV_EML_MCDC(0, 1, 14, true);
          CV_EML_IF(0, 1, 14, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 143U);
          c7_data_struct_input->stop_MA_event_right = true;
        } else {
          guard107 = true;
        }
      }

      if (guard107 == true) {
        CV_EML_MCDC(0, 1, 14, false);
        CV_EML_IF(0, 1, 14, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 147U);
      guard104 = false;
      guard105 = false;
      guard106 = false;
      if (CV_EML_COND(0, 1, 62, CV_RELATIONAL_EVAL(4U, 0U, 48, (real_T)
            c7_data_struct_input->state, 5.0, 0, 0U, c7_data_struct_input->state
            == 5))) {
        guard106 = true;
      } else if (CV_EML_COND(0, 1, 63, CV_RELATIONAL_EVAL(4U, 0U, 49, (real_T)
                   c7_data_struct_input->state, 6.0, 0, 0U,
                   c7_data_struct_input->state == 6))) {
        guard106 = true;
      } else if (CV_EML_COND(0, 1, 64, CV_RELATIONAL_EVAL(4U, 0U, 50, (real_T)
                   c7_data_struct_input->state, 1.0, 0, 0U,
                   c7_data_struct_input->state == 1))) {
        guard105 = true;
      } else {
        guard104 = true;
      }

      if (guard106 == true) {
        guard105 = true;
      }

      if (guard105 == true) {
        if (CV_EML_COND(0, 1, 65, CV_RELATIONAL_EVAL(4U, 0U, 51, (real_T)
              c7_data_struct_input->AngRShank_filt[199], (real_T)
              c7_data_struct_input->stop_IC_th_right, -3, 2U,
              c7_data_struct_input->AngRShank_filt[199] <
              c7_data_struct_input->stop_IC_th_right))) {
          CV_EML_MCDC(0, 1, 15, true);
          CV_EML_IF(0, 1, 15, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 148U);
          c7_data_struct_input->stop_IC_event_right = true;
        } else {
          guard104 = true;
        }
      }

      if (guard104 == true) {
        CV_EML_MCDC(0, 1, 15, false);
        CV_EML_IF(0, 1, 15, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 152U);
      guard101 = false;
      guard102 = false;
      guard103 = false;
      if (CV_EML_COND(0, 1, 66, CV_RELATIONAL_EVAL(4U, 0U, 52, (real_T)
            c7_data_struct_input->state, 2.0, 0, 0U, c7_data_struct_input->state
            == 2))) {
        guard103 = true;
      } else if (CV_EML_COND(0, 1, 67, CV_RELATIONAL_EVAL(4U, 0U, 53, (real_T)
                   c7_data_struct_input->state, 3.0, 0, 0U,
                   c7_data_struct_input->state == 3))) {
        guard103 = true;
      } else if (CV_EML_COND(0, 1, 68, CV_RELATIONAL_EVAL(4U, 0U, 54, (real_T)
                   c7_data_struct_input->state, 4.0, 0, 0U,
                   c7_data_struct_input->state == 4))) {
        guard102 = true;
      } else {
        guard101 = true;
      }

      if (guard103 == true) {
        guard102 = true;
      }

      if (guard102 == true) {
        if (CV_EML_COND(0, 1, 69, CV_RELATIONAL_EVAL(4U, 0U, 55, (real_T)
              c7_data_struct_input->AngLShank_filt[199], (real_T)
              c7_data_struct_input->stop_IC_th_left, -3, 2U,
              c7_data_struct_input->AngLShank_filt[199] <
              c7_data_struct_input->stop_IC_th_left))) {
          CV_EML_MCDC(0, 1, 16, true);
          CV_EML_IF(0, 1, 16, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 153U);
          c7_data_struct_input->stop_IC_event_left = true;
        } else {
          guard101 = true;
        }
      }

      if (guard101 == true) {
        CV_EML_MCDC(0, 1, 16, false);
        CV_EML_IF(0, 1, 16, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 160U);
      guard100 = false;
      if (CV_EML_COND(0, 1, 70, CV_RELATIONAL_EVAL(4U, 0U, 56, (real_T)
            c7_data_struct_input->state, 2.0, 0, 0U, c7_data_struct_input->state
            == 2))) {
        if (CV_EML_COND(0, 1, 71, c7_data_struct_input->MS_event_left)) {
          CV_EML_MCDC(0, 1, 17, true);
          CV_EML_IF(0, 1, 17, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 161U);
          c7_data_struct_input->state = 3;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 162U);
          c7_data_struct_input->MS_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 163U);
          c7_data_struct_input->MA_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 164U);
          c7_data_struct_input->IC_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 166U);
          c7_data_struct_input->MS_buffer_left[(uint8_T)
            sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 12412, 72, MAX_uint32_T, (int32_T)
            c7_data_struct_input->MS_buffer_index_left, 1, 200) - 1] = (real32_T)
            c7_timestamp;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 167U);
          c7_u5 = (uint32_T)c7_data_struct_input->MS_buffer_index_left + 1U;
          if (CV_SATURATION_EVAL(4, 0, 0, 0, c7_u5 > 255U)) {
            c7_u5 = 255U;
          }

          c7_data_struct_input->MS_buffer_index_left = (uint8_T)c7_u5;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 168U);
          c7_uv2[0] = c7_data_struct_input->MS_buffer_index_left;
          c7_b23 = ((real_T)c7_data_struct_input->MS_buffer_index_left > 200.0);
          c7_trueCount = 0;
          c7_d_i = 0;
          while (c7_d_i <= 0) {
            if (c7_b23) {
              c7_trueCount++;
            }

            c7_d_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_partialTrueCount = 0;
          c7_e_i = 0;
          while (c7_e_i <= 0) {
            if (c7_b23) {
              c7_iv0[0] = 1;
              c7_iv0[1] = c7_trueCount;
              c7_tmp_sizes[0] = 1;
              c7_tmp_sizes[1] = c7_iv0[1];
              c7_i307 = c7_tmp_sizes[0];
              c7_i308 = c7_tmp_sizes[1];
              c7_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
              for (c7_i309 = 0; c7_i309 <= c7_loop_ub; c7_i309++) {
                c7_tmp_data[c7_i309] = 200U;
              }

              c7_uv2[c7_e_i] = c7_tmp_data[c7_partialTrueCount];
              c7_partialTrueCount++;
            }

            c7_e_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_data_struct_input->MS_buffer_index_left = c7_uv2[0];
        } else {
          guard100 = true;
        }
      } else {
        guard100 = true;
      }

      if (guard100 == true) {
        CV_EML_MCDC(0, 1, 17, false);
        CV_EML_IF(0, 1, 17, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 171U);
      guard99 = false;
      if (CV_EML_COND(0, 1, 72, CV_RELATIONAL_EVAL(4U, 0U, 59, (real_T)
            c7_data_struct_input->state, 3.0, 0, 0U, c7_data_struct_input->state
            == 3))) {
        if (CV_EML_COND(0, 1, 73, c7_data_struct_input->IC_event_left)) {
          CV_EML_MCDC(0, 1, 18, true);
          CV_EML_IF(0, 1, 18, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 172U);
          c7_data_struct_input->state = 4;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 173U);
          c7_data_struct_input->last_IC = 1U;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 174U);
          c7_data_struct_input->IC_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 175U);
          c7_data_struct_input->EC_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 176U);
          c7_data_struct_input->AN_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 177U);
          c7_data_struct_input->stop_Vel_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 178U);
          c7_data_struct_input->stop_MA_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 180U);
          c7_data_struct_input->IC_buffer_left[(uint8_T)
            sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 13134, 72, MAX_uint32_T, (int32_T)
            c7_data_struct_input->IC_buffer_index_left, 1, 200) - 1] = (real32_T)
            c7_timestamp;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 181U);
          c7_u6 = (uint32_T)c7_data_struct_input->IC_buffer_index_left + 1U;
          if (CV_SATURATION_EVAL(4, 0, 1, 0, c7_u6 > 255U)) {
            c7_u6 = 255U;
          }

          c7_data_struct_input->IC_buffer_index_left = (uint8_T)c7_u6;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 182U);
          c7_uv3[0] = c7_data_struct_input->IC_buffer_index_left;
          c7_b24 = ((real_T)c7_data_struct_input->IC_buffer_index_left > 200.0);
          c7_b_trueCount = 0;
          c7_f_i = 0;
          while (c7_f_i <= 0) {
            if (c7_b24) {
              c7_b_trueCount++;
            }

            c7_f_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_b_partialTrueCount = 0;
          c7_g_i = 0;
          while (c7_g_i <= 0) {
            if (c7_b24) {
              c7_iv0[0] = 1;
              c7_iv0[1] = c7_b_trueCount;
              c7_tmp_sizes[0] = 1;
              c7_tmp_sizes[1] = c7_iv0[1];
              c7_i310 = c7_tmp_sizes[0];
              c7_i311 = c7_tmp_sizes[1];
              c7_b_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
              for (c7_i312 = 0; c7_i312 <= c7_b_loop_ub; c7_i312++) {
                c7_tmp_data[c7_i312] = 200U;
              }

              c7_uv3[c7_g_i] = c7_tmp_data[c7_b_partialTrueCount];
              c7_b_partialTrueCount++;
            }

            c7_g_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_data_struct_input->IC_buffer_index_left = c7_uv3[0];
        } else {
          guard99 = true;
        }
      } else {
        guard99 = true;
      }

      if (guard99 == true) {
        CV_EML_MCDC(0, 1, 18, false);
        CV_EML_IF(0, 1, 18, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 185U);
      guard97 = false;
      guard98 = false;
      if (CV_EML_COND(0, 1, 74, CV_RELATIONAL_EVAL(4U, 0U, 62, (real_T)
            c7_data_struct_input->state, 4.0, 0, 0U, c7_data_struct_input->state
            == 4))) {
        if (CV_EML_COND(0, 1, 75, c7_data_struct_input->EC_event_right)) {
          if (CV_EML_COND(0, 1, 76, c7_data_struct_input->AN_event_right)) {
            CV_EML_MCDC(0, 1, 19, true);
            CV_EML_IF(0, 1, 19, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 186U);
            c7_data_struct_input->state = 5;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 187U);
            c7_data_struct_input->last_EC = 1U;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 188U);
            c7_data_struct_input->EC_event_right = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 189U);
            c7_data_struct_input->AN_event_right = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 190U);
            c7_data_struct_input->MS_event_right = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 191U);
            c7_data_struct_input->MA_event_right = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 194U);
            CV_EML_COND(0, 1, 77, CV_RELATIONAL_EVAL(4U, 0U, 67, (real_T)
              c7_data_struct_input->last_IC, 0.0, -1, 4U, (real_T)
              c7_data_struct_input->last_IC > 0.0));
            if (CV_EML_COND(0, 1, 78, CV_RELATIONAL_EVAL(4U, 0U, 68, (real_T)
                  c7_data_struct_input->last_IC, 1.0, 0, 4U,
                  c7_data_struct_input->last_IC > 1))) {
              CV_EML_MCDC(0, 1, 20, true);
              CV_EML_IF(0, 1, 20, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 195U);
              c7_q0 = c7_data_struct_input->last_IC;
              c7_qY = c7_q0 - 1U;
              if (CV_SATURATION_EVAL(4, 0, 2, 0, c7_qY > c7_q0)) {
                c7_qY = 0U;
              }

              c7_u7 = c7_qY;
              if (CV_SATURATION_EVAL(4, 0, 2, 0, c7_u7 > 65535U)) {
                c7_u7 = 65535U;
              }

              c7_data_struct_input->stop_DS[(uint8_T)sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 13962, 58,
                 MAX_uint32_T, (int32_T)c7_data_struct_input->stop_DS_index, 1,
                 10) - 1] = (uint16_T)c7_u7;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 196U);
              c7_u8 = (uint32_T)c7_data_struct_input->stop_DS_index + 1U;
              if (CV_SATURATION_EVAL(4, 0, 3, 0, c7_u8 > 255U)) {
                c7_u8 = 255U;
              }

              c7_data_struct_input->stop_DS_index = (uint8_T)c7_u8;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 197U);
              c7_uv4[0] = c7_data_struct_input->stop_DS_index;
              c7_b25 = ((real_T)c7_data_struct_input->stop_DS_index > 10.0);
              c7_c_trueCount = 0;
              c7_h_i = 0;
              while (c7_h_i <= 0) {
                if (c7_b25) {
                  c7_c_trueCount++;
                }

                c7_h_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_c_partialTrueCount = 0;
              c7_i_i = 0;
              while (c7_i_i <= 0) {
                if (c7_b25) {
                  c7_iv0[0] = 1;
                  c7_iv0[1] = c7_c_trueCount;
                  c7_tmp_sizes[0] = 1;
                  c7_tmp_sizes[1] = c7_iv0[1];
                  c7_i313 = c7_tmp_sizes[0];
                  c7_i314 = c7_tmp_sizes[1];
                  c7_c_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                  for (c7_i315 = 0; c7_i315 <= c7_c_loop_ub; c7_i315++) {
                    c7_tmp_data[c7_i315] = 1U;
                  }

                  c7_uv4[c7_i_i] = c7_tmp_data[c7_c_partialTrueCount];
                  c7_c_partialTrueCount++;
                }

                c7_i_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_data_struct_input->stop_DS_index = c7_uv4[0];
            } else {
              CV_EML_MCDC(0, 1, 20, false);
              CV_EML_IF(0, 1, 20, false);
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 199U);
            for (c7_i316 = 0; c7_i316 < 10; c7_i316++) {
              c7_bv3[c7_i316] = ((real_T)c7_data_struct_input->stop_DS[c7_i316] <
                                 10000.0);
            }

            c7_d_trueCount = 0;
            c7_j_i = 0;
            while (c7_j_i <= 9) {
              if (c7_bv3[c7_j_i]) {
                c7_d_trueCount++;
              }

              c7_j_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_b_tmp_sizes[0] = 1;
            c7_b_tmp_sizes[1] = c7_d_trueCount;
            c7_d_partialTrueCount = 0;
            c7_k_i = 0;
            while (c7_k_i <= 9) {
              if (c7_bv3[c7_k_i]) {
                c7_b_tmp_data[c7_d_partialTrueCount] = c7_k_i + 1;
                c7_d_partialTrueCount++;
              }

              c7_k_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input_sizes[0] = 1;
            c7_data_struct_input_sizes[1] = c7_b_tmp_sizes[1];
            c7_n_data_struct_input = c7_data_struct_input_sizes[0];
            c7_o_data_struct_input = c7_data_struct_input_sizes[1];
            c7_d_loop_ub = c7_b_tmp_sizes[0] * c7_b_tmp_sizes[1] - 1;
            for (c7_i317 = 0; c7_i317 <= c7_d_loop_ub; c7_i317++) {
              c7_data_struct_input_data[c7_i317] = c7_data_struct_input->
                stop_DS[c7_b_tmp_data[c7_i317] - 1];
            }

            c7_d7 = muDoubleScalarRound(c7_mean(chartInstance,
              c7_data_struct_input_data, c7_data_struct_input_sizes));
            if (c7_d7 < 65536.0) {
              if (CV_SATURATION_EVAL(4, 0, 4, 1, c7_d7 >= 0.0)) {
                c7_u9 = (uint16_T)c7_d7;
              } else {
                c7_u9 = 0U;
              }
            } else if (CV_SATURATION_EVAL(4, 0, 4, 0, c7_d7 >= 65536.0)) {
              c7_u9 = MAX_uint16_T;
            } else {
              c7_u9 = 0U;
            }

            c7_data_struct_input->stop_DS_th = c7_u9;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 201U);
            c7_data_struct_input->EC_buffer_right[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 14382, 74, MAX_uint32_T, (int32_T)
              c7_data_struct_input->EC_buffer_index_right, 1, 200) - 1] =
              (real32_T)c7_timestamp;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 202U);
            c7_u10 = (uint32_T)c7_data_struct_input->EC_buffer_index_right + 1U;
            if (CV_SATURATION_EVAL(4, 0, 5, 0, c7_u10 > 255U)) {
              c7_u10 = 255U;
            }

            c7_data_struct_input->EC_buffer_index_right = (uint8_T)c7_u10;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 203U);
            c7_uv5[0] = c7_data_struct_input->EC_buffer_index_right;
            c7_b26 = ((real_T)c7_data_struct_input->EC_buffer_index_right >
                      200.0);
            c7_e_trueCount = 0;
            c7_l_i = 0;
            while (c7_l_i <= 0) {
              if (c7_b26) {
                c7_e_trueCount++;
              }

              c7_l_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_e_partialTrueCount = 0;
            c7_m_i = 0;
            while (c7_m_i <= 0) {
              if (c7_b26) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_e_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i318 = c7_tmp_sizes[0];
                c7_i319 = c7_tmp_sizes[1];
                c7_e_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i320 = 0; c7_i320 <= c7_e_loop_ub; c7_i320++) {
                  c7_tmp_data[c7_i320] = 200U;
                }

                c7_uv5[c7_m_i] = c7_tmp_data[c7_e_partialTrueCount];
                c7_e_partialTrueCount++;
              }

              c7_m_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->EC_buffer_index_right = c7_uv5[0];
          } else {
            guard97 = true;
          }
        } else {
          guard98 = true;
        }
      } else {
        guard98 = true;
      }

      if (guard98 == true) {
        guard97 = true;
      }

      if (guard97 == true) {
        CV_EML_MCDC(0, 1, 19, false);
        CV_EML_IF(0, 1, 19, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 206U);
      guard96 = false;
      if (CV_EML_COND(0, 1, 79, CV_RELATIONAL_EVAL(4U, 0U, 69, (real_T)
            c7_data_struct_input->state, 5.0, 0, 0U, c7_data_struct_input->state
            == 5))) {
        if (CV_EML_COND(0, 1, 80, c7_data_struct_input->MS_event_right)) {
          CV_EML_MCDC(0, 1, 21, true);
          CV_EML_IF(0, 1, 21, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 207U);
          c7_data_struct_input->state = 6;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 208U);
          c7_data_struct_input->MS_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 209U);
          c7_data_struct_input->MA_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 210U);
          c7_data_struct_input->IC_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 212U);
          c7_data_struct_input->MS_buffer_right[(uint8_T)
            sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 15001, 74, MAX_uint32_T, (int32_T)
            c7_data_struct_input->MS_buffer_index_right, 1, 200) - 1] =
            (real32_T)c7_timestamp;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 213U);
          c7_u11 = (uint32_T)c7_data_struct_input->MS_buffer_index_right + 1U;
          if (CV_SATURATION_EVAL(4, 0, 6, 0, c7_u11 > 255U)) {
            c7_u11 = 255U;
          }

          c7_data_struct_input->MS_buffer_index_right = (uint8_T)c7_u11;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 214U);
          c7_uv6[0] = c7_data_struct_input->MS_buffer_index_right;
          c7_b27 = ((real_T)c7_data_struct_input->MS_buffer_index_right > 200.0);
          c7_f_trueCount = 0;
          c7_n_i = 0;
          while (c7_n_i <= 0) {
            if (c7_b27) {
              c7_f_trueCount++;
            }

            c7_n_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_f_partialTrueCount = 0;
          c7_o_i = 0;
          while (c7_o_i <= 0) {
            if (c7_b27) {
              c7_iv0[0] = 1;
              c7_iv0[1] = c7_f_trueCount;
              c7_tmp_sizes[0] = 1;
              c7_tmp_sizes[1] = c7_iv0[1];
              c7_i321 = c7_tmp_sizes[0];
              c7_i322 = c7_tmp_sizes[1];
              c7_f_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
              for (c7_i323 = 0; c7_i323 <= c7_f_loop_ub; c7_i323++) {
                c7_tmp_data[c7_i323] = 200U;
              }

              c7_uv6[c7_o_i] = c7_tmp_data[c7_f_partialTrueCount];
              c7_f_partialTrueCount++;
            }

            c7_o_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_data_struct_input->MS_buffer_index_right = c7_uv6[0];
        } else {
          guard96 = true;
        }
      } else {
        guard96 = true;
      }

      if (guard96 == true) {
        CV_EML_MCDC(0, 1, 21, false);
        CV_EML_IF(0, 1, 21, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 217U);
      guard95 = false;
      if (CV_EML_COND(0, 1, 81, CV_RELATIONAL_EVAL(4U, 0U, 72, (real_T)
            c7_data_struct_input->state, 6.0, 0, 0U, c7_data_struct_input->state
            == 6))) {
        if (CV_EML_COND(0, 1, 82, c7_data_struct_input->IC_event_right)) {
          CV_EML_MCDC(0, 1, 22, true);
          CV_EML_IF(0, 1, 22, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 218U);
          c7_data_struct_input->state = 1;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 219U);
          c7_data_struct_input->last_IC = 1U;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 220U);
          c7_data_struct_input->IC_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 221U);
          c7_data_struct_input->EC_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 222U);
          c7_data_struct_input->AN_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 223U);
          c7_data_struct_input->stop_Vel_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 224U);
          c7_data_struct_input->stop_MA_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 227U);
          c7_data_struct_input->IC_buffer_right[(uint8_T)
            sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 15732, 74, MAX_uint32_T, (int32_T)
            c7_data_struct_input->IC_buffer_index_right, 1, 200) - 1] =
            (real32_T)c7_timestamp;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 228U);
          c7_u12 = (uint32_T)c7_data_struct_input->IC_buffer_index_right + 1U;
          if (CV_SATURATION_EVAL(4, 0, 7, 0, c7_u12 > 255U)) {
            c7_u12 = 255U;
          }

          c7_data_struct_input->IC_buffer_index_right = (uint8_T)c7_u12;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 229U);
          c7_uv7[0] = c7_data_struct_input->IC_buffer_index_right;
          c7_b28 = ((real_T)c7_data_struct_input->IC_buffer_index_right > 200.0);
          c7_g_trueCount = 0;
          c7_p_i = 0;
          while (c7_p_i <= 0) {
            if (c7_b28) {
              c7_g_trueCount++;
            }

            c7_p_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_g_partialTrueCount = 0;
          c7_q_i = 0;
          while (c7_q_i <= 0) {
            if (c7_b28) {
              c7_iv0[0] = 1;
              c7_iv0[1] = c7_g_trueCount;
              c7_tmp_sizes[0] = 1;
              c7_tmp_sizes[1] = c7_iv0[1];
              c7_i324 = c7_tmp_sizes[0];
              c7_i325 = c7_tmp_sizes[1];
              c7_g_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
              for (c7_i326 = 0; c7_i326 <= c7_g_loop_ub; c7_i326++) {
                c7_tmp_data[c7_i326] = 200U;
              }

              c7_uv7[c7_q_i] = c7_tmp_data[c7_g_partialTrueCount];
              c7_g_partialTrueCount++;
            }

            c7_q_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_data_struct_input->IC_buffer_index_right = c7_uv7[0];
        } else {
          guard95 = true;
        }
      } else {
        guard95 = true;
      }

      if (guard95 == true) {
        CV_EML_MCDC(0, 1, 22, false);
        CV_EML_IF(0, 1, 22, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 232U);
      guard93 = false;
      guard94 = false;
      if (CV_EML_COND(0, 1, 83, CV_RELATIONAL_EVAL(4U, 0U, 75, (real_T)
            c7_data_struct_input->state, 1.0, 0, 0U, c7_data_struct_input->state
            == 1))) {
        if (CV_EML_COND(0, 1, 84, c7_data_struct_input->EC_event_left)) {
          if (CV_EML_COND(0, 1, 85, c7_data_struct_input->AN_event_left)) {
            CV_EML_MCDC(0, 1, 23, true);
            CV_EML_IF(0, 1, 23, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 233U);
            c7_data_struct_input->state = 2;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 234U);
            c7_data_struct_input->last_EC = 1U;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 235U);
            c7_data_struct_input->EC_event_left = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 236U);
            c7_data_struct_input->AN_event_left = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 237U);
            c7_data_struct_input->MS_event_left = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 238U);
            c7_data_struct_input->MA_event_left = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 242U);
            CV_EML_COND(0, 1, 86, CV_RELATIONAL_EVAL(4U, 0U, 80, (real_T)
              c7_data_struct_input->last_IC, 0.0, -1, 4U, (real_T)
              c7_data_struct_input->last_IC > 0.0));
            if (CV_EML_COND(0, 1, 87, CV_RELATIONAL_EVAL(4U, 0U, 81, (real_T)
                  c7_data_struct_input->last_IC, 1.0, 0, 4U,
                  c7_data_struct_input->last_IC > 1))) {
              CV_EML_MCDC(0, 1, 24, true);
              CV_EML_IF(0, 1, 24, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 243U);
              c7_b_q0 = c7_data_struct_input->last_IC;
              c7_b_qY = c7_b_q0 - 1U;
              if (CV_SATURATION_EVAL(4, 0, 8, 0, c7_b_qY > c7_b_q0)) {
                c7_b_qY = 0U;
              }

              c7_u13 = c7_b_qY;
              if (CV_SATURATION_EVAL(4, 0, 8, 0, c7_u13 > 65535U)) {
                c7_u13 = 65535U;
              }

              c7_data_struct_input->stop_DS[(uint8_T)sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 16555, 58,
                 MAX_uint32_T, (int32_T)c7_data_struct_input->stop_DS_index, 1,
                 10) - 1] = (uint16_T)c7_u13;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 244U);
              c7_u14 = (uint32_T)c7_data_struct_input->stop_DS_index + 1U;
              if (CV_SATURATION_EVAL(4, 0, 9, 0, c7_u14 > 255U)) {
                c7_u14 = 255U;
              }

              c7_data_struct_input->stop_DS_index = (uint8_T)c7_u14;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 245U);
              c7_uv8[0] = c7_data_struct_input->stop_DS_index;
              c7_b29 = ((real_T)c7_data_struct_input->stop_DS_index > 10.0);
              c7_h_trueCount = 0;
              c7_r_i = 0;
              while (c7_r_i <= 0) {
                if (c7_b29) {
                  c7_h_trueCount++;
                }

                c7_r_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_h_partialTrueCount = 0;
              c7_s_i = 0;
              while (c7_s_i <= 0) {
                if (c7_b29) {
                  c7_iv0[0] = 1;
                  c7_iv0[1] = c7_h_trueCount;
                  c7_tmp_sizes[0] = 1;
                  c7_tmp_sizes[1] = c7_iv0[1];
                  c7_i327 = c7_tmp_sizes[0];
                  c7_i328 = c7_tmp_sizes[1];
                  c7_h_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                  for (c7_i329 = 0; c7_i329 <= c7_h_loop_ub; c7_i329++) {
                    c7_tmp_data[c7_i329] = 1U;
                  }

                  c7_uv8[c7_s_i] = c7_tmp_data[c7_h_partialTrueCount];
                  c7_h_partialTrueCount++;
                }

                c7_s_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_data_struct_input->stop_DS_index = c7_uv8[0];
            } else {
              CV_EML_MCDC(0, 1, 24, false);
              CV_EML_IF(0, 1, 24, false);
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 247U);
            for (c7_i330 = 0; c7_i330 < 10; c7_i330++) {
              c7_bv3[c7_i330] = ((real_T)c7_data_struct_input->stop_DS[c7_i330] <
                                 10000.0);
            }

            c7_i_trueCount = 0;
            c7_t_i = 0;
            while (c7_t_i <= 9) {
              if (c7_bv3[c7_t_i]) {
                c7_i_trueCount++;
              }

              c7_t_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_b_tmp_sizes[0] = 1;
            c7_b_tmp_sizes[1] = c7_i_trueCount;
            c7_i_partialTrueCount = 0;
            c7_u_i = 0;
            while (c7_u_i <= 9) {
              if (c7_bv3[c7_u_i]) {
                c7_b_tmp_data[c7_i_partialTrueCount] = c7_u_i + 1;
                c7_i_partialTrueCount++;
              }

              c7_u_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_b_data_struct_input_sizes[0] = 1;
            c7_b_data_struct_input_sizes[1] = c7_b_tmp_sizes[1];
            c7_p_data_struct_input = c7_b_data_struct_input_sizes[0];
            c7_q_data_struct_input = c7_b_data_struct_input_sizes[1];
            c7_i_loop_ub = c7_b_tmp_sizes[0] * c7_b_tmp_sizes[1] - 1;
            for (c7_i331 = 0; c7_i331 <= c7_i_loop_ub; c7_i331++) {
              c7_b_data_struct_input_data[c7_i331] =
                c7_data_struct_input->stop_DS[c7_b_tmp_data[c7_i331] - 1];
            }

            c7_d8 = muDoubleScalarRound(c7_mean(chartInstance,
              c7_b_data_struct_input_data, c7_b_data_struct_input_sizes));
            if (c7_d8 < 65536.0) {
              if (CV_SATURATION_EVAL(4, 0, 10, 1, c7_d8 >= 0.0)) {
                c7_u15 = (uint16_T)c7_d8;
              } else {
                c7_u15 = 0U;
              }
            } else if (CV_SATURATION_EVAL(4, 0, 10, 0, c7_d8 >= 65536.0)) {
              c7_u15 = MAX_uint16_T;
            } else {
              c7_u15 = 0U;
            }

            c7_data_struct_input->stop_DS_th = c7_u15;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 249U);
            c7_data_struct_input->EC_buffer_left[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 16975, 72, MAX_uint32_T, (int32_T)
              c7_data_struct_input->EC_buffer_index_left, 1, 200) - 1] =
              (real32_T)c7_timestamp;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 250U);
            c7_u16 = (uint32_T)c7_data_struct_input->EC_buffer_index_left + 1U;
            if (CV_SATURATION_EVAL(4, 0, 11, 0, c7_u16 > 255U)) {
              c7_u16 = 255U;
            }

            c7_data_struct_input->EC_buffer_index_left = (uint8_T)c7_u16;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 251U);
            c7_uv9[0] = c7_data_struct_input->EC_buffer_index_left;
            c7_b30 = ((real_T)c7_data_struct_input->EC_buffer_index_left > 200.0);
            c7_j_trueCount = 0;
            c7_v_i = 0;
            while (c7_v_i <= 0) {
              if (c7_b30) {
                c7_j_trueCount++;
              }

              c7_v_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_j_partialTrueCount = 0;
            c7_w_i = 0;
            while (c7_w_i <= 0) {
              if (c7_b30) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_j_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i332 = c7_tmp_sizes[0];
                c7_i333 = c7_tmp_sizes[1];
                c7_j_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i334 = 0; c7_i334 <= c7_j_loop_ub; c7_i334++) {
                  c7_tmp_data[c7_i334] = 200U;
                }

                c7_uv9[c7_w_i] = c7_tmp_data[c7_j_partialTrueCount];
                c7_j_partialTrueCount++;
              }

              c7_w_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->EC_buffer_index_left = c7_uv9[0];
          } else {
            guard93 = true;
          }
        } else {
          guard94 = true;
        }
      } else {
        guard94 = true;
      }

      if (guard94 == true) {
        guard93 = true;
      }

      if (guard93 == true) {
        CV_EML_MCDC(0, 1, 23, false);
        CV_EML_IF(0, 1, 23, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, MAX_uint8_T);
      guard85 = false;
      guard86 = false;
      guard87 = false;
      guard88 = false;
      guard89 = false;
      guard90 = false;
      guard91 = false;
      guard92 = false;
      if (CV_EML_COND(0, 1, 88, CV_RELATIONAL_EVAL(4U, 0U, 82, (real_T)
            c7_data_struct_input->state, 5.0, 0, 0U, c7_data_struct_input->state
            == 5))) {
        c7_cc_b = c7_data_struct_input->stop_DS_th;
        c7_u17 = 3U * (uint32_T)c7_cc_b;
        if (CV_SATURATION_EVAL(4, 0, 12, 0, c7_u17 > 65535U)) {
          c7_u17 = 65535U;
        }

        c7_cc_y = (uint16_T)c7_u17;
        c7_dc_b = c7_data_struct_input->stop_DS_th;
        c7_u18 = 3U * (uint32_T)c7_dc_b;
        if (CV_SATURATION_EVAL(4, 0, 12, 0, c7_u18 > 65535U)) {
          c7_u18 = 65535U;
        }

        c7_dc_y = (uint16_T)c7_u18;
        if (CV_EML_COND(0, 1, 89, CV_RELATIONAL_EVAL(4U, 0U, 83, (real_T)
              c7_data_struct_input->counter_stop, (real_T)c7_cc_y, 0, 4U,
              c7_data_struct_input->counter_stop > c7_dc_y))) {
          guard91 = true;
        } else {
          guard92 = true;
        }
      } else {
        guard92 = true;
      }

      if (guard92 == true) {
        if (CV_EML_COND(0, 1, 90, CV_RELATIONAL_EVAL(4U, 0U, 84, (real_T)
              c7_data_struct_input->state, 6.0, 0, 0U,
              c7_data_struct_input->state == 6))) {
          c7_ec_b = c7_data_struct_input->stop_DS_th;
          c7_u19 = 3U * (uint32_T)c7_ec_b;
          if (CV_SATURATION_EVAL(4, 0, 13, 0, c7_u19 > 65535U)) {
            c7_u19 = 65535U;
          }

          c7_ec_y = (uint16_T)c7_u19;
          c7_fc_b = c7_data_struct_input->stop_DS_th;
          c7_u20 = 3U * (uint32_T)c7_fc_b;
          if (CV_SATURATION_EVAL(4, 0, 13, 0, c7_u20 > 65535U)) {
            c7_u20 = 65535U;
          }

          c7_fc_y = (uint16_T)c7_u20;
          if (CV_EML_COND(0, 1, 91, CV_RELATIONAL_EVAL(4U, 0U, 85, (real_T)
                c7_data_struct_input->counter_stop, (real_T)c7_ec_y, 0, 4U,
                c7_data_struct_input->counter_stop > c7_fc_y))) {
            guard91 = true;
          } else {
            guard90 = true;
          }
        } else {
          guard90 = true;
        }
      }

      if (guard91 == true) {
        guard89 = true;
      }

      if (guard90 == true) {
        if (CV_EML_COND(0, 1, 92, CV_RELATIONAL_EVAL(4U, 0U, 86, (real_T)
              c7_data_struct_input->state, 1.0, 0, 0U,
              c7_data_struct_input->state == 1))) {
          c7_gc_b = c7_data_struct_input->stop_DS_th;
          c7_u21 = 3U * (uint32_T)c7_gc_b;
          if (CV_SATURATION_EVAL(4, 0, 14, 0, c7_u21 > 65535U)) {
            c7_u21 = 65535U;
          }

          c7_gc_y = (uint16_T)c7_u21;
          c7_hc_b = c7_data_struct_input->stop_DS_th;
          c7_u22 = 3U * (uint32_T)c7_hc_b;
          if (CV_SATURATION_EVAL(4, 0, 14, 0, c7_u22 > 65535U)) {
            c7_u22 = 65535U;
          }

          c7_hc_y = (uint16_T)c7_u22;
          if (CV_EML_COND(0, 1, 93, CV_RELATIONAL_EVAL(4U, 0U, 87, (real_T)
                c7_data_struct_input->counter_stop, (real_T)c7_gc_y, 0, 4U,
                c7_data_struct_input->counter_stop > c7_hc_y))) {
            guard89 = true;
          } else {
            guard88 = true;
          }
        } else {
          guard88 = true;
        }
      }

      if (guard89 == true) {
        if (CV_EML_COND(0, 1, 94, CV_RELATIONAL_EVAL(4U, 0U, 88, (real_T)
              c7_data_struct_input->state, (real_T)
              c7_data_struct_input->prevstate, 0, 0U,
              c7_data_struct_input->state == c7_data_struct_input->prevstate)))
        {
          if (CV_EML_COND(0, 1, 95, CV_RELATIONAL_EVAL(4U, 0U, 89, (real_T)
                c7_data_struct_input->stop_Vel_event_left, 0.0, -1, 0U,
                !c7_data_struct_input->stop_Vel_event_left))) {
            if (CV_EML_COND(0, 1, 96, CV_RELATIONAL_EVAL(4U, 0U, 90, (real_T)
                  c7_data_struct_input->stop_MA_event_left, 0.0, -1, 0U,
                  !c7_data_struct_input->stop_MA_event_left))) {
              CV_EML_MCDC(0, 1, 25, true);
              CV_EML_IF(0, 1, 25, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 256);
              c7_data_struct_input->state = 0;
            } else {
              guard85 = true;
            }
          } else {
            guard86 = true;
          }
        } else {
          guard87 = true;
        }
      }

      if (guard88 == true) {
        guard87 = true;
      }

      if (guard87 == true) {
        guard86 = true;
      }

      if (guard86 == true) {
        guard85 = true;
      }

      if (guard85 == true) {
        CV_EML_MCDC(0, 1, 25, false);
        CV_EML_IF(0, 1, 25, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 260);
      guard77 = false;
      guard78 = false;
      guard79 = false;
      guard80 = false;
      guard81 = false;
      guard82 = false;
      guard83 = false;
      guard84 = false;
      if (CV_EML_COND(0, 1, 97, CV_RELATIONAL_EVAL(4U, 0U, 91, (real_T)
            c7_data_struct_input->state, 2.0, 0, 0U, c7_data_struct_input->state
            == 2))) {
        c7_ic_b = c7_data_struct_input->stop_DS_th;
        c7_u23 = 3U * (uint32_T)c7_ic_b;
        if (CV_SATURATION_EVAL(4, 0, 15, 0, c7_u23 > 65535U)) {
          c7_u23 = 65535U;
        }

        c7_ic_y = (uint16_T)c7_u23;
        c7_jc_b = c7_data_struct_input->stop_DS_th;
        c7_u24 = 3U * (uint32_T)c7_jc_b;
        if (CV_SATURATION_EVAL(4, 0, 15, 0, c7_u24 > 65535U)) {
          c7_u24 = 65535U;
        }

        c7_jc_y = (uint16_T)c7_u24;
        if (CV_EML_COND(0, 1, 98, CV_RELATIONAL_EVAL(4U, 0U, 92, (real_T)
              c7_data_struct_input->counter_stop, (real_T)c7_ic_y, 0, 4U,
              c7_data_struct_input->counter_stop > c7_jc_y))) {
          guard83 = true;
        } else {
          guard84 = true;
        }
      } else {
        guard84 = true;
      }

      if (guard84 == true) {
        if (CV_EML_COND(0, 1, 99, CV_RELATIONAL_EVAL(4U, 0U, 93, (real_T)
              c7_data_struct_input->state, 3.0, 0, 0U,
              c7_data_struct_input->state == 3))) {
          c7_kc_b = c7_data_struct_input->stop_DS_th;
          c7_u25 = 3U * (uint32_T)c7_kc_b;
          if (CV_SATURATION_EVAL(4, 0, 16, 0, c7_u25 > 65535U)) {
            c7_u25 = 65535U;
          }

          c7_kc_y = (uint16_T)c7_u25;
          c7_lc_b = c7_data_struct_input->stop_DS_th;
          c7_u26 = 3U * (uint32_T)c7_lc_b;
          if (CV_SATURATION_EVAL(4, 0, 16, 0, c7_u26 > 65535U)) {
            c7_u26 = 65535U;
          }

          c7_lc_y = (uint16_T)c7_u26;
          if (CV_EML_COND(0, 1, 100, CV_RELATIONAL_EVAL(4U, 0U, 94, (real_T)
                c7_data_struct_input->counter_stop, (real_T)c7_kc_y, 0, 4U,
                c7_data_struct_input->counter_stop > c7_lc_y))) {
            guard83 = true;
          } else {
            guard82 = true;
          }
        } else {
          guard82 = true;
        }
      }

      if (guard83 == true) {
        guard81 = true;
      }

      if (guard82 == true) {
        if (CV_EML_COND(0, 1, 101, CV_RELATIONAL_EVAL(4U, 0U, 95, (real_T)
              c7_data_struct_input->state, 4.0, 0, 0U,
              c7_data_struct_input->state == 4))) {
          c7_mc_b = c7_data_struct_input->stop_DS_th;
          c7_u27 = 3U * (uint32_T)c7_mc_b;
          if (CV_SATURATION_EVAL(4, 0, 17, 0, c7_u27 > 65535U)) {
            c7_u27 = 65535U;
          }

          c7_mc_y = (uint16_T)c7_u27;
          c7_nc_b = c7_data_struct_input->stop_DS_th;
          c7_u28 = 3U * (uint32_T)c7_nc_b;
          if (CV_SATURATION_EVAL(4, 0, 17, 0, c7_u28 > 65535U)) {
            c7_u28 = 65535U;
          }

          c7_nc_y = (uint16_T)c7_u28;
          if (CV_EML_COND(0, 1, 102, CV_RELATIONAL_EVAL(4U, 0U, 96, (real_T)
                c7_data_struct_input->counter_stop, (real_T)c7_mc_y, 0, 4U,
                c7_data_struct_input->counter_stop > c7_nc_y))) {
            guard81 = true;
          } else {
            guard80 = true;
          }
        } else {
          guard80 = true;
        }
      }

      if (guard81 == true) {
        if (CV_EML_COND(0, 1, 103, CV_RELATIONAL_EVAL(4U, 0U, 97, (real_T)
              c7_data_struct_input->state, (real_T)
              c7_data_struct_input->prevstate, 0, 0U,
              c7_data_struct_input->state == c7_data_struct_input->prevstate)))
        {
          if (CV_EML_COND(0, 1, 104, CV_RELATIONAL_EVAL(4U, 0U, 98, (real_T)
                c7_data_struct_input->stop_Vel_event_right, 0.0, -1, 0U,
                !c7_data_struct_input->stop_Vel_event_right))) {
            if (CV_EML_COND(0, 1, 105, CV_RELATIONAL_EVAL(4U, 0U, 99, (real_T)
                  c7_data_struct_input->stop_MA_event_right, 0.0, -1, 0U,
                  !c7_data_struct_input->stop_MA_event_right))) {
              CV_EML_MCDC(0, 1, 26, true);
              CV_EML_IF(0, 1, 26, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 261);
              c7_data_struct_input->state = 0;
            } else {
              guard77 = true;
            }
          } else {
            guard78 = true;
          }
        } else {
          guard79 = true;
        }
      }

      if (guard80 == true) {
        guard79 = true;
      }

      if (guard79 == true) {
        guard78 = true;
      }

      if (guard78 == true) {
        guard77 = true;
      }

      if (guard77 == true) {
        CV_EML_MCDC(0, 1, 26, false);
        CV_EML_IF(0, 1, 26, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 265);
      c7_oc_b = c7_data_struct_input->stop_DS_th;
      c7_u29 = 6U * (uint32_T)c7_oc_b;
      if (CV_SATURATION_EVAL(4, 0, 18, 0, c7_u29 > 65535U)) {
        c7_u29 = 65535U;
      }

      c7_oc_y = (uint16_T)c7_u29;
      c7_pc_b = c7_data_struct_input->stop_DS_th;
      c7_u30 = 6U * (uint32_T)c7_pc_b;
      if (CV_SATURATION_EVAL(4, 0, 18, 0, c7_u30 > 65535U)) {
        c7_u30 = 65535U;
      }

      c7_pc_y = (uint16_T)c7_u30;
      if (CV_EML_IF(0, 1, 27, CV_RELATIONAL_EVAL(4U, 0U, 100, (real_T)
            c7_data_struct_input->counter_stop, (real_T)c7_oc_y, 0, 4U,
            c7_data_struct_input->counter_stop > c7_pc_y))) {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 266);
        c7_data_struct_input->state = 0;
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 270);
      guard76 = false;
      if (CV_EML_COND(0, 1, 106, CV_RELATIONAL_EVAL(4U, 0U, 101, (real_T)
            c7_data_struct_input->state, 0.0, 0, 0U, c7_data_struct_input->state
            == 0))) {
        if (CV_EML_COND(0, 1, 107, CV_RELATIONAL_EVAL(4U, 0U, 102, (real_T)
              c7_data_struct_input->VelRShank[199], 50.0, -1, 4U,
              c7_data_struct_input->VelRShank[199] > 50.0F))) {
          CV_EML_MCDC(0, 1, 27, true);
          CV_EML_IF(0, 1, 28, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 271);
          c7_data_struct_input->state = 5;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 272);
          c7_data_struct_input->MA_event_right = true;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 274);
          c7_data_struct_input->last_EC = 1U;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 275);
          c7_data_struct_input->EC_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 276);
          c7_data_struct_input->AN_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 277);
          c7_data_struct_input->MS_event_right = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 279);
          c7_data_struct_input->EC_buffer_right[(uint8_T)
            sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 18950, 74, MAX_uint32_T, (int32_T)
            c7_data_struct_input->EC_buffer_index_right, 1, 200) - 1] =
            (real32_T)c7_timestamp;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 280);
          c7_u31 = (uint32_T)c7_data_struct_input->EC_buffer_index_right + 1U;
          if (CV_SATURATION_EVAL(4, 0, 19, 0, c7_u31 > 255U)) {
            c7_u31 = 255U;
          }

          c7_data_struct_input->EC_buffer_index_right = (uint8_T)c7_u31;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 281);
          c7_uv10[0] = c7_data_struct_input->EC_buffer_index_right;
          c7_b31 = ((real_T)c7_data_struct_input->EC_buffer_index_right > 200.0);
          c7_k_trueCount = 0;
          c7_x_i = 0;
          while (c7_x_i <= 0) {
            if (c7_b31) {
              c7_k_trueCount++;
            }

            c7_x_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_k_partialTrueCount = 0;
          c7_y_i = 0;
          while (c7_y_i <= 0) {
            if (c7_b31) {
              c7_iv0[0] = 1;
              c7_iv0[1] = c7_k_trueCount;
              c7_tmp_sizes[0] = 1;
              c7_tmp_sizes[1] = c7_iv0[1];
              c7_i335 = c7_tmp_sizes[0];
              c7_i336 = c7_tmp_sizes[1];
              c7_k_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
              for (c7_i337 = 0; c7_i337 <= c7_k_loop_ub; c7_i337++) {
                c7_tmp_data[c7_i337] = 200U;
              }

              c7_uv10[c7_y_i] = c7_tmp_data[c7_k_partialTrueCount];
              c7_k_partialTrueCount++;
            }

            c7_y_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_data_struct_input->EC_buffer_index_right = c7_uv10[0];
        } else {
          guard76 = true;
        }
      } else {
        guard76 = true;
      }

      if (guard76 == true) {
        CV_EML_MCDC(0, 1, 27, false);
        CV_EML_IF(0, 1, 28, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 284);
      guard75 = false;
      if (CV_EML_COND(0, 1, 108, CV_RELATIONAL_EVAL(4U, 0U, 103, (real_T)
            c7_data_struct_input->state, 0.0, 0, 0U, c7_data_struct_input->state
            == 0))) {
        if (CV_EML_COND(0, 1, 109, CV_RELATIONAL_EVAL(4U, 0U, 104, (real_T)
              c7_data_struct_input->VelLShank[199], 50.0, -1, 4U,
              c7_data_struct_input->VelLShank[199] > 50.0F))) {
          CV_EML_MCDC(0, 1, 28, true);
          CV_EML_IF(0, 1, 29, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 285);
          c7_data_struct_input->state = 2;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 286);
          c7_data_struct_input->MA_event_left = true;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 288);
          c7_data_struct_input->last_EC = 1U;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 289);
          c7_data_struct_input->EC_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 290);
          c7_data_struct_input->AN_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 291);
          c7_data_struct_input->MS_event_left = false;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 294);
          c7_data_struct_input->EC_buffer_left[(uint8_T)
            sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 19619, 72, MAX_uint32_T, (int32_T)
            c7_data_struct_input->EC_buffer_index_left, 1, 200) - 1] = (real32_T)
            c7_timestamp;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 295);
          c7_u32 = (uint32_T)c7_data_struct_input->EC_buffer_index_left + 1U;
          if (CV_SATURATION_EVAL(4, 0, 20, 0, c7_u32 > 255U)) {
            c7_u32 = 255U;
          }

          c7_data_struct_input->EC_buffer_index_left = (uint8_T)c7_u32;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 296);
          c7_uv11[0] = c7_data_struct_input->EC_buffer_index_left;
          c7_b32 = ((real_T)c7_data_struct_input->EC_buffer_index_left > 200.0);
          c7_l_trueCount = 0;
          c7_ab_i = 0;
          while (c7_ab_i <= 0) {
            if (c7_b32) {
              c7_l_trueCount++;
            }

            c7_ab_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_l_partialTrueCount = 0;
          c7_bb_i = 0;
          while (c7_bb_i <= 0) {
            if (c7_b32) {
              c7_iv0[0] = 1;
              c7_iv0[1] = c7_l_trueCount;
              c7_tmp_sizes[0] = 1;
              c7_tmp_sizes[1] = c7_iv0[1];
              c7_i338 = c7_tmp_sizes[0];
              c7_i339 = c7_tmp_sizes[1];
              c7_l_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
              for (c7_i340 = 0; c7_i340 <= c7_l_loop_ub; c7_i340++) {
                c7_tmp_data[c7_i340] = 200U;
              }

              c7_uv11[c7_bb_i] = c7_tmp_data[c7_l_partialTrueCount];
              c7_l_partialTrueCount++;
            }

            c7_bb_i++;
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }

          c7_data_struct_input->EC_buffer_index_left = c7_uv11[0];
        } else {
          guard75 = true;
        }
      } else {
        guard75 = true;
      }

      if (guard75 == true) {
        CV_EML_MCDC(0, 1, 28, false);
        CV_EML_IF(0, 1, 29, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 310);
      guard72 = false;
      guard73 = false;
      if (CV_EML_COND(0, 1, 110, CV_RELATIONAL_EVAL(4U, 0U, 105, (real_T)
            c7_data_struct_input->AngLShank_LPF[198], (real_T)
            c7_data_struct_input->AngLShank_LPF[197], -3, 4U,
            c7_data_struct_input->AngLShank_LPF[198] >
            c7_data_struct_input->AngLShank_LPF[197]))) {
        if (CV_EML_COND(0, 1, 111, CV_RELATIONAL_EVAL(4U, 0U, 106, (real_T)
              c7_data_struct_input->AngLShank_LPF[198], (real_T)
              c7_data_struct_input->AngLShank_LPF[199], -3, 5U,
              c7_data_struct_input->AngLShank_LPF[198] >=
              c7_data_struct_input->AngLShank_LPF[199]))) {
          if (CV_EML_COND(0, 1, 112, CV_RELATIONAL_EVAL(4U, 0U, 107, (real_T)
                c7_data_struct_input->AngLShank_LPF[198], (real_T)
                c7_data_struct_input->MA_LPF_th_left, -3, 5U,
                c7_data_struct_input->AngLShank_LPF[198] >=
                c7_data_struct_input->MA_LPF_th_left))) {
            CV_EML_MCDC(0, 1, 29, true);
            CV_EML_IF(0, 1, 30, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 311);
            c7_data_struct_input->MA_LPF_maxs_left[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 20547, 71, MAX_uint32_T, (int32_T)
              c7_data_struct_input->MA_LPF_index_left, 1, 5) - 1] =
              c7_data_struct_input->AngLShank_LPF[198];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 312);
            c7_u33 = (uint32_T)c7_data_struct_input->MA_LPF_index_left + 1U;
            if (CV_SATURATION_EVAL(4, 0, 21, 0, c7_u33 > 255U)) {
              c7_u33 = 255U;
            }

            c7_data_struct_input->MA_LPF_index_left = (uint8_T)c7_u33;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 313);
            c7_uv12[0] = c7_data_struct_input->MA_LPF_index_left;
            c7_b33 = ((real_T)c7_data_struct_input->MA_LPF_index_left > 5.0);
            c7_m_trueCount = 0;
            c7_cb_i = 0;
            while (c7_cb_i <= 0) {
              if (c7_b33) {
                c7_m_trueCount++;
              }

              c7_cb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_m_partialTrueCount = 0;
            c7_db_i = 0;
            while (c7_db_i <= 0) {
              if (c7_b33) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_m_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i341 = c7_tmp_sizes[0];
                c7_i342 = c7_tmp_sizes[1];
                c7_m_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i343 = 0; c7_i343 <= c7_m_loop_ub; c7_i343++) {
                  c7_tmp_data[c7_i343] = 1U;
                }

                c7_uv12[c7_db_i] = c7_tmp_data[c7_m_partialTrueCount];
                c7_m_partialTrueCount++;
              }

              c7_db_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->MA_LPF_index_left = c7_uv12[0];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 315);
            for (c7_i344 = 0; c7_i344 < 5; c7_i344++) {
              c7_bv4[c7_i344] = (c7_data_struct_input->MA_LPF_maxs_left[c7_i344]
                                 > -1.0E+6F);
            }

            c7_n_trueCount = 0;
            c7_eb_i = 0;
            while (c7_eb_i <= 4) {
              if (c7_bv4[c7_eb_i]) {
                c7_n_trueCount++;
              }

              c7_eb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_n_trueCount;
            c7_n_partialTrueCount = 0;
            c7_fb_i = 0;
            while (c7_fb_i <= 4) {
              if (c7_bv4[c7_fb_i]) {
                c7_c_tmp_data[c7_n_partialTrueCount] = c7_fb_i + 1;
                c7_n_partialTrueCount++;
              }

              c7_fb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_data_struct_input_sizes[0] = 1;
            c7_c_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_r_data_struct_input = c7_c_data_struct_input_sizes[0];
            c7_s_data_struct_input = c7_c_data_struct_input_sizes[1];
            c7_n_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i345 = 0; c7_i345 <= c7_n_loop_ub; c7_i345++) {
              c7_c_data_struct_input_data[c7_i345] =
                c7_data_struct_input->MA_LPF_maxs_left[c7_c_tmp_data[c7_i345] -
                1];
            }

            c7_qc_b = c7_std(chartInstance, c7_c_data_struct_input_data,
                             c7_c_data_struct_input_sizes);
            c7_qc_y = 5.0F * c7_qc_b;
            c7_d_data_struct_input_sizes[0] = 1;
            c7_d_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_t_data_struct_input = c7_d_data_struct_input_sizes[0];
            c7_u_data_struct_input = c7_d_data_struct_input_sizes[1];
            c7_o_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i346 = 0; c7_i346 <= c7_o_loop_ub; c7_i346++) {
              c7_d_data_struct_input_data[c7_i346] =
                c7_data_struct_input->MA_LPF_maxs_left[c7_c_tmp_data[c7_i346] -
                1];
            }

            c7_data_struct_input->MA_LPF_th_left = c7_b_mean(chartInstance,
              c7_d_data_struct_input_data, c7_d_data_struct_input_sizes) -
              c7_qc_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 318);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 319);
            c7_index = 1.0;
            _SFD_SYMBOL_SWITCH(2U, 2U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 320);
            exitg32 = false;
            while ((exitg32 == false) && (c7_found == 0.0)) {
              if (c7_index < (real_T)c7_left_limit) {
                CV_EML_WHILE(0, 1, 0, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 321);
                c7_f1 = c7_data_struct_input->
                  AngLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 21213, 43,
                   MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                c7_f2 = c7_data_struct_input->
                  AngLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 21257, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) + 1.0), 1, 200) -
                  1];
                guard74 = false;
                if (CV_EML_COND(0, 1, 113, CV_RELATIONAL_EVAL(4U, 0U, 108,
                      (real_T)c7_f1, (real_T)c7_f2, -3, 4U, c7_f1 > c7_f2))) {
                  c7_f3 = c7_data_struct_input->
                    AngLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 21306,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  c7_f4 = c7_data_struct_input->
                    AngLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 21351,
                     45, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  if (CV_EML_COND(0, 1, 114, CV_RELATIONAL_EVAL(4U, 0U, 109,
                        (real_T)c7_f3, (real_T)c7_f4, -3, 5U, c7_f3 >= c7_f4)))
                  {
                    CV_EML_MCDC(0, 1, 30, true);
                    CV_EML_IF(0, 1, 31, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 322);
                    c7_data_struct_input->MA_maxs_left[(uint8_T)
                      sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                      chartInstance->S, 5U, 21414, 63, MAX_uint32_T, (int32_T)
                      c7_data_struct_input->MA_index_left, 1, 5) - 1] =
                      c7_data_struct_input->
                      AngLShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 21478,
                       43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) -
                      1];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 323);
                    c7_u34 = (uint32_T)c7_data_struct_input->MA_index_left + 1U;
                    if (CV_SATURATION_EVAL(4, 0, 22, 0, c7_u34 > 255U)) {
                      c7_u34 = 255U;
                    }

                    c7_data_struct_input->MA_index_left = (uint8_T)c7_u34;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 324);
                    c7_uv13[0] = c7_data_struct_input->MA_index_left;
                    c7_b34 = ((real_T)c7_data_struct_input->MA_index_left > 5.0);
                    c7_o_trueCount = 0;
                    c7_gb_i = 0;
                    while (c7_gb_i <= 0) {
                      if (c7_b34) {
                        c7_o_trueCount++;
                      }

                      c7_gb_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_o_partialTrueCount = 0;
                    c7_hb_i = 0;
                    while (c7_hb_i <= 0) {
                      if (c7_b34) {
                        c7_iv0[0] = 1;
                        c7_iv0[1] = c7_o_trueCount;
                        c7_tmp_sizes[0] = 1;
                        c7_tmp_sizes[1] = c7_iv0[1];
                        c7_i347 = c7_tmp_sizes[0];
                        c7_i348 = c7_tmp_sizes[1];
                        c7_p_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                        for (c7_i349 = 0; c7_i349 <= c7_p_loop_ub; c7_i349++) {
                          c7_tmp_data[c7_i349] = 1U;
                        }

                        c7_uv13[c7_hb_i] = c7_tmp_data[c7_o_partialTrueCount];
                        c7_o_partialTrueCount++;
                      }

                      c7_hb_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_data_struct_input->MA_index_left = c7_uv13[0];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 325);
                    c7_found = 1.0;
                  } else {
                    guard74 = true;
                  }
                } else {
                  guard74 = true;
                }

                if (guard74 == true) {
                  CV_EML_MCDC(0, 1, 30, false);
                  CV_EML_IF(0, 1, 31, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 327);
                c7_index++;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 320);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg32 = true;
              }
            }

            CV_EML_WHILE(0, 1, 0, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 330);
            for (c7_i350 = 0; c7_i350 < 5; c7_i350++) {
              c7_bv4[c7_i350] = (c7_data_struct_input->MA_maxs_left[c7_i350] >
                                 -1.0E+6F);
            }

            c7_p_trueCount = 0;
            c7_ib_i = 0;
            while (c7_ib_i <= 4) {
              if (c7_bv4[c7_ib_i]) {
                c7_p_trueCount++;
              }

              c7_ib_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_p_trueCount;
            c7_p_partialTrueCount = 0;
            c7_jb_i = 0;
            while (c7_jb_i <= 4) {
              if (c7_bv4[c7_jb_i]) {
                c7_c_tmp_data[c7_p_partialTrueCount] = c7_jb_i + 1;
                c7_p_partialTrueCount++;
              }

              c7_jb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_e_data_struct_input_sizes[0] = 1;
            c7_e_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_v_data_struct_input = c7_e_data_struct_input_sizes[0];
            c7_w_data_struct_input = c7_e_data_struct_input_sizes[1];
            c7_q_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i351 = 0; c7_i351 <= c7_q_loop_ub; c7_i351++) {
              c7_e_data_struct_input_data[c7_i351] =
                c7_data_struct_input->MA_maxs_left[c7_c_tmp_data[c7_i351] - 1];
            }

            c7_rc_b = c7_std(chartInstance, c7_e_data_struct_input_data,
                             c7_e_data_struct_input_sizes);
            c7_rc_y = 5.0F * c7_rc_b;
            c7_f_data_struct_input_sizes[0] = 1;
            c7_f_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_x_data_struct_input = c7_f_data_struct_input_sizes[0];
            c7_y_data_struct_input = c7_f_data_struct_input_sizes[1];
            c7_r_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i352 = 0; c7_i352 <= c7_r_loop_ub; c7_i352++) {
              c7_f_data_struct_input_data[c7_i352] =
                c7_data_struct_input->MA_maxs_left[c7_c_tmp_data[c7_i352] - 1];
            }

            c7_data_struct_input->MA_th_left = c7_b_mean(chartInstance,
              c7_f_data_struct_input_data, c7_f_data_struct_input_sizes) -
              c7_rc_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 333);
            c7_data_struct_input->MA_flag_left = true;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 334);
            for (c7_i353 = 0; c7_i353 < 5; c7_i353++) {
              c7_bv4[c7_i353] = (c7_data_struct_input->MA_maxs_left[c7_i353] >
                                 -1.0E+6F);
            }

            c7_q_trueCount = 0;
            c7_kb_i = 0;
            while (c7_kb_i <= 4) {
              if (c7_bv4[c7_kb_i]) {
                c7_q_trueCount++;
              }

              c7_kb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_q_trueCount;
            c7_q_partialTrueCount = 0;
            c7_lb_i = 0;
            while (c7_lb_i <= 4) {
              if (c7_bv4[c7_lb_i]) {
                c7_c_tmp_data[c7_q_partialTrueCount] = c7_lb_i + 1;
                c7_q_partialTrueCount++;
              }

              c7_lb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_g_data_struct_input_sizes[0] = 1;
            c7_g_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_ab_data_struct_input = c7_g_data_struct_input_sizes[0];
            c7_bb_data_struct_input = c7_g_data_struct_input_sizes[1];
            c7_s_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i354 = 0; c7_i354 <= c7_s_loop_ub; c7_i354++) {
              c7_g_data_struct_input_data[c7_i354] =
                c7_data_struct_input->MA_maxs_left[c7_c_tmp_data[c7_i354] - 1];
            }

            c7_A = c7_b_mean(chartInstance, c7_g_data_struct_input_data,
                             c7_g_data_struct_input_sizes);
            c7_sc_y = c7_b_rdivide(chartInstance, c7_A, 3.0);
            c7_data_struct_input->stop_MA_th_left = c7_sc_y;
          } else {
            guard72 = true;
          }
        } else {
          guard73 = true;
        }
      } else {
        guard73 = true;
      }

      if (guard73 == true) {
        guard72 = true;
      }

      if (guard72 == true) {
        CV_EML_MCDC(0, 1, 29, false);
        CV_EML_IF(0, 1, 30, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 338);
      guard64 = false;
      guard65 = false;
      if (CV_EML_COND(0, 1, 115, CV_RELATIONAL_EVAL(4U, 0U, 110, (real_T)
            c7_data_struct_input->AngLShank_LPF[198], 0.0, -1, 5U,
            c7_data_struct_input->AngLShank_LPF[198] >= 0.0F))) {
        if (CV_EML_COND(0, 1, 116, CV_RELATIONAL_EVAL(4U, 0U, 111, (real_T)
              c7_data_struct_input->AngLShank_LPF[199], 0.0, -1, 3U,
              c7_data_struct_input->AngLShank_LPF[199] <= 0.0F))) {
          if (CV_EML_COND(0, 1, 117, c7_data_struct_input->MA_flag_left)) {
            CV_EML_MCDC(0, 1, 31, true);
            CV_EML_IF(0, 1, 32, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 339);
            c7_data_struct_input->MA_flag_left = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 341);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 342);
            c7_MS_inds_left = 0.0;
            _SFD_SYMBOL_SWITCH(3U, 3U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 344);
            c7_index = 0.0;
            _SFD_SYMBOL_SWITCH(2U, 2U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 345);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 346);
            exitg31 = false;
            while ((exitg31 == false) && (c7_index < (real_T)c7_left_limit)) {
              if (c7_found == 0.0) {
                CV_EML_WHILE(0, 1, 1, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 347);
                c7_d9 = c7_data_struct_input->
                  AngLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 22690, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1, 200) -
                  1];
                guard71 = false;
                if (CV_EML_COND(0, 1, 118, CV_RELATIONAL_EVAL(4U, 0U, 114, c7_d9,
                      0.0, -1, 5U, c7_d9 >= 0.0))) {
                  c7_d10 = c7_data_struct_input->
                    AngLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 22742,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  if (CV_EML_COND(0, 1, 119, CV_RELATIONAL_EVAL(4U, 0U, 115,
                        c7_d10, 0.0, -1, 2U, c7_d10 < 0.0))) {
                    CV_EML_MCDC(0, 1, 32, true);
                    CV_EML_IF(0, 1, 33, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 348);
                    c7_MS_inds_left = c7_index;
                    _SFD_SYMBOL_SWITCH(3U, 3U);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 349);
                    c7_found = 1.0;
                  } else {
                    guard71 = true;
                  }
                } else {
                  guard71 = true;
                }

                if (guard71 == true) {
                  CV_EML_MCDC(0, 1, 32, false);
                  CV_EML_IF(0, 1, 33, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 351);
                c7_index++;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 346);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg31 = true;
              }
            }

            CV_EML_WHILE(0, 1, 1, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 355);
            c7_index = c7_MS_inds_left;
            _SFD_SYMBOL_SWITCH(2U, 2U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 356);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 357);
            c7_EC_events_inds_left = 0.0;
            _SFD_SYMBOL_SWITCH(4U, 4U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 358);
            c7_EC_distance_left = 0.0;
            _SFD_SYMBOL_SWITCH(5U, 5U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 359);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 361);
            exitg30 = false;
            while ((exitg30 == false) && (c7_index < (real_T)c7_left_limit)) {
              if (c7_found == 0.0) {
                CV_EML_WHILE(0, 1, 2, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 362);
                c7_f5 = c7_data_struct_input->
                  VelLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 23222, 43,
                   MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                c7_f6 = c7_data_struct_input->
                  VelLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 23266, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) + 1.0), 1, 200) -
                  1];
                guard69 = false;
                guard70 = false;
                if (CV_EML_COND(0, 1, 120, CV_RELATIONAL_EVAL(4U, 0U, 116,
                      (real_T)c7_f5, (real_T)c7_f6, -3, 2U, c7_f5 < c7_f6))) {
                  c7_f7 = c7_data_struct_input->
                    VelLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 23315,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  c7_f8 = c7_data_struct_input->
                    VelLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 23359,
                     45, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  if (CV_EML_COND(0, 1, 121, CV_RELATIONAL_EVAL(4U, 0U, 117,
                        (real_T)c7_f7, (real_T)c7_f8, -3, 2U, c7_f7 < c7_f8))) {
                    c7_d11 = c7_data_struct_input->
                      VelLShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 23408,
                       43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) -
                      1];
                    if (CV_EML_COND(0, 1, 122, CV_RELATIONAL_EVAL(4U, 0U, 118,
                          c7_d11, 0.0, -1, 2U, c7_d11 < 0.0))) {
                      CV_EML_MCDC(0, 1, 33, true);
                      CV_EML_IF(0, 1, 34, true);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 363);
                      c7_data_struct_input->EC_events_mins_left[(uint8_T)
                        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                        chartInstance->S, 5U, 23471, 77, MAX_uint32_T, (int32_T)
                        c7_data_struct_input->EC_events_index_left, 1, 5) - 1] =
                        c7_data_struct_input->
                        VelLShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         23549, 43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1,
                         200) - 1];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 364);
                      c7_EC_events_inds_left = c7_index;
                      _SFD_SYMBOL_SWITCH(4U, 4U);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 365);
                      c7_EC_distance_left = c7_index - c7_MS_inds_left;
                      _SFD_SYMBOL_SWITCH(5U, 5U);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 366);
                      c7_data_struct_input->AN_events_left[(uint8_T)
                        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                        chartInstance->S, 5U, 23794, 72, MAX_uint32_T, (int32_T)
                        c7_data_struct_input->EC_events_index_left, 1, 5) - 1] =
                        c7_data_struct_input->
                        AngLShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         23867, 43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1,
                         200) - 1];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 367);
                      c7_u35 = (uint32_T)
                        c7_data_struct_input->EC_events_index_left + 1U;
                      if (CV_SATURATION_EVAL(4, 0, 23, 0, c7_u35 > 255U)) {
                        c7_u35 = 255U;
                      }

                      c7_data_struct_input->EC_events_index_left = (uint8_T)
                        c7_u35;
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 368);
                      c7_uv14[0] = c7_data_struct_input->EC_events_index_left;
                      c7_b35 = ((real_T)
                                c7_data_struct_input->EC_events_index_left > 5.0);
                      c7_r_trueCount = 0;
                      c7_mb_i = 0;
                      while (c7_mb_i <= 0) {
                        if (c7_b35) {
                          c7_r_trueCount++;
                        }

                        c7_mb_i++;
                        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                      }

                      c7_r_partialTrueCount = 0;
                      c7_nb_i = 0;
                      while (c7_nb_i <= 0) {
                        if (c7_b35) {
                          c7_iv0[0] = 1;
                          c7_iv0[1] = c7_r_trueCount;
                          c7_tmp_sizes[0] = 1;
                          c7_tmp_sizes[1] = c7_iv0[1];
                          c7_i355 = c7_tmp_sizes[0];
                          c7_i356 = c7_tmp_sizes[1];
                          c7_t_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                          for (c7_i357 = 0; c7_i357 <= c7_t_loop_ub; c7_i357++)
                          {
                            c7_tmp_data[c7_i357] = 1U;
                          }

                          c7_uv14[c7_nb_i] = c7_tmp_data[c7_r_partialTrueCount];
                          c7_r_partialTrueCount++;
                        }

                        c7_nb_i++;
                        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                      }

                      c7_data_struct_input->EC_events_index_left = c7_uv14[0];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 369);
                      c7_found = 1.0;
                    } else {
                      guard69 = true;
                    }
                  } else {
                    guard70 = true;
                  }
                } else {
                  guard70 = true;
                }

                if (guard70 == true) {
                  guard69 = true;
                }

                if (guard69 == true) {
                  CV_EML_MCDC(0, 1, 33, false);
                  CV_EML_IF(0, 1, 34, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 371);
                c7_index++;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 361);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg30 = true;
              }
            }

            CV_EML_WHILE(0, 1, 2, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 373);
            for (c7_i358 = 0; c7_i358 < 50; c7_i358++) {
              c7_EC_peaks[c7_i358] = -2.0E+6;
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 374);
            for (c7_i359 = 0; c7_i359 < 50; c7_i359++) {
              c7_AN_peaks[c7_i359] = 2.0E+6;
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 375);
            c7_EC_peaks_index = 1.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 376);
            if (CV_EML_IF(0, 1, 35, CV_RELATIONAL_EVAL(4U, 0U, 119, c7_found,
                  1.0, -1, 0U, c7_found == 1.0))) {
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 377);
              c7_found = 0.0;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 379);
              c7_d12 = c7_EC_events_inds_left + 1.0;
              c7_d13 = c7_EC_events_inds_left + c7_EC_distance_left;
              c7_i360 = (int32_T)(c7_d13 + (1.0 - c7_d12)) - 1;
              c7_c_index = 0;
              while (c7_c_index <= c7_i360) {
                c7_index = c7_d12 + (real_T)c7_c_index;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                CV_EML_FOR(0, 1, 0, 1);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 380);
                c7_f9 = c7_data_struct_input->
                  VelLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 24492, 43,
                   MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                c7_f10 = c7_data_struct_input->
                  VelLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 24536, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) + 1.0), 1, 200) -
                  1];
                guard67 = false;
                guard68 = false;
                if (CV_EML_COND(0, 1, 123, CV_RELATIONAL_EVAL(4U, 0U, 120,
                      (real_T)c7_f9, (real_T)c7_f10, -3, 2U, c7_f9 < c7_f10))) {
                  c7_f11 = c7_data_struct_input->
                    VelLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 24585,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  c7_f12 = c7_data_struct_input->
                    VelLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 24629,
                     45, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  if (CV_EML_COND(0, 1, 124, CV_RELATIONAL_EVAL(4U, 0U, 121,
                        (real_T)c7_f11, (real_T)c7_f12, -3, 2U, c7_f11 < c7_f12)))
                  {
                    c7_d14 = c7_data_struct_input->
                      VelLShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 24678,
                       43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) -
                      1];
                    if (CV_EML_COND(0, 1, 125, CV_RELATIONAL_EVAL(4U, 0U, 122,
                          c7_d14, 0.0, -1, 2U, c7_d14 < 0.0))) {
                      CV_EML_MCDC(0, 1, 34, true);
                      CV_EML_IF(0, 1, 36, true);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 381);
                      c7_EC_peaks[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         24745, 24, 0U, (int32_T)c7_EC_peaks_index, 1, 50) - 1] =
                        c7_data_struct_input->
                        VelLShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         24770, 43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1,
                         200) - 1];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 382);
                      c7_AN_peaks[(int32_T)c7_EC_peaks_index - 1] =
                        c7_data_struct_input->
                        AngLShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         24860, 43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1,
                         200) - 1];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 383);
                      c7_EC_peaks_index++;
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 384);
                      c7_dv2[0] = c7_EC_peaks_index;
                      c7_s_trueCount = 0;
                      c7_ob_i = 0;
                      while (c7_ob_i <= 0) {
                        if (c7_EC_peaks_index > 50.0) {
                          c7_s_trueCount++;
                        }

                        c7_ob_i++;
                        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                      }

                      c7_s_partialTrueCount = 0;
                      c7_pb_i = 0;
                      while (c7_pb_i <= 0) {
                        if (c7_EC_peaks_index > 50.0) {
                          c7_iv0[0] = 1;
                          c7_iv0[1] = c7_s_trueCount;
                          c7_d_tmp_sizes[0] = 1;
                          c7_d_tmp_sizes[1] = c7_iv0[1];
                          c7_i361 = c7_d_tmp_sizes[0];
                          c7_i362 = c7_d_tmp_sizes[1];
                          c7_u_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                          for (c7_i363 = 0; c7_i363 <= c7_u_loop_ub; c7_i363++)
                          {
                            c7_d_tmp_data[c7_i363] = 50.0;
                          }

                          c7_dv2[c7_pb_i] = c7_d_tmp_data[c7_s_partialTrueCount];
                          c7_s_partialTrueCount++;
                        }

                        c7_pb_i++;
                        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                      }

                      c7_EC_peaks_index = c7_dv2[0];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 385);
                      c7_found = 1.0;
                    } else {
                      guard67 = true;
                    }
                  } else {
                    guard68 = true;
                  }
                } else {
                  guard68 = true;
                }

                if (guard68 == true) {
                  guard67 = true;
                }

                if (guard67 == true) {
                  CV_EML_MCDC(0, 1, 34, false);
                  CV_EML_IF(0, 1, 36, false);
                }

                c7_c_index++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              CV_EML_FOR(0, 1, 0, 0);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 389);
              if (CV_EML_IF(0, 1, 37, CV_RELATIONAL_EVAL(4U, 0U, 123, c7_found,
                    0.0, -1, 0U, c7_found == 0.0))) {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 390);
                c7_f13 = c7_data_struct_input->
                  VelLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 25344, 74,
                   MAX_uint32_T, (int32_T)((200.0 - c7_EC_events_inds_left) -
                    c7_EC_distance_left), 1, 200) - 1] + 1.0F;
                c7_b_sign(chartInstance, &c7_f13);
                c7_b_A = -c7_f13;
                c7_tc_y = c7_b_rdivide(chartInstance, c7_b_A, 2.0);
                c7_EC_peaks[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 25237, 24,
                   0U, (int32_T)c7_EC_peaks_index, 1, 50) - 1] =
                  c7_data_struct_input->VelLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 25262, 74,
                   MAX_uint32_T, (int32_T)((200.0 - c7_EC_events_inds_left) -
                    c7_EC_distance_left), 1, 200) - 1] * c7_tc_y;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 391);
                c7_AN_peaks[(int32_T)c7_EC_peaks_index - 1] =
                  c7_data_struct_input->AngLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 25467, 74,
                   MAX_uint32_T, (int32_T)((200.0 - c7_EC_events_inds_left) -
                    c7_EC_distance_left), 1, 200) - 1];
              }
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 395);
            c7_t_trueCount = 0;
            c7_qb_i = 0;
            while (c7_qb_i <= 49) {
              if (c7_EC_peaks[c7_qb_i] > -1.0E+6) {
                c7_t_trueCount++;
              }

              c7_qb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_e_tmp_sizes = c7_t_trueCount;
            c7_t_partialTrueCount = 0;
            c7_rb_i = 0;
            while (c7_rb_i <= 49) {
              if (c7_EC_peaks[c7_rb_i] > -1.0E+6) {
                c7_e_tmp_data[c7_t_partialTrueCount] = c7_rb_i + 1;
                c7_t_partialTrueCount++;
              }

              c7_rb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_EC_peaks_sizes = c7_e_tmp_sizes;
            c7_v_loop_ub = c7_e_tmp_sizes - 1;
            for (c7_i364 = 0; c7_i364 <= c7_v_loop_ub; c7_i364++) {
              c7_EC_peaks_data[c7_i364] = c7_EC_peaks[c7_e_tmp_data[c7_i364] - 1];
            }

            c7_data_struct_input->EC_peaks_mins_left[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 25588, 75, MAX_uint32_T, (int32_T)
              c7_data_struct_input->EC_peaks_index_left, 1, 5) - 1] = (real32_T)
              c7_c_mean(chartInstance, c7_EC_peaks_data, c7_EC_peaks_sizes);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 396);
            for (c7_i365 = 0; c7_i365 < 50; c7_i365++) {
              c7_b_varargin_1[c7_i365] = c7_AN_peaks[c7_i365];
            }

            c7_ixstart = 1;
            c7_c_mtmp = c7_b_varargin_1[0];
            c7_x = c7_c_mtmp;
            c7_sc_b = muDoubleScalarIsNaN(c7_x);
            if (c7_sc_b) {
              c7_ix = 2;
              exitg29 = false;
              while ((exitg29 == false) && (c7_ix < 51)) {
                c7_b_ix = c7_ix - 1;
                c7_ixstart = c7_b_ix + 1;
                c7_b_x = c7_b_varargin_1[c7_b_ix];
                c7_tc_b = muDoubleScalarIsNaN(c7_b_x);
                if (!c7_tc_b) {
                  c7_c_mtmp = c7_b_varargin_1[c7_b_ix];
                  exitg29 = true;
                } else {
                  c7_ix++;
                }
              }
            }

            if (c7_ixstart < 50) {
              c7_i366 = c7_ixstart;
              for (c7_c_ix = c7_i366 + 1; c7_c_ix < 51; c7_c_ix++) {
                c7_b_ix = c7_c_ix - 1;
                c7_b_a = c7_b_varargin_1[c7_b_ix];
                c7_uc_b = c7_c_mtmp;
                c7_b_p = (c7_b_a < c7_uc_b);
                if (c7_b_p) {
                  c7_c_mtmp = c7_b_varargin_1[c7_b_ix];
                }
              }
            }

            c7_d_mtmp = c7_c_mtmp;
            c7_minval = c7_d_mtmp;
            c7_data_struct_input->AN_peaks_left[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 25703, 70, MAX_uint32_T, (int32_T)
              c7_data_struct_input->EC_peaks_index_left, 1, 5) - 1] = (real32_T)
              c7_minval;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 397);
            c7_u36 = (uint32_T)c7_data_struct_input->EC_peaks_index_left + 1U;
            if (CV_SATURATION_EVAL(4, 0, 24, 0, c7_u36 > 255U)) {
              c7_u36 = 255U;
            }

            c7_data_struct_input->EC_peaks_index_left = (uint8_T)c7_u36;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 398);
            c7_uv15[0] = c7_data_struct_input->EC_peaks_index_left;
            c7_b36 = ((real_T)c7_data_struct_input->EC_peaks_index_left > 5.0);
            c7_u_trueCount = 0;
            c7_sb_i = 0;
            while (c7_sb_i <= 0) {
              if (c7_b36) {
                c7_u_trueCount++;
              }

              c7_sb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_u_partialTrueCount = 0;
            c7_tb_i = 0;
            while (c7_tb_i <= 0) {
              if (c7_b36) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_u_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i367 = c7_tmp_sizes[0];
                c7_i368 = c7_tmp_sizes[1];
                c7_w_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i369 = 0; c7_i369 <= c7_w_loop_ub; c7_i369++) {
                  c7_tmp_data[c7_i369] = 1U;
                }

                c7_uv15[c7_tb_i] = c7_tmp_data[c7_u_partialTrueCount];
                c7_u_partialTrueCount++;
              }

              c7_tb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->EC_peaks_index_left = c7_uv15[0];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 400);
            for (c7_i370 = 0; c7_i370 < 5; c7_i370++) {
              c7_bv4[c7_i370] = (c7_data_struct_input->
                                 EC_events_mins_left[c7_i370] > -1.0E+6F);
            }

            for (c7_i371 = 0; c7_i371 < 5; c7_i371++) {
              c7_bv5[c7_i371] = (c7_data_struct_input->
                                 EC_peaks_mins_left[c7_i371] > -1.0E+6F);
            }

            c7_v_trueCount = 0;
            c7_ub_i = 0;
            while (c7_ub_i <= 4) {
              if (c7_bv4[c7_ub_i]) {
                c7_v_trueCount++;
              }

              c7_ub_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_v_trueCount;
            c7_v_partialTrueCount = 0;
            c7_vb_i = 0;
            while (c7_vb_i <= 4) {
              if (c7_bv4[c7_vb_i]) {
                c7_c_tmp_data[c7_v_partialTrueCount] = c7_vb_i + 1;
                c7_v_partialTrueCount++;
              }

              c7_vb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_w_trueCount = 0;
            c7_wb_i = 0;
            while (c7_wb_i <= 4) {
              if (c7_bv5[c7_wb_i]) {
                c7_w_trueCount++;
              }

              c7_wb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_f_tmp_sizes[0] = 1;
            c7_f_tmp_sizes[1] = c7_w_trueCount;
            c7_w_partialTrueCount = 0;
            c7_xb_i = 0;
            while (c7_xb_i <= 4) {
              if (c7_bv5[c7_xb_i]) {
                c7_f_tmp_data[c7_w_partialTrueCount] = c7_xb_i + 1;
                c7_w_partialTrueCount++;
              }

              c7_xb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_h_data_struct_input_sizes[0] = 1;
            c7_h_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_cb_data_struct_input = c7_h_data_struct_input_sizes[0];
            c7_db_data_struct_input = c7_h_data_struct_input_sizes[1];
            c7_x_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i372 = 0; c7_i372 <= c7_x_loop_ub; c7_i372++) {
              c7_h_data_struct_input_data[c7_i372] =
                c7_data_struct_input->EC_events_mins_left[c7_c_tmp_data[c7_i372]
                - 1];
            }

            c7_i_data_struct_input_sizes[0] = 1;
            c7_i_data_struct_input_sizes[1] = c7_f_tmp_sizes[1];
            c7_eb_data_struct_input = c7_i_data_struct_input_sizes[0];
            c7_fb_data_struct_input = c7_i_data_struct_input_sizes[1];
            c7_y_loop_ub = c7_f_tmp_sizes[0] * c7_f_tmp_sizes[1] - 1;
            for (c7_i373 = 0; c7_i373 <= c7_y_loop_ub; c7_i373++) {
              c7_i_data_struct_input_data[c7_i373] =
                c7_data_struct_input->EC_peaks_mins_left[c7_f_tmp_data[c7_i373]
                - 1];
            }

            c7_c_A = c7_b_mean(chartInstance, c7_h_data_struct_input_data,
                               c7_h_data_struct_input_sizes) + c7_b_mean
              (chartInstance, c7_i_data_struct_input_data,
               c7_i_data_struct_input_sizes);
            c7_uc_y = c7_b_rdivide(chartInstance, c7_c_A, 2.0);
            c7_data_struct_input->EC_th_left = c7_uc_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 401);
            for (c7_i374 = 0; c7_i374 < 5; c7_i374++) {
              c7_bv4[c7_i374] = (c7_data_struct_input->AN_events_left[c7_i374] >
                                 -1.0E+6F);
            }

            for (c7_i375 = 0; c7_i375 < 5; c7_i375++) {
              c7_bv5[c7_i375] = (c7_data_struct_input->AN_peaks_left[c7_i375] >
                                 -1.0E+6F);
            }

            c7_x_trueCount = 0;
            c7_yb_i = 0;
            while (c7_yb_i <= 4) {
              if (c7_bv4[c7_yb_i]) {
                c7_x_trueCount++;
              }

              c7_yb_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_x_trueCount;
            c7_x_partialTrueCount = 0;
            c7_ac_i = 0;
            while (c7_ac_i <= 4) {
              if (c7_bv4[c7_ac_i]) {
                c7_c_tmp_data[c7_x_partialTrueCount] = c7_ac_i + 1;
                c7_x_partialTrueCount++;
              }

              c7_ac_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_y_trueCount = 0;
            c7_bc_i = 0;
            while (c7_bc_i <= 4) {
              if (c7_bv5[c7_bc_i]) {
                c7_y_trueCount++;
              }

              c7_bc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_f_tmp_sizes[0] = 1;
            c7_f_tmp_sizes[1] = c7_y_trueCount;
            c7_y_partialTrueCount = 0;
            c7_cc_i = 0;
            while (c7_cc_i <= 4) {
              if (c7_bv5[c7_cc_i]) {
                c7_f_tmp_data[c7_y_partialTrueCount] = c7_cc_i + 1;
                c7_y_partialTrueCount++;
              }

              c7_cc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_j_data_struct_input_sizes[0] = 1;
            c7_j_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_gb_data_struct_input = c7_j_data_struct_input_sizes[0];
            c7_hb_data_struct_input = c7_j_data_struct_input_sizes[1];
            c7_ab_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i376 = 0; c7_i376 <= c7_ab_loop_ub; c7_i376++) {
              c7_j_data_struct_input_data[c7_i376] =
                c7_data_struct_input->AN_events_left[c7_c_tmp_data[c7_i376] - 1];
            }

            c7_k_data_struct_input_sizes[0] = 1;
            c7_k_data_struct_input_sizes[1] = c7_f_tmp_sizes[1];
            c7_ib_data_struct_input = c7_k_data_struct_input_sizes[0];
            c7_jb_data_struct_input = c7_k_data_struct_input_sizes[1];
            c7_bb_loop_ub = c7_f_tmp_sizes[0] * c7_f_tmp_sizes[1] - 1;
            for (c7_i377 = 0; c7_i377 <= c7_bb_loop_ub; c7_i377++) {
              c7_k_data_struct_input_data[c7_i377] =
                c7_data_struct_input->AN_peaks_left[c7_f_tmp_data[c7_i377] - 1];
            }

            c7_d_A = c7_b_mean(chartInstance, c7_j_data_struct_input_data,
                               c7_j_data_struct_input_sizes) + c7_b_mean
              (chartInstance, c7_k_data_struct_input_data,
               c7_k_data_struct_input_sizes);
            c7_vc_y = c7_b_rdivide(chartInstance, c7_d_A, 2.0);
            c7_data_struct_input->AN_th_left = c7_vc_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 404);
            for (c7_i378 = 0; c7_i378 < 5; c7_i378++) {
              c7_bv4[c7_i378] = (c7_data_struct_input->
                                 EC_events_mins_left[c7_i378] > -1.0E+6F);
            }

            c7_ab_trueCount = 0;
            c7_dc_i = 0;
            while (c7_dc_i <= 4) {
              if (c7_bv4[c7_dc_i]) {
                c7_ab_trueCount++;
              }

              c7_dc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_ab_trueCount;
            c7_ab_partialTrueCount = 0;
            c7_ec_i = 0;
            while (c7_ec_i <= 4) {
              if (c7_bv4[c7_ec_i]) {
                c7_c_tmp_data[c7_ab_partialTrueCount] = c7_ec_i + 1;
                c7_ab_partialTrueCount++;
              }

              c7_ec_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_l_data_struct_input_sizes[0] = 1;
            c7_l_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_kb_data_struct_input = c7_l_data_struct_input_sizes[0];
            c7_lb_data_struct_input = c7_l_data_struct_input_sizes[1];
            c7_cb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i379 = 0; c7_i379 <= c7_cb_loop_ub; c7_i379++) {
              c7_l_data_struct_input_data[c7_i379] =
                c7_data_struct_input->EC_events_mins_left[c7_c_tmp_data[c7_i379]
                - 1];
            }

            c7_e_A = c7_b_mean(chartInstance, c7_l_data_struct_input_data,
                               c7_l_data_struct_input_sizes);
            c7_wc_y = c7_b_rdivide(chartInstance, c7_e_A, 3.0);
            c7_data_struct_input->stop_Vel_th_left = c7_wc_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 407);
            guard66 = false;
            if (CV_EML_COND(0, 1, 126, CV_RELATIONAL_EVAL(4U, 0U, 124, (real_T)
                  c7_data_struct_input->state, 1.0, 0, 0U,
                  c7_data_struct_input->state == 1))) {
              guard66 = true;
            } else if (CV_EML_COND(0, 1, MAX_int8_T, CV_RELATIONAL_EVAL(4U, 0U,
                         125, (real_T)c7_data_struct_input->state, 2.0, 0, 0U,
                         c7_data_struct_input->state == 2))) {
              guard66 = true;
            } else {
              CV_EML_MCDC(0, 1, 35, false);
              CV_EML_IF(0, 1, 38, false);
            }

            if (guard66 == true) {
              CV_EML_MCDC(0, 1, 35, true);
              CV_EML_IF(0, 1, 38, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 408);
              if (CV_EML_IF(0, 1, 39, CV_RELATIONAL_EVAL(4U, 0U, 126, (real_T)
                    c7_data_struct_input->IC_event_left, 0.0, -1, 4U, (real_T)
                    c7_data_struct_input->IC_event_left > 0.0))) {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 409);
                c7_data_struct_input->state = 4;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 410);
                c7_data_struct_input->IC_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 411);
                c7_data_struct_input->EC_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 412);
                c7_data_struct_input->AN_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 413);
                c7_data_struct_input->stop_Vel_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 414);
                c7_data_struct_input->stop_MA_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 415);
                c7_data_struct_input->stop_IC_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 416);
                c7_data_struct_input->last_IC = 1U;
              } else {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 418);
                c7_data_struct_input->state = 3;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 419);
                c7_data_struct_input->MS_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 420);
                c7_data_struct_input->MA_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 421);
                c7_data_struct_input->IC_event_left = false;
              }
            }
          } else {
            guard64 = true;
          }
        } else {
          guard65 = true;
        }
      } else {
        guard65 = true;
      }

      if (guard65 == true) {
        guard64 = true;
      }

      if (guard64 == true) {
        CV_EML_MCDC(0, 1, 31, false);
        CV_EML_IF(0, 1, 32, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 427);
      guard60 = false;
      guard61 = false;
      if (CV_EML_COND(0, 1, 128U, CV_RELATIONAL_EVAL(4U, 0U, 127, (real_T)
            c7_data_struct_input->AngLShank_LPF[198], (real_T)
            c7_data_struct_input->AngLShank_LPF[197], -3, 2U,
            c7_data_struct_input->AngLShank_LPF[198] <
            c7_data_struct_input->AngLShank_LPF[197]))) {
        if (CV_EML_COND(0, 1, 129U, CV_RELATIONAL_EVAL(4U, 0U, 128, (real_T)
              c7_data_struct_input->AngLShank_LPF[198], (real_T)
              c7_data_struct_input->AngLShank_LPF[199], -3, 3U,
              c7_data_struct_input->AngLShank_LPF[198] <=
              c7_data_struct_input->AngLShank_LPF[199]))) {
          if (CV_EML_COND(0, 1, 130U, CV_RELATIONAL_EVAL(4U, 0U, 129, (real_T)
                c7_data_struct_input->AngLShank_LPF[198], (real_T)
                c7_data_struct_input->IC_LPF_th_left, -3, 3U,
                c7_data_struct_input->AngLShank_LPF[198] <=
                c7_data_struct_input->IC_LPF_th_left))) {
            CV_EML_MCDC(0, 1, 36, true);
            CV_EML_IF(0, 1, 40, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 428);
            c7_data_struct_input->IC_LPF_mins_left[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 27859, 71, MAX_uint32_T, (int32_T)
              c7_data_struct_input->IC_LPF_index_left, 1, 5) - 1] =
              c7_data_struct_input->AngLShank_LPF[198];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 429);
            c7_u37 = (uint32_T)c7_data_struct_input->IC_LPF_index_left + 1U;
            if (CV_SATURATION_EVAL(4, 0, 25, 0, c7_u37 > 255U)) {
              c7_u37 = 255U;
            }

            c7_data_struct_input->IC_LPF_index_left = (uint8_T)c7_u37;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 430);
            c7_uv16[0] = c7_data_struct_input->IC_LPF_index_left;
            c7_b37 = ((real_T)c7_data_struct_input->IC_LPF_index_left > 5.0);
            c7_bb_trueCount = 0;
            c7_fc_i = 0;
            while (c7_fc_i <= 0) {
              if (c7_b37) {
                c7_bb_trueCount++;
              }

              c7_fc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_bb_partialTrueCount = 0;
            c7_gc_i = 0;
            while (c7_gc_i <= 0) {
              if (c7_b37) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_bb_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i380 = c7_tmp_sizes[0];
                c7_i381 = c7_tmp_sizes[1];
                c7_db_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i382 = 0; c7_i382 <= c7_db_loop_ub; c7_i382++) {
                  c7_tmp_data[c7_i382] = 1U;
                }

                c7_uv16[c7_gc_i] = c7_tmp_data[c7_bb_partialTrueCount];
                c7_bb_partialTrueCount++;
              }

              c7_gc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->IC_LPF_index_left = c7_uv16[0];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 432);
            for (c7_i383 = 0; c7_i383 < 5; c7_i383++) {
              c7_bv4[c7_i383] = (c7_data_struct_input->IC_LPF_mins_left[c7_i383]
                                 > -1.0E+6F);
            }

            c7_cb_trueCount = 0;
            c7_hc_i = 0;
            while (c7_hc_i <= 4) {
              if (c7_bv4[c7_hc_i]) {
                c7_cb_trueCount++;
              }

              c7_hc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_cb_trueCount;
            c7_cb_partialTrueCount = 0;
            c7_ic_i = 0;
            while (c7_ic_i <= 4) {
              if (c7_bv4[c7_ic_i]) {
                c7_c_tmp_data[c7_cb_partialTrueCount] = c7_ic_i + 1;
                c7_cb_partialTrueCount++;
              }

              c7_ic_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_m_data_struct_input_sizes[0] = 1;
            c7_m_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_mb_data_struct_input = c7_m_data_struct_input_sizes[0];
            c7_nb_data_struct_input = c7_m_data_struct_input_sizes[1];
            c7_eb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i384 = 0; c7_i384 <= c7_eb_loop_ub; c7_i384++) {
              c7_m_data_struct_input_data[c7_i384] =
                c7_data_struct_input->IC_LPF_mins_left[c7_c_tmp_data[c7_i384] -
                1];
            }

            c7_vc_b = c7_std(chartInstance, c7_m_data_struct_input_data,
                             c7_m_data_struct_input_sizes);
            c7_xc_y = 5.0F * c7_vc_b;
            c7_n_data_struct_input_sizes[0] = 1;
            c7_n_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_ob_data_struct_input = c7_n_data_struct_input_sizes[0];
            c7_pb_data_struct_input = c7_n_data_struct_input_sizes[1];
            c7_fb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i385 = 0; c7_i385 <= c7_fb_loop_ub; c7_i385++) {
              c7_n_data_struct_input_data[c7_i385] =
                c7_data_struct_input->IC_LPF_mins_left[c7_c_tmp_data[c7_i385] -
                1];
            }

            c7_data_struct_input->IC_LPF_th_left = c7_b_mean(chartInstance,
              c7_n_data_struct_input_data, c7_n_data_struct_input_sizes) +
              c7_xc_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 435);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 436);
            c7_index = 1.0;
            _SFD_SYMBOL_SWITCH(2U, 2U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 437);
            exitg28 = false;
            while ((exitg28 == false) && (c7_found == 0.0)) {
              if (c7_index < (real_T)c7_left_limit) {
                CV_EML_WHILE(0, 1, 3, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 438);
                c7_f14 = c7_data_struct_input->
                  AngLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 28507, 43,
                   MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                c7_f15 = c7_data_struct_input->
                  AngLShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 28551, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) + 1.0), 1, 200) -
                  1];
                guard63 = false;
                if (CV_EML_COND(0, 1, 131U, CV_RELATIONAL_EVAL(4U, 0U, 130,
                      (real_T)c7_f14, (real_T)c7_f15, -3, 2U, c7_f14 < c7_f15)))
                {
                  c7_f16 = c7_data_struct_input->
                    AngLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 28600,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  c7_f17 = c7_data_struct_input->
                    AngLShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 28645,
                     45, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  if (CV_EML_COND(0, 1, 132U, CV_RELATIONAL_EVAL(4U, 0U, 131,
                        (real_T)c7_f16, (real_T)c7_f17, -3, 3U, c7_f16 <= c7_f17)))
                  {
                    CV_EML_MCDC(0, 1, 37, true);
                    CV_EML_IF(0, 1, 41, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 439);
                    c7_data_struct_input->IC_mins_left[(uint8_T)
                      sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                      chartInstance->S, 5U, 28708, 63, MAX_uint32_T, (int32_T)
                      c7_data_struct_input->IC_index_left, 1, 5) - 1] =
                      c7_data_struct_input->
                      AngLShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 28772,
                       43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) -
                      1];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 440);
                    c7_u38 = (uint32_T)c7_data_struct_input->IC_index_left + 1U;
                    if (CV_SATURATION_EVAL(4, 0, 26, 0, c7_u38 > 255U)) {
                      c7_u38 = 255U;
                    }

                    c7_data_struct_input->IC_index_left = (uint8_T)c7_u38;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 441);
                    c7_uv17[0] = c7_data_struct_input->IC_index_left;
                    c7_b38 = ((real_T)c7_data_struct_input->IC_index_left > 5.0);
                    c7_db_trueCount = 0;
                    c7_jc_i = 0;
                    while (c7_jc_i <= 0) {
                      if (c7_b38) {
                        c7_db_trueCount++;
                      }

                      c7_jc_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_db_partialTrueCount = 0;
                    c7_kc_i = 0;
                    while (c7_kc_i <= 0) {
                      if (c7_b38) {
                        c7_iv0[0] = 1;
                        c7_iv0[1] = c7_db_trueCount;
                        c7_tmp_sizes[0] = 1;
                        c7_tmp_sizes[1] = c7_iv0[1];
                        c7_i386 = c7_tmp_sizes[0];
                        c7_i387 = c7_tmp_sizes[1];
                        c7_gb_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                        for (c7_i388 = 0; c7_i388 <= c7_gb_loop_ub; c7_i388++) {
                          c7_tmp_data[c7_i388] = 1U;
                        }

                        c7_uv17[c7_kc_i] = c7_tmp_data[c7_db_partialTrueCount];
                        c7_db_partialTrueCount++;
                      }

                      c7_kc_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_data_struct_input->IC_index_left = c7_uv17[0];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 442);
                    c7_found = 1.0;
                  } else {
                    guard63 = true;
                  }
                } else {
                  guard63 = true;
                }

                if (guard63 == true) {
                  CV_EML_MCDC(0, 1, 37, false);
                  CV_EML_IF(0, 1, 41, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 444);
                c7_index++;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 437);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg28 = true;
              }
            }

            CV_EML_WHILE(0, 1, 3, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 448);
            for (c7_i389 = 0; c7_i389 < 5; c7_i389++) {
              c7_bv4[c7_i389] = (c7_data_struct_input->IC_mins_left[c7_i389] >
                                 -1.0E+6F);
            }

            c7_eb_trueCount = 0;
            c7_lc_i = 0;
            while (c7_lc_i <= 4) {
              if (c7_bv4[c7_lc_i]) {
                c7_eb_trueCount++;
              }

              c7_lc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_eb_trueCount;
            c7_eb_partialTrueCount = 0;
            c7_mc_i = 0;
            while (c7_mc_i <= 4) {
              if (c7_bv4[c7_mc_i]) {
                c7_c_tmp_data[c7_eb_partialTrueCount] = c7_mc_i + 1;
                c7_eb_partialTrueCount++;
              }

              c7_mc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_o_data_struct_input_sizes[0] = 1;
            c7_o_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_qb_data_struct_input = c7_o_data_struct_input_sizes[0];
            c7_rb_data_struct_input = c7_o_data_struct_input_sizes[1];
            c7_hb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i390 = 0; c7_i390 <= c7_hb_loop_ub; c7_i390++) {
              c7_o_data_struct_input_data[c7_i390] =
                c7_data_struct_input->IC_mins_left[c7_c_tmp_data[c7_i390] - 1];
            }

            c7_wc_b = c7_std(chartInstance, c7_o_data_struct_input_data,
                             c7_o_data_struct_input_sizes);
            c7_yc_y = 5.0F * c7_wc_b;
            c7_p_data_struct_input_sizes[0] = 1;
            c7_p_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_sb_data_struct_input = c7_p_data_struct_input_sizes[0];
            c7_tb_data_struct_input = c7_p_data_struct_input_sizes[1];
            c7_ib_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i391 = 0; c7_i391 <= c7_ib_loop_ub; c7_i391++) {
              c7_p_data_struct_input_data[c7_i391] =
                c7_data_struct_input->IC_mins_left[c7_c_tmp_data[c7_i391] - 1];
            }

            c7_data_struct_input->IC_th_left = c7_b_mean(chartInstance,
              c7_p_data_struct_input_data, c7_p_data_struct_input_sizes) +
              c7_yc_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 449);
            for (c7_i392 = 0; c7_i392 < 5; c7_i392++) {
              c7_bv4[c7_i392] = (c7_data_struct_input->IC_mins_left[c7_i392] >
                                 -1.0E+6F);
            }

            c7_fb_trueCount = 0;
            c7_nc_i = 0;
            while (c7_nc_i <= 4) {
              if (c7_bv4[c7_nc_i]) {
                c7_fb_trueCount++;
              }

              c7_nc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_fb_trueCount;
            c7_fb_partialTrueCount = 0;
            c7_oc_i = 0;
            while (c7_oc_i <= 4) {
              if (c7_bv4[c7_oc_i]) {
                c7_c_tmp_data[c7_fb_partialTrueCount] = c7_oc_i + 1;
                c7_fb_partialTrueCount++;
              }

              c7_oc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_q_data_struct_input_sizes[0] = 1;
            c7_q_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_ub_data_struct_input = c7_q_data_struct_input_sizes[0];
            c7_vb_data_struct_input = c7_q_data_struct_input_sizes[1];
            c7_jb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i393 = 0; c7_i393 <= c7_jb_loop_ub; c7_i393++) {
              c7_q_data_struct_input_data[c7_i393] =
                c7_data_struct_input->IC_mins_left[c7_c_tmp_data[c7_i393] - 1];
            }

            c7_f_A = c7_b_mean(chartInstance, c7_q_data_struct_input_data,
                               c7_q_data_struct_input_sizes);
            c7_ad_y = c7_b_rdivide(chartInstance, c7_f_A, 3.0);
            c7_data_struct_input->stop_IC_th_left = c7_ad_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 451);
            guard62 = false;
            if (CV_EML_COND(0, 1, 133U, CV_RELATIONAL_EVAL(4U, 0U, 132, (real_T)
                  c7_data_struct_input->state, 3.0, 0, 0U,
                  c7_data_struct_input->state == 3))) {
              guard62 = true;
            } else if (CV_EML_COND(0, 1, 134U, CV_RELATIONAL_EVAL(4U, 0U, 133,
                         (real_T)c7_data_struct_input->state, 2.0, 0, 0U,
                         c7_data_struct_input->state == 2))) {
              guard62 = true;
            } else {
              CV_EML_MCDC(0, 1, 38, false);
              CV_EML_IF(0, 1, 42, false);
            }

            if (guard62 == true) {
              CV_EML_MCDC(0, 1, 38, true);
              CV_EML_IF(0, 1, 42, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 452);
              if (CV_EML_IF(0, 1, 43, CV_RELATIONAL_EVAL(4U, 0U, 134, (real_T)
                    c7_data_struct_input->EC_event_right, 0.0, -1, 4U, (real_T)
                    c7_data_struct_input->EC_event_right > 0.0))) {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 453);
                c7_data_struct_input->state = 5;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 454);
                c7_data_struct_input->EC_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 455);
                c7_data_struct_input->AN_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 456);
                c7_data_struct_input->last_EC = 1U;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 457);
                c7_data_struct_input->MS_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 458);
                c7_data_struct_input->MA_event_right = false;
              } else {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 460);
                c7_data_struct_input->state = 4;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 461);
                c7_data_struct_input->IC_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 462);
                c7_data_struct_input->EC_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 463);
                c7_data_struct_input->AN_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 464);
                c7_data_struct_input->stop_Vel_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 465);
                c7_data_struct_input->stop_MA_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 466);
                c7_data_struct_input->stop_IC_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 467);
                c7_data_struct_input->last_IC = 1U;
              }
            }
          } else {
            guard60 = true;
          }
        } else {
          guard61 = true;
        }
      } else {
        guard61 = true;
      }

      if (guard61 == true) {
        guard60 = true;
      }

      if (guard60 == true) {
        CV_EML_MCDC(0, 1, 36, false);
        CV_EML_IF(0, 1, 40, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 473);
      guard57 = false;
      guard58 = false;
      if (CV_EML_COND(0, 1, 135U, CV_RELATIONAL_EVAL(4U, 0U, 135, (real_T)
            c7_data_struct_input->AngRShank_LPF[198], (real_T)
            c7_data_struct_input->AngRShank_LPF[197], -3, 4U,
            c7_data_struct_input->AngRShank_LPF[198] >
            c7_data_struct_input->AngRShank_LPF[197]))) {
        if (CV_EML_COND(0, 1, 136U, CV_RELATIONAL_EVAL(4U, 0U, 136, (real_T)
              c7_data_struct_input->AngRShank_LPF[198], (real_T)
              c7_data_struct_input->AngRShank_LPF[199], -3, 5U,
              c7_data_struct_input->AngRShank_LPF[198] >=
              c7_data_struct_input->AngRShank_LPF[199]))) {
          if (CV_EML_COND(0, 1, 137U, CV_RELATIONAL_EVAL(4U, 0U, 137, (real_T)
                c7_data_struct_input->AngRShank_LPF[198], (real_T)
                c7_data_struct_input->MA_LPF_th_right, -3, 5U,
                c7_data_struct_input->AngRShank_LPF[198] >=
                c7_data_struct_input->MA_LPF_th_right))) {
            CV_EML_MCDC(0, 1, 39, true);
            CV_EML_IF(0, 1, 44, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 474);
            c7_data_struct_input->MA_LPF_maxs_right[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 30801, 73, MAX_uint32_T, (int32_T)
              c7_data_struct_input->MA_LPF_index_right, 1, 5) - 1] =
              c7_data_struct_input->AngRShank_LPF[198];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 475);
            c7_u39 = (uint32_T)c7_data_struct_input->MA_LPF_index_right + 1U;
            if (CV_SATURATION_EVAL(4, 0, 27, 0, c7_u39 > 255U)) {
              c7_u39 = 255U;
            }

            c7_data_struct_input->MA_LPF_index_right = (uint8_T)c7_u39;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 476);
            c7_uv18[0] = c7_data_struct_input->MA_LPF_index_right;
            c7_b39 = ((real_T)c7_data_struct_input->MA_LPF_index_right > 5.0);
            c7_gb_trueCount = 0;
            c7_pc_i = 0;
            while (c7_pc_i <= 0) {
              if (c7_b39) {
                c7_gb_trueCount++;
              }

              c7_pc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_gb_partialTrueCount = 0;
            c7_qc_i = 0;
            while (c7_qc_i <= 0) {
              if (c7_b39) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_gb_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i394 = c7_tmp_sizes[0];
                c7_i395 = c7_tmp_sizes[1];
                c7_kb_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i396 = 0; c7_i396 <= c7_kb_loop_ub; c7_i396++) {
                  c7_tmp_data[c7_i396] = 1U;
                }

                c7_uv18[c7_qc_i] = c7_tmp_data[c7_gb_partialTrueCount];
                c7_gb_partialTrueCount++;
              }

              c7_qc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->MA_LPF_index_right = c7_uv18[0];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 478);
            for (c7_i397 = 0; c7_i397 < 5; c7_i397++) {
              c7_bv4[c7_i397] = (c7_data_struct_input->MA_LPF_maxs_right[c7_i397]
                                 > -1.0E+6F);
            }

            c7_hb_trueCount = 0;
            c7_rc_i = 0;
            while (c7_rc_i <= 4) {
              if (c7_bv4[c7_rc_i]) {
                c7_hb_trueCount++;
              }

              c7_rc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_hb_trueCount;
            c7_hb_partialTrueCount = 0;
            c7_sc_i = 0;
            while (c7_sc_i <= 4) {
              if (c7_bv4[c7_sc_i]) {
                c7_c_tmp_data[c7_hb_partialTrueCount] = c7_sc_i + 1;
                c7_hb_partialTrueCount++;
              }

              c7_sc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_r_data_struct_input_sizes[0] = 1;
            c7_r_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_wb_data_struct_input = c7_r_data_struct_input_sizes[0];
            c7_xb_data_struct_input = c7_r_data_struct_input_sizes[1];
            c7_lb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i398 = 0; c7_i398 <= c7_lb_loop_ub; c7_i398++) {
              c7_r_data_struct_input_data[c7_i398] =
                c7_data_struct_input->MA_LPF_maxs_right[c7_c_tmp_data[c7_i398] -
                1];
            }

            c7_xc_b = c7_std(chartInstance, c7_r_data_struct_input_data,
                             c7_r_data_struct_input_sizes);
            c7_bd_y = 5.0F * c7_xc_b;
            c7_s_data_struct_input_sizes[0] = 1;
            c7_s_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_yb_data_struct_input = c7_s_data_struct_input_sizes[0];
            c7_ac_data_struct_input = c7_s_data_struct_input_sizes[1];
            c7_mb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i399 = 0; c7_i399 <= c7_mb_loop_ub; c7_i399++) {
              c7_s_data_struct_input_data[c7_i399] =
                c7_data_struct_input->MA_LPF_maxs_right[c7_c_tmp_data[c7_i399] -
                1];
            }

            c7_data_struct_input->MA_LPF_th_right = c7_b_mean(chartInstance,
              c7_s_data_struct_input_data, c7_s_data_struct_input_sizes) -
              c7_bd_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 481);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 482);
            c7_index = 1.0;
            _SFD_SYMBOL_SWITCH(2U, 2U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 483);
            exitg27 = false;
            while ((exitg27 == false) && (c7_found == 0.0)) {
              if (c7_index < (real_T)c7_left_limit) {
                CV_EML_WHILE(0, 1, 4, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 484);
                c7_f18 = c7_data_struct_input->
                  AngRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 31478, 43,
                   MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                c7_f19 = c7_data_struct_input->
                  AngRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 31522, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) + 1.0), 1, 200) -
                  1];
                guard59 = false;
                if (CV_EML_COND(0, 1, 138U, CV_RELATIONAL_EVAL(4U, 0U, 138,
                      (real_T)c7_f18, (real_T)c7_f19, -3, 4U, c7_f18 > c7_f19)))
                {
                  c7_f20 = c7_data_struct_input->
                    AngRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 31571,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  c7_f21 = c7_data_struct_input->
                    AngRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 31616,
                     45, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  if (CV_EML_COND(0, 1, 139U, CV_RELATIONAL_EVAL(4U, 0U, 139,
                        (real_T)c7_f20, (real_T)c7_f21, -3, 5U, c7_f20 >= c7_f21)))
                  {
                    CV_EML_MCDC(0, 1, 40, true);
                    CV_EML_IF(0, 1, 45, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 485);
                    c7_data_struct_input->MA_maxs_right[(uint8_T)
                      sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                      chartInstance->S, 5U, 31679, 65, MAX_uint32_T, (int32_T)
                      c7_data_struct_input->MA_index_right, 1, 5) - 1] =
                      c7_data_struct_input->
                      AngRShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 31745,
                       43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) -
                      1];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 486);
                    c7_u40 = (uint32_T)c7_data_struct_input->MA_index_right + 1U;
                    if (CV_SATURATION_EVAL(4, 0, 28, 0, c7_u40 > 255U)) {
                      c7_u40 = 255U;
                    }

                    c7_data_struct_input->MA_index_right = (uint8_T)c7_u40;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 487);
                    c7_uv19[0] = c7_data_struct_input->MA_index_right;
                    c7_b40 = ((real_T)c7_data_struct_input->MA_index_right > 5.0);
                    c7_ib_trueCount = 0;
                    c7_tc_i = 0;
                    while (c7_tc_i <= 0) {
                      if (c7_b40) {
                        c7_ib_trueCount++;
                      }

                      c7_tc_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_ib_partialTrueCount = 0;
                    c7_uc_i = 0;
                    while (c7_uc_i <= 0) {
                      if (c7_b40) {
                        c7_iv0[0] = 1;
                        c7_iv0[1] = c7_ib_trueCount;
                        c7_tmp_sizes[0] = 1;
                        c7_tmp_sizes[1] = c7_iv0[1];
                        c7_i400 = c7_tmp_sizes[0];
                        c7_i401 = c7_tmp_sizes[1];
                        c7_nb_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                        for (c7_i402 = 0; c7_i402 <= c7_nb_loop_ub; c7_i402++) {
                          c7_tmp_data[c7_i402] = 1U;
                        }

                        c7_uv19[c7_uc_i] = c7_tmp_data[c7_ib_partialTrueCount];
                        c7_ib_partialTrueCount++;
                      }

                      c7_uc_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_data_struct_input->MA_index_right = c7_uv19[0];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 488);
                    c7_found = 1.0;
                  } else {
                    guard59 = true;
                  }
                } else {
                  guard59 = true;
                }

                if (guard59 == true) {
                  CV_EML_MCDC(0, 1, 40, false);
                  CV_EML_IF(0, 1, 45, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 490);
                c7_index++;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 483);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg27 = true;
              }
            }

            CV_EML_WHILE(0, 1, 4, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 493);
            for (c7_i403 = 0; c7_i403 < 5; c7_i403++) {
              c7_bv4[c7_i403] = (c7_data_struct_input->MA_maxs_right[c7_i403] >
                                 -1.0E+6F);
            }

            c7_jb_trueCount = 0;
            c7_vc_i = 0;
            while (c7_vc_i <= 4) {
              if (c7_bv4[c7_vc_i]) {
                c7_jb_trueCount++;
              }

              c7_vc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_jb_trueCount;
            c7_jb_partialTrueCount = 0;
            c7_wc_i = 0;
            while (c7_wc_i <= 4) {
              if (c7_bv4[c7_wc_i]) {
                c7_c_tmp_data[c7_jb_partialTrueCount] = c7_wc_i + 1;
                c7_jb_partialTrueCount++;
              }

              c7_wc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_t_data_struct_input_sizes[0] = 1;
            c7_t_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_bc_data_struct_input = c7_t_data_struct_input_sizes[0];
            c7_cc_data_struct_input = c7_t_data_struct_input_sizes[1];
            c7_ob_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i404 = 0; c7_i404 <= c7_ob_loop_ub; c7_i404++) {
              c7_t_data_struct_input_data[c7_i404] =
                c7_data_struct_input->MA_maxs_right[c7_c_tmp_data[c7_i404] - 1];
            }

            c7_yc_b = c7_std(chartInstance, c7_t_data_struct_input_data,
                             c7_t_data_struct_input_sizes);
            c7_cd_y = 5.0F * c7_yc_b;
            c7_u_data_struct_input_sizes[0] = 1;
            c7_u_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_dc_data_struct_input = c7_u_data_struct_input_sizes[0];
            c7_ec_data_struct_input = c7_u_data_struct_input_sizes[1];
            c7_pb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i405 = 0; c7_i405 <= c7_pb_loop_ub; c7_i405++) {
              c7_u_data_struct_input_data[c7_i405] =
                c7_data_struct_input->MA_maxs_right[c7_c_tmp_data[c7_i405] - 1];
            }

            c7_data_struct_input->MA_th_right = c7_b_mean(chartInstance,
              c7_u_data_struct_input_data, c7_u_data_struct_input_sizes) -
              c7_cd_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 496);
            c7_data_struct_input->MA_flag_right = true;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 497);
            for (c7_i406 = 0; c7_i406 < 5; c7_i406++) {
              c7_bv4[c7_i406] = (c7_data_struct_input->MA_maxs_right[c7_i406] >
                                 -1.0E+6F);
            }

            c7_kb_trueCount = 0;
            c7_xc_i = 0;
            while (c7_xc_i <= 4) {
              if (c7_bv4[c7_xc_i]) {
                c7_kb_trueCount++;
              }

              c7_xc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_kb_trueCount;
            c7_kb_partialTrueCount = 0;
            c7_yc_i = 0;
            while (c7_yc_i <= 4) {
              if (c7_bv4[c7_yc_i]) {
                c7_c_tmp_data[c7_kb_partialTrueCount] = c7_yc_i + 1;
                c7_kb_partialTrueCount++;
              }

              c7_yc_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_v_data_struct_input_sizes[0] = 1;
            c7_v_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_fc_data_struct_input = c7_v_data_struct_input_sizes[0];
            c7_gc_data_struct_input = c7_v_data_struct_input_sizes[1];
            c7_qb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i407 = 0; c7_i407 <= c7_qb_loop_ub; c7_i407++) {
              c7_v_data_struct_input_data[c7_i407] =
                c7_data_struct_input->MA_maxs_right[c7_c_tmp_data[c7_i407] - 1];
            }

            c7_g_A = c7_b_mean(chartInstance, c7_v_data_struct_input_data,
                               c7_v_data_struct_input_sizes);
            c7_dd_y = c7_b_rdivide(chartInstance, c7_g_A, 3.0);
            c7_data_struct_input->stop_MA_th_right = c7_dd_y;
          } else {
            guard57 = true;
          }
        } else {
          guard58 = true;
        }
      } else {
        guard58 = true;
      }

      if (guard58 == true) {
        guard57 = true;
      }

      if (guard57 == true) {
        CV_EML_MCDC(0, 1, 39, false);
        CV_EML_IF(0, 1, 44, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 501);
      guard49 = false;
      guard50 = false;
      if (CV_EML_COND(0, 1, 140U, CV_RELATIONAL_EVAL(4U, 0U, 140, (real_T)
            c7_data_struct_input->AngRShank_LPF[198], 0.0, -1, 5U,
            c7_data_struct_input->AngRShank_LPF[198] >= 0.0F))) {
        if (CV_EML_COND(0, 1, 141U, CV_RELATIONAL_EVAL(4U, 0U, 141, (real_T)
              c7_data_struct_input->AngRShank_LPF[199], 0.0, -1, 3U,
              c7_data_struct_input->AngRShank_LPF[199] <= 0.0F))) {
          if (CV_EML_COND(0, 1, 142U, c7_data_struct_input->MA_flag_right)) {
            CV_EML_MCDC(0, 1, 41, true);
            CV_EML_IF(0, 1, 46, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 502);
            c7_data_struct_input->MA_flag_right = false;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 504);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 505);
            c7_MS_inds_right = 0.0;
            _SFD_SYMBOL_SWITCH(9U, 9U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 507);
            c7_index = 0.0;
            _SFD_SYMBOL_SWITCH(2U, 2U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 508);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 509);
            exitg26 = false;
            while ((exitg26 == false) && (c7_index < (real_T)c7_left_limit)) {
              if (c7_found == 0.0) {
                CV_EML_WHILE(0, 1, 5, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 510);
                c7_d15 = c7_data_struct_input->
                  AngRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 32971, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1, 200) -
                  1];
                guard56 = false;
                if (CV_EML_COND(0, 1, 143U, CV_RELATIONAL_EVAL(4U, 0U, 144,
                      c7_d15, 0.0, -1, 5U, c7_d15 >= 0.0))) {
                  c7_d16 = c7_data_struct_input->
                    AngRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 33023,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  if (CV_EML_COND(0, 1, 144U, CV_RELATIONAL_EVAL(4U, 0U, 145,
                        c7_d16, 0.0, -1, 2U, c7_d16 < 0.0))) {
                    CV_EML_MCDC(0, 1, 42, true);
                    CV_EML_IF(0, 1, 47, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 511);
                    c7_MS_inds_right = c7_index;
                    _SFD_SYMBOL_SWITCH(9U, 9U);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 512);
                    c7_found = 1.0;
                  } else {
                    guard56 = true;
                  }
                } else {
                  guard56 = true;
                }

                if (guard56 == true) {
                  CV_EML_MCDC(0, 1, 42, false);
                  CV_EML_IF(0, 1, 47, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 514);
                c7_index++;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 509);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg26 = true;
              }
            }

            CV_EML_WHILE(0, 1, 5, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 518);
            c7_index = c7_MS_inds_right;
            _SFD_SYMBOL_SWITCH(2U, 2U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 519);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 520);
            c7_EC_events_inds_right = 0.0;
            _SFD_SYMBOL_SWITCH(10U, 10U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 521);
            c7_EC_distance_right = 0.0;
            _SFD_SYMBOL_SWITCH(11U, 11U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 522);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 524);
            exitg25 = false;
            while ((exitg25 == false) && (c7_index < (real_T)c7_left_limit)) {
              if (c7_found == 0.0) {
                CV_EML_WHILE(0, 1, 6, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 525);
                c7_f22 = c7_data_struct_input->
                  VelRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 33508, 43,
                   MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                c7_f23 = c7_data_struct_input->
                  VelRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 33552, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) + 1.0), 1, 200) -
                  1];
                guard54 = false;
                guard55 = false;
                if (CV_EML_COND(0, 1, 145U, CV_RELATIONAL_EVAL(4U, 0U, 146,
                      (real_T)c7_f22, (real_T)c7_f23, -3, 2U, c7_f22 < c7_f23)))
                {
                  c7_f24 = c7_data_struct_input->
                    VelRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 33601,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  c7_f25 = c7_data_struct_input->
                    VelRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 33645,
                     45, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  if (CV_EML_COND(0, 1, 146U, CV_RELATIONAL_EVAL(4U, 0U, 147,
                        (real_T)c7_f24, (real_T)c7_f25, -3, 2U, c7_f24 < c7_f25)))
                  {
                    c7_d17 = c7_data_struct_input->
                      VelRShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 33694,
                       43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) -
                      1];
                    if (CV_EML_COND(0, 1, 147U, CV_RELATIONAL_EVAL(4U, 0U, 148,
                          c7_d17, 0.0, -1, 2U, c7_d17 < 0.0))) {
                      CV_EML_MCDC(0, 1, 43, true);
                      CV_EML_IF(0, 1, 48, true);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 526);
                      c7_data_struct_input->EC_events_mins_right[(uint8_T)
                        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                        chartInstance->S, 5U, 33757, 79, MAX_uint32_T, (int32_T)
                        c7_data_struct_input->EC_events_index_right, 1, 5) - 1] =
                        c7_data_struct_input->
                        VelRShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         33837, 43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1,
                         200) - 1];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 527);
                      c7_EC_events_inds_right = c7_index;
                      _SFD_SYMBOL_SWITCH(10U, 10U);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 528);
                      c7_EC_distance_right = c7_index - c7_MS_inds_right;
                      _SFD_SYMBOL_SWITCH(11U, 11U);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 529);
                      c7_data_struct_input->AN_events_right[(uint8_T)
                        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                        chartInstance->S, 5U, 34085, 74, MAX_uint32_T, (int32_T)
                        c7_data_struct_input->EC_events_index_right, 1, 5) - 1] =
                        c7_data_struct_input->
                        AngRShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         34160, 43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1,
                         200) - 1];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 530);
                      c7_u41 = (uint32_T)
                        c7_data_struct_input->EC_events_index_right + 1U;
                      if (CV_SATURATION_EVAL(4, 0, 29, 0, c7_u41 > 255U)) {
                        c7_u41 = 255U;
                      }

                      c7_data_struct_input->EC_events_index_right = (uint8_T)
                        c7_u41;
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 531);
                      c7_uv20[0] = c7_data_struct_input->EC_events_index_right;
                      c7_b41 = ((real_T)
                                c7_data_struct_input->EC_events_index_right >
                                5.0);
                      c7_lb_trueCount = 0;
                      c7_ad_i = 0;
                      while (c7_ad_i <= 0) {
                        if (c7_b41) {
                          c7_lb_trueCount++;
                        }

                        c7_ad_i++;
                        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                      }

                      c7_lb_partialTrueCount = 0;
                      c7_bd_i = 0;
                      while (c7_bd_i <= 0) {
                        if (c7_b41) {
                          c7_iv0[0] = 1;
                          c7_iv0[1] = c7_lb_trueCount;
                          c7_tmp_sizes[0] = 1;
                          c7_tmp_sizes[1] = c7_iv0[1];
                          c7_i408 = c7_tmp_sizes[0];
                          c7_i409 = c7_tmp_sizes[1];
                          c7_rb_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                          for (c7_i410 = 0; c7_i410 <= c7_rb_loop_ub; c7_i410++)
                          {
                            c7_tmp_data[c7_i410] = 1U;
                          }

                          c7_uv20[c7_bd_i] = c7_tmp_data[c7_lb_partialTrueCount];
                          c7_lb_partialTrueCount++;
                        }

                        c7_bd_i++;
                        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                      }

                      c7_data_struct_input->EC_events_index_right = c7_uv20[0];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 532);
                      c7_found = 1.0;
                    } else {
                      guard54 = true;
                    }
                  } else {
                    guard55 = true;
                  }
                } else {
                  guard55 = true;
                }

                if (guard55 == true) {
                  guard54 = true;
                }

                if (guard54 == true) {
                  CV_EML_MCDC(0, 1, 43, false);
                  CV_EML_IF(0, 1, 48, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 534);
                c7_index++;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 524);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg25 = true;
              }
            }

            CV_EML_WHILE(0, 1, 6, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 536);
            for (c7_i411 = 0; c7_i411 < 50; c7_i411++) {
              c7_EC_peaks[c7_i411] = -2.0E+6;
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 537);
            for (c7_i412 = 0; c7_i412 < 50; c7_i412++) {
              c7_AN_peaks[c7_i412] = 2.0E+6;
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 538);
            c7_EC_peaks_index = 1.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 539);
            if (CV_EML_IF(0, 1, 49, CV_RELATIONAL_EVAL(4U, 0U, 149, c7_found,
                  1.0, -1, 0U, c7_found == 1.0))) {
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 540);
              c7_found = 0.0;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 542);
              c7_d18 = c7_EC_events_inds_right + 1.0;
              c7_d19 = c7_EC_events_inds_right + c7_EC_distance_right;
              c7_i413 = (int32_T)(c7_d19 + (1.0 - c7_d18)) - 1;
              c7_d_index = 0;
              while (c7_d_index <= c7_i413) {
                c7_index = c7_d18 + (real_T)c7_d_index;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                CV_EML_FOR(0, 1, 1, 1);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 543);
                c7_f26 = c7_data_struct_input->
                  VelRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 34792, 43,
                   MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                c7_f27 = c7_data_struct_input->
                  VelRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 34836, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) + 1.0), 1, 200) -
                  1];
                guard52 = false;
                guard53 = false;
                if (CV_EML_COND(0, 1, 148U, CV_RELATIONAL_EVAL(4U, 0U, 150,
                      (real_T)c7_f26, (real_T)c7_f27, -3, 2U, c7_f26 < c7_f27)))
                {
                  c7_f28 = c7_data_struct_input->
                    VelRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 34885,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  c7_f29 = c7_data_struct_input->
                    VelRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 34929,
                     45, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  if (CV_EML_COND(0, 1, 149U, CV_RELATIONAL_EVAL(4U, 0U, 151,
                        (real_T)c7_f28, (real_T)c7_f29, -3, 2U, c7_f28 < c7_f29)))
                  {
                    c7_d20 = c7_data_struct_input->
                      VelRShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 34978,
                       43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) -
                      1];
                    if (CV_EML_COND(0, 1, 150U, CV_RELATIONAL_EVAL(4U, 0U, 152,
                          c7_d20, 0.0, -1, 2U, c7_d20 < 0.0))) {
                      CV_EML_MCDC(0, 1, 44, true);
                      CV_EML_IF(0, 1, 50, true);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 544);
                      c7_EC_peaks[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         35045, 24, 0U, (int32_T)c7_EC_peaks_index, 1, 50) - 1] =
                        c7_data_struct_input->
                        VelRShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         35070, 43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1,
                         200) - 1];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 545);
                      c7_AN_peaks[(int32_T)c7_EC_peaks_index - 1] =
                        c7_data_struct_input->
                        AngRShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         35160, 43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1,
                         200) - 1];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 546);
                      c7_EC_peaks_index++;
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 547);
                      c7_dv3[0] = c7_EC_peaks_index;
                      c7_mb_trueCount = 0;
                      c7_cd_i = 0;
                      while (c7_cd_i <= 0) {
                        if (c7_EC_peaks_index > 50.0) {
                          c7_mb_trueCount++;
                        }

                        c7_cd_i++;
                        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                      }

                      c7_mb_partialTrueCount = 0;
                      c7_dd_i = 0;
                      while (c7_dd_i <= 0) {
                        if (c7_EC_peaks_index > 50.0) {
                          c7_iv0[0] = 1;
                          c7_iv0[1] = c7_mb_trueCount;
                          c7_d_tmp_sizes[0] = 1;
                          c7_d_tmp_sizes[1] = c7_iv0[1];
                          c7_i414 = c7_d_tmp_sizes[0];
                          c7_i415 = c7_d_tmp_sizes[1];
                          c7_sb_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                          for (c7_i416 = 0; c7_i416 <= c7_sb_loop_ub; c7_i416++)
                          {
                            c7_d_tmp_data[c7_i416] = 50.0;
                          }

                          c7_dv3[c7_dd_i] = c7_d_tmp_data[c7_mb_partialTrueCount];
                          c7_mb_partialTrueCount++;
                        }

                        c7_dd_i++;
                        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                      }

                      c7_EC_peaks_index = c7_dv3[0];
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 548);
                      c7_found = 1.0;
                    } else {
                      guard52 = true;
                    }
                  } else {
                    guard53 = true;
                  }
                } else {
                  guard53 = true;
                }

                if (guard53 == true) {
                  guard52 = true;
                }

                if (guard52 == true) {
                  CV_EML_MCDC(0, 1, 44, false);
                  CV_EML_IF(0, 1, 50, false);
                }

                c7_d_index++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              CV_EML_FOR(0, 1, 1, 0);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 552);
              if (CV_EML_IF(0, 1, 51, CV_RELATIONAL_EVAL(4U, 0U, 153, c7_found,
                    0.0, -1, 0U, c7_found == 0.0))) {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 553);
                c7_f30 = c7_data_struct_input->
                  VelRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 35646, 76,
                   MAX_uint32_T, (int32_T)((200.0 - c7_EC_events_inds_right) -
                    c7_EC_distance_right), 1, 200) - 1] + 1.0F;
                c7_b_sign(chartInstance, &c7_f30);
                c7_h_A = -c7_f30;
                c7_ed_y = c7_b_rdivide(chartInstance, c7_h_A, 2.0);
                c7_EC_peaks[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 35537, 24,
                   0U, (int32_T)c7_EC_peaks_index, 1, 50) - 1] =
                  c7_data_struct_input->VelRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 35562, 76,
                   MAX_uint32_T, (int32_T)((200.0 - c7_EC_events_inds_right) -
                    c7_EC_distance_right), 1, 200) - 1] * c7_ed_y;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 554);
                c7_AN_peaks[(int32_T)c7_EC_peaks_index - 1] =
                  c7_data_struct_input->AngRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 35771, 76,
                   MAX_uint32_T, (int32_T)((200.0 - c7_EC_events_inds_right) -
                    c7_EC_distance_right), 1, 200) - 1];
              }
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 558);
            c7_nb_trueCount = 0;
            c7_ed_i = 0;
            while (c7_ed_i <= 49) {
              if (c7_EC_peaks[c7_ed_i] > -1.0E+6) {
                c7_nb_trueCount++;
              }

              c7_ed_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_e_tmp_sizes = c7_nb_trueCount;
            c7_nb_partialTrueCount = 0;
            c7_fd_i = 0;
            while (c7_fd_i <= 49) {
              if (c7_EC_peaks[c7_fd_i] > -1.0E+6) {
                c7_e_tmp_data[c7_nb_partialTrueCount] = c7_fd_i + 1;
                c7_nb_partialTrueCount++;
              }

              c7_fd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_b_EC_peaks_sizes = c7_e_tmp_sizes;
            c7_tb_loop_ub = c7_e_tmp_sizes - 1;
            for (c7_i417 = 0; c7_i417 <= c7_tb_loop_ub; c7_i417++) {
              c7_b_EC_peaks_data[c7_i417] = c7_EC_peaks[c7_e_tmp_data[c7_i417] -
                1];
            }

            c7_data_struct_input->EC_peaks_mins_right[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 35894, 77, MAX_uint32_T, (int32_T)
              c7_data_struct_input->EC_peaks_index_right, 1, 5) - 1] = (real32_T)
              c7_c_mean(chartInstance, c7_b_EC_peaks_data, c7_b_EC_peaks_sizes);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 559);
            for (c7_i418 = 0; c7_i418 < 50; c7_i418++) {
              c7_b_varargin_1[c7_i418] = c7_AN_peaks[c7_i418];
            }

            c7_b_ixstart = 1;
            c7_e_mtmp = c7_b_varargin_1[0];
            c7_c_x = c7_e_mtmp;
            c7_ad_b = muDoubleScalarIsNaN(c7_c_x);
            if (c7_ad_b) {
              c7_d_ix = 2;
              exitg24 = false;
              while ((exitg24 == false) && (c7_d_ix < 51)) {
                c7_e_ix = c7_d_ix - 1;
                c7_b_ixstart = c7_e_ix + 1;
                c7_d_x = c7_b_varargin_1[c7_e_ix];
                c7_bd_b = muDoubleScalarIsNaN(c7_d_x);
                if (!c7_bd_b) {
                  c7_e_mtmp = c7_b_varargin_1[c7_e_ix];
                  exitg24 = true;
                } else {
                  c7_d_ix++;
                }
              }
            }

            if (c7_b_ixstart < 50) {
              c7_i419 = c7_b_ixstart;
              for (c7_f_ix = c7_i419 + 1; c7_f_ix < 51; c7_f_ix++) {
                c7_e_ix = c7_f_ix - 1;
                c7_c_a = c7_b_varargin_1[c7_e_ix];
                c7_cd_b = c7_e_mtmp;
                c7_c_p = (c7_c_a < c7_cd_b);
                if (c7_c_p) {
                  c7_e_mtmp = c7_b_varargin_1[c7_e_ix];
                }
              }
            }

            c7_f_mtmp = c7_e_mtmp;
            c7_b_minval = c7_f_mtmp;
            c7_data_struct_input->AN_peaks_right[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 36011, 72, MAX_uint32_T, (int32_T)
              c7_data_struct_input->EC_peaks_index_right, 1, 5) - 1] = (real32_T)
              c7_b_minval;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 560);
            c7_u42 = (uint32_T)c7_data_struct_input->EC_peaks_index_right + 1U;
            if (CV_SATURATION_EVAL(4, 0, 30, 0, c7_u42 > 255U)) {
              c7_u42 = 255U;
            }

            c7_data_struct_input->EC_peaks_index_right = (uint8_T)c7_u42;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 561);
            c7_uv21[0] = c7_data_struct_input->EC_peaks_index_right;
            c7_b42 = ((real_T)c7_data_struct_input->EC_peaks_index_right > 5.0);
            c7_ob_trueCount = 0;
            c7_gd_i = 0;
            while (c7_gd_i <= 0) {
              if (c7_b42) {
                c7_ob_trueCount++;
              }

              c7_gd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_ob_partialTrueCount = 0;
            c7_hd_i = 0;
            while (c7_hd_i <= 0) {
              if (c7_b42) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_ob_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i420 = c7_tmp_sizes[0];
                c7_i421 = c7_tmp_sizes[1];
                c7_ub_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i422 = 0; c7_i422 <= c7_ub_loop_ub; c7_i422++) {
                  c7_tmp_data[c7_i422] = 1U;
                }

                c7_uv21[c7_hd_i] = c7_tmp_data[c7_ob_partialTrueCount];
                c7_ob_partialTrueCount++;
              }

              c7_hd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->EC_peaks_index_right = c7_uv21[0];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 563);
            for (c7_i423 = 0; c7_i423 < 5; c7_i423++) {
              c7_bv4[c7_i423] = (c7_data_struct_input->
                                 EC_events_mins_right[c7_i423] > -1.0E+6F);
            }

            for (c7_i424 = 0; c7_i424 < 5; c7_i424++) {
              c7_bv5[c7_i424] = (c7_data_struct_input->
                                 EC_peaks_mins_right[c7_i424] > -1.0E+6F);
            }

            c7_pb_trueCount = 0;
            c7_id_i = 0;
            while (c7_id_i <= 4) {
              if (c7_bv4[c7_id_i]) {
                c7_pb_trueCount++;
              }

              c7_id_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_pb_trueCount;
            c7_pb_partialTrueCount = 0;
            c7_jd_i = 0;
            while (c7_jd_i <= 4) {
              if (c7_bv4[c7_jd_i]) {
                c7_c_tmp_data[c7_pb_partialTrueCount] = c7_jd_i + 1;
                c7_pb_partialTrueCount++;
              }

              c7_jd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_qb_trueCount = 0;
            c7_kd_i = 0;
            while (c7_kd_i <= 4) {
              if (c7_bv5[c7_kd_i]) {
                c7_qb_trueCount++;
              }

              c7_kd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_f_tmp_sizes[0] = 1;
            c7_f_tmp_sizes[1] = c7_qb_trueCount;
            c7_qb_partialTrueCount = 0;
            c7_ld_i = 0;
            while (c7_ld_i <= 4) {
              if (c7_bv5[c7_ld_i]) {
                c7_f_tmp_data[c7_qb_partialTrueCount] = c7_ld_i + 1;
                c7_qb_partialTrueCount++;
              }

              c7_ld_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_w_data_struct_input_sizes[0] = 1;
            c7_w_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_hc_data_struct_input = c7_w_data_struct_input_sizes[0];
            c7_ic_data_struct_input = c7_w_data_struct_input_sizes[1];
            c7_vb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i425 = 0; c7_i425 <= c7_vb_loop_ub; c7_i425++) {
              c7_w_data_struct_input_data[c7_i425] =
                c7_data_struct_input->EC_events_mins_right[c7_c_tmp_data[c7_i425]
                - 1];
            }

            c7_x_data_struct_input_sizes[0] = 1;
            c7_x_data_struct_input_sizes[1] = c7_f_tmp_sizes[1];
            c7_jc_data_struct_input = c7_x_data_struct_input_sizes[0];
            c7_kc_data_struct_input = c7_x_data_struct_input_sizes[1];
            c7_wb_loop_ub = c7_f_tmp_sizes[0] * c7_f_tmp_sizes[1] - 1;
            for (c7_i426 = 0; c7_i426 <= c7_wb_loop_ub; c7_i426++) {
              c7_x_data_struct_input_data[c7_i426] =
                c7_data_struct_input->EC_peaks_mins_right[c7_f_tmp_data[c7_i426]
                - 1];
            }

            c7_i_A = c7_b_mean(chartInstance, c7_w_data_struct_input_data,
                               c7_w_data_struct_input_sizes) + c7_b_mean
              (chartInstance, c7_x_data_struct_input_data,
               c7_x_data_struct_input_sizes);
            c7_fd_y = c7_b_rdivide(chartInstance, c7_i_A, 2.0);
            c7_data_struct_input->EC_th_right = c7_fd_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 564);
            for (c7_i427 = 0; c7_i427 < 5; c7_i427++) {
              c7_bv4[c7_i427] = (c7_data_struct_input->AN_events_right[c7_i427] >
                                 -1.0E+6F);
            }

            for (c7_i428 = 0; c7_i428 < 5; c7_i428++) {
              c7_bv5[c7_i428] = (c7_data_struct_input->AN_peaks_right[c7_i428] >
                                 -1.0E+6F);
            }

            c7_rb_trueCount = 0;
            c7_md_i = 0;
            while (c7_md_i <= 4) {
              if (c7_bv4[c7_md_i]) {
                c7_rb_trueCount++;
              }

              c7_md_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_rb_trueCount;
            c7_rb_partialTrueCount = 0;
            c7_nd_i = 0;
            while (c7_nd_i <= 4) {
              if (c7_bv4[c7_nd_i]) {
                c7_c_tmp_data[c7_rb_partialTrueCount] = c7_nd_i + 1;
                c7_rb_partialTrueCount++;
              }

              c7_nd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_sb_trueCount = 0;
            c7_od_i = 0;
            while (c7_od_i <= 4) {
              if (c7_bv5[c7_od_i]) {
                c7_sb_trueCount++;
              }

              c7_od_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_f_tmp_sizes[0] = 1;
            c7_f_tmp_sizes[1] = c7_sb_trueCount;
            c7_sb_partialTrueCount = 0;
            c7_pd_i = 0;
            while (c7_pd_i <= 4) {
              if (c7_bv5[c7_pd_i]) {
                c7_f_tmp_data[c7_sb_partialTrueCount] = c7_pd_i + 1;
                c7_sb_partialTrueCount++;
              }

              c7_pd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_y_data_struct_input_sizes[0] = 1;
            c7_y_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_lc_data_struct_input = c7_y_data_struct_input_sizes[0];
            c7_mc_data_struct_input = c7_y_data_struct_input_sizes[1];
            c7_xb_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i429 = 0; c7_i429 <= c7_xb_loop_ub; c7_i429++) {
              c7_y_data_struct_input_data[c7_i429] =
                c7_data_struct_input->AN_events_right[c7_c_tmp_data[c7_i429] - 1];
            }

            c7_ab_data_struct_input_sizes[0] = 1;
            c7_ab_data_struct_input_sizes[1] = c7_f_tmp_sizes[1];
            c7_nc_data_struct_input = c7_ab_data_struct_input_sizes[0];
            c7_oc_data_struct_input = c7_ab_data_struct_input_sizes[1];
            c7_yb_loop_ub = c7_f_tmp_sizes[0] * c7_f_tmp_sizes[1] - 1;
            for (c7_i430 = 0; c7_i430 <= c7_yb_loop_ub; c7_i430++) {
              c7_ab_data_struct_input_data[c7_i430] =
                c7_data_struct_input->AN_peaks_right[c7_f_tmp_data[c7_i430] - 1];
            }

            c7_j_A = c7_b_mean(chartInstance, c7_y_data_struct_input_data,
                               c7_y_data_struct_input_sizes) + c7_b_mean
              (chartInstance, c7_ab_data_struct_input_data,
               c7_ab_data_struct_input_sizes);
            c7_gd_y = c7_b_rdivide(chartInstance, c7_j_A, 2.0);
            c7_data_struct_input->AN_th_right = c7_gd_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 567);
            for (c7_i431 = 0; c7_i431 < 5; c7_i431++) {
              c7_bv4[c7_i431] = (c7_data_struct_input->
                                 EC_events_mins_right[c7_i431] > -1.0E+6F);
            }

            c7_tb_trueCount = 0;
            c7_qd_i = 0;
            while (c7_qd_i <= 4) {
              if (c7_bv4[c7_qd_i]) {
                c7_tb_trueCount++;
              }

              c7_qd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_tb_trueCount;
            c7_tb_partialTrueCount = 0;
            c7_rd_i = 0;
            while (c7_rd_i <= 4) {
              if (c7_bv4[c7_rd_i]) {
                c7_c_tmp_data[c7_tb_partialTrueCount] = c7_rd_i + 1;
                c7_tb_partialTrueCount++;
              }

              c7_rd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_bb_data_struct_input_sizes[0] = 1;
            c7_bb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_pc_data_struct_input = c7_bb_data_struct_input_sizes[0];
            c7_qc_data_struct_input = c7_bb_data_struct_input_sizes[1];
            c7_ac_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i432 = 0; c7_i432 <= c7_ac_loop_ub; c7_i432++) {
              c7_bb_data_struct_input_data[c7_i432] =
                c7_data_struct_input->EC_events_mins_right[c7_c_tmp_data[c7_i432]
                - 1];
            }

            c7_k_A = c7_b_mean(chartInstance, c7_bb_data_struct_input_data,
                               c7_bb_data_struct_input_sizes);
            c7_hd_y = c7_b_rdivide(chartInstance, c7_k_A, 3.0);
            c7_data_struct_input->stop_Vel_th_right = c7_hd_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 570);
            guard51 = false;
            if (CV_EML_COND(0, 1, 151U, CV_RELATIONAL_EVAL(4U, 0U, 154, (real_T)
                  c7_data_struct_input->state, 4.0, 0, 0U,
                  c7_data_struct_input->state == 4))) {
              guard51 = true;
            } else if (CV_EML_COND(0, 1, 152U, CV_RELATIONAL_EVAL(4U, 0U, 155,
                         (real_T)c7_data_struct_input->state, 5.0, 0, 0U,
                         c7_data_struct_input->state == 5))) {
              guard51 = true;
            } else {
              CV_EML_MCDC(0, 1, 45, false);
              CV_EML_IF(0, 1, 52, false);
            }

            if (guard51 == true) {
              CV_EML_MCDC(0, 1, 45, true);
              CV_EML_IF(0, 1, 52, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 571);
              if (CV_EML_IF(0, 1, 53, CV_RELATIONAL_EVAL(4U, 0U, 156, (real_T)
                    c7_data_struct_input->IC_event_right, 0.0, -1, 4U, (real_T)
                    c7_data_struct_input->IC_event_right > 0.0))) {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 572);
                c7_data_struct_input->state = 1;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 573);
                c7_data_struct_input->IC_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 574);
                c7_data_struct_input->EC_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 575);
                c7_data_struct_input->AN_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 576);
                c7_data_struct_input->stop_Vel_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 577);
                c7_data_struct_input->stop_MA_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 578);
                c7_data_struct_input->stop_IC_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 579);
                c7_data_struct_input->last_EC = 1U;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 580);
                c7_data_struct_input->MS_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 581);
                c7_data_struct_input->MA_event_left = false;
              } else {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 583);
                c7_data_struct_input->state = 6;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 584);
                c7_data_struct_input->MS_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 585);
                c7_data_struct_input->MA_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 586);
                c7_data_struct_input->last_IC = 1U;
              }
            }
          } else {
            guard49 = true;
          }
        } else {
          guard50 = true;
        }
      } else {
        guard50 = true;
      }

      if (guard50 == true) {
        guard49 = true;
      }

      if (guard49 == true) {
        CV_EML_MCDC(0, 1, 41, false);
        CV_EML_IF(0, 1, 46, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 592);
      guard45 = false;
      guard46 = false;
      if (CV_EML_COND(0, 1, 153U, CV_RELATIONAL_EVAL(4U, 0U, 157, (real_T)
            c7_data_struct_input->AngRShank_LPF[198], (real_T)
            c7_data_struct_input->AngRShank_LPF[197], -3, 2U,
            c7_data_struct_input->AngRShank_LPF[198] <
            c7_data_struct_input->AngRShank_LPF[197]))) {
        if (CV_EML_COND(0, 1, 154U, CV_RELATIONAL_EVAL(4U, 0U, 158, (real_T)
              c7_data_struct_input->AngRShank_LPF[198], (real_T)
              c7_data_struct_input->AngRShank_LPF[199], -3, 3U,
              c7_data_struct_input->AngRShank_LPF[198] <=
              c7_data_struct_input->AngRShank_LPF[199]))) {
          if (CV_EML_COND(0, 1, 155U, CV_RELATIONAL_EVAL(4U, 0U, 159, (real_T)
                c7_data_struct_input->AngRShank_LPF[198], (real_T)
                c7_data_struct_input->IC_LPF_th_right, -3, 3U,
                c7_data_struct_input->AngRShank_LPF[198] <=
                c7_data_struct_input->IC_LPF_th_right))) {
            CV_EML_MCDC(0, 1, 46, true);
            CV_EML_IF(0, 1, 54, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 593);
            c7_data_struct_input->IC_LPF_mins_right[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 38296, 73, MAX_uint32_T, (int32_T)
              c7_data_struct_input->IC_LPF_index_right, 1, 5) - 1] =
              c7_data_struct_input->AngRShank_LPF[198];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 594);
            c7_u43 = (uint32_T)c7_data_struct_input->IC_LPF_index_right + 1U;
            if (CV_SATURATION_EVAL(4, 0, 31, 0, c7_u43 > 255U)) {
              c7_u43 = 255U;
            }

            c7_data_struct_input->IC_LPF_index_right = (uint8_T)c7_u43;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 595);
            c7_uv22[0] = c7_data_struct_input->IC_LPF_index_right;
            c7_b43 = ((real_T)c7_data_struct_input->IC_LPF_index_right > 5.0);
            c7_ub_trueCount = 0;
            c7_sd_i = 0;
            while (c7_sd_i <= 0) {
              if (c7_b43) {
                c7_ub_trueCount++;
              }

              c7_sd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_ub_partialTrueCount = 0;
            c7_td_i = 0;
            while (c7_td_i <= 0) {
              if (c7_b43) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_ub_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i433 = c7_tmp_sizes[0];
                c7_i434 = c7_tmp_sizes[1];
                c7_bc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i435 = 0; c7_i435 <= c7_bc_loop_ub; c7_i435++) {
                  c7_tmp_data[c7_i435] = 1U;
                }

                c7_uv22[c7_td_i] = c7_tmp_data[c7_ub_partialTrueCount];
                c7_ub_partialTrueCount++;
              }

              c7_td_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->IC_LPF_index_right = c7_uv22[0];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 597);
            for (c7_i436 = 0; c7_i436 < 5; c7_i436++) {
              c7_bv4[c7_i436] = (c7_data_struct_input->IC_LPF_mins_right[c7_i436]
                                 > -1.0E+6F);
            }

            c7_vb_trueCount = 0;
            c7_ud_i = 0;
            while (c7_ud_i <= 4) {
              if (c7_bv4[c7_ud_i]) {
                c7_vb_trueCount++;
              }

              c7_ud_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_vb_trueCount;
            c7_vb_partialTrueCount = 0;
            c7_vd_i = 0;
            while (c7_vd_i <= 4) {
              if (c7_bv4[c7_vd_i]) {
                c7_c_tmp_data[c7_vb_partialTrueCount] = c7_vd_i + 1;
                c7_vb_partialTrueCount++;
              }

              c7_vd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_cb_data_struct_input_sizes[0] = 1;
            c7_cb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_rc_data_struct_input = c7_cb_data_struct_input_sizes[0];
            c7_sc_data_struct_input = c7_cb_data_struct_input_sizes[1];
            c7_cc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i437 = 0; c7_i437 <= c7_cc_loop_ub; c7_i437++) {
              c7_cb_data_struct_input_data[c7_i437] =
                c7_data_struct_input->IC_LPF_mins_right[c7_c_tmp_data[c7_i437] -
                1];
            }

            c7_dd_b = c7_std(chartInstance, c7_cb_data_struct_input_data,
                             c7_cb_data_struct_input_sizes);
            c7_id_y = 5.0F * c7_dd_b;
            c7_db_data_struct_input_sizes[0] = 1;
            c7_db_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_tc_data_struct_input = c7_db_data_struct_input_sizes[0];
            c7_uc_data_struct_input = c7_db_data_struct_input_sizes[1];
            c7_dc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i438 = 0; c7_i438 <= c7_dc_loop_ub; c7_i438++) {
              c7_db_data_struct_input_data[c7_i438] =
                c7_data_struct_input->IC_LPF_mins_right[c7_c_tmp_data[c7_i438] -
                1];
            }

            c7_data_struct_input->IC_LPF_th_right = c7_b_mean(chartInstance,
              c7_db_data_struct_input_data, c7_db_data_struct_input_sizes) +
              c7_id_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 600);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 601);
            c7_index = 1.0;
            _SFD_SYMBOL_SWITCH(2U, 2U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 602);
            exitg23 = false;
            while ((exitg23 == false) && (c7_found == 0.0)) {
              if (c7_index < (real_T)c7_left_limit) {
                CV_EML_WHILE(0, 1, 7, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 603);
                c7_f31 = c7_data_struct_input->
                  AngRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 38955, 43,
                   MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                c7_f32 = c7_data_struct_input->
                  AngRShank_filt[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 38999, 45,
                   MAX_uint32_T, (int32_T)((200.0 - c7_index) + 1.0), 1, 200) -
                  1];
                guard48 = false;
                if (CV_EML_COND(0, 1, 156U, CV_RELATIONAL_EVAL(4U, 0U, 160,
                      (real_T)c7_f31, (real_T)c7_f32, -3, 2U, c7_f31 < c7_f32)))
                {
                  c7_f33 = c7_data_struct_input->
                    AngRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 39048,
                     43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) - 1];
                  c7_f34 = c7_data_struct_input->
                    AngRShank_filt[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 39093,
                     45, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  if (CV_EML_COND(0, 1, 157U, CV_RELATIONAL_EVAL(4U, 0U, 161,
                        (real_T)c7_f33, (real_T)c7_f34, -3, 3U, c7_f33 <= c7_f34)))
                  {
                    CV_EML_MCDC(0, 1, 47, true);
                    CV_EML_IF(0, 1, 55, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 604);
                    c7_data_struct_input->IC_mins_right[(uint8_T)
                      sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                      chartInstance->S, 5U, 39156, 65, MAX_uint32_T, (int32_T)
                      c7_data_struct_input->IC_index_right, 1, 5) - 1] =
                      c7_data_struct_input->
                      AngRShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 39222,
                       43, MAX_uint32_T, (int32_T)(200.0 - c7_index), 1, 200) -
                      1];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 605);
                    c7_u44 = (uint32_T)c7_data_struct_input->IC_index_right + 1U;
                    if (CV_SATURATION_EVAL(4, 0, 32, 0, c7_u44 > 255U)) {
                      c7_u44 = 255U;
                    }

                    c7_data_struct_input->IC_index_right = (uint8_T)c7_u44;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 606);
                    c7_uv23[0] = c7_data_struct_input->IC_index_right;
                    c7_b44 = ((real_T)c7_data_struct_input->IC_index_right > 5.0);
                    c7_wb_trueCount = 0;
                    c7_wd_i = 0;
                    while (c7_wd_i <= 0) {
                      if (c7_b44) {
                        c7_wb_trueCount++;
                      }

                      c7_wd_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_wb_partialTrueCount = 0;
                    c7_xd_i = 0;
                    while (c7_xd_i <= 0) {
                      if (c7_b44) {
                        c7_iv0[0] = 1;
                        c7_iv0[1] = c7_wb_trueCount;
                        c7_tmp_sizes[0] = 1;
                        c7_tmp_sizes[1] = c7_iv0[1];
                        c7_i439 = c7_tmp_sizes[0];
                        c7_i440 = c7_tmp_sizes[1];
                        c7_ec_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                        for (c7_i441 = 0; c7_i441 <= c7_ec_loop_ub; c7_i441++) {
                          c7_tmp_data[c7_i441] = 1U;
                        }

                        c7_uv23[c7_xd_i] = c7_tmp_data[c7_wb_partialTrueCount];
                        c7_wb_partialTrueCount++;
                      }

                      c7_xd_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_data_struct_input->IC_index_right = c7_uv23[0];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 607);
                    c7_found = 1.0;
                  } else {
                    guard48 = true;
                  }
                } else {
                  guard48 = true;
                }

                if (guard48 == true) {
                  CV_EML_MCDC(0, 1, 47, false);
                  CV_EML_IF(0, 1, 55, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 609);
                c7_index++;
                _SFD_SYMBOL_SWITCH(2U, 2U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 602);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg23 = true;
              }
            }

            CV_EML_WHILE(0, 1, 7, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 612);
            for (c7_i442 = 0; c7_i442 < 5; c7_i442++) {
              c7_bv4[c7_i442] = (c7_data_struct_input->IC_mins_right[c7_i442] >
                                 -1.0E+6F);
            }

            c7_xb_trueCount = 0;
            c7_yd_i = 0;
            while (c7_yd_i <= 4) {
              if (c7_bv4[c7_yd_i]) {
                c7_xb_trueCount++;
              }

              c7_yd_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_xb_trueCount;
            c7_xb_partialTrueCount = 0;
            c7_ae_i = 0;
            while (c7_ae_i <= 4) {
              if (c7_bv4[c7_ae_i]) {
                c7_c_tmp_data[c7_xb_partialTrueCount] = c7_ae_i + 1;
                c7_xb_partialTrueCount++;
              }

              c7_ae_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_eb_data_struct_input_sizes[0] = 1;
            c7_eb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_vc_data_struct_input = c7_eb_data_struct_input_sizes[0];
            c7_wc_data_struct_input = c7_eb_data_struct_input_sizes[1];
            c7_fc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i443 = 0; c7_i443 <= c7_fc_loop_ub; c7_i443++) {
              c7_eb_data_struct_input_data[c7_i443] =
                c7_data_struct_input->IC_mins_right[c7_c_tmp_data[c7_i443] - 1];
            }

            c7_ed_b = c7_std(chartInstance, c7_eb_data_struct_input_data,
                             c7_eb_data_struct_input_sizes);
            c7_jd_y = 5.0F * c7_ed_b;
            c7_fb_data_struct_input_sizes[0] = 1;
            c7_fb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_xc_data_struct_input = c7_fb_data_struct_input_sizes[0];
            c7_yc_data_struct_input = c7_fb_data_struct_input_sizes[1];
            c7_gc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i444 = 0; c7_i444 <= c7_gc_loop_ub; c7_i444++) {
              c7_fb_data_struct_input_data[c7_i444] =
                c7_data_struct_input->IC_mins_right[c7_c_tmp_data[c7_i444] - 1];
            }

            c7_data_struct_input->IC_th_right = c7_b_mean(chartInstance,
              c7_fb_data_struct_input_data, c7_fb_data_struct_input_sizes) +
              c7_jd_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 613);
            for (c7_i445 = 0; c7_i445 < 5; c7_i445++) {
              c7_bv4[c7_i445] = (c7_data_struct_input->IC_mins_right[c7_i445] >
                                 -1.0E+6F);
            }

            c7_yb_trueCount = 0;
            c7_be_i = 0;
            while (c7_be_i <= 4) {
              if (c7_bv4[c7_be_i]) {
                c7_yb_trueCount++;
              }

              c7_be_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_c_tmp_sizes[0] = 1;
            c7_c_tmp_sizes[1] = c7_yb_trueCount;
            c7_yb_partialTrueCount = 0;
            c7_ce_i = 0;
            while (c7_ce_i <= 4) {
              if (c7_bv4[c7_ce_i]) {
                c7_c_tmp_data[c7_yb_partialTrueCount] = c7_ce_i + 1;
                c7_yb_partialTrueCount++;
              }

              c7_ce_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_gb_data_struct_input_sizes[0] = 1;
            c7_gb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
            c7_ad_data_struct_input = c7_gb_data_struct_input_sizes[0];
            c7_bd_data_struct_input = c7_gb_data_struct_input_sizes[1];
            c7_hc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
            for (c7_i446 = 0; c7_i446 <= c7_hc_loop_ub; c7_i446++) {
              c7_gb_data_struct_input_data[c7_i446] =
                c7_data_struct_input->IC_mins_right[c7_c_tmp_data[c7_i446] - 1];
            }

            c7_l_A = c7_b_mean(chartInstance, c7_gb_data_struct_input_data,
                               c7_gb_data_struct_input_sizes);
            c7_kd_y = c7_b_rdivide(chartInstance, c7_l_A, 3.0);
            c7_data_struct_input->stop_IC_th_right = c7_kd_y;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 615);
            guard47 = false;
            if (CV_EML_COND(0, 1, 158U, CV_RELATIONAL_EVAL(4U, 0U, 162, (real_T)
                  c7_data_struct_input->state, 5.0, 0, 0U,
                  c7_data_struct_input->state == 5))) {
              guard47 = true;
            } else if (CV_EML_COND(0, 1, 159U, CV_RELATIONAL_EVAL(4U, 0U, 163,
                         (real_T)c7_data_struct_input->state, 6.0, 0, 0U,
                         c7_data_struct_input->state == 6))) {
              guard47 = true;
            } else {
              CV_EML_MCDC(0, 1, 48, false);
              CV_EML_IF(0, 1, 56, false);
            }

            if (guard47 == true) {
              CV_EML_MCDC(0, 1, 48, true);
              CV_EML_IF(0, 1, 56, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 616);
              if (CV_EML_IF(0, 1, 57, CV_RELATIONAL_EVAL(4U, 0U, 164, (real_T)
                    c7_data_struct_input->EC_event_left, 0.0, -1, 4U, (real_T)
                    c7_data_struct_input->EC_event_left > 0.0))) {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 617);
                c7_data_struct_input->state = 2;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 618);
                c7_data_struct_input->EC_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 619);
                c7_data_struct_input->AN_event_left = false;
              } else {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 621);
                c7_data_struct_input->state = 1;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 622);
                c7_data_struct_input->IC_event_right = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 623);
                c7_data_struct_input->EC_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 624);
                c7_data_struct_input->AN_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 625);
                c7_data_struct_input->stop_Vel_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 626);
                c7_data_struct_input->stop_MA_event_left = false;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 627);
                c7_data_struct_input->stop_IC_event_right = false;
              }
            }
          } else {
            guard45 = true;
          }
        } else {
          guard46 = true;
        }
      } else {
        guard46 = true;
      }

      if (guard46 == true) {
        guard45 = true;
      }

      if (guard45 == true) {
        CV_EML_MCDC(0, 1, 46, false);
        CV_EML_IF(0, 1, 54, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 632);
      if (CV_EML_IF(0, 1, 58, CV_RELATIONAL_EVAL(4U, 0U, 165, (real_T)
            c7_data_struct_input->prevstate, (real_T)c7_data_struct_input->state,
            0, 1U, c7_data_struct_input->prevstate !=
            c7_data_struct_input->state))) {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 633);
        c7_data_struct_input->counter_stop = 0U;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 634);
        c7_data_struct_input->stop_Vel_event_left = false;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 635);
        c7_data_struct_input->stop_MA_event_right = false;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 636);
        c7_data_struct_input->stop_Vel_event_right = false;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 637);
        c7_data_struct_input->stop_MA_event_left = false;
      } else {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 639);
        c7_u45 = (uint32_T)c7_data_struct_input->counter_stop + 1U;
        if (CV_SATURATION_EVAL(4, 0, 33, 0, c7_u45 > 65535U)) {
          c7_u45 = 65535U;
        }

        c7_data_struct_input->counter_stop = (uint16_T)c7_u45;
      }
    } else {
      guard44 = true;
    }
  } else {
    guard44 = true;
  }

  if (guard44 == true) {
    CV_EML_MCDC(0, 1, 0, false);
    CV_EML_IF(0, 1, 0, false);
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 644);
  guard43 = false;
  if (CV_EML_COND(0, 1, 160U, c7_data_struct_input->flag_calib)) {
    if (CV_EML_COND(0, 1, 161U, CV_RELATIONAL_EVAL(4U, 0U, 168, (real_T)
          c7_data_struct_input->calibrating, 0.0, 0, 0U,
          c7_data_struct_input->calibrating == 0))) {
      CV_EML_MCDC(0, 1, 49, true);
      CV_EML_IF(0, 1, 59, true);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 645);
      c7_data_struct_input->calibrating = 1;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 646);
      c7_data_struct_input->counter_stop = 0U;
    } else {
      guard43 = true;
    }
  } else {
    guard43 = true;
  }

  if (guard43 == true) {
    CV_EML_MCDC(0, 1, 49, false);
    CV_EML_IF(0, 1, 59, false);
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 648);
  guard28 = false;
  guard29 = false;
  if (CV_EML_COND(0, 1, 162U, CV_RELATIONAL_EVAL(4U, 0U, 169, (real_T)
        c7_data_struct_input->calibrating, 1.0, -1, 0U, (real_T)
        c7_data_struct_input->calibrating == 1.0))) {
    guard29 = true;
  } else if (CV_EML_COND(0, 1, 163U, CV_RELATIONAL_EVAL(4U, 0U, 170, (real_T)
               c7_data_struct_input->calibrating, 2.0, -1, 0U, (real_T)
               c7_data_struct_input->calibrating == 2.0))) {
    guard29 = true;
  } else if (CV_EML_COND(0, 1, 164U, CV_RELATIONAL_EVAL(4U, 0U, 171, (real_T)
               c7_data_struct_input->calibrating, 3.0, -1, 0U, (real_T)
               c7_data_struct_input->calibrating == 3.0))) {
    guard28 = true;
  } else {
    CV_EML_MCDC(0, 1, 50, false);
    CV_EML_IF(0, 1, 60, false);
  }

  if (guard29 == true) {
    guard28 = true;
  }

  if (guard28 == true) {
    CV_EML_MCDC(0, 1, 50, true);
    CV_EML_IF(0, 1, 60, true);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 651);
    guard41 = false;
    guard42 = false;
    if (CV_EML_COND(0, 1, 165U, CV_RELATIONAL_EVAL(4U, 0U, 172, (real_T)
          c7_data_struct_input->calibrating, 1.0, -1, 0U, (real_T)
          c7_data_struct_input->calibrating == 1.0))) {
      if (CV_EML_COND(0, 1, 166U, CV_RELATIONAL_EVAL(4U, 0U, 173, (real_T)
            c7_data_struct_input->VelRShank[199], 50.0, -1, 5U,
            c7_data_struct_input->VelRShank[199] >= 50.0F))) {
        guard42 = true;
      } else if (CV_EML_COND(0, 1, 167U, CV_RELATIONAL_EVAL(4U, 0U, 174, (real_T)
                   c7_data_struct_input->VelLShank[199], 50.0, -1, 5U,
                   c7_data_struct_input->VelLShank[199] >= 50.0F))) {
        guard42 = true;
      } else {
        guard41 = true;
      }
    } else {
      guard41 = true;
    }

    if (guard42 == true) {
      CV_EML_MCDC(0, 1, 51, true);
      CV_EML_IF(0, 1, 61, true);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 652);
      c7_data_struct_input->index_start_calib = 0U;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 653);
      c7_data_struct_input->calibrating = 2;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 654);
      c7_data_struct_input->counter = 0U;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 655);
      c7_data_struct_input->initial_leg = true;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 656);
      if (CV_EML_IF(0, 1, 62, CV_RELATIONAL_EVAL(4U, 0U, 175, (real_T)
            c7_data_struct_input->VelLShank[199], 50.0, -1, 5U,
            c7_data_struct_input->VelLShank[199] >= 50.0F))) {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 657);
        c7_data_struct_input->initial_leg = false;
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 659);
      c7_data_struct_input->state = -1;
    }

    if (guard41 == true) {
      CV_EML_MCDC(0, 1, 51, false);
      CV_EML_IF(0, 1, 61, false);
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 663);
    for (c7_i447 = 0; c7_i447 < 199; c7_i447++) {
      c7_cd_data_struct_input[c7_i447] = c7_data_struct_input->
        AngRShank_LPF2Hz[c7_i447 + 1];
    }

    for (c7_i448 = 0; c7_i448 < 199; c7_i448++) {
      c7_data_struct_input->AngRShank_LPF2Hz[c7_i448] =
        c7_cd_data_struct_input[c7_i448];
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 664);
    c7_fd_b = c7_data_struct_input->AngRShank[199];
    c7_ld_y = 0.00224619219F * c7_fd_b;
    c7_gd_b = c7_data_struct_input->AngRShank[198];
    c7_md_y = 0.0119676683F * c7_gd_b;
    c7_hd_b = c7_data_struct_input->AngRShank[197];
    c7_nd_y = 0.0342848971F * c7_hd_b;
    c7_id_b = c7_data_struct_input->AngRShank[196];
    c7_od_y = 0.067212306F * c7_id_b;
    c7_jd_b = c7_data_struct_input->AngRShank[195];
    c7_pd_y = 0.0982885659F * c7_jd_b;
    c7_kd_b = c7_data_struct_input->AngRShank[194];
    c7_qd_y = 0.111179359F * c7_kd_b;
    c7_ld_b = c7_data_struct_input->AngRShank[193];
    c7_rd_y = 0.0982885659F * c7_ld_b;
    c7_md_b = c7_data_struct_input->AngRShank[192];
    c7_sd_y = 0.067212306F * c7_md_b;
    c7_nd_b = c7_data_struct_input->AngRShank[191];
    c7_td_y = 0.0342848971F * c7_nd_b;
    c7_od_b = c7_data_struct_input->AngRShank[190];
    c7_ud_y = 0.0119676683F * c7_od_b;
    c7_pd_b = c7_data_struct_input->AngRShank[189];
    c7_vd_y = 0.00224619219F * c7_pd_b;
    c7_data_struct_input->AngRShank_LPF2Hz[199] = (((((((((c7_ld_y + c7_md_y) +
      c7_nd_y) + c7_od_y) + c7_pd_y) + c7_qd_y) + c7_rd_y) + c7_sd_y) + c7_td_y)
      + c7_ud_y) + c7_vd_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 667);
    for (c7_i449 = 0; c7_i449 < 199; c7_i449++) {
      c7_dd_data_struct_input[c7_i449] = c7_data_struct_input->
        AngLShank_LPF2Hz[c7_i449 + 1];
    }

    for (c7_i450 = 0; c7_i450 < 199; c7_i450++) {
      c7_data_struct_input->AngLShank_LPF2Hz[c7_i450] =
        c7_dd_data_struct_input[c7_i450];
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 668);
    c7_qd_b = c7_data_struct_input->AngLShank[199];
    c7_wd_y = 0.00224619219F * c7_qd_b;
    c7_rd_b = c7_data_struct_input->AngLShank[198];
    c7_xd_y = 0.0119676683F * c7_rd_b;
    c7_sd_b = c7_data_struct_input->AngLShank[197];
    c7_yd_y = 0.0342848971F * c7_sd_b;
    c7_td_b = c7_data_struct_input->AngLShank[196];
    c7_ae_y = 0.067212306F * c7_td_b;
    c7_ud_b = c7_data_struct_input->AngLShank[195];
    c7_be_y = 0.0982885659F * c7_ud_b;
    c7_vd_b = c7_data_struct_input->AngLShank[194];
    c7_ce_y = 0.111179359F * c7_vd_b;
    c7_wd_b = c7_data_struct_input->AngLShank[193];
    c7_de_y = 0.0982885659F * c7_wd_b;
    c7_xd_b = c7_data_struct_input->AngLShank[192];
    c7_ee_y = 0.067212306F * c7_xd_b;
    c7_yd_b = c7_data_struct_input->AngLShank[191];
    c7_fe_y = 0.0342848971F * c7_yd_b;
    c7_ae_b = c7_data_struct_input->AngLShank[190];
    c7_ge_y = 0.0119676683F * c7_ae_b;
    c7_be_b = c7_data_struct_input->AngLShank[189];
    c7_he_y = 0.00224619219F * c7_be_b;
    c7_data_struct_input->AngLShank_LPF2Hz[199] = (((((((((c7_wd_y + c7_xd_y) +
      c7_yd_y) + c7_ae_y) + c7_be_y) + c7_ce_y) + c7_de_y) + c7_ee_y) + c7_fe_y)
      + c7_ge_y) + c7_he_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 672);
    c7_u46 = (uint32_T)c7_data_struct_input->index_start_calib + 1U;
    if (CV_SATURATION_EVAL(4, 0, 34, 0, c7_u46 > 65535U)) {
      c7_u46 = 65535U;
    }

    c7_data_struct_input->index_start_calib = (uint16_T)c7_u46;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 677);
    guard37 = false;
    guard38 = false;
    guard39 = false;
    if (CV_EML_COND(0, 1, 168U, CV_RELATIONAL_EVAL(4U, 0U, 176, (real_T)
          c7_data_struct_input->calibrating, 2.0, 0, 0U,
          c7_data_struct_input->calibrating == 2))) {
      if (CV_EML_COND(0, 1, 169U, c7_data_struct_input->initial_leg)) {
        if (CV_EML_COND(0, 1, 170U, CV_RELATIONAL_EVAL(4U, 0U, 179, (real_T)
              c7_data_struct_input->AngLShank_LPF2Hz[198], 0.0, -1, 4U,
              c7_data_struct_input->AngLShank_LPF2Hz[198] > 0.0F))) {
          if (CV_EML_COND(0, 1, 171U, CV_RELATIONAL_EVAL(4U, 0U, 180, (real_T)
                c7_data_struct_input->AngLShank_LPF2Hz[199], 0.0, -1, 2U,
                c7_data_struct_input->AngLShank_LPF2Hz[199] < 0.0F))) {
            CV_EML_MCDC(0, 1, 52, true);
            CV_EML_IF(0, 1, 63, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 678);
            if (CV_EML_IF(0, 1, 64, CV_RELATIONAL_EVAL(4U, 0U, 181, (real_T)
                  c7_data_struct_input->counter, 0.0, -1, 0U, (real_T)
                  c7_data_struct_input->counter == 0.0))) {
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 679);
              c7_index = 1.0;
              _SFD_SYMBOL_SWITCH(2U, 2U);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 680);
              c7_found = 0.0;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 681);
              exitg22 = false;
              while ((exitg22 == false) && (c7_index < 200.0)) {
                if (c7_found == 0.0) {
                  CV_EML_WHILE(0, 1, 8, true);
                  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 682);
                  c7_f35 = c7_data_struct_input->
                    AngLShank_LPF2Hz[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 44405,
                     47, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  guard40 = false;
                  if (CV_EML_COND(0, 1, 172U, CV_RELATIONAL_EVAL(4U, 0U, 182,
                        (real_T)c7_data_struct_input->AngLShank_LPF2Hz[(int32_T)
                        (200.0 - c7_index) - 1], (real_T)c7_f35, -3, 4U,
                        c7_data_struct_input->AngLShank_LPF2Hz[(int32_T)(200.0 -
                         c7_index) - 1] > c7_f35))) {
                    if (CV_EML_COND(0, 1, 173U, CV_RELATIONAL_EVAL(4U, 0U, 183,
                          (real_T)c7_data_struct_input->AngLShank_LPF2Hz
                          [(int32_T)(200.0 - c7_index) - 1], (real_T)
                          c7_data_struct_input->AngLShank_LPF2Hz[(int32_T)
                          ((200.0 - c7_index) + 1.0) - 1], -3, 4U,
                          c7_data_struct_input->AngLShank_LPF2Hz[(int32_T)(200.0
                           - c7_index) - 1] >
                          c7_data_struct_input->AngLShank_LPF2Hz[(int32_T)
                          ((200.0 - c7_index) + 1.0) - 1]))) {
                      CV_EML_MCDC(0, 1, 53, true);
                      CV_EML_IF(0, 1, 65, true);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 683);
                      c7_found = 1.0;
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 684);
                      c7_d21 = muDoubleScalarRound(c7_index + 10.0);
                      if (c7_d21 < 65536.0) {
                        if (CV_SATURATION_EVAL(4, 0, 35, 1, c7_d21 >= 0.0)) {
                          c7_u47 = (uint16_T)c7_d21;
                        } else {
                          c7_u47 = 0U;
                        }
                      } else if (CV_SATURATION_EVAL(4, 0, 35, 0, c7_d21 >=
                                  65536.0)) {
                        c7_u47 = MAX_uint16_T;
                      } else {
                        c7_u47 = 0U;
                      }

                      c7_data_struct_input->index_start_calib = c7_u47;
                    } else {
                      guard40 = true;
                    }
                  } else {
                    guard40 = true;
                  }

                  if (guard40 == true) {
                    CV_EML_MCDC(0, 1, 53, false);
                    CV_EML_IF(0, 1, 65, false);
                  }

                  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 686);
                  c7_index++;
                  _SFD_SYMBOL_SWITCH(2U, 2U);
                  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 681);
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                } else {
                  exitg22 = true;
                }
              }

              CV_EML_WHILE(0, 1, 8, false);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 688);
              if (CV_EML_IF(0, 1, 66, CV_RELATIONAL_EVAL(4U, 0U, 184, c7_found,
                    0.0, -1, 0U, c7_found == 0.0))) {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 689);
                c7_data_struct_input->index_start_calib = 0U;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 690);
                c7_data_struct_input->index_stop_calib = 1U;
              }
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 693);
            c7_u48 = (uint32_T)c7_data_struct_input->counter + 1U;
            if (CV_SATURATION_EVAL(4, 0, 36, 0, c7_u48 > 255U)) {
              c7_u48 = 255U;
            }

            c7_data_struct_input->counter = (uint8_T)c7_u48;
          } else {
            guard37 = true;
          }
        } else {
          guard38 = true;
        }
      } else {
        guard39 = true;
      }
    } else {
      guard39 = true;
    }

    if (guard39 == true) {
      guard38 = true;
    }

    if (guard38 == true) {
      guard37 = true;
    }

    if (guard37 == true) {
      CV_EML_MCDC(0, 1, 52, false);
      CV_EML_IF(0, 1, 63, false);
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 695);
    guard33 = false;
    guard34 = false;
    guard35 = false;
    if (CV_EML_COND(0, 1, 174U, CV_RELATIONAL_EVAL(4U, 0U, 185, (real_T)
          c7_data_struct_input->calibrating, 2.0, 0, 0U,
          c7_data_struct_input->calibrating == 2))) {
      if (CV_EML_COND(0, 1, 175U, !c7_data_struct_input->initial_leg)) {
        if (CV_EML_COND(0, 1, 176U, CV_RELATIONAL_EVAL(4U, 0U, 188, (real_T)
              c7_data_struct_input->AngRShank_LPF2Hz[198], 0.0, -1, 4U,
              c7_data_struct_input->AngRShank_LPF2Hz[198] > 0.0F))) {
          if (CV_EML_COND(0, 1, 177U, CV_RELATIONAL_EVAL(4U, 0U, 189, (real_T)
                c7_data_struct_input->AngRShank_LPF2Hz[199], 0.0, -1, 2U,
                c7_data_struct_input->AngRShank_LPF2Hz[199] < 0.0F))) {
            CV_EML_MCDC(0, 1, 54, true);
            CV_EML_IF(0, 1, 67, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 696);
            if (CV_EML_IF(0, 1, 68, CV_RELATIONAL_EVAL(4U, 0U, 190, (real_T)
                  c7_data_struct_input->counter, 0.0, -1, 0U, (real_T)
                  c7_data_struct_input->counter == 0.0))) {
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 697);
              c7_index = 1.0;
              _SFD_SYMBOL_SWITCH(2U, 2U);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 698);
              c7_found = 0.0;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 699);
              exitg21 = false;
              while ((exitg21 == false) && (c7_index < 200.0)) {
                if (c7_found == 0.0) {
                  CV_EML_WHILE(0, 1, 9, true);
                  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 700);
                  c7_f36 = c7_data_struct_input->
                    AngRShank_LPF2Hz[sf_eml_array_bounds_check
                    (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 45467,
                     47, MAX_uint32_T, (int32_T)((200.0 - c7_index) - 1.0), 1,
                     200) - 1];
                  guard36 = false;
                  if (CV_EML_COND(0, 1, 178U, CV_RELATIONAL_EVAL(4U, 0U, 191,
                        (real_T)c7_data_struct_input->AngRShank_LPF2Hz[(int32_T)
                        (200.0 - c7_index) - 1], (real_T)c7_f36, -3, 4U,
                        c7_data_struct_input->AngRShank_LPF2Hz[(int32_T)(200.0 -
                         c7_index) - 1] > c7_f36))) {
                    if (CV_EML_COND(0, 1, 179U, CV_RELATIONAL_EVAL(4U, 0U, 192,
                          (real_T)c7_data_struct_input->AngRShank_LPF2Hz
                          [(int32_T)(200.0 - c7_index) - 1], (real_T)
                          c7_data_struct_input->AngRShank_LPF2Hz[(int32_T)
                          ((200.0 - c7_index) + 1.0) - 1], -3, 4U,
                          c7_data_struct_input->AngRShank_LPF2Hz[(int32_T)(200.0
                           - c7_index) - 1] >
                          c7_data_struct_input->AngRShank_LPF2Hz[(int32_T)
                          ((200.0 - c7_index) + 1.0) - 1]))) {
                      CV_EML_MCDC(0, 1, 55, true);
                      CV_EML_IF(0, 1, 69, true);
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 701);
                      c7_found = 1.0;
                      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 702);
                      c7_d22 = muDoubleScalarRound(c7_index + 10.0);
                      if (c7_d22 < 65536.0) {
                        if (CV_SATURATION_EVAL(4, 0, 37, 1, c7_d22 >= 0.0)) {
                          c7_u49 = (uint16_T)c7_d22;
                        } else {
                          c7_u49 = 0U;
                        }
                      } else if (CV_SATURATION_EVAL(4, 0, 37, 0, c7_d22 >=
                                  65536.0)) {
                        c7_u49 = MAX_uint16_T;
                      } else {
                        c7_u49 = 0U;
                      }

                      c7_data_struct_input->index_start_calib = c7_u49;
                    } else {
                      guard36 = true;
                    }
                  } else {
                    guard36 = true;
                  }

                  if (guard36 == true) {
                    CV_EML_MCDC(0, 1, 55, false);
                    CV_EML_IF(0, 1, 69, false);
                  }

                  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 704);
                  c7_index++;
                  _SFD_SYMBOL_SWITCH(2U, 2U);
                  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 699);
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                } else {
                  exitg21 = true;
                }
              }

              CV_EML_WHILE(0, 1, 9, false);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 706);
              if (CV_EML_IF(0, 1, 70, CV_RELATIONAL_EVAL(4U, 0U, 193, c7_found,
                    0.0, -1, 0U, c7_found == 0.0))) {
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 707);
                c7_data_struct_input->index_start_calib = 0U;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 708);
                c7_data_struct_input->index_stop_calib = 1U;
              }
            }

            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 711);
            c7_u50 = (uint32_T)c7_data_struct_input->counter + 1U;
            if (CV_SATURATION_EVAL(4, 0, 38, 0, c7_u50 > 255U)) {
              c7_u50 = 255U;
            }

            c7_data_struct_input->counter = (uint8_T)c7_u50;
          } else {
            guard33 = true;
          }
        } else {
          guard34 = true;
        }
      } else {
        guard35 = true;
      }
    } else {
      guard35 = true;
    }

    if (guard35 == true) {
      guard34 = true;
    }

    if (guard34 == true) {
      guard33 = true;
    }

    if (guard33 == true) {
      CV_EML_MCDC(0, 1, 54, false);
      CV_EML_IF(0, 1, 67, false);
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 713);
    guard32 = false;
    if (CV_EML_COND(0, 1, 180U, CV_RELATIONAL_EVAL(4U, 0U, 194, (real_T)
          c7_data_struct_input->calibrating, 2.0, 0, 0U,
          c7_data_struct_input->calibrating == 2))) {
      if (CV_EML_COND(0, 1, 181U, CV_RELATIONAL_EVAL(4U, 0U, 195, (real_T)
            c7_data_struct_input->counter, 3.0, -1, 5U, (real_T)
            c7_data_struct_input->counter >= 3.0))) {
        CV_EML_MCDC(0, 1, 56, true);
        CV_EML_IF(0, 1, 71, true);
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 714);
        c7_data_struct_input->calibrating = 3;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 715);
        if (CV_EML_IF(0, 1, 72, CV_RELATIONAL_EVAL(4U, 0U, 196, (real_T)
              c7_data_struct_input->index_stop_calib, 1.0, 0, 0U,
              c7_data_struct_input->index_stop_calib == 1))) {
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 716);
          c7_m_A = c7_data_struct_input->index_start_calib;
          c7_e_x = c7_m_A;
          c7_f_x = c7_e_x;
          c7_g_x = c7_f_x;
          c7_h_x = c7_g_x;
          c7_xk = (real_T)c7_h_x;
          c7_d23 = muDoubleScalarRound(c7_xk / 4.0);
          if (c7_d23 < 65536.0) {
            if (CV_SATURATION_EVAL(4, 0, 40, 1, c7_d23 >= 0.0)) {
              c7_u51 = (uint16_T)c7_d23;
            } else {
              c7_u51 = 0U;
            }
          } else if (CV_SATURATION_EVAL(4, 0, 40, 0, c7_d23 >= 65536.0)) {
            c7_u51 = MAX_uint16_T;
          } else {
            c7_u51 = 0U;
          }

          c7_ie_y = c7_u51;
          c7_u52 = (uint32_T)c7_data_struct_input->index_start_calib + (uint32_T)
            c7_ie_y;
          if (CV_SATURATION_EVAL(4, 0, 39, 0, c7_u52 > 65535U)) {
            c7_u52 = 65535U;
          }

          c7_u53 = (uint16_T)c7_u52;
          c7_b_ceil(chartInstance, &c7_u53);
          c7_data_struct_input->index_stop_calib = c7_u53;
        }

        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 718);
        c7_uv24[0] = c7_data_struct_input->index_stop_calib;
        c7_b45 = ((real_T)c7_data_struct_input->index_stop_calib > 200.0);
        c7_ac_trueCount = 0;
        c7_de_i = 0;
        while (c7_de_i <= 0) {
          if (c7_b45) {
            c7_ac_trueCount++;
          }

          c7_de_i++;
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        }

        c7_ac_partialTrueCount = 0;
        c7_ee_i = 0;
        while (c7_ee_i <= 0) {
          if (c7_b45) {
            c7_iv0[0] = 1;
            c7_iv0[1] = c7_ac_trueCount;
            c7_g_tmp_sizes[0] = 1;
            c7_g_tmp_sizes[1] = c7_iv0[1];
            c7_i451 = c7_g_tmp_sizes[0];
            c7_i452 = c7_g_tmp_sizes[1];
            c7_ic_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
            for (c7_i453 = 0; c7_i453 <= c7_ic_loop_ub; c7_i453++) {
              c7_g_tmp_data[c7_i453] = 200U;
            }

            c7_uv24[c7_ee_i] = c7_g_tmp_data[c7_ac_partialTrueCount];
            c7_ac_partialTrueCount++;
          }

          c7_ee_i++;
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        }

        c7_data_struct_input->index_stop_calib = c7_uv24[0];
      } else {
        guard32 = true;
      }
    } else {
      guard32 = true;
    }

    if (guard32 == true) {
      CV_EML_MCDC(0, 1, 56, false);
      CV_EML_IF(0, 1, 71, false);
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 721);
    guard31 = false;
    if (CV_EML_COND(0, 1, 182U, CV_RELATIONAL_EVAL(4U, 0U, 197, (real_T)
          c7_data_struct_input->calibrating, 3.0, 0, 0U,
          c7_data_struct_input->calibrating == 3))) {
      if (CV_EML_COND(0, 1, 183U, CV_RELATIONAL_EVAL(4U, 0U, 198, (real_T)
            c7_data_struct_input->index_start_calib, (real_T)
            c7_data_struct_input->index_stop_calib, 0, 5U,
            c7_data_struct_input->index_start_calib >=
            c7_data_struct_input->index_stop_calib))) {
        CV_EML_MCDC(0, 1, 57, true);
        CV_EML_IF(0, 1, 73, true);
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 722);
        c7_data_struct_input->calibrating = 4;
      } else {
        guard31 = true;
      }
    } else {
      guard31 = true;
    }

    if (guard31 == true) {
      CV_EML_MCDC(0, 1, 57, false);
      CV_EML_IF(0, 1, 73, false);
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 727);
    guard30 = false;
    if (CV_EML_COND(0, 1, 184U, CV_RELATIONAL_EVAL(4U, 0U, 199, (real_T)
          c7_data_struct_input->VelRShank[199], 20.0, -1, 3U,
          c7_data_struct_input->VelRShank[199] <= 20.0F))) {
      if (CV_EML_COND(0, 1, 185U, CV_RELATIONAL_EVAL(4U, 0U, 200, (real_T)
            c7_data_struct_input->VelLShank[199], 20.0, -1, 2U,
            c7_data_struct_input->VelLShank[199] < 20.0F))) {
        CV_EML_MCDC(0, 1, 58, true);
        CV_EML_IF(0, 1, 74, true);
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 728);
        c7_u54 = (uint32_T)c7_data_struct_input->counter_stop + 1U;
        if (CV_SATURATION_EVAL(4, 0, 41, 0, c7_u54 > 65535U)) {
          c7_u54 = 65535U;
        }

        c7_data_struct_input->counter_stop = (uint16_T)c7_u54;
      } else {
        guard30 = true;
      }
    } else {
      guard30 = true;
    }

    if (guard30 == true) {
      CV_EML_MCDC(0, 1, 58, false);
      CV_EML_IF(0, 1, 74, false);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 730);
      c7_data_struct_input->counter_stop = 0U;
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 733);
    if (CV_EML_IF(0, 1, 75, CV_RELATIONAL_EVAL(4U, 0U, 201, (real_T)
          c7_data_struct_input->counter_stop, 100.0, -1, 4U, (real_T)
          c7_data_struct_input->counter_stop > 100.0))) {
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 734);
      c7_data_struct_input->index_start_calib = 0U;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 735);
      c7_data_struct_input->calibrating = 0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 736);
      c7_data_struct_input->counter = 0U;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 737);
      c7_data_struct_input->state = 0;
    }
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 742);
  if (CV_EML_IF(0, 1, 76, CV_RELATIONAL_EVAL(4U, 0U, 202, (real_T)
        c7_data_struct_input->calibrating, 4.0, 0, 0U,
        c7_data_struct_input->calibrating == 4))) {
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 744);
    c7_uv25[0] = c7_data_struct_input->index_start_calib;
    c7_b46 = ((real_T)c7_data_struct_input->index_start_calib >= 200.0);
    c7_bc_trueCount = 0;
    c7_fe_i = 0;
    while (c7_fe_i <= 0) {
      if (c7_b46) {
        c7_bc_trueCount++;
      }

      c7_fe_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_bc_partialTrueCount = 0;
    c7_ge_i = 0;
    while (c7_ge_i <= 0) {
      if (c7_b46) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_bc_trueCount;
        c7_g_tmp_sizes[0] = 1;
        c7_g_tmp_sizes[1] = c7_iv0[1];
        c7_i454 = c7_g_tmp_sizes[0];
        c7_i455 = c7_g_tmp_sizes[1];
        c7_jc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i456 = 0; c7_i456 <= c7_jc_loop_ub; c7_i456++) {
          c7_g_tmp_data[c7_i456] = 199U;
        }

        c7_uv25[c7_ge_i] = c7_g_tmp_data[c7_bc_partialTrueCount];
        c7_bc_partialTrueCount++;
      }

      c7_ge_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->index_start_calib = c7_uv25[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 746);
    for (c7_i457 = 0; c7_i457 < 5; c7_i457++) {
      c7_b_MS_inds_right[c7_i457] = 0.0;
    }

    _SFD_SYMBOL_SWITCH(9U, 20U);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 747);
    c7_MS_inds_index_right = 1.0;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 748);
    for (c7_i458 = 0; c7_i458 < 5; c7_i458++) {
      c7_b_MS_inds_left[c7_i458] = 0.0;
    }

    _SFD_SYMBOL_SWITCH(3U, 21U);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 749);
    c7_MS_inds_index_left = 1.0;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 750);
    for (c7_i459 = 0; c7_i459 < 5; c7_i459++) {
      c7_b_EC_distance_right[c7_i459] = 0.0;
    }

    _SFD_SYMBOL_SWITCH(11U, 22U);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 751);
    for (c7_i460 = 0; c7_i460 < 5; c7_i460++) {
      c7_b_EC_distance_left[c7_i460] = 0.0;
    }

    _SFD_SYMBOL_SWITCH(5U, 23U);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 752);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 753);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 754);
    for (c7_i461 = 0; c7_i461 < 5; c7_i461++) {
      c7_b_EC_events_inds_right[c7_i461] = 0.0;
    }

    _SFD_SYMBOL_SWITCH(10U, 24U);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 755);
    for (c7_i462 = 0; c7_i462 < 5; c7_i462++) {
      c7_b_EC_events_inds_left[c7_i462] = 0.0;
    }

    _SFD_SYMBOL_SWITCH(4U, 25U);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 756);
    for (c7_i463 = 0; c7_i463 < 5; c7_i463++) {
      c7_IC_LPF_inds_right[c7_i463] = 0.0;
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 757);
    for (c7_i464 = 0; c7_i464 < 5; c7_i464++) {
      c7_IC_LPF_inds_left[c7_i464] = 0.0;
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 758);
    for (c7_i465 = 0; c7_i465 < 5; c7_i465++) {
      c7_IC_inds_right[c7_i465] = 0.0;
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 759);
    for (c7_i466 = 0; c7_i466 < 5; c7_i466++) {
      c7_IC_inds_left[c7_i466] = 0.0;
    }

    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 762);
    c7_c_q0 = 200U;
    c7_c_qY = c7_c_q0 - (uint32_T)c7_data_struct_input->index_start_calib;
    if (CV_SATURATION_EVAL(4, 0, 42, 0, c7_c_qY > c7_c_q0)) {
      c7_c_qY = 0U;
    }

    c7_u55 = c7_c_qY;
    if (CV_SATURATION_EVAL(4, 0, 42, 0, c7_u55 > 65535U)) {
      c7_u55 = 65535U;
    }

    c7_u56 = (uint32_T)(uint16_T)c7_u55 + 1U;
    if (CV_SATURATION_EVAL(4, 0, 43, 0, c7_u56 > 65535U)) {
      c7_u56 = 65535U;
    }

    c7_u57 = (uint16_T)c7_u56;
    c7_he_i = c7_u57;
    while (c7_he_i < 200) {
      c7_i = c7_he_i;
      _SFD_SYMBOL_SWITCH(18U, 18U);
      CV_EML_FOR(0, 1, 2, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 764);
      c7_d_q0 = c7_i;
      c7_d_qY = c7_d_q0 - 1U;
      if (CV_SATURATION_EVAL(4, 0, 44, 0, c7_d_qY > c7_d_q0)) {
        c7_d_qY = 0U;
      }

      c7_u58 = c7_d_qY;
      if (CV_SATURATION_EVAL(4, 0, 44, 0, c7_u58 > 65535U)) {
        c7_u58 = 65535U;
      }

      c7_f37 = c7_data_struct_input->AngRShank_LPF[(uint16_T)
        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct, chartInstance->S,
        5U, 48413, 36, MAX_uint32_T, (int32_T)(uint16_T)c7_u58, 1, 200) - 1];
      guard24 = false;
      guard25 = false;
      if (CV_EML_COND(0, 1, 186U, CV_RELATIONAL_EVAL(4U, 0U, 203, (real_T)
            c7_data_struct_input->AngRShank_LPF[c7_i - 1], (real_T)c7_f37, -3,
            4U, c7_data_struct_input->AngRShank_LPF[c7_i - 1] > c7_f37))) {
        c7_u59 = (uint32_T)c7_i + 1U;
        if (CV_SATURATION_EVAL(4, 0, 45, 0, c7_u59 > 65535U)) {
          c7_u59 = 65535U;
        }

        c7_u60 = (uint32_T)c7_i + 1U;
        if (CV_SATURATION_EVAL(4, 0, 45, 0, c7_u60 > 65535U)) {
          c7_u60 = 65535U;
        }

        if (CV_EML_COND(0, 1, 187U, CV_RELATIONAL_EVAL(4U, 0U, 204, (real_T)
              c7_data_struct_input->AngRShank_LPF[c7_i - 1], (real_T)
              c7_data_struct_input->AngRShank_LPF[(uint16_T)c7_u59 - 1], -3, 4U,
              c7_data_struct_input->AngRShank_LPF[c7_i - 1] >
              c7_data_struct_input->AngRShank_LPF[(uint16_T)c7_u60 - 1]))) {
          if (CV_EML_COND(0, 1, 188U, CV_RELATIONAL_EVAL(4U, 0U, 205, (real_T)
                c7_data_struct_input->AngRShank_LPF[c7_i - 1], 0.0, -1, 4U,
                c7_data_struct_input->AngRShank_LPF[c7_i - 1] > 0.0F))) {
            CV_EML_MCDC(0, 1, 59, true);
            CV_EML_IF(0, 1, 77, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 765);
            c7_data_struct_input->MA_LPF_maxs_right[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 48581, 73, MAX_uint32_T, (int32_T)
              c7_data_struct_input->MA_LPF_index_right, 1, 5) - 1] =
              c7_data_struct_input->AngRShank_LPF[c7_i - 1];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 766);
            c7_u61 = (uint32_T)c7_data_struct_input->MA_LPF_index_right + 1U;
            if (CV_SATURATION_EVAL(4, 0, 46, 0, c7_u61 > 255U)) {
              c7_u61 = 255U;
            }

            c7_data_struct_input->MA_LPF_index_right = (uint8_T)c7_u61;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 767);
            c7_uv26[0] = c7_data_struct_input->MA_LPF_index_right;
            c7_b47 = ((real_T)c7_data_struct_input->MA_LPF_index_right > 5.0);
            c7_cc_trueCount = 0;
            c7_ie_i = 0;
            while (c7_ie_i <= 0) {
              if (c7_b47) {
                c7_cc_trueCount++;
              }

              c7_ie_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_cc_partialTrueCount = 0;
            c7_je_i = 0;
            while (c7_je_i <= 0) {
              if (c7_b47) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_cc_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i467 = c7_tmp_sizes[0];
                c7_i468 = c7_tmp_sizes[1];
                c7_kc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i469 = 0; c7_i469 <= c7_kc_loop_ub; c7_i469++) {
                  c7_tmp_data[c7_i469] = 5U;
                }

                c7_uv26[c7_je_i] = c7_tmp_data[c7_cc_partialTrueCount];
                c7_cc_partialTrueCount++;
              }

              c7_je_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->MA_LPF_index_right = c7_uv26[0];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 769);
            c7_b_index = c7_i;
            _SFD_SYMBOL_SWITCH(2U, 29U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 770);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 772);
            exitg20 = false;
            while ((exitg20 == false) && (c7_found == 0.0)) {
              c7_e_q0 = 200U;
              c7_e_qY = c7_e_q0 - (uint32_T)
                c7_data_struct_input->index_start_calib;
              if (CV_SATURATION_EVAL(4, 0, 47, 0, c7_e_qY > c7_e_q0)) {
                c7_e_qY = 0U;
              }

              c7_u62 = c7_e_qY;
              if (CV_SATURATION_EVAL(4, 0, 47, 0, c7_u62 > 65535U)) {
                c7_u62 = 65535U;
              }

              c7_u63 = (uint32_T)(uint16_T)c7_u62 + 1U;
              if (CV_SATURATION_EVAL(4, 0, 48, 0, c7_u63 > 65535U)) {
                c7_u63 = 65535U;
              }

              if (c7_b_index > (uint16_T)c7_u63) {
                CV_EML_WHILE(0, 1, 10, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 773);
                c7_f_q0 = c7_b_index;
                c7_f_qY = c7_f_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 49, 0, c7_f_qY > c7_f_q0)) {
                  c7_f_qY = 0U;
                }

                c7_u64 = c7_f_qY;
                if (CV_SATURATION_EVAL(4, 0, 49, 0, c7_u64 > 65535U)) {
                  c7_u64 = 65535U;
                }

                c7_g_q0 = c7_b_index;
                c7_g_qY = c7_g_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 49, 0, c7_g_qY > c7_g_q0)) {
                  c7_g_qY = 0U;
                }

                c7_u65 = c7_g_qY;
                if (CV_SATURATION_EVAL(4, 0, 49, 0, c7_u65 > 65535U)) {
                  c7_u65 = 65535U;
                }

                guard27 = false;
                if (CV_EML_COND(0, 1, 189U, CV_RELATIONAL_EVAL(4U, 0U, 206,
                      (real_T)c7_data_struct_input->AngRShank_filt[c7_b_index -
                      1], (real_T)c7_data_struct_input->AngRShank_filt[(uint16_T)
                      c7_u64 - 1], -3, 4U, c7_data_struct_input->
                      AngRShank_filt[c7_b_index - 1] >
                      c7_data_struct_input->AngRShank_filt[(uint16_T)c7_u65 - 1])))
                {
                  c7_u66 = (uint32_T)c7_b_index + 1U;
                  if (CV_SATURATION_EVAL(4, 0, 50, 0, c7_u66 > 65535U)) {
                    c7_u66 = 65535U;
                  }

                  c7_u67 = (uint32_T)c7_b_index + 1U;
                  if (CV_SATURATION_EVAL(4, 0, 50, 0, c7_u67 > 65535U)) {
                    c7_u67 = 65535U;
                  }

                  if (CV_EML_COND(0, 1, 190U, CV_RELATIONAL_EVAL(4U, 0U, 207,
                        (real_T)c7_data_struct_input->AngRShank_filt[c7_b_index
                        - 1], (real_T)c7_data_struct_input->AngRShank_filt
                        [(uint16_T)c7_u66 - 1], -3, 4U,
                        c7_data_struct_input->AngRShank_filt[c7_b_index - 1] >
                        c7_data_struct_input->AngRShank_filt[(uint16_T)c7_u67 -
                        1]))) {
                    CV_EML_MCDC(0, 1, 60, true);
                    CV_EML_IF(0, 1, 78, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 774);
                    c7_data_struct_input->MA_maxs_right[(uint8_T)
                      sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                      chartInstance->S, 5U, 49329, 65, MAX_uint32_T, (int32_T)
                      c7_data_struct_input->MA_index_right, 1, 5) - 1] =
                      c7_data_struct_input->AngRShank_filt[c7_b_index - 1];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 775);
                    c7_found = 1.0;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 776);
                    c7_u68 = (uint32_T)c7_data_struct_input->MA_index_right + 1U;
                    if (CV_SATURATION_EVAL(4, 0, 51, 0, c7_u68 > 255U)) {
                      c7_u68 = 255U;
                    }

                    c7_data_struct_input->MA_index_right = (uint8_T)c7_u68;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 777);
                    c7_uv27[0] = c7_data_struct_input->MA_index_right;
                    c7_b48 = ((real_T)c7_data_struct_input->MA_index_right > 5.0);
                    c7_dc_trueCount = 0;
                    c7_ke_i = 0;
                    while (c7_ke_i <= 0) {
                      if (c7_b48) {
                        c7_dc_trueCount++;
                      }

                      c7_ke_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_dc_partialTrueCount = 0;
                    c7_le_i = 0;
                    while (c7_le_i <= 0) {
                      if (c7_b48) {
                        c7_iv0[0] = 1;
                        c7_iv0[1] = c7_dc_trueCount;
                        c7_tmp_sizes[0] = 1;
                        c7_tmp_sizes[1] = c7_iv0[1];
                        c7_i470 = c7_tmp_sizes[0];
                        c7_i471 = c7_tmp_sizes[1];
                        c7_lc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                        for (c7_i472 = 0; c7_i472 <= c7_lc_loop_ub; c7_i472++) {
                          c7_tmp_data[c7_i472] = 5U;
                        }

                        c7_uv27[c7_le_i] = c7_tmp_data[c7_dc_partialTrueCount];
                        c7_dc_partialTrueCount++;
                      }

                      c7_le_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_data_struct_input->MA_index_right = c7_uv27[0];
                  } else {
                    guard27 = true;
                  }
                } else {
                  guard27 = true;
                }

                if (guard27 == true) {
                  CV_EML_MCDC(0, 1, 60, false);
                  CV_EML_IF(0, 1, 78, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 779);
                c7_h_q0 = c7_b_index;
                c7_h_qY = c7_h_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 52, 0, c7_h_qY > c7_h_q0)) {
                  c7_h_qY = 0U;
                }

                c7_u69 = c7_h_qY;
                if (CV_SATURATION_EVAL(4, 0, 52, 0, c7_u69 > 65535U)) {
                  c7_u69 = 65535U;
                }

                c7_b_index = (uint16_T)c7_u69;
                _SFD_SYMBOL_SWITCH(2U, 29U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 772);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg20 = true;
              }
            }

            CV_EML_WHILE(0, 1, 10, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 783);
            c7_u70 = (uint32_T)c7_b_index + 1U;
            if (CV_SATURATION_EVAL(4, 0, 53, 0, c7_u70 > 65535U)) {
              c7_u70 = 65535U;
            }

            c7_b_index = (uint16_T)c7_u70;
            _SFD_SYMBOL_SWITCH(2U, 29U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 784);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 785);
            exitg19 = false;
            while ((exitg19 == false) && (c7_found == 0.0)) {
              if ((real_T)c7_b_index < 199.0) {
                CV_EML_WHILE(0, 1, 11, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 786);
                c7_i_q0 = c7_b_index;
                c7_i_qY = c7_i_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 54, 0, c7_i_qY > c7_i_q0)) {
                  c7_i_qY = 0U;
                }

                c7_u71 = c7_i_qY;
                if (CV_SATURATION_EVAL(4, 0, 54, 0, c7_u71 > 65535U)) {
                  c7_u71 = 65535U;
                }

                c7_j_q0 = c7_b_index;
                c7_j_qY = c7_j_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 54, 0, c7_j_qY > c7_j_q0)) {
                  c7_j_qY = 0U;
                }

                c7_u72 = c7_j_qY;
                if (CV_SATURATION_EVAL(4, 0, 54, 0, c7_u72 > 65535U)) {
                  c7_u72 = 65535U;
                }

                guard26 = false;
                if (CV_EML_COND(0, 1, 191U, CV_RELATIONAL_EVAL(4U, 0U, 208,
                      (real_T)c7_data_struct_input->AngRShank_filt[(uint16_T)
                      c7_u71 - 1], 0.0, -1, 5U,
                      c7_data_struct_input->AngRShank_filt[(uint16_T)c7_u72 - 1]
                      >= 0.0F))) {
                  if (CV_EML_COND(0, 1, 192U, CV_RELATIONAL_EVAL(4U, 0U, 209,
                        (real_T)c7_data_struct_input->AngRShank_filt[c7_b_index
                        - 1], 0.0, -1, 3U, c7_data_struct_input->
                        AngRShank_filt[c7_b_index - 1] <= 0.0F))) {
                    CV_EML_MCDC(0, 1, 61, true);
                    CV_EML_IF(0, 1, 79, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 787);
                    c7_b_MS_inds_right[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 50075,
                       34, 0U, (int32_T)c7_MS_inds_index_right, 1, 5) - 1] =
                      (real_T)c7_b_index;
                    _SFD_SYMBOL_SWITCH(9U, 20U);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 788);
                    c7_found = 1.0;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 789);
                    c7_MS_inds_index_right++;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 790);
                    c7_dv4[0] = c7_MS_inds_index_right;
                    c7_ec_trueCount = 0;
                    c7_me_i = 0;
                    while (c7_me_i <= 0) {
                      if (c7_MS_inds_index_right > 5.0) {
                        c7_ec_trueCount++;
                      }

                      c7_me_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_ec_partialTrueCount = 0;
                    c7_ne_i = 0;
                    while (c7_ne_i <= 0) {
                      if (c7_MS_inds_index_right > 5.0) {
                        c7_iv0[0] = 1;
                        c7_iv0[1] = c7_ec_trueCount;
                        c7_d_tmp_sizes[0] = 1;
                        c7_d_tmp_sizes[1] = c7_iv0[1];
                        c7_i473 = c7_d_tmp_sizes[0];
                        c7_i474 = c7_d_tmp_sizes[1];
                        c7_mc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                        for (c7_i475 = 0; c7_i475 <= c7_mc_loop_ub; c7_i475++) {
                          c7_d_tmp_data[c7_i475] = 5.0;
                        }

                        c7_dv4[c7_ne_i] = c7_d_tmp_data[c7_ec_partialTrueCount];
                        c7_ec_partialTrueCount++;
                      }

                      c7_ne_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_MS_inds_index_right = c7_dv4[0];
                  } else {
                    guard26 = true;
                  }
                } else {
                  guard26 = true;
                }

                if (guard26 == true) {
                  CV_EML_MCDC(0, 1, 61, false);
                  CV_EML_IF(0, 1, 79, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 792);
                c7_u73 = (uint32_T)c7_b_index + 1U;
                if (CV_SATURATION_EVAL(4, 0, 55, 0, c7_u73 > 65535U)) {
                  c7_u73 = 65535U;
                }

                c7_b_index = (uint16_T)c7_u73;
                _SFD_SYMBOL_SWITCH(2U, 29U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 785);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg19 = true;
              }
            }

            CV_EML_WHILE(0, 1, 11, false);
          } else {
            guard24 = true;
          }
        } else {
          guard25 = true;
        }
      } else {
        guard25 = true;
      }

      if (guard25 == true) {
        guard24 = true;
      }

      if (guard24 == true) {
        CV_EML_MCDC(0, 1, 59, false);
        CV_EML_IF(0, 1, 77, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 797);
      c7_k_q0 = c7_i;
      c7_k_qY = c7_k_q0 - 1U;
      if (CV_SATURATION_EVAL(4, 0, 56, 0, c7_k_qY > c7_k_q0)) {
        c7_k_qY = 0U;
      }

      c7_u74 = c7_k_qY;
      if (CV_SATURATION_EVAL(4, 0, 56, 0, c7_u74 > 65535U)) {
        c7_u74 = 65535U;
      }

      c7_f38 = c7_data_struct_input->AngLShank_LPF[(uint16_T)
        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct, chartInstance->S,
        5U, 50478, 36, MAX_uint32_T, (int32_T)(uint16_T)c7_u74, 1, 200) - 1];
      guard20 = false;
      guard21 = false;
      if (CV_EML_COND(0, 1, 193U, CV_RELATIONAL_EVAL(4U, 0U, 210, (real_T)
            c7_data_struct_input->AngLShank_LPF[c7_i - 1], (real_T)c7_f38, -3,
            4U, c7_data_struct_input->AngLShank_LPF[c7_i - 1] > c7_f38))) {
        c7_u75 = (uint32_T)c7_i + 1U;
        if (CV_SATURATION_EVAL(4, 0, 57, 0, c7_u75 > 65535U)) {
          c7_u75 = 65535U;
        }

        c7_u76 = (uint32_T)c7_i + 1U;
        if (CV_SATURATION_EVAL(4, 0, 57, 0, c7_u76 > 65535U)) {
          c7_u76 = 65535U;
        }

        if (CV_EML_COND(0, 1, 194U, CV_RELATIONAL_EVAL(4U, 0U, 211, (real_T)
              c7_data_struct_input->AngLShank_LPF[c7_i - 1], (real_T)
              c7_data_struct_input->AngLShank_LPF[(uint16_T)c7_u75 - 1], -3, 4U,
              c7_data_struct_input->AngLShank_LPF[c7_i - 1] >
              c7_data_struct_input->AngLShank_LPF[(uint16_T)c7_u76 - 1]))) {
          if (CV_EML_COND(0, 1, 195U, CV_RELATIONAL_EVAL(4U, 0U, 212, (real_T)
                c7_data_struct_input->AngLShank_LPF[c7_i - 1], 0.0, -1, 4U,
                c7_data_struct_input->AngLShank_LPF[c7_i - 1] > 0.0F))) {
            CV_EML_MCDC(0, 1, 62, true);
            CV_EML_IF(0, 1, 80, true);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 798);
            c7_data_struct_input->MA_LPF_maxs_left[(uint8_T)
              sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
              chartInstance->S, 5U, 50646, 71, MAX_uint32_T, (int32_T)
              c7_data_struct_input->MA_LPF_index_left, 1, 5) - 1] =
              c7_data_struct_input->AngLShank_LPF[c7_i - 1];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 799);
            c7_u77 = (uint32_T)c7_data_struct_input->MA_LPF_index_left + 1U;
            if (CV_SATURATION_EVAL(4, 0, 58, 0, c7_u77 > 255U)) {
              c7_u77 = 255U;
            }

            c7_data_struct_input->MA_LPF_index_left = (uint8_T)c7_u77;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 800);
            c7_uv28[0] = c7_data_struct_input->MA_LPF_index_left;
            c7_b49 = ((real_T)c7_data_struct_input->MA_LPF_index_left > 5.0);
            c7_fc_trueCount = 0;
            c7_oe_i = 0;
            while (c7_oe_i <= 0) {
              if (c7_b49) {
                c7_fc_trueCount++;
              }

              c7_oe_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_fc_partialTrueCount = 0;
            c7_pe_i = 0;
            while (c7_pe_i <= 0) {
              if (c7_b49) {
                c7_iv0[0] = 1;
                c7_iv0[1] = c7_fc_trueCount;
                c7_tmp_sizes[0] = 1;
                c7_tmp_sizes[1] = c7_iv0[1];
                c7_i476 = c7_tmp_sizes[0];
                c7_i477 = c7_tmp_sizes[1];
                c7_nc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                for (c7_i478 = 0; c7_i478 <= c7_nc_loop_ub; c7_i478++) {
                  c7_tmp_data[c7_i478] = 5U;
                }

                c7_uv28[c7_pe_i] = c7_tmp_data[c7_fc_partialTrueCount];
                c7_fc_partialTrueCount++;
              }

              c7_pe_i++;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            }

            c7_data_struct_input->MA_LPF_index_left = c7_uv28[0];
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 802);
            c7_b_index = c7_i;
            _SFD_SYMBOL_SWITCH(2U, 29U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 803);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 805);
            exitg18 = false;
            while ((exitg18 == false) && (c7_found == 0.0)) {
              c7_l_q0 = 200U;
              c7_l_qY = c7_l_q0 - (uint32_T)
                c7_data_struct_input->index_start_calib;
              if (CV_SATURATION_EVAL(4, 0, 59, 0, c7_l_qY > c7_l_q0)) {
                c7_l_qY = 0U;
              }

              c7_u78 = c7_l_qY;
              if (CV_SATURATION_EVAL(4, 0, 59, 0, c7_u78 > 65535U)) {
                c7_u78 = 65535U;
              }

              c7_u79 = (uint32_T)(uint16_T)c7_u78 + 1U;
              if (CV_SATURATION_EVAL(4, 0, 60, 0, c7_u79 > 65535U)) {
                c7_u79 = 65535U;
              }

              if (c7_b_index > (uint16_T)c7_u79) {
                CV_EML_WHILE(0, 1, 12, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 806);
                c7_m_q0 = c7_b_index;
                c7_m_qY = c7_m_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 61, 0, c7_m_qY > c7_m_q0)) {
                  c7_m_qY = 0U;
                }

                c7_u80 = c7_m_qY;
                if (CV_SATURATION_EVAL(4, 0, 61, 0, c7_u80 > 65535U)) {
                  c7_u80 = 65535U;
                }

                c7_n_q0 = c7_b_index;
                c7_n_qY = c7_n_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 61, 0, c7_n_qY > c7_n_q0)) {
                  c7_n_qY = 0U;
                }

                c7_u81 = c7_n_qY;
                if (CV_SATURATION_EVAL(4, 0, 61, 0, c7_u81 > 65535U)) {
                  c7_u81 = 65535U;
                }

                guard23 = false;
                if (CV_EML_COND(0, 1, 196U, CV_RELATIONAL_EVAL(4U, 0U, 213,
                      (real_T)c7_data_struct_input->AngLShank_filt[c7_b_index -
                      1], (real_T)c7_data_struct_input->AngLShank_filt[(uint16_T)
                      c7_u80 - 1], -3, 4U, c7_data_struct_input->
                      AngLShank_filt[c7_b_index - 1] >
                      c7_data_struct_input->AngLShank_filt[(uint16_T)c7_u81 - 1])))
                {
                  c7_u82 = (uint32_T)c7_b_index + 1U;
                  if (CV_SATURATION_EVAL(4, 0, 62, 0, c7_u82 > 65535U)) {
                    c7_u82 = 65535U;
                  }

                  c7_u83 = (uint32_T)c7_b_index + 1U;
                  if (CV_SATURATION_EVAL(4, 0, 62, 0, c7_u83 > 65535U)) {
                    c7_u83 = 65535U;
                  }

                  if (CV_EML_COND(0, 1, 197U, CV_RELATIONAL_EVAL(4U, 0U, 214,
                        (real_T)c7_data_struct_input->AngLShank_filt[c7_b_index
                        - 1], (real_T)c7_data_struct_input->AngLShank_filt
                        [(uint16_T)c7_u82 - 1], -3, 4U,
                        c7_data_struct_input->AngLShank_filt[c7_b_index - 1] >
                        c7_data_struct_input->AngLShank_filt[(uint16_T)c7_u83 -
                        1]))) {
                    CV_EML_MCDC(0, 1, 63, true);
                    CV_EML_IF(0, 1, 81, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 807);
                    c7_data_struct_input->MA_maxs_left[(uint8_T)
                      sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                      chartInstance->S, 5U, 51388, 63, MAX_uint32_T, (int32_T)
                      c7_data_struct_input->MA_index_left, 1, 5) - 1] =
                      c7_data_struct_input->AngLShank_filt[c7_b_index - 1];
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 808);
                    c7_found = 1.0;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 809);
                    c7_u84 = (uint32_T)c7_data_struct_input->MA_index_left + 1U;
                    if (CV_SATURATION_EVAL(4, 0, 63, 0, c7_u84 > 255U)) {
                      c7_u84 = 255U;
                    }

                    c7_data_struct_input->MA_index_left = (uint8_T)c7_u84;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 810);
                    c7_uv29[0] = c7_data_struct_input->MA_index_left;
                    c7_b50 = ((real_T)c7_data_struct_input->MA_index_left > 5.0);
                    c7_gc_trueCount = 0;
                    c7_qe_i = 0;
                    while (c7_qe_i <= 0) {
                      if (c7_b50) {
                        c7_gc_trueCount++;
                      }

                      c7_qe_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_gc_partialTrueCount = 0;
                    c7_re_i = 0;
                    while (c7_re_i <= 0) {
                      if (c7_b50) {
                        c7_iv0[0] = 1;
                        c7_iv0[1] = c7_gc_trueCount;
                        c7_tmp_sizes[0] = 1;
                        c7_tmp_sizes[1] = c7_iv0[1];
                        c7_i479 = c7_tmp_sizes[0];
                        c7_i480 = c7_tmp_sizes[1];
                        c7_oc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                        for (c7_i481 = 0; c7_i481 <= c7_oc_loop_ub; c7_i481++) {
                          c7_tmp_data[c7_i481] = 5U;
                        }

                        c7_uv29[c7_re_i] = c7_tmp_data[c7_gc_partialTrueCount];
                        c7_gc_partialTrueCount++;
                      }

                      c7_re_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_data_struct_input->MA_index_left = c7_uv29[0];
                  } else {
                    guard23 = true;
                  }
                } else {
                  guard23 = true;
                }

                if (guard23 == true) {
                  CV_EML_MCDC(0, 1, 63, false);
                  CV_EML_IF(0, 1, 81, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 812);
                c7_o_q0 = c7_b_index;
                c7_o_qY = c7_o_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 64, 0, c7_o_qY > c7_o_q0)) {
                  c7_o_qY = 0U;
                }

                c7_u85 = c7_o_qY;
                if (CV_SATURATION_EVAL(4, 0, 64, 0, c7_u85 > 65535U)) {
                  c7_u85 = 65535U;
                }

                c7_b_index = (uint16_T)c7_u85;
                _SFD_SYMBOL_SWITCH(2U, 29U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 805);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg18 = true;
              }
            }

            CV_EML_WHILE(0, 1, 12, false);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 816);
            c7_u86 = (uint32_T)c7_b_index + 1U;
            if (CV_SATURATION_EVAL(4, 0, 65, 0, c7_u86 > 65535U)) {
              c7_u86 = 65535U;
            }

            c7_b_index = (uint16_T)c7_u86;
            _SFD_SYMBOL_SWITCH(2U, 29U);
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 817);
            c7_found = 0.0;
            _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 818);
            exitg17 = false;
            while ((exitg17 == false) && (c7_found == 0.0)) {
              if ((real_T)c7_b_index < 199.0) {
                CV_EML_WHILE(0, 1, 13, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 819);
                c7_p_q0 = c7_b_index;
                c7_p_qY = c7_p_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 66, 0, c7_p_qY > c7_p_q0)) {
                  c7_p_qY = 0U;
                }

                c7_u87 = c7_p_qY;
                if (CV_SATURATION_EVAL(4, 0, 66, 0, c7_u87 > 65535U)) {
                  c7_u87 = 65535U;
                }

                c7_q_q0 = c7_b_index;
                c7_q_qY = c7_q_q0 - 1U;
                if (CV_SATURATION_EVAL(4, 0, 66, 0, c7_q_qY > c7_q_q0)) {
                  c7_q_qY = 0U;
                }

                c7_u88 = c7_q_qY;
                if (CV_SATURATION_EVAL(4, 0, 66, 0, c7_u88 > 65535U)) {
                  c7_u88 = 65535U;
                }

                guard22 = false;
                if (CV_EML_COND(0, 1, 198U, CV_RELATIONAL_EVAL(4U, 0U, 215,
                      (real_T)c7_data_struct_input->AngLShank_filt[(uint16_T)
                      c7_u87 - 1], 0.0, -1, 5U,
                      c7_data_struct_input->AngLShank_filt[(uint16_T)c7_u88 - 1]
                      >= 0.0F))) {
                  if (CV_EML_COND(0, 1, 199U, CV_RELATIONAL_EVAL(4U, 0U, 216,
                        (real_T)c7_data_struct_input->AngLShank_filt[c7_b_index
                        - 1], 0.0, -1, 3U, c7_data_struct_input->
                        AngLShank_filt[c7_b_index - 1] <= 0.0F))) {
                    CV_EML_MCDC(0, 1, 64, true);
                    CV_EML_IF(0, 1, 82, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 820);
                    c7_b_MS_inds_left[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 52127,
                       32, 0U, (int32_T)c7_MS_inds_index_left, 1, 5) - 1] =
                      (real_T)c7_b_index;
                    _SFD_SYMBOL_SWITCH(3U, 21U);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 821);
                    c7_found = 1.0;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 822);
                    c7_MS_inds_index_left++;
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 823);
                    c7_dv5[0] = c7_MS_inds_index_left;
                    c7_hc_trueCount = 0;
                    c7_se_i = 0;
                    while (c7_se_i <= 0) {
                      if (c7_MS_inds_index_left > 5.0) {
                        c7_hc_trueCount++;
                      }

                      c7_se_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_hc_partialTrueCount = 0;
                    c7_te_i = 0;
                    while (c7_te_i <= 0) {
                      if (c7_MS_inds_index_left > 5.0) {
                        c7_iv0[0] = 1;
                        c7_iv0[1] = c7_hc_trueCount;
                        c7_d_tmp_sizes[0] = 1;
                        c7_d_tmp_sizes[1] = c7_iv0[1];
                        c7_i482 = c7_d_tmp_sizes[0];
                        c7_i483 = c7_d_tmp_sizes[1];
                        c7_pc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                        for (c7_i484 = 0; c7_i484 <= c7_pc_loop_ub; c7_i484++) {
                          c7_d_tmp_data[c7_i484] = 5.0;
                        }

                        c7_dv5[c7_te_i] = c7_d_tmp_data[c7_hc_partialTrueCount];
                        c7_hc_partialTrueCount++;
                      }

                      c7_te_i++;
                      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                    }

                    c7_MS_inds_index_left = c7_dv5[0];
                  } else {
                    guard22 = true;
                  }
                } else {
                  guard22 = true;
                }

                if (guard22 == true) {
                  CV_EML_MCDC(0, 1, 64, false);
                  CV_EML_IF(0, 1, 82, false);
                }

                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 825);
                c7_u89 = (uint32_T)c7_b_index + 1U;
                if (CV_SATURATION_EVAL(4, 0, 67, 0, c7_u89 > 65535U)) {
                  c7_u89 = 65535U;
                }

                c7_b_index = (uint16_T)c7_u89;
                _SFD_SYMBOL_SWITCH(2U, 29U);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 818);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                exitg17 = true;
              }
            }

            CV_EML_WHILE(0, 1, 13, false);
          } else {
            guard20 = true;
          }
        } else {
          guard21 = true;
        }
      } else {
        guard21 = true;
      }

      if (guard21 == true) {
        guard20 = true;
      }

      if (guard20 == true) {
        CV_EML_MCDC(0, 1, 62, false);
        CV_EML_IF(0, 1, 80, false);
      }

      c7_he_i = (uint16_T)((uint32_T)c7_he_i + 1U);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 2, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 830);
    c7_data_struct_input->MA_LPF_th_left = 0.0F;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 831);
    c7_data_struct_input->MA_LPF_th_right = 0.0F;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 832);
    for (c7_i485 = 0; c7_i485 < 5; c7_i485++) {
      c7_bv4[c7_i485] = (c7_data_struct_input->MA_maxs_left[c7_i485] > -1.0E+6F);
    }

    c7_ic_trueCount = 0;
    c7_ue_i = 0;
    while (c7_ue_i <= 4) {
      if (c7_bv4[c7_ue_i]) {
        c7_ic_trueCount++;
      }

      c7_ue_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_ic_trueCount;
    c7_ic_partialTrueCount = 0;
    c7_ve_i = 0;
    while (c7_ve_i <= 4) {
      if (c7_bv4[c7_ve_i]) {
        c7_c_tmp_data[c7_ic_partialTrueCount] = c7_ve_i + 1;
        c7_ic_partialTrueCount++;
      }

      c7_ve_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_hb_data_struct_input_sizes[0] = 1;
    c7_hb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_ed_data_struct_input = c7_hb_data_struct_input_sizes[0];
    c7_fd_data_struct_input = c7_hb_data_struct_input_sizes[1];
    c7_qc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i486 = 0; c7_i486 <= c7_qc_loop_ub; c7_i486++) {
      c7_hb_data_struct_input_data[c7_i486] = c7_data_struct_input->
        MA_maxs_left[c7_c_tmp_data[c7_i486] - 1];
    }

    c7_data_struct_input->MA_th_left = c7_b_mean(chartInstance,
      c7_hb_data_struct_input_data, c7_hb_data_struct_input_sizes) - 20.0F;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 833);
    for (c7_i487 = 0; c7_i487 < 5; c7_i487++) {
      c7_bv4[c7_i487] = (c7_data_struct_input->MA_maxs_right[c7_i487] > -1.0E+6F);
    }

    c7_jc_trueCount = 0;
    c7_we_i = 0;
    while (c7_we_i <= 4) {
      if (c7_bv4[c7_we_i]) {
        c7_jc_trueCount++;
      }

      c7_we_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_jc_trueCount;
    c7_jc_partialTrueCount = 0;
    c7_xe_i = 0;
    while (c7_xe_i <= 4) {
      if (c7_bv4[c7_xe_i]) {
        c7_c_tmp_data[c7_jc_partialTrueCount] = c7_xe_i + 1;
        c7_jc_partialTrueCount++;
      }

      c7_xe_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_ib_data_struct_input_sizes[0] = 1;
    c7_ib_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_gd_data_struct_input = c7_ib_data_struct_input_sizes[0];
    c7_hd_data_struct_input = c7_ib_data_struct_input_sizes[1];
    c7_rc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i488 = 0; c7_i488 <= c7_rc_loop_ub; c7_i488++) {
      c7_ib_data_struct_input_data[c7_i488] =
        c7_data_struct_input->MA_maxs_right[c7_c_tmp_data[c7_i488] - 1];
    }

    c7_data_struct_input->MA_th_right = c7_b_mean(chartInstance,
      c7_ib_data_struct_input_data, c7_ib_data_struct_input_sizes) - 20.0F;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 837);
    c7_d24 = c7_MS_inds_index_right - 1.0;
    c7_i489 = (int32_T)c7_d24 - 1;
    c7_ye_i = 0;
    while (c7_ye_i <= c7_i489) {
      c7_b_i = 1.0 + (real_T)c7_ye_i;
      _SFD_SYMBOL_SWITCH(18U, 26U);
      CV_EML_FOR(0, 1, 3, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 838);
      c7_found = 0.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 839);
      c7_index = c7_b_MS_inds_right[(int32_T)c7_b_i - 1];
      _SFD_SYMBOL_SWITCH(2U, 2U);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 841);
      exitg16 = false;
      while ((exitg16 == false) && (c7_found == 0.0)) {
        if (c7_index < 199.0) {
          CV_EML_WHILE(0, 1, 14, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 842);
          c7_f39 = c7_data_struct_input->AngRShank_LPF[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 53168, 38,
             MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
          c7_f40 = c7_data_struct_input->AngRShank_LPF[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 53207, 40,
             MAX_uint32_T, (int32_T)(c7_index + 1.0), 1, 200) - 1];
          guard19 = false;
          if (CV_EML_COND(0, 1, 200U, CV_RELATIONAL_EVAL(4U, 0U, 217, (real_T)
                c7_f39, (real_T)c7_f40, -3, 2U, c7_f39 < c7_f40))) {
            c7_f41 = c7_data_struct_input->
              AngRShank_LPF[sf_eml_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 53251, 38,
               MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
            c7_f42 = c7_data_struct_input->
              AngRShank_LPF[sf_eml_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 53290, 40,
               MAX_uint32_T, (int32_T)(c7_index - 1.0), 1, 200) - 1];
            if (CV_EML_COND(0, 1, 201U, CV_RELATIONAL_EVAL(4U, 0U, 218, (real_T)
                  c7_f41, (real_T)c7_f42, -3, 2U, c7_f41 < c7_f42))) {
              CV_EML_MCDC(0, 1, 65, true);
              CV_EML_IF(0, 1, 83, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 843);
              c7_data_struct_input->IC_LPF_mins_right[(uint8_T)
                sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                chartInstance->S, 5U, 53348, 73, MAX_uint32_T, (int32_T)
                c7_data_struct_input->IC_LPF_index_right, 1, 5) - 1] =
                c7_data_struct_input->AngRShank_LPF[sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 53422, 38,
                 MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 844);
              c7_IC_LPF_inds_right[(uint8_T)sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 53478, 55,
                 0U, (int32_T)c7_data_struct_input->IC_LPF_index_right, 1, 5) -
                1] = c7_index;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 845);
              c7_u90 = (uint32_T)c7_data_struct_input->IC_LPF_index_right + 1U;
              if (CV_SATURATION_EVAL(4, 0, 68, 0, c7_u90 > 255U)) {
                c7_u90 = 255U;
              }

              c7_data_struct_input->IC_LPF_index_right = (uint8_T)c7_u90;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 846);
              c7_uv30[0] = c7_data_struct_input->IC_LPF_index_right;
              c7_b51 = ((real_T)c7_data_struct_input->IC_LPF_index_right > 5.0);
              c7_kc_trueCount = 0;
              c7_af_i = 0;
              while (c7_af_i <= 0) {
                if (c7_b51) {
                  c7_kc_trueCount++;
                }

                c7_af_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_kc_partialTrueCount = 0;
              c7_bf_i = 0;
              while (c7_bf_i <= 0) {
                if (c7_b51) {
                  c7_iv0[0] = 1;
                  c7_iv0[1] = c7_kc_trueCount;
                  c7_tmp_sizes[0] = 1;
                  c7_tmp_sizes[1] = c7_iv0[1];
                  c7_i490 = c7_tmp_sizes[0];
                  c7_i491 = c7_tmp_sizes[1];
                  c7_sc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                  for (c7_i492 = 0; c7_i492 <= c7_sc_loop_ub; c7_i492++) {
                    c7_tmp_data[c7_i492] = 5U;
                  }

                  c7_uv30[c7_bf_i] = c7_tmp_data[c7_kc_partialTrueCount];
                  c7_kc_partialTrueCount++;
                }

                c7_bf_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_data_struct_input->IC_LPF_index_right = c7_uv30[0];
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 847);
              c7_found = 1.0;
            } else {
              guard19 = true;
            }
          } else {
            guard19 = true;
          }

          if (guard19 == true) {
            CV_EML_MCDC(0, 1, 65, false);
            CV_EML_IF(0, 1, 83, false);
          }

          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 849);
          c7_index++;
          _SFD_SYMBOL_SWITCH(2U, 2U);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 841);
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        } else {
          exitg16 = true;
        }
      }

      CV_EML_WHILE(0, 1, 14, false);
      c7_ye_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 3, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 855);
    c7_d25 = c7_MS_inds_index_left - 1.0;
    c7_i493 = (int32_T)c7_d25 - 1;
    c7_cf_i = 0;
    while (c7_cf_i <= c7_i493) {
      c7_b_i = 1.0 + (real_T)c7_cf_i;
      _SFD_SYMBOL_SWITCH(18U, 26U);
      CV_EML_FOR(0, 1, 4, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 856);
      c7_found = 0.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 857);
      c7_index = c7_b_MS_inds_left[(int32_T)c7_b_i - 1];
      _SFD_SYMBOL_SWITCH(2U, 2U);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 859);
      exitg15 = false;
      while ((exitg15 == false) && (c7_found == 0.0)) {
        if (c7_index < 199.0) {
          CV_EML_WHILE(0, 1, 15, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 860);
          c7_f43 = c7_data_struct_input->AngLShank_LPF[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 54118, 38,
             MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
          c7_f44 = c7_data_struct_input->AngLShank_LPF[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 54157, 40,
             MAX_uint32_T, (int32_T)(c7_index + 1.0), 1, 200) - 1];
          guard18 = false;
          if (CV_EML_COND(0, 1, 202U, CV_RELATIONAL_EVAL(4U, 0U, 219, (real_T)
                c7_f43, (real_T)c7_f44, -3, 2U, c7_f43 < c7_f44))) {
            c7_f45 = c7_data_struct_input->
              AngLShank_LPF[sf_eml_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 54201, 38,
               MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
            c7_f46 = c7_data_struct_input->
              AngLShank_LPF[sf_eml_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 54240, 40,
               MAX_uint32_T, (int32_T)(c7_index - 1.0), 1, 200) - 1];
            if (CV_EML_COND(0, 1, 203U, CV_RELATIONAL_EVAL(4U, 0U, 220, (real_T)
                  c7_f45, (real_T)c7_f46, -3, 2U, c7_f45 < c7_f46))) {
              CV_EML_MCDC(0, 1, 66, true);
              CV_EML_IF(0, 1, 84, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 861);
              c7_data_struct_input->IC_LPF_mins_left[(uint8_T)
                sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                chartInstance->S, 5U, 54298, 71, MAX_uint32_T, (int32_T)
                c7_data_struct_input->IC_LPF_index_left, 1, 5) - 1] =
                c7_data_struct_input->AngLShank_LPF[sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 54370, 38,
                 MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 862);
              c7_IC_LPF_inds_left[(uint8_T)sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 54426, 53,
                 0U, (int32_T)c7_data_struct_input->IC_LPF_index_left, 1, 5) - 1]
                = c7_index;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 863);
              c7_u91 = (uint32_T)c7_data_struct_input->IC_LPF_index_left + 1U;
              if (CV_SATURATION_EVAL(4, 0, 69, 0, c7_u91 > 255U)) {
                c7_u91 = 255U;
              }

              c7_data_struct_input->IC_LPF_index_left = (uint8_T)c7_u91;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 864);
              c7_uv31[0] = c7_data_struct_input->IC_LPF_index_left;
              c7_b52 = ((real_T)c7_data_struct_input->IC_LPF_index_left > 5.0);
              c7_lc_trueCount = 0;
              c7_df_i = 0;
              while (c7_df_i <= 0) {
                if (c7_b52) {
                  c7_lc_trueCount++;
                }

                c7_df_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_lc_partialTrueCount = 0;
              c7_ef_i = 0;
              while (c7_ef_i <= 0) {
                if (c7_b52) {
                  c7_iv0[0] = 1;
                  c7_iv0[1] = c7_lc_trueCount;
                  c7_tmp_sizes[0] = 1;
                  c7_tmp_sizes[1] = c7_iv0[1];
                  c7_i494 = c7_tmp_sizes[0];
                  c7_i495 = c7_tmp_sizes[1];
                  c7_tc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                  for (c7_i496 = 0; c7_i496 <= c7_tc_loop_ub; c7_i496++) {
                    c7_tmp_data[c7_i496] = 5U;
                  }

                  c7_uv31[c7_ef_i] = c7_tmp_data[c7_lc_partialTrueCount];
                  c7_lc_partialTrueCount++;
                }

                c7_ef_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_data_struct_input->IC_LPF_index_left = c7_uv31[0];
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 865);
              c7_found = 1.0;
            } else {
              guard18 = true;
            }
          } else {
            guard18 = true;
          }

          if (guard18 == true) {
            CV_EML_MCDC(0, 1, 66, false);
            CV_EML_IF(0, 1, 84, false);
          }

          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 867);
          c7_index++;
          _SFD_SYMBOL_SWITCH(2U, 2U);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 859);
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        } else {
          exitg15 = true;
        }
      }

      CV_EML_WHILE(0, 1, 15, false);
      c7_cf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 4, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 873);
    c7_r_q0 = c7_data_struct_input->IC_LPF_index_right;
    c7_r_qY = c7_r_q0 - 1U;
    if (CV_SATURATION_EVAL(4, 0, 70, 0, c7_r_qY > c7_r_q0)) {
      c7_r_qY = 0U;
    }

    c7_u92 = c7_r_qY;
    if (CV_SATURATION_EVAL(4, 0, 70, 0, c7_u92 > 255U)) {
      c7_u92 = 255U;
    }

    c7_u93 = (uint8_T)c7_u92;
    c7_ff_i = 1U;
    while (c7_ff_i <= c7_u93) {
      c7_c_i = c7_ff_i;
      _SFD_SYMBOL_SWITCH(18U, 27U);
      CV_EML_FOR(0, 1, 5, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 874);
      c7_found = 0.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 875);
      c7_index = c7_IC_LPF_inds_right[(uint8_T)sf_eml_array_bounds_check
        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 54986, 20,
         MAX_uint32_T, (int32_T)c7_c_i, 1, 5) - 1];
      _SFD_SYMBOL_SWITCH(2U, 2U);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 876);
      exitg14 = false;
      while ((exitg14 == false) && (c7_found == 0.0)) {
        c7_s_q0 = 200U;
        c7_s_qY = c7_s_q0 - (uint32_T)c7_data_struct_input->index_start_calib;
        if (CV_SATURATION_EVAL(4, 0, 71, 0, c7_s_qY > c7_s_q0)) {
          c7_s_qY = 0U;
        }

        c7_u94 = c7_s_qY;
        if (CV_SATURATION_EVAL(4, 0, 71, 0, c7_u94 > 65535U)) {
          c7_u94 = 65535U;
        }

        c7_u95 = (uint32_T)(uint16_T)c7_u94 + 1U;
        if (CV_SATURATION_EVAL(4, 0, 72, 0, c7_u95 > 65535U)) {
          c7_u95 = 65535U;
        }

        if (c7_index > (real_T)(uint16_T)c7_u95) {
          CV_EML_WHILE(0, 1, 16, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 877);
          guard17 = false;
          if (CV_EML_COND(0, 1, 204U, CV_RELATIONAL_EVAL(4U, 0U, 221, (real_T)
                c7_data_struct_input->AngRShank_filt[(int32_T)c7_index - 1],
                (real_T)c7_data_struct_input->AngRShank_filt[(int32_T)(c7_index
                 + 1.0) - 1], -3, 2U, c7_data_struct_input->AngRShank_filt
                [(int32_T)c7_index - 1] < c7_data_struct_input->AngRShank_filt
                [(int32_T)(c7_index + 1.0) - 1]))) {
            if (CV_EML_COND(0, 1, 205U, CV_RELATIONAL_EVAL(4U, 0U, 222, (real_T)
                  c7_data_struct_input->AngRShank_filt[(int32_T)c7_index - 1],
                  (real_T)c7_data_struct_input->AngRShank_filt[(int32_T)
                  (c7_index - 1.0) - 1], -3, 2U,
                  c7_data_struct_input->AngRShank_filt[(int32_T)c7_index - 1] <
                  c7_data_struct_input->AngRShank_filt[(int32_T)(c7_index - 1.0)
                  - 1]))) {
              CV_EML_MCDC(0, 1, 67, true);
              CV_EML_IF(0, 1, 85, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 878);
              c7_data_struct_input->IC_mins_right[(uint8_T)
                sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                chartInstance->S, 5U, 55322, 65, MAX_uint32_T, (int32_T)
                c7_data_struct_input->IC_index_right, 1, 5) - 1] =
                c7_data_struct_input->AngRShank_filt[(int32_T)c7_index - 1];
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 879);
              c7_IC_inds_right[(uint8_T)sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 55445, 47,
                 0U, (int32_T)c7_data_struct_input->IC_index_right, 1, 5) - 1] =
                c7_index;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 880);
              c7_u96 = (uint32_T)c7_data_struct_input->IC_index_right + 1U;
              if (CV_SATURATION_EVAL(4, 0, 73, 0, c7_u96 > 255U)) {
                c7_u96 = 255U;
              }

              c7_data_struct_input->IC_index_right = (uint8_T)c7_u96;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 881);
              c7_uv32[0] = c7_data_struct_input->IC_index_right;
              c7_b53 = ((real_T)c7_data_struct_input->IC_index_right > 5.0);
              c7_mc_trueCount = 0;
              c7_gf_i = 0;
              while (c7_gf_i <= 0) {
                if (c7_b53) {
                  c7_mc_trueCount++;
                }

                c7_gf_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_mc_partialTrueCount = 0;
              c7_hf_i = 0;
              while (c7_hf_i <= 0) {
                if (c7_b53) {
                  c7_iv0[0] = 1;
                  c7_iv0[1] = c7_mc_trueCount;
                  c7_tmp_sizes[0] = 1;
                  c7_tmp_sizes[1] = c7_iv0[1];
                  c7_i497 = c7_tmp_sizes[0];
                  c7_i498 = c7_tmp_sizes[1];
                  c7_uc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                  for (c7_i499 = 0; c7_i499 <= c7_uc_loop_ub; c7_i499++) {
                    c7_tmp_data[c7_i499] = 5U;
                  }

                  c7_uv32[c7_hf_i] = c7_tmp_data[c7_mc_partialTrueCount];
                  c7_mc_partialTrueCount++;
                }

                c7_hf_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_data_struct_input->IC_index_right = c7_uv32[0];
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 882);
              c7_found = 1.0;
            } else {
              guard17 = true;
            }
          } else {
            guard17 = true;
          }

          if (guard17 == true) {
            CV_EML_MCDC(0, 1, 67, false);
            CV_EML_IF(0, 1, 85, false);
          }

          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 884);
          c7_index--;
          _SFD_SYMBOL_SWITCH(2U, 2U);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 876);
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        } else {
          exitg14 = true;
        }
      }

      CV_EML_WHILE(0, 1, 16, false);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 886);
      if (CV_EML_IF(0, 1, 86, CV_RELATIONAL_EVAL(4U, 0U, 223, c7_found, 0.0, -1,
            0U, c7_found == 0.0))) {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 887);
        c7_data_struct_input->IC_LPF_mins_right[c7_c_i - 1] = -2.0E+6F;
      }

      c7_ff_i = (uint8_T)((uint32_T)c7_ff_i + 1U);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 5, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 890);
    c7_t_q0 = c7_data_struct_input->IC_LPF_index_left;
    c7_t_qY = c7_t_q0 - 1U;
    if (CV_SATURATION_EVAL(4, 0, 74, 0, c7_t_qY > c7_t_q0)) {
      c7_t_qY = 0U;
    }

    c7_u97 = c7_t_qY;
    if (CV_SATURATION_EVAL(4, 0, 74, 0, c7_u97 > 255U)) {
      c7_u97 = 255U;
    }

    c7_u98 = (uint8_T)c7_u97;
    c7_if_i = 1U;
    while (c7_if_i <= c7_u98) {
      c7_c_i = c7_if_i;
      _SFD_SYMBOL_SWITCH(18U, 27U);
      CV_EML_FOR(0, 1, 6, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 891);
      c7_found = 0.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 892);
      c7_index = c7_IC_LPF_inds_left[(uint8_T)sf_eml_array_bounds_check
        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 55931, 19,
         MAX_uint32_T, (int32_T)c7_c_i, 1, 5) - 1];
      _SFD_SYMBOL_SWITCH(2U, 2U);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 893);
      exitg13 = false;
      while ((exitg13 == false) && (c7_found == 0.0)) {
        c7_u_q0 = 200U;
        c7_u_qY = c7_u_q0 - (uint32_T)c7_data_struct_input->index_start_calib;
        if (CV_SATURATION_EVAL(4, 0, 75, 0, c7_u_qY > c7_u_q0)) {
          c7_u_qY = 0U;
        }

        c7_u99 = c7_u_qY;
        if (CV_SATURATION_EVAL(4, 0, 75, 0, c7_u99 > 65535U)) {
          c7_u99 = 65535U;
        }

        c7_u100 = (uint32_T)(uint16_T)c7_u99 + 1U;
        if (CV_SATURATION_EVAL(4, 0, 76, 0, c7_u100 > 65535U)) {
          c7_u100 = 65535U;
        }

        if (c7_index > (real_T)(uint16_T)c7_u100) {
          CV_EML_WHILE(0, 1, 17, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 894);
          guard16 = false;
          if (CV_EML_COND(0, 1, 206U, CV_RELATIONAL_EVAL(4U, 0U, 224, (real_T)
                c7_data_struct_input->AngLShank_filt[(int32_T)c7_index - 1],
                (real_T)c7_data_struct_input->AngLShank_filt[(int32_T)(c7_index
                 + 1.0) - 1], -3, 2U, c7_data_struct_input->AngLShank_filt
                [(int32_T)c7_index - 1] < c7_data_struct_input->AngLShank_filt
                [(int32_T)(c7_index + 1.0) - 1]))) {
            if (CV_EML_COND(0, 1, 207U, CV_RELATIONAL_EVAL(4U, 0U, 225, (real_T)
                  c7_data_struct_input->AngLShank_filt[(int32_T)c7_index - 1],
                  (real_T)c7_data_struct_input->AngLShank_filt[(int32_T)
                  (c7_index - 1.0) - 1], -3, 2U,
                  c7_data_struct_input->AngLShank_filt[(int32_T)c7_index - 1] <
                  c7_data_struct_input->AngLShank_filt[(int32_T)(c7_index - 1.0)
                  - 1]))) {
              CV_EML_MCDC(0, 1, 68, true);
              CV_EML_IF(0, 1, 87, true);
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 895);
              c7_data_struct_input->IC_mins_left[(uint8_T)
                sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
                chartInstance->S, 5U, 56266, 63, MAX_uint32_T, (int32_T)
                c7_data_struct_input->IC_index_left, 1, 5) - 1] =
                c7_data_struct_input->AngLShank_filt[(int32_T)c7_index - 1];
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 896);
              c7_IC_inds_left[(uint8_T)sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 56387, 45,
                 0U, (int32_T)c7_data_struct_input->IC_index_left, 1, 5) - 1] =
                c7_index;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 897);
              c7_u101 = (uint32_T)c7_data_struct_input->IC_index_left + 1U;
              if (CV_SATURATION_EVAL(4, 0, 77, 0, c7_u101 > 255U)) {
                c7_u101 = 255U;
              }

              c7_data_struct_input->IC_index_left = (uint8_T)c7_u101;
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 898);
              c7_uv33[0] = c7_data_struct_input->IC_index_left;
              c7_b54 = ((real_T)c7_data_struct_input->IC_index_left > 5.0);
              c7_nc_trueCount = 0;
              c7_jf_i = 0;
              while (c7_jf_i <= 0) {
                if (c7_b54) {
                  c7_nc_trueCount++;
                }

                c7_jf_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_nc_partialTrueCount = 0;
              c7_kf_i = 0;
              while (c7_kf_i <= 0) {
                if (c7_b54) {
                  c7_iv0[0] = 1;
                  c7_iv0[1] = c7_nc_trueCount;
                  c7_tmp_sizes[0] = 1;
                  c7_tmp_sizes[1] = c7_iv0[1];
                  c7_i500 = c7_tmp_sizes[0];
                  c7_i501 = c7_tmp_sizes[1];
                  c7_vc_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                  for (c7_i502 = 0; c7_i502 <= c7_vc_loop_ub; c7_i502++) {
                    c7_tmp_data[c7_i502] = 5U;
                  }

                  c7_uv33[c7_kf_i] = c7_tmp_data[c7_nc_partialTrueCount];
                  c7_nc_partialTrueCount++;
                }

                c7_kf_i++;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }

              c7_data_struct_input->IC_index_left = c7_uv33[0];
              _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 899);
              c7_found = 1.0;
            } else {
              guard16 = true;
            }
          } else {
            guard16 = true;
          }

          if (guard16 == true) {
            CV_EML_MCDC(0, 1, 68, false);
            CV_EML_IF(0, 1, 87, false);
          }

          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 901);
          c7_index--;
          _SFD_SYMBOL_SWITCH(2U, 2U);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 893);
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        } else {
          exitg13 = true;
        }
      }

      CV_EML_WHILE(0, 1, 17, false);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 903);
      if (CV_EML_IF(0, 1, 88, CV_RELATIONAL_EVAL(4U, 0U, 226, c7_found, 0.0, -1,
            0U, c7_found == 0.0))) {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 904);
        c7_data_struct_input->IC_LPF_mins_left[c7_c_i - 1] = -2.0E+6F;
      }

      c7_if_i = (uint8_T)((uint32_T)c7_if_i + 1U);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 6, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 908);
    for (c7_i503 = 0; c7_i503 < 5; c7_i503++) {
      c7_bv4[c7_i503] = (c7_data_struct_input->IC_LPF_mins_left[c7_i503] >
                         -1.0E+6F);
    }

    c7_oc_trueCount = 0;
    c7_lf_i = 0;
    while (c7_lf_i <= 4) {
      if (c7_bv4[c7_lf_i]) {
        c7_oc_trueCount++;
      }

      c7_lf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_oc_trueCount;
    c7_oc_partialTrueCount = 0;
    c7_mf_i = 0;
    while (c7_mf_i <= 4) {
      if (c7_bv4[c7_mf_i]) {
        c7_c_tmp_data[c7_oc_partialTrueCount] = c7_mf_i + 1;
        c7_oc_partialTrueCount++;
      }

      c7_mf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_jb_data_struct_input_sizes[0] = 1;
    c7_jb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_id_data_struct_input = c7_jb_data_struct_input_sizes[0];
    c7_jd_data_struct_input = c7_jb_data_struct_input_sizes[1];
    c7_wc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i504 = 0; c7_i504 <= c7_wc_loop_ub; c7_i504++) {
      c7_jb_data_struct_input_data[c7_i504] =
        c7_data_struct_input->IC_LPF_mins_left[c7_c_tmp_data[c7_i504] - 1];
    }

    c7_data_struct_input->IC_LPF_th_left = c7_b_mean(chartInstance,
      c7_jb_data_struct_input_data, c7_jb_data_struct_input_sizes) + 10.0F;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 909);
    for (c7_i505 = 0; c7_i505 < 5; c7_i505++) {
      c7_bv4[c7_i505] = (c7_data_struct_input->IC_LPF_mins_right[c7_i505] >
                         -1.0E+6F);
    }

    c7_pc_trueCount = 0;
    c7_nf_i = 0;
    while (c7_nf_i <= 4) {
      if (c7_bv4[c7_nf_i]) {
        c7_pc_trueCount++;
      }

      c7_nf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_pc_trueCount;
    c7_pc_partialTrueCount = 0;
    c7_of_i = 0;
    while (c7_of_i <= 4) {
      if (c7_bv4[c7_of_i]) {
        c7_c_tmp_data[c7_pc_partialTrueCount] = c7_of_i + 1;
        c7_pc_partialTrueCount++;
      }

      c7_of_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_kb_data_struct_input_sizes[0] = 1;
    c7_kb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_kd_data_struct_input = c7_kb_data_struct_input_sizes[0];
    c7_ld_data_struct_input = c7_kb_data_struct_input_sizes[1];
    c7_xc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i506 = 0; c7_i506 <= c7_xc_loop_ub; c7_i506++) {
      c7_kb_data_struct_input_data[c7_i506] =
        c7_data_struct_input->IC_LPF_mins_right[c7_c_tmp_data[c7_i506] - 1];
    }

    c7_data_struct_input->IC_LPF_th_right = c7_b_mean(chartInstance,
      c7_kb_data_struct_input_data, c7_kb_data_struct_input_sizes) + 10.0F;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 910);
    for (c7_i507 = 0; c7_i507 < 5; c7_i507++) {
      c7_bv4[c7_i507] = (c7_data_struct_input->IC_mins_left[c7_i507] > -1.0E+6F);
    }

    c7_qc_trueCount = 0;
    c7_pf_i = 0;
    while (c7_pf_i <= 4) {
      if (c7_bv4[c7_pf_i]) {
        c7_qc_trueCount++;
      }

      c7_pf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_qc_trueCount;
    c7_qc_partialTrueCount = 0;
    c7_qf_i = 0;
    while (c7_qf_i <= 4) {
      if (c7_bv4[c7_qf_i]) {
        c7_c_tmp_data[c7_qc_partialTrueCount] = c7_qf_i + 1;
        c7_qc_partialTrueCount++;
      }

      c7_qf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_lb_data_struct_input_sizes[0] = 1;
    c7_lb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_md_data_struct_input = c7_lb_data_struct_input_sizes[0];
    c7_nd_data_struct_input = c7_lb_data_struct_input_sizes[1];
    c7_yc_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i508 = 0; c7_i508 <= c7_yc_loop_ub; c7_i508++) {
      c7_lb_data_struct_input_data[c7_i508] = c7_data_struct_input->
        IC_mins_left[c7_c_tmp_data[c7_i508] - 1];
    }

    c7_data_struct_input->IC_th_left = c7_b_mean(chartInstance,
      c7_lb_data_struct_input_data, c7_lb_data_struct_input_sizes) + 10.0F;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 911);
    for (c7_i509 = 0; c7_i509 < 5; c7_i509++) {
      c7_bv4[c7_i509] = (c7_data_struct_input->IC_mins_right[c7_i509] > -1.0E+6F);
    }

    c7_rc_trueCount = 0;
    c7_rf_i = 0;
    while (c7_rf_i <= 4) {
      if (c7_bv4[c7_rf_i]) {
        c7_rc_trueCount++;
      }

      c7_rf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_rc_trueCount;
    c7_rc_partialTrueCount = 0;
    c7_sf_i = 0;
    while (c7_sf_i <= 4) {
      if (c7_bv4[c7_sf_i]) {
        c7_c_tmp_data[c7_rc_partialTrueCount] = c7_sf_i + 1;
        c7_rc_partialTrueCount++;
      }

      c7_sf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_mb_data_struct_input_sizes[0] = 1;
    c7_mb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_od_data_struct_input = c7_mb_data_struct_input_sizes[0];
    c7_pd_data_struct_input = c7_mb_data_struct_input_sizes[1];
    c7_ad_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i510 = 0; c7_i510 <= c7_ad_loop_ub; c7_i510++) {
      c7_mb_data_struct_input_data[c7_i510] =
        c7_data_struct_input->IC_mins_right[c7_c_tmp_data[c7_i510] - 1];
    }

    c7_data_struct_input->IC_th_right = c7_b_mean(chartInstance,
      c7_mb_data_struct_input_data, c7_mb_data_struct_input_sizes) + 10.0F;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 931);
    c7_d26 = c7_MS_inds_index_right - 1.0;
    c7_i511 = (int32_T)c7_d26 - 1;
    c7_tf_i = 0;
    while (c7_tf_i <= c7_i511) {
      c7_b_i = 1.0 + (real_T)c7_tf_i;
      _SFD_SYMBOL_SWITCH(18U, 26U);
      CV_EML_FOR(0, 1, 7, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 932);
      c7_found = 0.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 933);
      c7_index = c7_b_MS_inds_right[(int32_T)c7_b_i - 1];
      _SFD_SYMBOL_SWITCH(2U, 2U);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 935);
      exitg11 = false;
      while ((exitg11 == false) && (c7_found == 0.0)) {
        c7_v_q0 = 200U;
        c7_v_qY = c7_v_q0 - (uint32_T)c7_data_struct_input->index_start_calib;
        if (CV_SATURATION_EVAL(4, 0, 78, 0, c7_v_qY > c7_v_q0)) {
          c7_v_qY = 0U;
        }

        c7_u102 = c7_v_qY;
        if (CV_SATURATION_EVAL(4, 0, 78, 0, c7_u102 > 65535U)) {
          c7_u102 = 65535U;
        }

        c7_u103 = (uint32_T)(uint16_T)c7_u102 + 1U;
        if (CV_SATURATION_EVAL(4, 0, 79, 0, c7_u103 > 65535U)) {
          c7_u103 = 65535U;
        }

        if (c7_index > (real_T)(uint16_T)c7_u103) {
          CV_EML_WHILE(0, 1, 18, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 936);
          c7_f47 = c7_data_struct_input->VelRShank_LPF[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 58536, 38,
             MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
          c7_f48 = c7_data_struct_input->VelRShank_LPF[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 58575, 40,
             MAX_uint32_T, (int32_T)(c7_index + 1.0), 1, 200) - 1];
          guard12 = false;
          guard13 = false;
          if (CV_EML_COND(0, 1, 208U, CV_RELATIONAL_EVAL(4U, 0U, 227, (real_T)
                c7_f47, (real_T)c7_f48, -3, 2U, c7_f47 < c7_f48))) {
            c7_f49 = c7_data_struct_input->
              VelRShank_LPF[sf_eml_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 58620, 38,
               MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
            c7_f50 = c7_data_struct_input->
              VelRShank_LPF[sf_eml_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 58659, 40,
               MAX_uint32_T, (int32_T)(c7_index - 1.0), 1, 200) - 1];
            if (CV_EML_COND(0, 1, 209U, CV_RELATIONAL_EVAL(4U, 0U, 228, (real_T)
                  c7_f49, (real_T)c7_f50, -3, 2U, c7_f49 < c7_f50))) {
              c7_d27 = c7_data_struct_input->
                VelRShank_LPF[sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 58703, 38,
                 MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
              if (CV_EML_COND(0, 1, 210U, CV_RELATIONAL_EVAL(4U, 0U, 229, c7_d27,
                    0.0, -1, 2U, c7_d27 < 0.0))) {
                CV_EML_MCDC(0, 1, 69, true);
                CV_EML_IF(0, 1, 89, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 938);
                exitg12 = false;
                while ((exitg12 == false) && (c7_found == 0.0)) {
                  c7_w_q0 = 200U;
                  c7_w_qY = c7_w_q0 - (uint32_T)
                    c7_data_struct_input->index_start_calib;
                  if (CV_SATURATION_EVAL(4, 0, 80, 0, c7_w_qY > c7_w_q0)) {
                    c7_w_qY = 0U;
                  }

                  c7_u104 = c7_w_qY;
                  if (CV_SATURATION_EVAL(4, 0, 80, 0, c7_u104 > 65535U)) {
                    c7_u104 = 65535U;
                  }

                  c7_u105 = (uint32_T)(uint16_T)c7_u104 + 1U;
                  if (CV_SATURATION_EVAL(4, 0, 81, 0, c7_u105 > 65535U)) {
                    c7_u105 = 65535U;
                  }

                  if (c7_index > (real_T)(uint16_T)c7_u105) {
                    CV_EML_WHILE(0, 1, 19, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 939);
                    c7_f51 = c7_data_struct_input->
                      VelRShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 58982,
                       39, MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
                    c7_f52 = c7_data_struct_input->
                      VelRShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 59022,
                       41, MAX_uint32_T, (int32_T)(c7_index + 1.0), 1, 200) - 1];
                    guard14 = false;
                    guard15 = false;
                    if (CV_EML_COND(0, 1, 211U, CV_RELATIONAL_EVAL(4U, 0U, 230,
                          (real_T)c7_f51, (real_T)c7_f52, -3, 2U, c7_f51 <
                          c7_f52))) {
                      c7_f53 = c7_data_struct_input->
                        VelRShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         59068, 39, MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
                      c7_f54 = c7_data_struct_input->
                        VelRShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         59108, 41, MAX_uint32_T, (int32_T)(c7_index - 1.0), 1,
                         200) - 1];
                      if (CV_EML_COND(0, 1, 212U, CV_RELATIONAL_EVAL(4U, 0U, 231,
                            (real_T)c7_f53, (real_T)c7_f54, -3, 2U, c7_f53 <
                            c7_f54))) {
                        c7_d28 = c7_data_struct_input->
                          VelRShank_filt[sf_eml_array_bounds_check
                          (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                           59153, 39, MAX_uint32_T, (int32_T)c7_index, 1, 200) -
                          1];
                        if (CV_EML_COND(0, 1, 213U, CV_RELATIONAL_EVAL(4U, 0U,
                              232, c7_d28, 0.0, -1, 2U, c7_d28 < 0.0))) {
                          CV_EML_MCDC(0, 1, 70, true);
                          CV_EML_IF(0, 1, 90, true);
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 940);
                          c7_data_struct_input->EC_events_mins_right[(uint8_T)
                            sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             59220, 79, MAX_uint32_T, (int32_T)
                             c7_data_struct_input->EC_events_index_right, 1, 5)
                            - 1] = c7_data_struct_input->
                            VelRShank_filt[sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             59300, 39, MAX_uint32_T, (int32_T)c7_index, 1, 200)
                            - 1];
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 941);
                          c7_b_EC_events_inds_right[(uint8_T)
                            sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             59404, 61, 0U, (int32_T)
                             c7_data_struct_input->EC_events_index_right, 1, 5)
                            - 1] = c7_index;
                          _SFD_SYMBOL_SWITCH(10U, 24U);
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 942);
                          c7_b_EC_distance_right[(uint8_T)
                            sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             59548, 58, 0U, (int32_T)
                             c7_data_struct_input->EC_events_index_right, 1, 5)
                            - 1] = c7_b_MS_inds_right[(int32_T)c7_b_i - 1] -
                            c7_index;
                          _SFD_SYMBOL_SWITCH(11U, 22U);
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 943);
                          c7_data_struct_input->AN_events_right[(uint8_T)
                            sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             59692, 74, MAX_uint32_T, (int32_T)
                             c7_data_struct_input->EC_events_index_right, 1, 5)
                            - 1] = c7_data_struct_input->AngRShank_filt[(int32_T)
                            c7_index - 1];
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 944);
                          c7_u106 = (uint32_T)
                            c7_data_struct_input->EC_events_index_right + 1U;
                          if (CV_SATURATION_EVAL(4, 0, 82, 0, c7_u106 > 255U)) {
                            c7_u106 = 255U;
                          }

                          c7_data_struct_input->EC_events_index_right = (uint8_T)
                            c7_u106;
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 945);
                          c7_uv34[0] =
                            c7_data_struct_input->EC_events_index_right;
                          c7_b55 = ((real_T)
                                    c7_data_struct_input->EC_events_index_right >
                                    5.0);
                          c7_sc_trueCount = 0;
                          c7_uf_i = 0;
                          while (c7_uf_i <= 0) {
                            if (c7_b55) {
                              c7_sc_trueCount++;
                            }

                            c7_uf_i++;
                            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                          }

                          c7_sc_partialTrueCount = 0;
                          c7_vf_i = 0;
                          while (c7_vf_i <= 0) {
                            if (c7_b55) {
                              c7_iv0[0] = 1;
                              c7_iv0[1] = c7_sc_trueCount;
                              c7_tmp_sizes[0] = 1;
                              c7_tmp_sizes[1] = c7_iv0[1];
                              c7_i512 = c7_tmp_sizes[0];
                              c7_i513 = c7_tmp_sizes[1];
                              c7_bd_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                              for (c7_i514 = 0; c7_i514 <= c7_bd_loop_ub;
                                   c7_i514++) {
                                c7_tmp_data[c7_i514] = 5U;
                              }

                              c7_uv34[c7_vf_i] =
                                c7_tmp_data[c7_sc_partialTrueCount];
                              c7_sc_partialTrueCount++;
                            }

                            c7_vf_i++;
                            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                          }

                          c7_data_struct_input->EC_events_index_right = c7_uv34
                            [0];
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 946);
                          c7_found = 1.0;
                        } else {
                          guard14 = true;
                        }
                      } else {
                        guard15 = true;
                      }
                    } else {
                      guard15 = true;
                    }

                    if (guard15 == true) {
                      guard14 = true;
                    }

                    if (guard14 == true) {
                      CV_EML_MCDC(0, 1, 70, false);
                      CV_EML_IF(0, 1, 90, false);
                    }

                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 948);
                    c7_index--;
                    _SFD_SYMBOL_SWITCH(2U, 2U);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 938);
                    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                  } else {
                    exitg12 = true;
                  }
                }

                CV_EML_WHILE(0, 1, 19, false);
              } else {
                guard12 = true;
              }
            } else {
              guard13 = true;
            }
          } else {
            guard13 = true;
          }

          if (guard13 == true) {
            guard12 = true;
          }

          if (guard12 == true) {
            CV_EML_MCDC(0, 1, 69, false);
            CV_EML_IF(0, 1, 89, false);
          }

          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 951);
          c7_index--;
          _SFD_SYMBOL_SWITCH(2U, 2U);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 935);
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        } else {
          exitg11 = true;
        }
      }

      CV_EML_WHILE(0, 1, 18, false);
      c7_tf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 7, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 955);
    c7_d29 = c7_MS_inds_index_left - 1.0;
    c7_i515 = (int32_T)c7_d29 - 1;
    c7_wf_i = 0;
    while (c7_wf_i <= c7_i515) {
      c7_b_i = 1.0 + (real_T)c7_wf_i;
      _SFD_SYMBOL_SWITCH(18U, 26U);
      CV_EML_FOR(0, 1, 8, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 956);
      c7_found = 0.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 957);
      c7_index = c7_b_MS_inds_left[(int32_T)c7_b_i - 1];
      _SFD_SYMBOL_SWITCH(2U, 2U);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 959);
      exitg9 = false;
      while ((exitg9 == false) && (c7_found == 0.0)) {
        c7_x_q0 = 200U;
        c7_x_qY = c7_x_q0 - (uint32_T)c7_data_struct_input->index_start_calib;
        if (CV_SATURATION_EVAL(4, 0, 83, 0, c7_x_qY > c7_x_q0)) {
          c7_x_qY = 0U;
        }

        c7_u107 = c7_x_qY;
        if (CV_SATURATION_EVAL(4, 0, 83, 0, c7_u107 > 65535U)) {
          c7_u107 = 65535U;
        }

        c7_u108 = (uint32_T)(uint16_T)c7_u107 + 1U;
        if (CV_SATURATION_EVAL(4, 0, 84, 0, c7_u108 > 65535U)) {
          c7_u108 = 65535U;
        }

        if (c7_index > (real_T)(uint16_T)c7_u108) {
          CV_EML_WHILE(0, 1, 20, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 960);
          c7_f55 = c7_data_struct_input->VelLShank_LPF[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 60487, 38,
             MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
          c7_f56 = c7_data_struct_input->VelLShank_LPF[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 60526, 40,
             MAX_uint32_T, (int32_T)(c7_index + 1.0), 1, 200) - 1];
          guard8 = false;
          guard9 = false;
          if (CV_EML_COND(0, 1, 214U, CV_RELATIONAL_EVAL(4U, 0U, 233, (real_T)
                c7_f55, (real_T)c7_f56, -3, 2U, c7_f55 < c7_f56))) {
            c7_f57 = c7_data_struct_input->
              VelLShank_LPF[sf_eml_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 60571, 38,
               MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
            c7_f58 = c7_data_struct_input->
              VelLShank_LPF[sf_eml_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 60610, 40,
               MAX_uint32_T, (int32_T)(c7_index - 1.0), 1, 200) - 1];
            if (CV_EML_COND(0, 1, 215U, CV_RELATIONAL_EVAL(4U, 0U, 234, (real_T)
                  c7_f57, (real_T)c7_f58, -3, 2U, c7_f57 < c7_f58))) {
              c7_d30 = c7_data_struct_input->
                VelLShank_LPF[sf_eml_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 60654, 38,
                 MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
              if (CV_EML_COND(0, 1, 216U, CV_RELATIONAL_EVAL(4U, 0U, 235, c7_d30,
                    0.0, -1, 2U, c7_d30 < 0.0))) {
                CV_EML_MCDC(0, 1, 71, true);
                CV_EML_IF(0, 1, 91, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 962);
                exitg10 = false;
                while ((exitg10 == false) && (c7_found == 0.0)) {
                  c7_y_q0 = 200U;
                  c7_y_qY = c7_y_q0 - (uint32_T)
                    c7_data_struct_input->index_start_calib;
                  if (CV_SATURATION_EVAL(4, 0, 85, 0, c7_y_qY > c7_y_q0)) {
                    c7_y_qY = 0U;
                  }

                  c7_u109 = c7_y_qY;
                  if (CV_SATURATION_EVAL(4, 0, 85, 0, c7_u109 > 65535U)) {
                    c7_u109 = 65535U;
                  }

                  c7_u110 = (uint32_T)(uint16_T)c7_u109 + 1U;
                  if (CV_SATURATION_EVAL(4, 0, 86, 0, c7_u110 > 65535U)) {
                    c7_u110 = 65535U;
                  }

                  if (c7_index > (real_T)(uint16_T)c7_u110) {
                    CV_EML_WHILE(0, 1, 21, true);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 963);
                    c7_f59 = c7_data_struct_input->
                      VelLShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 60933,
                       39, MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
                    c7_f60 = c7_data_struct_input->
                      VelLShank_filt[sf_eml_array_bounds_check
                      (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 60973,
                       41, MAX_uint32_T, (int32_T)(c7_index + 1.0), 1, 200) - 1];
                    guard10 = false;
                    guard11 = false;
                    if (CV_EML_COND(0, 1, 217U, CV_RELATIONAL_EVAL(4U, 0U, 236,
                          (real_T)c7_f59, (real_T)c7_f60, -3, 2U, c7_f59 <
                          c7_f60))) {
                      c7_f61 = c7_data_struct_input->
                        VelLShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         61019, 39, MAX_uint32_T, (int32_T)c7_index, 1, 200) - 1];
                      c7_f62 = c7_data_struct_input->
                        VelLShank_filt[sf_eml_array_bounds_check
                        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                         61059, 41, MAX_uint32_T, (int32_T)(c7_index - 1.0), 1,
                         200) - 1];
                      if (CV_EML_COND(0, 1, 218U, CV_RELATIONAL_EVAL(4U, 0U, 237,
                            (real_T)c7_f61, (real_T)c7_f62, -3, 2U, c7_f61 <
                            c7_f62))) {
                        c7_d31 = c7_data_struct_input->
                          VelLShank_filt[sf_eml_array_bounds_check
                          (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                           61104, 39, MAX_uint32_T, (int32_T)c7_index, 1, 200) -
                          1];
                        if (CV_EML_COND(0, 1, 219U, CV_RELATIONAL_EVAL(4U, 0U,
                              238, c7_d31, 0.0, -1, 2U, c7_d31 < 0.0))) {
                          CV_EML_MCDC(0, 1, 72, true);
                          CV_EML_IF(0, 1, 92, true);
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 964);
                          c7_data_struct_input->EC_events_mins_left[(uint8_T)
                            sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             61171, 77, MAX_uint32_T, (int32_T)
                             c7_data_struct_input->EC_events_index_left, 1, 5) -
                            1] = c7_data_struct_input->
                            VelLShank_filt[sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             61249, 39, MAX_uint32_T, (int32_T)c7_index, 1, 200)
                            - 1];
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 965);
                          c7_b_EC_events_inds_left[(uint8_T)
                            sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             61353, 59, 0U, (int32_T)
                             c7_data_struct_input->EC_events_index_left, 1, 5) -
                            1] = c7_index;
                          _SFD_SYMBOL_SWITCH(4U, 25U);
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 966);
                          c7_b_EC_distance_left[(uint8_T)
                            sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             61495, 56, 0U, (int32_T)
                             c7_data_struct_input->EC_events_index_left, 1, 5) -
                            1] = c7_b_MS_inds_left[(int32_T)c7_b_i - 1] -
                            c7_index;
                          _SFD_SYMBOL_SWITCH(5U, 23U);
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 967);
                          c7_data_struct_input->AN_events_left[(uint8_T)
                            sf_eml_array_bounds_check
                            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U,
                             61636, 72, MAX_uint32_T, (int32_T)
                             c7_data_struct_input->EC_events_index_left, 1, 5) -
                            1] = c7_data_struct_input->AngLShank_filt[(int32_T)
                            c7_index - 1];
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 968);
                          c7_u111 = (uint32_T)
                            c7_data_struct_input->EC_events_index_left + 1U;
                          if (CV_SATURATION_EVAL(4, 0, 87, 0, c7_u111 > 255U)) {
                            c7_u111 = 255U;
                          }

                          c7_data_struct_input->EC_events_index_left = (uint8_T)
                            c7_u111;
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 969);
                          c7_uv35[0] =
                            c7_data_struct_input->EC_events_index_left;
                          c7_b56 = ((real_T)
                                    c7_data_struct_input->EC_events_index_left >
                                    5.0);
                          c7_tc_trueCount = 0;
                          c7_xf_i = 0;
                          while (c7_xf_i <= 0) {
                            if (c7_b56) {
                              c7_tc_trueCount++;
                            }

                            c7_xf_i++;
                            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                          }

                          c7_tc_partialTrueCount = 0;
                          c7_yf_i = 0;
                          while (c7_yf_i <= 0) {
                            if (c7_b56) {
                              c7_iv0[0] = 1;
                              c7_iv0[1] = c7_tc_trueCount;
                              c7_tmp_sizes[0] = 1;
                              c7_tmp_sizes[1] = c7_iv0[1];
                              c7_i516 = c7_tmp_sizes[0];
                              c7_i517 = c7_tmp_sizes[1];
                              c7_cd_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                              for (c7_i518 = 0; c7_i518 <= c7_cd_loop_ub;
                                   c7_i518++) {
                                c7_tmp_data[c7_i518] = 5U;
                              }

                              c7_uv35[c7_yf_i] =
                                c7_tmp_data[c7_tc_partialTrueCount];
                              c7_tc_partialTrueCount++;
                            }

                            c7_yf_i++;
                            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                          }

                          c7_data_struct_input->EC_events_index_left = c7_uv35[0];
                          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 970);
                          c7_found = 1.0;
                        } else {
                          guard10 = true;
                        }
                      } else {
                        guard11 = true;
                      }
                    } else {
                      guard11 = true;
                    }

                    if (guard11 == true) {
                      guard10 = true;
                    }

                    if (guard10 == true) {
                      CV_EML_MCDC(0, 1, 72, false);
                      CV_EML_IF(0, 1, 92, false);
                    }

                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 972);
                    c7_index--;
                    _SFD_SYMBOL_SWITCH(2U, 2U);
                    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 962);
                    _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                  } else {
                    exitg10 = true;
                  }
                }

                CV_EML_WHILE(0, 1, 21, false);
              } else {
                guard8 = true;
              }
            } else {
              guard9 = true;
            }
          } else {
            guard9 = true;
          }

          if (guard9 == true) {
            guard8 = true;
          }

          if (guard8 == true) {
            CV_EML_MCDC(0, 1, 71, false);
            CV_EML_IF(0, 1, 91, false);
          }

          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 975);
          c7_index--;
          _SFD_SYMBOL_SWITCH(2U, 2U);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 959);
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        } else {
          exitg9 = true;
        }
      }

      CV_EML_WHILE(0, 1, 20, false);
      c7_wf_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 8, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 979);
    c7_ab_q0 = c7_data_struct_input->EC_events_index_right;
    c7_ab_qY = c7_ab_q0 - 1U;
    if (CV_SATURATION_EVAL(4, 0, 88, 0, c7_ab_qY > c7_ab_q0)) {
      c7_ab_qY = 0U;
    }

    c7_u112 = c7_ab_qY;
    if (CV_SATURATION_EVAL(4, 0, 88, 0, c7_u112 > 255U)) {
      c7_u112 = 255U;
    }

    c7_u113 = (uint8_T)c7_u112;
    c7_ag_i = 1U;
    while (c7_ag_i <= c7_u113) {
      c7_c_i = c7_ag_i;
      _SFD_SYMBOL_SWITCH(18U, 27U);
      CV_EML_FOR(0, 1, 9, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 980);
      c7_found = 0.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 981);
      c7_index = c7_b_EC_events_inds_right[(uint8_T)sf_eml_array_bounds_check
        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 62228, 23,
         MAX_uint32_T, (int32_T)c7_c_i, 1, 5) - 1] - 1.0;
      _SFD_SYMBOL_SWITCH(2U, 2U);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 982);
      for (c7_i519 = 0; c7_i519 < 50; c7_i519++) {
        c7_EC_peaks[c7_i519] = -2.0E+6;
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 983);
      for (c7_i520 = 0; c7_i520 < 50; c7_i520++) {
        c7_AN_peaks[c7_i520] = 2.0E+6;
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 984);
      c7_EC_peaks_index = 1.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 986);
      exitg8 = false;
      while ((exitg8 == false) && (c7_index >= c7_b_EC_events_inds_right[c7_c_i
              - 1] - c7_b_EC_distance_right[c7_c_i - 1])) {
        if (c7_index > 2.0) {
          CV_EML_WHILE(0, 1, 22, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 987);
          guard6 = false;
          guard7 = false;
          if (CV_EML_COND(0, 1, 220U, CV_RELATIONAL_EVAL(4U, 0U, 239, (real_T)
                c7_data_struct_input->VelRShank_filt[(int32_T)c7_index - 1],
                (real_T)c7_data_struct_input->VelRShank_filt[(int32_T)(c7_index
                 + 1.0) - 1], -3, 2U, c7_data_struct_input->VelRShank_filt
                [(int32_T)c7_index - 1] < c7_data_struct_input->VelRShank_filt
                [(int32_T)(c7_index + 1.0) - 1]))) {
            if (CV_EML_COND(0, 1, 221U, CV_RELATIONAL_EVAL(4U, 0U, 240, (real_T)
                  c7_data_struct_input->VelRShank_filt[(int32_T)c7_index - 1],
                  (real_T)c7_data_struct_input->VelRShank_filt[(int32_T)
                  (c7_index - 1.0) - 1], -3, 2U,
                  c7_data_struct_input->VelRShank_filt[(int32_T)c7_index - 1] <
                  c7_data_struct_input->VelRShank_filt[(int32_T)(c7_index - 1.0)
                  - 1]))) {
              if (CV_EML_COND(0, 1, 222U, CV_RELATIONAL_EVAL(4U, 0U, 241,
                    (real_T)c7_data_struct_input->VelRShank_filt[(int32_T)
                    c7_index - 1], 0.0, -1, 2U,
                    c7_data_struct_input->VelRShank_filt[(int32_T)c7_index - 1] <
                    0.0F))) {
                CV_EML_MCDC(0, 1, 73, true);
                CV_EML_IF(0, 1, 93, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 988);
                c7_EC_peaks[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 62761, 24,
                   0U, (int32_T)c7_EC_peaks_index, 1, 50) - 1] =
                  c7_data_struct_input->VelRShank_filt[(int32_T)c7_index - 1];
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 989);
                c7_AN_peaks[(int32_T)c7_EC_peaks_index - 1] =
                  c7_data_struct_input->AngRShank_filt[(int32_T)c7_index - 1];
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 990);
                c7_EC_peaks_index++;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 991);
                c7_dv6[0] = c7_EC_peaks_index;
                c7_uc_trueCount = 0;
                c7_bg_i = 0;
                while (c7_bg_i <= 0) {
                  if (c7_EC_peaks_index > 50.0) {
                    c7_uc_trueCount++;
                  }

                  c7_bg_i++;
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                }

                c7_uc_partialTrueCount = 0;
                c7_cg_i = 0;
                while (c7_cg_i <= 0) {
                  if (c7_EC_peaks_index > 50.0) {
                    c7_iv0[0] = 1;
                    c7_iv0[1] = c7_uc_trueCount;
                    c7_d_tmp_sizes[0] = 1;
                    c7_d_tmp_sizes[1] = c7_iv0[1];
                    c7_i521 = c7_d_tmp_sizes[0];
                    c7_i522 = c7_d_tmp_sizes[1];
                    c7_dd_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                    for (c7_i523 = 0; c7_i523 <= c7_dd_loop_ub; c7_i523++) {
                      c7_d_tmp_data[c7_i523] = 50.0;
                    }

                    c7_dv6[c7_cg_i] = c7_d_tmp_data[c7_uc_partialTrueCount];
                    c7_uc_partialTrueCount++;
                  }

                  c7_cg_i++;
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                }

                c7_EC_peaks_index = c7_dv6[0];
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 992);
                c7_found = 1.0;
              } else {
                guard6 = true;
              }
            } else {
              guard7 = true;
            }
          } else {
            guard7 = true;
          }

          if (guard7 == true) {
            guard6 = true;
          }

          if (guard6 == true) {
            CV_EML_MCDC(0, 1, 73, false);
            CV_EML_IF(0, 1, 93, false);
          }

          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 994);
          c7_index--;
          _SFD_SYMBOL_SWITCH(2U, 2U);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 986);
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        } else {
          exitg8 = true;
        }
      }

      CV_EML_WHILE(0, 1, 22, false);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 997);
      if (CV_EML_IF(0, 1, 94, CV_RELATIONAL_EVAL(4U, 0U, 242, c7_found, 0.0, -1,
            0U, c7_found == 0.0))) {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 998);
        c7_f63 = c7_data_struct_input->VelRShank_filt[sf_eml_array_bounds_check
          (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 63347, 78,
           MAX_uint32_T, (int32_T)(c7_b_EC_events_inds_right[c7_c_i - 1] -
            c7_b_EC_distance_right[c7_c_i - 1]), 1, 200) - 1] + 1.0F;
        c7_b_sign(chartInstance, &c7_f63);
        c7_n_A = -c7_f63;
        c7_je_y = c7_b_rdivide(chartInstance, c7_n_A, 2.0);
        c7_EC_peaks[sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
          chartInstance->S, 5U, 63236, 24, 0U, (int32_T)c7_EC_peaks_index, 1, 50)
          - 1] = c7_data_struct_input->VelRShank_filt[sf_eml_array_bounds_check
          (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 63261, 78,
           MAX_uint32_T, (int32_T)(c7_b_EC_events_inds_right[c7_c_i - 1] -
            c7_b_EC_distance_right[c7_c_i - 1]), 1, 200) - 1] * c7_je_y;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 999);
        c7_AN_peaks[(int32_T)c7_EC_peaks_index - 1] =
          c7_data_struct_input->AngRShank_filt[sf_eml_array_bounds_check
          (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 63470, 78,
           MAX_uint32_T, (int32_T)(c7_b_EC_events_inds_right[c7_c_i - 1] -
            c7_b_EC_distance_right[c7_c_i - 1]), 1, 200) - 1];
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1001);
      c7_vc_trueCount = 0;
      c7_dg_i = 0;
      while (c7_dg_i <= 49) {
        if (c7_EC_peaks[c7_dg_i] > -1.0E+6) {
          c7_vc_trueCount++;
        }

        c7_dg_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_e_tmp_sizes = c7_vc_trueCount;
      c7_vc_partialTrueCount = 0;
      c7_eg_i = 0;
      while (c7_eg_i <= 49) {
        if (c7_EC_peaks[c7_eg_i] > -1.0E+6) {
          c7_e_tmp_data[c7_vc_partialTrueCount] = c7_eg_i + 1;
          c7_vc_partialTrueCount++;
        }

        c7_eg_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_c_EC_peaks_sizes = c7_e_tmp_sizes;
      c7_ed_loop_ub = c7_e_tmp_sizes - 1;
      for (c7_i524 = 0; c7_i524 <= c7_ed_loop_ub; c7_i524++) {
        c7_c_EC_peaks_data[c7_i524] = c7_EC_peaks[c7_e_tmp_data[c7_i524] - 1];
      }

      c7_data_struct_input->EC_peaks_mins_right[(uint8_T)
        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct, chartInstance->S,
        5U, 63570, 77, MAX_uint32_T, (int32_T)
        c7_data_struct_input->EC_peaks_index_right, 1, 5) - 1] = (real32_T)
        c7_c_mean(chartInstance, c7_c_EC_peaks_data, c7_c_EC_peaks_sizes);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1002);
      for (c7_i525 = 0; c7_i525 < 50; c7_i525++) {
        c7_b_varargin_1[c7_i525] = c7_AN_peaks[c7_i525];
      }

      c7_c_ixstart = 1;
      c7_g_mtmp = c7_b_varargin_1[0];
      c7_i_x = c7_g_mtmp;
      c7_ce_b = muDoubleScalarIsNaN(c7_i_x);
      if (c7_ce_b) {
        c7_g_ix = 2;
        exitg7 = false;
        while ((exitg7 == false) && (c7_g_ix < 51)) {
          c7_h_ix = c7_g_ix - 1;
          c7_c_ixstart = c7_h_ix + 1;
          c7_j_x = c7_b_varargin_1[c7_h_ix];
          c7_de_b = muDoubleScalarIsNaN(c7_j_x);
          if (!c7_de_b) {
            c7_g_mtmp = c7_b_varargin_1[c7_h_ix];
            exitg7 = true;
          } else {
            c7_g_ix++;
          }
        }
      }

      if (c7_c_ixstart < 50) {
        c7_i526 = c7_c_ixstart;
        for (c7_i_ix = c7_i526 + 1; c7_i_ix < 51; c7_i_ix++) {
          c7_h_ix = c7_i_ix - 1;
          c7_d_a = c7_b_varargin_1[c7_h_ix];
          c7_ee_b = c7_g_mtmp;
          c7_d_p = (c7_d_a < c7_ee_b);
          if (c7_d_p) {
            c7_g_mtmp = c7_b_varargin_1[c7_h_ix];
          }
        }
      }

      c7_h_mtmp = c7_g_mtmp;
      c7_c_minval = c7_h_mtmp;
      c7_data_struct_input->AN_peaks_right[(uint8_T)sf_eml_array_bounds_check
        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 63687, 72,
         MAX_uint32_T, (int32_T)c7_data_struct_input->EC_peaks_index_right, 1, 5)
        - 1] = (real32_T)c7_c_minval;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1003);
      c7_u114 = (uint32_T)c7_data_struct_input->EC_peaks_index_right + 1U;
      if (CV_SATURATION_EVAL(4, 0, 90, 0, c7_u114 > 255U)) {
        c7_u114 = 255U;
      }

      c7_data_struct_input->EC_peaks_index_right = (uint8_T)c7_u114;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1004);
      c7_uv36[0] = c7_data_struct_input->EC_peaks_index_right;
      c7_b57 = ((real_T)c7_data_struct_input->EC_peaks_index_right > 5.0);
      c7_wc_trueCount = 0;
      c7_fg_i = 0;
      while (c7_fg_i <= 0) {
        if (c7_b57) {
          c7_wc_trueCount++;
        }

        c7_fg_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_wc_partialTrueCount = 0;
      c7_gg_i = 0;
      while (c7_gg_i <= 0) {
        if (c7_b57) {
          c7_iv0[0] = 1;
          c7_iv0[1] = c7_wc_trueCount;
          c7_tmp_sizes[0] = 1;
          c7_tmp_sizes[1] = c7_iv0[1];
          c7_i527 = c7_tmp_sizes[0];
          c7_i528 = c7_tmp_sizes[1];
          c7_fd_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
          for (c7_i529 = 0; c7_i529 <= c7_fd_loop_ub; c7_i529++) {
            c7_tmp_data[c7_i529] = 5U;
          }

          c7_uv36[c7_gg_i] = c7_tmp_data[c7_wc_partialTrueCount];
          c7_wc_partialTrueCount++;
        }

        c7_gg_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_data_struct_input->EC_peaks_index_right = c7_uv36[0];
      c7_ag_i = (uint8_T)((uint32_T)c7_ag_i + 1U);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 9, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1007);
    c7_bb_q0 = c7_data_struct_input->EC_events_index_left;
    c7_bb_qY = c7_bb_q0 - 1U;
    if (CV_SATURATION_EVAL(4, 0, 91, 0, c7_bb_qY > c7_bb_q0)) {
      c7_bb_qY = 0U;
    }

    c7_u115 = c7_bb_qY;
    if (CV_SATURATION_EVAL(4, 0, 91, 0, c7_u115 > 255U)) {
      c7_u115 = 255U;
    }

    c7_u116 = (uint8_T)c7_u115;
    c7_hg_i = 1U;
    while (c7_hg_i <= c7_u116) {
      c7_c_i = c7_hg_i;
      _SFD_SYMBOL_SWITCH(18U, 27U);
      CV_EML_FOR(0, 1, 10, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1008);
      c7_found = 0.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1009);
      c7_index = c7_b_EC_events_inds_left[(uint8_T)sf_eml_array_bounds_check
        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 64053, 22,
         MAX_uint32_T, (int32_T)c7_c_i, 1, 5) - 1] - 1.0;
      _SFD_SYMBOL_SWITCH(2U, 2U);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1010);
      for (c7_i530 = 0; c7_i530 < 50; c7_i530++) {
        c7_EC_peaks[c7_i530] = -2.0E+6;
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1011);
      for (c7_i531 = 0; c7_i531 < 50; c7_i531++) {
        c7_AN_peaks[c7_i531] = 2.0E+6;
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1012);
      c7_EC_peaks_index = 1.0;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1014);
      exitg6 = false;
      while ((exitg6 == false) && (c7_index >= c7_b_EC_events_inds_left[c7_c_i -
              1] - c7_b_EC_distance_left[c7_c_i - 1])) {
        if (c7_index > 2.0) {
          CV_EML_WHILE(0, 1, 23, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1015);
          guard4 = false;
          guard5 = false;
          if (CV_EML_COND(0, 1, 223U, CV_RELATIONAL_EVAL(4U, 0U, 243, (real_T)
                c7_data_struct_input->VelLShank_filt[(int32_T)c7_index - 1],
                (real_T)c7_data_struct_input->VelLShank_filt[(int32_T)(c7_index
                 + 1.0) - 1], -3, 2U, c7_data_struct_input->VelLShank_filt
                [(int32_T)c7_index - 1] < c7_data_struct_input->VelLShank_filt
                [(int32_T)(c7_index + 1.0) - 1]))) {
            if (CV_EML_COND(0, 1, 224U, CV_RELATIONAL_EVAL(4U, 0U, 244, (real_T)
                  c7_data_struct_input->VelLShank_filt[(int32_T)c7_index - 1],
                  (real_T)c7_data_struct_input->VelLShank_filt[(int32_T)
                  (c7_index - 1.0) - 1], -3, 2U,
                  c7_data_struct_input->VelLShank_filt[(int32_T)c7_index - 1] <
                  c7_data_struct_input->VelLShank_filt[(int32_T)(c7_index - 1.0)
                  - 1]))) {
              if (CV_EML_COND(0, 1, 225U, CV_RELATIONAL_EVAL(4U, 0U, 245,
                    (real_T)c7_data_struct_input->VelLShank_filt[(int32_T)
                    c7_index - 1], 0.0, -1, 2U,
                    c7_data_struct_input->VelLShank_filt[(int32_T)c7_index - 1] <
                    0.0F))) {
                CV_EML_MCDC(0, 1, 74, true);
                CV_EML_IF(0, 1, 95, true);
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1016);
                c7_EC_peaks[sf_eml_array_bounds_check
                  (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 64583, 24,
                   0U, (int32_T)c7_EC_peaks_index, 1, 50) - 1] =
                  c7_data_struct_input->VelLShank_filt[(int32_T)c7_index - 1];
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1017);
                c7_AN_peaks[(int32_T)c7_EC_peaks_index - 1] =
                  c7_data_struct_input->AngLShank_filt[(int32_T)c7_index - 1];
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1018);
                c7_EC_peaks_index++;
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1019);
                c7_dv7[0] = c7_EC_peaks_index;
                c7_xc_trueCount = 0;
                c7_ig_i = 0;
                while (c7_ig_i <= 0) {
                  if (c7_EC_peaks_index > 50.0) {
                    c7_xc_trueCount++;
                  }

                  c7_ig_i++;
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                }

                c7_xc_partialTrueCount = 0;
                c7_jg_i = 0;
                while (c7_jg_i <= 0) {
                  if (c7_EC_peaks_index > 50.0) {
                    c7_iv0[0] = 1;
                    c7_iv0[1] = c7_xc_trueCount;
                    c7_d_tmp_sizes[0] = 1;
                    c7_d_tmp_sizes[1] = c7_iv0[1];
                    c7_i532 = c7_d_tmp_sizes[0];
                    c7_i533 = c7_d_tmp_sizes[1];
                    c7_gd_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
                    for (c7_i534 = 0; c7_i534 <= c7_gd_loop_ub; c7_i534++) {
                      c7_d_tmp_data[c7_i534] = 50.0;
                    }

                    c7_dv7[c7_jg_i] = c7_d_tmp_data[c7_xc_partialTrueCount];
                    c7_xc_partialTrueCount++;
                  }

                  c7_jg_i++;
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                }

                c7_EC_peaks_index = c7_dv7[0];
                _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1020);
                c7_found = 1.0;
              } else {
                guard4 = true;
              }
            } else {
              guard5 = true;
            }
          } else {
            guard5 = true;
          }

          if (guard5 == true) {
            guard4 = true;
          }

          if (guard4 == true) {
            CV_EML_MCDC(0, 1, 74, false);
            CV_EML_IF(0, 1, 95, false);
          }

          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1022);
          c7_index--;
          _SFD_SYMBOL_SWITCH(2U, 2U);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1014);
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        } else {
          exitg6 = true;
        }
      }

      CV_EML_WHILE(0, 1, 23, false);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1025);
      guard3 = false;
      if (CV_EML_COND(0, 1, 226U, CV_RELATIONAL_EVAL(4U, 0U, 246, c7_found, 0.0,
            -1, 0U, c7_found == 0.0))) {
        if (CV_EML_COND(0, 1, 227U, CV_RELATIONAL_EVAL(4U, 0U, 247,
              c7_b_EC_events_inds_left[c7_c_i - 1] -
              c7_b_EC_distance_left[c7_c_i - 1], 0.0, -1, 4U,
              c7_b_EC_events_inds_left[c7_c_i - 1] -
              c7_b_EC_distance_left[c7_c_i - 1] > 0.0))) {
          CV_EML_MCDC(0, 1, 75, true);
          CV_EML_IF(0, 1, 96, true);
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1026);
          c7_f64 = c7_data_struct_input->
            VelLShank_filt[sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 65215, 76, MAX_uint32_T, (int32_T)
            (c7_b_EC_events_inds_left[c7_c_i - 1] - c7_b_EC_distance_left[c7_c_i
             - 1]), 1, 200) - 1] + 1.0F;
          c7_b_sign(chartInstance, &c7_f64);
          c7_o_A = -c7_f64;
          c7_ke_y = c7_b_rdivide(chartInstance, c7_o_A, 2.0);
          c7_EC_peaks[sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 65106, 24, 0U, (int32_T)c7_EC_peaks_index, 1,
            50) - 1] = c7_data_struct_input->
            VelLShank_filt[sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 65131, 76, MAX_uint32_T, (int32_T)
            (c7_b_EC_events_inds_left[c7_c_i - 1] - c7_b_EC_distance_left[c7_c_i
             - 1]), 1, 200) - 1] * c7_ke_y;
          _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1027);
          c7_AN_peaks[(int32_T)c7_EC_peaks_index - 1] =
            c7_data_struct_input->AngLShank_filt[sf_eml_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 65336, 76,
             MAX_uint32_T, (int32_T)(c7_b_EC_events_inds_left[c7_c_i - 1] -
              c7_b_EC_distance_left[c7_c_i - 1]), 1, 200) - 1];
        } else {
          guard3 = true;
        }
      } else {
        guard3 = true;
      }

      if (guard3 == true) {
        CV_EML_MCDC(0, 1, 75, false);
        CV_EML_IF(0, 1, 96, false);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1029);
      c7_yc_trueCount = 0;
      c7_kg_i = 0;
      while (c7_kg_i <= 49) {
        if (c7_EC_peaks[c7_kg_i] > -1.0E+6) {
          c7_yc_trueCount++;
        }

        c7_kg_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_e_tmp_sizes = c7_yc_trueCount;
      c7_yc_partialTrueCount = 0;
      c7_lg_i = 0;
      while (c7_lg_i <= 49) {
        if (c7_EC_peaks[c7_lg_i] > -1.0E+6) {
          c7_e_tmp_data[c7_yc_partialTrueCount] = c7_lg_i + 1;
          c7_yc_partialTrueCount++;
        }

        c7_lg_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_d_EC_peaks_sizes = c7_e_tmp_sizes;
      c7_hd_loop_ub = c7_e_tmp_sizes - 1;
      for (c7_i535 = 0; c7_i535 <= c7_hd_loop_ub; c7_i535++) {
        c7_d_EC_peaks_data[c7_i535] = c7_EC_peaks[c7_e_tmp_data[c7_i535] - 1];
      }

      c7_data_struct_input->EC_peaks_mins_left[(uint8_T)
        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct, chartInstance->S,
        5U, 65434, 75, MAX_uint32_T, (int32_T)
        c7_data_struct_input->EC_peaks_index_left, 1, 5) - 1] = (real32_T)
        c7_c_mean(chartInstance, c7_d_EC_peaks_data, c7_d_EC_peaks_sizes);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1030);
      for (c7_i536 = 0; c7_i536 < 50; c7_i536++) {
        c7_b_varargin_1[c7_i536] = c7_AN_peaks[c7_i536];
      }

      c7_d_ixstart = 1;
      c7_i_mtmp = c7_b_varargin_1[0];
      c7_k_x = c7_i_mtmp;
      c7_fe_b = muDoubleScalarIsNaN(c7_k_x);
      if (c7_fe_b) {
        c7_j_ix = 2;
        exitg5 = false;
        while ((exitg5 == false) && (c7_j_ix < 51)) {
          c7_k_ix = c7_j_ix - 1;
          c7_d_ixstart = c7_k_ix + 1;
          c7_l_x = c7_b_varargin_1[c7_k_ix];
          c7_ge_b = muDoubleScalarIsNaN(c7_l_x);
          if (!c7_ge_b) {
            c7_i_mtmp = c7_b_varargin_1[c7_k_ix];
            exitg5 = true;
          } else {
            c7_j_ix++;
          }
        }
      }

      if (c7_d_ixstart < 50) {
        c7_i537 = c7_d_ixstart;
        for (c7_l_ix = c7_i537 + 1; c7_l_ix < 51; c7_l_ix++) {
          c7_k_ix = c7_l_ix - 1;
          c7_e_a = c7_b_varargin_1[c7_k_ix];
          c7_he_b = c7_i_mtmp;
          c7_e_p = (c7_e_a < c7_he_b);
          if (c7_e_p) {
            c7_i_mtmp = c7_b_varargin_1[c7_k_ix];
          }
        }
      }

      c7_j_mtmp = c7_i_mtmp;
      c7_d_minval = c7_j_mtmp;
      c7_data_struct_input->AN_peaks_left[(uint8_T)sf_eml_array_bounds_check
        (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 65549, 70,
         MAX_uint32_T, (int32_T)c7_data_struct_input->EC_peaks_index_left, 1, 5)
        - 1] = (real32_T)c7_d_minval;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1031);
      c7_u117 = (uint32_T)c7_data_struct_input->EC_peaks_index_left + 1U;
      if (CV_SATURATION_EVAL(4, 0, 94, 0, c7_u117 > 255U)) {
        c7_u117 = 255U;
      }

      c7_data_struct_input->EC_peaks_index_left = (uint8_T)c7_u117;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1032);
      c7_uv37[0] = c7_data_struct_input->EC_peaks_index_left;
      c7_b58 = ((real_T)c7_data_struct_input->EC_peaks_index_left > 5.0);
      c7_ad_trueCount = 0;
      c7_mg_i = 0;
      while (c7_mg_i <= 0) {
        if (c7_b58) {
          c7_ad_trueCount++;
        }

        c7_mg_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_ad_partialTrueCount = 0;
      c7_ng_i = 0;
      while (c7_ng_i <= 0) {
        if (c7_b58) {
          c7_iv0[0] = 1;
          c7_iv0[1] = c7_ad_trueCount;
          c7_tmp_sizes[0] = 1;
          c7_tmp_sizes[1] = c7_iv0[1];
          c7_i538 = c7_tmp_sizes[0];
          c7_i539 = c7_tmp_sizes[1];
          c7_id_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
          for (c7_i540 = 0; c7_i540 <= c7_id_loop_ub; c7_i540++) {
            c7_tmp_data[c7_i540] = 5U;
          }

          c7_uv37[c7_ng_i] = c7_tmp_data[c7_ad_partialTrueCount];
          c7_ad_partialTrueCount++;
        }

        c7_ng_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_data_struct_input->EC_peaks_index_left = c7_uv37[0];
      c7_hg_i = (uint8_T)((uint32_T)c7_hg_i + 1U);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 10, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1035);
    for (c7_i541 = 0; c7_i541 < 5; c7_i541++) {
      c7_bv4[c7_i541] = (c7_data_struct_input->EC_events_mins_right[c7_i541] >
                         -1.0E+6F);
    }

    for (c7_i542 = 0; c7_i542 < 5; c7_i542++) {
      c7_bv5[c7_i542] = (c7_data_struct_input->EC_peaks_mins_right[c7_i542] >
                         -1.0E+6F);
    }

    c7_bd_trueCount = 0;
    c7_og_i = 0;
    while (c7_og_i <= 4) {
      if (c7_bv4[c7_og_i]) {
        c7_bd_trueCount++;
      }

      c7_og_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_bd_trueCount;
    c7_bd_partialTrueCount = 0;
    c7_pg_i = 0;
    while (c7_pg_i <= 4) {
      if (c7_bv4[c7_pg_i]) {
        c7_c_tmp_data[c7_bd_partialTrueCount] = c7_pg_i + 1;
        c7_bd_partialTrueCount++;
      }

      c7_pg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_cd_trueCount = 0;
    c7_qg_i = 0;
    while (c7_qg_i <= 4) {
      if (c7_bv5[c7_qg_i]) {
        c7_cd_trueCount++;
      }

      c7_qg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_f_tmp_sizes[0] = 1;
    c7_f_tmp_sizes[1] = c7_cd_trueCount;
    c7_cd_partialTrueCount = 0;
    c7_rg_i = 0;
    while (c7_rg_i <= 4) {
      if (c7_bv5[c7_rg_i]) {
        c7_f_tmp_data[c7_cd_partialTrueCount] = c7_rg_i + 1;
        c7_cd_partialTrueCount++;
      }

      c7_rg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_nb_data_struct_input_sizes[0] = 1;
    c7_nb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_qd_data_struct_input = c7_nb_data_struct_input_sizes[0];
    c7_rd_data_struct_input = c7_nb_data_struct_input_sizes[1];
    c7_jd_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i543 = 0; c7_i543 <= c7_jd_loop_ub; c7_i543++) {
      c7_nb_data_struct_input_data[c7_i543] =
        c7_data_struct_input->EC_events_mins_right[c7_c_tmp_data[c7_i543] - 1];
    }

    c7_ob_data_struct_input_sizes[0] = 1;
    c7_ob_data_struct_input_sizes[1] = c7_f_tmp_sizes[1];
    c7_sd_data_struct_input = c7_ob_data_struct_input_sizes[0];
    c7_td_data_struct_input = c7_ob_data_struct_input_sizes[1];
    c7_kd_loop_ub = c7_f_tmp_sizes[0] * c7_f_tmp_sizes[1] - 1;
    for (c7_i544 = 0; c7_i544 <= c7_kd_loop_ub; c7_i544++) {
      c7_ob_data_struct_input_data[c7_i544] =
        c7_data_struct_input->EC_peaks_mins_right[c7_f_tmp_data[c7_i544] - 1];
    }

    c7_p_A = c7_b_mean(chartInstance, c7_nb_data_struct_input_data,
                       c7_nb_data_struct_input_sizes) + c7_b_mean(chartInstance,
      c7_ob_data_struct_input_data, c7_ob_data_struct_input_sizes);
    c7_le_y = c7_b_rdivide(chartInstance, c7_p_A, 2.0);
    c7_data_struct_input->EC_th_right = c7_le_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1036);
    for (c7_i545 = 0; c7_i545 < 5; c7_i545++) {
      c7_bv4[c7_i545] = (c7_data_struct_input->EC_events_mins_left[c7_i545] >
                         -1.0E+6F);
    }

    for (c7_i546 = 0; c7_i546 < 5; c7_i546++) {
      c7_bv5[c7_i546] = (c7_data_struct_input->EC_peaks_mins_left[c7_i546] >
                         -1.0E+6F);
    }

    c7_dd_trueCount = 0;
    c7_sg_i = 0;
    while (c7_sg_i <= 4) {
      if (c7_bv4[c7_sg_i]) {
        c7_dd_trueCount++;
      }

      c7_sg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_dd_trueCount;
    c7_dd_partialTrueCount = 0;
    c7_tg_i = 0;
    while (c7_tg_i <= 4) {
      if (c7_bv4[c7_tg_i]) {
        c7_c_tmp_data[c7_dd_partialTrueCount] = c7_tg_i + 1;
        c7_dd_partialTrueCount++;
      }

      c7_tg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_ed_trueCount = 0;
    c7_ug_i = 0;
    while (c7_ug_i <= 4) {
      if (c7_bv5[c7_ug_i]) {
        c7_ed_trueCount++;
      }

      c7_ug_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_f_tmp_sizes[0] = 1;
    c7_f_tmp_sizes[1] = c7_ed_trueCount;
    c7_ed_partialTrueCount = 0;
    c7_vg_i = 0;
    while (c7_vg_i <= 4) {
      if (c7_bv5[c7_vg_i]) {
        c7_f_tmp_data[c7_ed_partialTrueCount] = c7_vg_i + 1;
        c7_ed_partialTrueCount++;
      }

      c7_vg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_pb_data_struct_input_sizes[0] = 1;
    c7_pb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_ud_data_struct_input = c7_pb_data_struct_input_sizes[0];
    c7_vd_data_struct_input = c7_pb_data_struct_input_sizes[1];
    c7_ld_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i547 = 0; c7_i547 <= c7_ld_loop_ub; c7_i547++) {
      c7_pb_data_struct_input_data[c7_i547] =
        c7_data_struct_input->EC_events_mins_left[c7_c_tmp_data[c7_i547] - 1];
    }

    c7_qb_data_struct_input_sizes[0] = 1;
    c7_qb_data_struct_input_sizes[1] = c7_f_tmp_sizes[1];
    c7_wd_data_struct_input = c7_qb_data_struct_input_sizes[0];
    c7_xd_data_struct_input = c7_qb_data_struct_input_sizes[1];
    c7_md_loop_ub = c7_f_tmp_sizes[0] * c7_f_tmp_sizes[1] - 1;
    for (c7_i548 = 0; c7_i548 <= c7_md_loop_ub; c7_i548++) {
      c7_qb_data_struct_input_data[c7_i548] =
        c7_data_struct_input->EC_peaks_mins_left[c7_f_tmp_data[c7_i548] - 1];
    }

    c7_q_A = c7_b_mean(chartInstance, c7_pb_data_struct_input_data,
                       c7_pb_data_struct_input_sizes) + c7_b_mean(chartInstance,
      c7_qb_data_struct_input_data, c7_qb_data_struct_input_sizes);
    c7_me_y = c7_b_rdivide(chartInstance, c7_q_A, 2.0);
    c7_data_struct_input->EC_th_left = c7_me_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1037);
    for (c7_i549 = 0; c7_i549 < 5; c7_i549++) {
      c7_bv4[c7_i549] = (c7_data_struct_input->AN_events_right[c7_i549] >
                         -1.0E+6F);
    }

    for (c7_i550 = 0; c7_i550 < 5; c7_i550++) {
      c7_bv5[c7_i550] = (c7_data_struct_input->AN_peaks_right[c7_i550] >
                         -1.0E+6F);
    }

    c7_fd_trueCount = 0;
    c7_wg_i = 0;
    while (c7_wg_i <= 4) {
      if (c7_bv4[c7_wg_i]) {
        c7_fd_trueCount++;
      }

      c7_wg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_fd_trueCount;
    c7_fd_partialTrueCount = 0;
    c7_xg_i = 0;
    while (c7_xg_i <= 4) {
      if (c7_bv4[c7_xg_i]) {
        c7_c_tmp_data[c7_fd_partialTrueCount] = c7_xg_i + 1;
        c7_fd_partialTrueCount++;
      }

      c7_xg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_gd_trueCount = 0;
    c7_yg_i = 0;
    while (c7_yg_i <= 4) {
      if (c7_bv5[c7_yg_i]) {
        c7_gd_trueCount++;
      }

      c7_yg_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_f_tmp_sizes[0] = 1;
    c7_f_tmp_sizes[1] = c7_gd_trueCount;
    c7_gd_partialTrueCount = 0;
    c7_ah_i = 0;
    while (c7_ah_i <= 4) {
      if (c7_bv5[c7_ah_i]) {
        c7_f_tmp_data[c7_gd_partialTrueCount] = c7_ah_i + 1;
        c7_gd_partialTrueCount++;
      }

      c7_ah_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_rb_data_struct_input_sizes[0] = 1;
    c7_rb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_yd_data_struct_input = c7_rb_data_struct_input_sizes[0];
    c7_ae_data_struct_input = c7_rb_data_struct_input_sizes[1];
    c7_nd_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i551 = 0; c7_i551 <= c7_nd_loop_ub; c7_i551++) {
      c7_rb_data_struct_input_data[c7_i551] =
        c7_data_struct_input->AN_events_right[c7_c_tmp_data[c7_i551] - 1];
    }

    c7_sb_data_struct_input_sizes[0] = 1;
    c7_sb_data_struct_input_sizes[1] = c7_f_tmp_sizes[1];
    c7_be_data_struct_input = c7_sb_data_struct_input_sizes[0];
    c7_ce_data_struct_input = c7_sb_data_struct_input_sizes[1];
    c7_od_loop_ub = c7_f_tmp_sizes[0] * c7_f_tmp_sizes[1] - 1;
    for (c7_i552 = 0; c7_i552 <= c7_od_loop_ub; c7_i552++) {
      c7_sb_data_struct_input_data[c7_i552] =
        c7_data_struct_input->AN_peaks_right[c7_f_tmp_data[c7_i552] - 1];
    }

    c7_r_A = c7_b_mean(chartInstance, c7_rb_data_struct_input_data,
                       c7_rb_data_struct_input_sizes) + c7_b_mean(chartInstance,
      c7_sb_data_struct_input_data, c7_sb_data_struct_input_sizes);
    c7_ne_y = c7_b_rdivide(chartInstance, c7_r_A, 2.0);
    c7_data_struct_input->AN_th_right = c7_ne_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1038);
    for (c7_i553 = 0; c7_i553 < 5; c7_i553++) {
      c7_bv4[c7_i553] = (c7_data_struct_input->AN_events_left[c7_i553] >
                         -1.0E+6F);
    }

    for (c7_i554 = 0; c7_i554 < 5; c7_i554++) {
      c7_bv5[c7_i554] = (c7_data_struct_input->AN_peaks_left[c7_i554] > -1.0E+6F);
    }

    c7_hd_trueCount = 0;
    c7_bh_i = 0;
    while (c7_bh_i <= 4) {
      if (c7_bv4[c7_bh_i]) {
        c7_hd_trueCount++;
      }

      c7_bh_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_hd_trueCount;
    c7_hd_partialTrueCount = 0;
    c7_ch_i = 0;
    while (c7_ch_i <= 4) {
      if (c7_bv4[c7_ch_i]) {
        c7_c_tmp_data[c7_hd_partialTrueCount] = c7_ch_i + 1;
        c7_hd_partialTrueCount++;
      }

      c7_ch_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_id_trueCount = 0;
    c7_dh_i = 0;
    while (c7_dh_i <= 4) {
      if (c7_bv5[c7_dh_i]) {
        c7_id_trueCount++;
      }

      c7_dh_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_f_tmp_sizes[0] = 1;
    c7_f_tmp_sizes[1] = c7_id_trueCount;
    c7_id_partialTrueCount = 0;
    c7_eh_i = 0;
    while (c7_eh_i <= 4) {
      if (c7_bv5[c7_eh_i]) {
        c7_f_tmp_data[c7_id_partialTrueCount] = c7_eh_i + 1;
        c7_id_partialTrueCount++;
      }

      c7_eh_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_tb_data_struct_input_sizes[0] = 1;
    c7_tb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_de_data_struct_input = c7_tb_data_struct_input_sizes[0];
    c7_ee_data_struct_input = c7_tb_data_struct_input_sizes[1];
    c7_pd_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i555 = 0; c7_i555 <= c7_pd_loop_ub; c7_i555++) {
      c7_tb_data_struct_input_data[c7_i555] =
        c7_data_struct_input->AN_events_left[c7_c_tmp_data[c7_i555] - 1];
    }

    c7_ub_data_struct_input_sizes[0] = 1;
    c7_ub_data_struct_input_sizes[1] = c7_f_tmp_sizes[1];
    c7_fe_data_struct_input = c7_ub_data_struct_input_sizes[0];
    c7_ge_data_struct_input = c7_ub_data_struct_input_sizes[1];
    c7_qd_loop_ub = c7_f_tmp_sizes[0] * c7_f_tmp_sizes[1] - 1;
    for (c7_i556 = 0; c7_i556 <= c7_qd_loop_ub; c7_i556++) {
      c7_ub_data_struct_input_data[c7_i556] =
        c7_data_struct_input->AN_peaks_left[c7_f_tmp_data[c7_i556] - 1];
    }

    c7_s_A = c7_b_mean(chartInstance, c7_tb_data_struct_input_data,
                       c7_tb_data_struct_input_sizes) + c7_b_mean(chartInstance,
      c7_ub_data_struct_input_data, c7_ub_data_struct_input_sizes);
    c7_oe_y = c7_b_rdivide(chartInstance, c7_s_A, 2.0);
    c7_data_struct_input->AN_th_left = c7_oe_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1042);
    for (c7_i557 = 0; c7_i557 < 5; c7_i557++) {
      c7_bv4[c7_i557] = (c7_data_struct_input->EC_events_mins_left[c7_i557] >
                         -1.0E+6F);
    }

    c7_jd_trueCount = 0;
    c7_fh_i = 0;
    while (c7_fh_i <= 4) {
      if (c7_bv4[c7_fh_i]) {
        c7_jd_trueCount++;
      }

      c7_fh_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_jd_trueCount;
    c7_jd_partialTrueCount = 0;
    c7_gh_i = 0;
    while (c7_gh_i <= 4) {
      if (c7_bv4[c7_gh_i]) {
        c7_c_tmp_data[c7_jd_partialTrueCount] = c7_gh_i + 1;
        c7_jd_partialTrueCount++;
      }

      c7_gh_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_vb_data_struct_input_sizes[0] = 1;
    c7_vb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_he_data_struct_input = c7_vb_data_struct_input_sizes[0];
    c7_ie_data_struct_input = c7_vb_data_struct_input_sizes[1];
    c7_rd_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i558 = 0; c7_i558 <= c7_rd_loop_ub; c7_i558++) {
      c7_vb_data_struct_input_data[c7_i558] =
        c7_data_struct_input->EC_events_mins_left[c7_c_tmp_data[c7_i558] - 1];
    }

    c7_t_A = c7_b_mean(chartInstance, c7_vb_data_struct_input_data,
                       c7_vb_data_struct_input_sizes);
    c7_pe_y = c7_b_rdivide(chartInstance, c7_t_A, 3.0);
    c7_data_struct_input->stop_Vel_th_left = c7_pe_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1043);
    for (c7_i559 = 0; c7_i559 < 5; c7_i559++) {
      c7_bv4[c7_i559] = (c7_data_struct_input->EC_events_mins_right[c7_i559] >
                         -1.0E+6F);
    }

    c7_kd_trueCount = 0;
    c7_hh_i = 0;
    while (c7_hh_i <= 4) {
      if (c7_bv4[c7_hh_i]) {
        c7_kd_trueCount++;
      }

      c7_hh_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_kd_trueCount;
    c7_kd_partialTrueCount = 0;
    c7_ih_i = 0;
    while (c7_ih_i <= 4) {
      if (c7_bv4[c7_ih_i]) {
        c7_c_tmp_data[c7_kd_partialTrueCount] = c7_ih_i + 1;
        c7_kd_partialTrueCount++;
      }

      c7_ih_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_wb_data_struct_input_sizes[0] = 1;
    c7_wb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_je_data_struct_input = c7_wb_data_struct_input_sizes[0];
    c7_ke_data_struct_input = c7_wb_data_struct_input_sizes[1];
    c7_sd_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i560 = 0; c7_i560 <= c7_sd_loop_ub; c7_i560++) {
      c7_wb_data_struct_input_data[c7_i560] =
        c7_data_struct_input->EC_events_mins_right[c7_c_tmp_data[c7_i560] - 1];
    }

    c7_u_A = c7_b_mean(chartInstance, c7_wb_data_struct_input_data,
                       c7_wb_data_struct_input_sizes);
    c7_qe_y = c7_b_rdivide(chartInstance, c7_u_A, 3.0);
    c7_data_struct_input->stop_Vel_th_right = c7_qe_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1046);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1047);
    c7_cb_q0 = c7_data_struct_input->EC_events_index_left;
    c7_cb_qY = c7_cb_q0 - 1U;
    if (CV_SATURATION_EVAL(4, 0, 95, 0, c7_cb_qY > c7_cb_q0)) {
      c7_cb_qY = 0U;
    }

    c7_u118 = c7_cb_qY;
    if (CV_SATURATION_EVAL(4, 0, 95, 0, c7_u118 > 255U)) {
      c7_u118 = 255U;
    }

    c7_u119 = (uint8_T)c7_u118;
    c7_jh_i = 1U;
    while (c7_jh_i <= c7_u119) {
      c7_c_i = c7_jh_i;
      _SFD_SYMBOL_SWITCH(18U, 27U);
      CV_EML_FOR(0, 1, 11, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1048);
      c7_ld_trueCount = 0;
      c7_kh_i = 0;
      while (c7_kh_i <= 4) {
        if (c7_IC_inds_right[c7_kh_i] > 0.0) {
          c7_ld_trueCount++;
        }

        c7_kh_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_h_tmp_sizes = c7_ld_trueCount;
      c7_ld_partialTrueCount = 0;
      c7_lh_i = 0;
      while (c7_lh_i <= 4) {
        if (c7_IC_inds_right[c7_lh_i] > 0.0) {
          c7_h_tmp_data[c7_ld_partialTrueCount] = c7_lh_i + 1;
          c7_ld_partialTrueCount++;
        }

        c7_lh_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_c_EC_events_inds_left = c7_b_EC_events_inds_left[(uint8_T)
        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct, chartInstance->S,
        5U, 67099, 22, MAX_uint32_T, (int32_T)c7_c_i, 1, 5) - 1];
      c7_EC_events_inds_right_sizes = c7_h_tmp_sizes;
      c7_td_loop_ub = c7_h_tmp_sizes - 1;
      for (c7_i561 = 0; c7_i561 <= c7_td_loop_ub; c7_i561++) {
        c7_EC_events_inds_right_data[c7_i561] = c7_c_EC_events_inds_left -
          c7_IC_inds_right[c7_h_tmp_data[c7_i561] - 1];
      }

      c7_temp_sizes[0] = c7_h_tmp_sizes;
      c7_temp_sizes[1] = 1;
      c7_temp = c7_temp_sizes[0];
      c7_b_temp = c7_temp_sizes[1];
      c7_ud_loop_ub = c7_h_tmp_sizes - 1;
      for (c7_i562 = 0; c7_i562 <= c7_ud_loop_ub; c7_i562++) {
        c7_temp_data[c7_i562] = c7_EC_events_inds_right_data[c7_i562];
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1049);
      c7_end = c7_temp_sizes[0] - 1;
      c7_md_trueCount = 0;
      c7_mh_i = 0;
      while (c7_mh_i <= c7_end) {
        if (c7_temp_data[c7_mh_i] < 0.0) {
          c7_md_trueCount++;
        }

        c7_mh_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_b_end = c7_temp_sizes[0] - 1;
      c7_md_partialTrueCount = 0;
      c7_nh_i = 0;
      while (c7_nh_i <= c7_b_end) {
        if (c7_temp_data[c7_nh_i] < 0.0) {
          c7_EC_events_inds_right_sizes = c7_md_trueCount;
          c7_vd_loop_ub = c7_md_trueCount - 1;
          for (c7_i563 = 0; c7_i563 <= c7_vd_loop_ub; c7_i563++) {
            c7_EC_events_inds_right_data[c7_i563] = 2.0E+6;
          }

          c7_temp_data[sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 67162, 12, 0U, c7_nh_i + 1, 1, c7_temp_sizes[0])
            - 1] = c7_EC_events_inds_right_data[c7_md_partialTrueCount];
          c7_md_partialTrueCount++;
        }

        c7_nh_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1050);
      c7_EC_events_inds_right_sizes = c7_temp_sizes[0];
      c7_wd_loop_ub = c7_temp_sizes[0] - 1;
      for (c7_i564 = 0; c7_i564 <= c7_wd_loop_ub; c7_i564++) {
        c7_EC_events_inds_right_data[c7_i564] = c7_temp_data[c7_i564];
      }

      guard2 = false;
      if (c7_EC_events_inds_right_sizes == 1) {
        guard2 = true;
      } else if ((real_T)c7_EC_events_inds_right_sizes != 1.0) {
        guard2 = true;
      } else {
        c7_b59 = false;
      }

      if (guard2 == true) {
        c7_b59 = true;
      }

      if (c7_b59) {
      } else {
        c7_re_y = NULL;
        sf_mex_assign(&c7_re_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1,
          36), false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                          sf_mex_call_debug(sfGlobalDebugInstanceStruct,
          "message", 1U, 1U, 14, c7_re_y));
      }

      if ((real_T)c7_EC_events_inds_right_sizes > 0.0) {
      } else {
        c7_se_y = NULL;
        sf_mex_assign(&c7_se_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1,
          39), false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                          sf_mex_call_debug(sfGlobalDebugInstanceStruct,
          "message", 1U, 1U, 14, c7_se_y));
      }

      c7_e_ixstart = 1;
      c7_n = c7_EC_events_inds_right_sizes;
      c7_ixstop = c7_n;
      c7_k_mtmp = c7_EC_events_inds_right_data[0];
      if (c7_n > 1) {
        c7_m_x = c7_k_mtmp;
        c7_ie_b = muDoubleScalarIsNaN(c7_m_x);
        if (c7_ie_b) {
          c7_b_ixstop = c7_ixstop;
          c7_m_ix = 2;
          exitg4 = false;
          while ((exitg4 == false) && (c7_m_ix <= c7_b_ixstop)) {
            c7_n_ix = c7_m_ix - 1;
            c7_e_ixstart = c7_n_ix + 1;
            c7_n_x = c7_EC_events_inds_right_data[c7_n_ix];
            c7_je_b = muDoubleScalarIsNaN(c7_n_x);
            if (!c7_je_b) {
              c7_k_mtmp = c7_EC_events_inds_right_data[c7_n_ix];
              exitg4 = true;
            } else {
              c7_m_ix++;
            }
          }
        }

        if (c7_e_ixstart < c7_ixstop) {
          c7_i565 = c7_e_ixstart;
          c7_c_ixstop = c7_ixstop;
          for (c7_o_ix = c7_i565 + 1; c7_o_ix <= c7_c_ixstop; c7_o_ix++) {
            c7_n_ix = c7_o_ix - 1;
            c7_f_a = c7_EC_events_inds_right_data[c7_n_ix];
            c7_ke_b = c7_k_mtmp;
            c7_f_p = (c7_f_a < c7_ke_b);
            if (c7_f_p) {
              c7_k_mtmp = c7_EC_events_inds_right_data[c7_n_ix];
            }
          }
        }
      }

      c7_l_mtmp = c7_k_mtmp;
      c7_DS_min = c7_l_mtmp;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1051);
      if (CV_EML_IF(0, 1, 97, CV_RELATIONAL_EVAL(4U, 0U, 248, c7_DS_min, 1.0E+6,
            -1, 2U, c7_DS_min < 1.0E+6))) {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1052);
        c7_d32 = muDoubleScalarRound(c7_DS_min);
        if (c7_d32 < 65536.0) {
          if (CV_SATURATION_EVAL(4, 0, 96, 1, c7_d32 >= 0.0)) {
            c7_u120 = (uint16_T)c7_d32;
          } else {
            c7_u120 = 0U;
          }
        } else if (CV_SATURATION_EVAL(4, 0, 96, 0, c7_d32 >= 65536.0)) {
          c7_u120 = MAX_uint16_T;
        } else {
          c7_u120 = 0U;
        }

        c7_data_struct_input->stop_DS[(uint8_T)sf_eml_array_bounds_check
          (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 67245, 58,
           MAX_uint32_T, (int32_T)c7_data_struct_input->stop_DS_index, 1, 10) -
          1] = c7_u120;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1053);
        c7_u121 = (uint32_T)c7_data_struct_input->stop_DS_index + 1U;
        if (CV_SATURATION_EVAL(4, 0, 97, 0, c7_u121 > 255U)) {
          c7_u121 = 255U;
        }

        c7_data_struct_input->stop_DS_index = (uint8_T)c7_u121;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1054);
        c7_uv38[0] = c7_data_struct_input->stop_DS_index;
        c7_b60 = ((real_T)c7_data_struct_input->stop_DS_index > 10.0);
        c7_nd_trueCount = 0;
        c7_oh_i = 0;
        while (c7_oh_i <= 0) {
          if (c7_b60) {
            c7_nd_trueCount++;
          }

          c7_oh_i++;
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        }

        c7_nd_partialTrueCount = 0;
        c7_ph_i = 0;
        while (c7_ph_i <= 0) {
          if (c7_b60) {
            c7_iv0[0] = 1;
            c7_iv0[1] = c7_nd_trueCount;
            c7_tmp_sizes[0] = 1;
            c7_tmp_sizes[1] = c7_iv0[1];
            c7_i566 = c7_tmp_sizes[0];
            c7_i567 = c7_tmp_sizes[1];
            c7_xd_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
            for (c7_i568 = 0; c7_i568 <= c7_xd_loop_ub; c7_i568++) {
              c7_tmp_data[c7_i568] = 10U;
            }

            c7_uv38[c7_ph_i] = c7_tmp_data[c7_nd_partialTrueCount];
            c7_nd_partialTrueCount++;
          }

          c7_ph_i++;
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        }

        c7_data_struct_input->stop_DS_index = c7_uv38[0];
      }

      c7_jh_i = (uint8_T)((uint32_T)c7_jh_i + 1U);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 11, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1057);
    c7_db_q0 = c7_data_struct_input->EC_events_index_right;
    c7_db_qY = c7_db_q0 - 1U;
    if (CV_SATURATION_EVAL(4, 0, 98, 0, c7_db_qY > c7_db_q0)) {
      c7_db_qY = 0U;
    }

    c7_u122 = c7_db_qY;
    if (CV_SATURATION_EVAL(4, 0, 98, 0, c7_u122 > 255U)) {
      c7_u122 = 255U;
    }

    c7_u123 = (uint8_T)c7_u122;
    c7_qh_i = 1U;
    while (c7_qh_i <= c7_u123) {
      c7_c_i = c7_qh_i;
      _SFD_SYMBOL_SWITCH(18U, 27U);
      CV_EML_FOR(0, 1, 12, 1);
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1058);
      c7_od_trueCount = 0;
      c7_rh_i = 0;
      while (c7_rh_i <= 4) {
        if (c7_IC_inds_left[c7_rh_i] > 0.0) {
          c7_od_trueCount++;
        }

        c7_rh_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_h_tmp_sizes = c7_od_trueCount;
      c7_od_partialTrueCount = 0;
      c7_sh_i = 0;
      while (c7_sh_i <= 4) {
        if (c7_IC_inds_left[c7_sh_i] > 0.0) {
          c7_h_tmp_data[c7_od_partialTrueCount] = c7_sh_i + 1;
          c7_od_partialTrueCount++;
        }

        c7_sh_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_c_EC_events_inds_right = c7_b_EC_events_inds_right[(uint8_T)
        sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct, chartInstance->S,
        5U, 67570, 23, MAX_uint32_T, (int32_T)c7_c_i, 1, 5) - 1];
      c7_EC_events_inds_right_sizes = c7_h_tmp_sizes;
      c7_yd_loop_ub = c7_h_tmp_sizes - 1;
      for (c7_i569 = 0; c7_i569 <= c7_yd_loop_ub; c7_i569++) {
        c7_EC_events_inds_right_data[c7_i569] = c7_c_EC_events_inds_right -
          c7_IC_inds_left[c7_h_tmp_data[c7_i569] - 1];
      }

      c7_temp_sizes[0] = c7_h_tmp_sizes;
      c7_temp_sizes[1] = 1;
      c7_c_temp = c7_temp_sizes[0];
      c7_d_temp = c7_temp_sizes[1];
      c7_ae_loop_ub = c7_h_tmp_sizes - 1;
      for (c7_i570 = 0; c7_i570 <= c7_ae_loop_ub; c7_i570++) {
        c7_temp_data[c7_i570] = c7_EC_events_inds_right_data[c7_i570];
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1059);
      c7_c_end = c7_temp_sizes[0] - 1;
      c7_pd_trueCount = 0;
      c7_th_i = 0;
      while (c7_th_i <= c7_c_end) {
        if (c7_temp_data[c7_th_i] < 0.0) {
          c7_pd_trueCount++;
        }

        c7_th_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      c7_d_end = c7_temp_sizes[0] - 1;
      c7_pd_partialTrueCount = 0;
      c7_uh_i = 0;
      while (c7_uh_i <= c7_d_end) {
        if (c7_temp_data[c7_uh_i] < 0.0) {
          c7_EC_events_inds_right_sizes = c7_pd_trueCount;
          c7_be_loop_ub = c7_pd_trueCount - 1;
          for (c7_i571 = 0; c7_i571 <= c7_be_loop_ub; c7_i571++) {
            c7_EC_events_inds_right_data[c7_i571] = 2.0E+6;
          }

          c7_temp_data[sf_eml_array_bounds_check(sfGlobalDebugInstanceStruct,
            chartInstance->S, 5U, 67632, 12, 0U, c7_uh_i + 1, 1, c7_temp_sizes[0])
            - 1] = c7_EC_events_inds_right_data[c7_pd_partialTrueCount];
          c7_pd_partialTrueCount++;
        }

        c7_uh_i++;
        _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
      }

      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1060);
      c7_EC_events_inds_right_sizes = c7_temp_sizes[0];
      c7_ce_loop_ub = c7_temp_sizes[0] - 1;
      for (c7_i572 = 0; c7_i572 <= c7_ce_loop_ub; c7_i572++) {
        c7_EC_events_inds_right_data[c7_i572] = c7_temp_data[c7_i572];
      }

      guard1 = false;
      if (c7_EC_events_inds_right_sizes == 1) {
        guard1 = true;
      } else if ((real_T)c7_EC_events_inds_right_sizes != 1.0) {
        guard1 = true;
      } else {
        c7_b61 = false;
      }

      if (guard1 == true) {
        c7_b61 = true;
      }

      if (c7_b61) {
      } else {
        c7_te_y = NULL;
        sf_mex_assign(&c7_te_y, sf_mex_create("y", c7_u, 10, 0U, 1U, 0U, 2, 1,
          36), false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                          sf_mex_call_debug(sfGlobalDebugInstanceStruct,
          "message", 1U, 1U, 14, c7_te_y));
      }

      if ((real_T)c7_EC_events_inds_right_sizes > 0.0) {
      } else {
        c7_ue_y = NULL;
        sf_mex_assign(&c7_ue_y, sf_mex_create("y", c7_b_u, 10, 0U, 1U, 0U, 2, 1,
          39), false);
        sf_mex_call_debug(sfGlobalDebugInstanceStruct, "error", 0U, 1U, 14,
                          sf_mex_call_debug(sfGlobalDebugInstanceStruct,
          "message", 1U, 1U, 14, c7_ue_y));
      }

      c7_f_ixstart = 1;
      c7_b_n = c7_EC_events_inds_right_sizes;
      c7_d_ixstop = c7_b_n;
      c7_m_mtmp = c7_EC_events_inds_right_data[0];
      if (c7_b_n > 1) {
        c7_o_x = c7_m_mtmp;
        c7_le_b = muDoubleScalarIsNaN(c7_o_x);
        if (c7_le_b) {
          c7_e_ixstop = c7_d_ixstop;
          c7_p_ix = 2;
          exitg3 = false;
          while ((exitg3 == false) && (c7_p_ix <= c7_e_ixstop)) {
            c7_q_ix = c7_p_ix - 1;
            c7_f_ixstart = c7_q_ix + 1;
            c7_p_x = c7_EC_events_inds_right_data[c7_q_ix];
            c7_me_b = muDoubleScalarIsNaN(c7_p_x);
            if (!c7_me_b) {
              c7_m_mtmp = c7_EC_events_inds_right_data[c7_q_ix];
              exitg3 = true;
            } else {
              c7_p_ix++;
            }
          }
        }

        if (c7_f_ixstart < c7_d_ixstop) {
          c7_i573 = c7_f_ixstart;
          c7_f_ixstop = c7_d_ixstop;
          for (c7_r_ix = c7_i573 + 1; c7_r_ix <= c7_f_ixstop; c7_r_ix++) {
            c7_q_ix = c7_r_ix - 1;
            c7_g_a = c7_EC_events_inds_right_data[c7_q_ix];
            c7_ne_b = c7_m_mtmp;
            c7_g_p = (c7_g_a < c7_ne_b);
            if (c7_g_p) {
              c7_m_mtmp = c7_EC_events_inds_right_data[c7_q_ix];
            }
          }
        }
      }

      c7_n_mtmp = c7_m_mtmp;
      c7_DS_min = c7_n_mtmp;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1061);
      if (CV_EML_IF(0, 1, 98, CV_RELATIONAL_EVAL(4U, 0U, 249, c7_DS_min, 1.0E+6,
            -1, 2U, c7_DS_min < 1.0E+6))) {
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1062);
        c7_d33 = muDoubleScalarRound(c7_DS_min);
        if (c7_d33 < 65536.0) {
          if (CV_SATURATION_EVAL(4, 0, 99, 1, c7_d33 >= 0.0)) {
            c7_u124 = (uint16_T)c7_d33;
          } else {
            c7_u124 = 0U;
          }
        } else if (CV_SATURATION_EVAL(4, 0, 99, 0, c7_d33 >= 65536.0)) {
          c7_u124 = MAX_uint16_T;
        } else {
          c7_u124 = 0U;
        }

        c7_data_struct_input->stop_DS[(uint8_T)sf_eml_array_bounds_check
          (sfGlobalDebugInstanceStruct, chartInstance->S, 5U, 67715, 58,
           MAX_uint32_T, (int32_T)c7_data_struct_input->stop_DS_index, 1, 10) -
          1] = c7_u124;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1063);
        c7_u125 = (uint32_T)c7_data_struct_input->stop_DS_index + 1U;
        if (CV_SATURATION_EVAL(4, 0, 100, 0, c7_u125 > 255U)) {
          c7_u125 = 255U;
        }

        c7_data_struct_input->stop_DS_index = (uint8_T)c7_u125;
        _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1064);
        c7_uv39[0] = c7_data_struct_input->stop_DS_index;
        c7_b62 = ((real_T)c7_data_struct_input->stop_DS_index > 10.0);
        c7_qd_trueCount = 0;
        c7_vh_i = 0;
        while (c7_vh_i <= 0) {
          if (c7_b62) {
            c7_qd_trueCount++;
          }

          c7_vh_i++;
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        }

        c7_qd_partialTrueCount = 0;
        c7_wh_i = 0;
        while (c7_wh_i <= 0) {
          if (c7_b62) {
            c7_iv0[0] = 1;
            c7_iv0[1] = c7_qd_trueCount;
            c7_tmp_sizes[0] = 1;
            c7_tmp_sizes[1] = c7_iv0[1];
            c7_i574 = c7_tmp_sizes[0];
            c7_i575 = c7_tmp_sizes[1];
            c7_de_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
            for (c7_i576 = 0; c7_i576 <= c7_de_loop_ub; c7_i576++) {
              c7_tmp_data[c7_i576] = 10U;
            }

            c7_uv39[c7_wh_i] = c7_tmp_data[c7_qd_partialTrueCount];
            c7_qd_partialTrueCount++;
          }

          c7_wh_i++;
          _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
        }

        c7_data_struct_input->stop_DS_index = c7_uv39[0];
      }

      c7_qh_i = (uint8_T)((uint32_T)c7_qh_i + 1U);
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    CV_EML_FOR(0, 1, 12, 0);
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1067);
    for (c7_i577 = 0; c7_i577 < 10; c7_i577++) {
      c7_bv3[c7_i577] = ((real_T)c7_data_struct_input->stop_DS[c7_i577] <
                         10000.0);
    }

    c7_rd_trueCount = 0;
    c7_xh_i = 0;
    while (c7_xh_i <= 9) {
      if (c7_bv3[c7_xh_i]) {
        c7_rd_trueCount++;
      }

      c7_xh_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_b_tmp_sizes[0] = 1;
    c7_b_tmp_sizes[1] = c7_rd_trueCount;
    c7_rd_partialTrueCount = 0;
    c7_yh_i = 0;
    while (c7_yh_i <= 9) {
      if (c7_bv3[c7_yh_i]) {
        c7_b_tmp_data[c7_rd_partialTrueCount] = c7_yh_i + 1;
        c7_rd_partialTrueCount++;
      }

      c7_yh_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_xb_data_struct_input_sizes[0] = 1;
    c7_xb_data_struct_input_sizes[1] = c7_b_tmp_sizes[1];
    c7_le_data_struct_input = c7_xb_data_struct_input_sizes[0];
    c7_me_data_struct_input = c7_xb_data_struct_input_sizes[1];
    c7_ee_loop_ub = c7_b_tmp_sizes[0] * c7_b_tmp_sizes[1] - 1;
    for (c7_i578 = 0; c7_i578 <= c7_ee_loop_ub; c7_i578++) {
      c7_xb_data_struct_input_data[c7_i578] = c7_data_struct_input->
        stop_DS[c7_b_tmp_data[c7_i578] - 1];
    }

    c7_d34 = muDoubleScalarRound(c7_mean(chartInstance,
      c7_xb_data_struct_input_data, c7_xb_data_struct_input_sizes));
    if (c7_d34 < 65536.0) {
      if (CV_SATURATION_EVAL(4, 0, 101, 1, c7_d34 >= 0.0)) {
        c7_u126 = (uint16_T)c7_d34;
      } else {
        c7_u126 = 0U;
      }
    } else if (CV_SATURATION_EVAL(4, 0, 101, 0, c7_d34 >= 65536.0)) {
      c7_u126 = MAX_uint16_T;
    } else {
      c7_u126 = 0U;
    }

    c7_data_struct_input->stop_DS_th = c7_u126;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1070);
    for (c7_i579 = 0; c7_i579 < 5; c7_i579++) {
      c7_bv4[c7_i579] = (c7_data_struct_input->MA_maxs_left[c7_i579] > -1.0E+6F);
    }

    c7_sd_trueCount = 0;
    c7_ai_i = 0;
    while (c7_ai_i <= 4) {
      if (c7_bv4[c7_ai_i]) {
        c7_sd_trueCount++;
      }

      c7_ai_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_sd_trueCount;
    c7_sd_partialTrueCount = 0;
    c7_bi_i = 0;
    while (c7_bi_i <= 4) {
      if (c7_bv4[c7_bi_i]) {
        c7_c_tmp_data[c7_sd_partialTrueCount] = c7_bi_i + 1;
        c7_sd_partialTrueCount++;
      }

      c7_bi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_yb_data_struct_input_sizes[0] = 1;
    c7_yb_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_ne_data_struct_input = c7_yb_data_struct_input_sizes[0];
    c7_oe_data_struct_input = c7_yb_data_struct_input_sizes[1];
    c7_fe_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i580 = 0; c7_i580 <= c7_fe_loop_ub; c7_i580++) {
      c7_yb_data_struct_input_data[c7_i580] = c7_data_struct_input->
        MA_maxs_left[c7_c_tmp_data[c7_i580] - 1];
    }

    c7_v_A = c7_b_mean(chartInstance, c7_yb_data_struct_input_data,
                       c7_yb_data_struct_input_sizes);
    c7_ve_y = c7_b_rdivide(chartInstance, c7_v_A, 3.0);
    c7_data_struct_input->stop_MA_th_left = c7_ve_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1071);
    for (c7_i581 = 0; c7_i581 < 5; c7_i581++) {
      c7_bv4[c7_i581] = (c7_data_struct_input->MA_maxs_right[c7_i581] > -1.0E+6F);
    }

    c7_td_trueCount = 0;
    c7_ci_i = 0;
    while (c7_ci_i <= 4) {
      if (c7_bv4[c7_ci_i]) {
        c7_td_trueCount++;
      }

      c7_ci_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_td_trueCount;
    c7_td_partialTrueCount = 0;
    c7_di_i = 0;
    while (c7_di_i <= 4) {
      if (c7_bv4[c7_di_i]) {
        c7_c_tmp_data[c7_td_partialTrueCount] = c7_di_i + 1;
        c7_td_partialTrueCount++;
      }

      c7_di_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_ac_data_struct_input_sizes[0] = 1;
    c7_ac_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_pe_data_struct_input = c7_ac_data_struct_input_sizes[0];
    c7_qe_data_struct_input = c7_ac_data_struct_input_sizes[1];
    c7_ge_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i582 = 0; c7_i582 <= c7_ge_loop_ub; c7_i582++) {
      c7_ac_data_struct_input_data[c7_i582] =
        c7_data_struct_input->MA_maxs_right[c7_c_tmp_data[c7_i582] - 1];
    }

    c7_w_A = c7_b_mean(chartInstance, c7_ac_data_struct_input_data,
                       c7_ac_data_struct_input_sizes);
    c7_we_y = c7_b_rdivide(chartInstance, c7_w_A, 3.0);
    c7_data_struct_input->stop_MA_th_right = c7_we_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1074);
    for (c7_i583 = 0; c7_i583 < 5; c7_i583++) {
      c7_bv4[c7_i583] = (c7_data_struct_input->IC_mins_left[c7_i583] > -1.0E+6F);
    }

    c7_ud_trueCount = 0;
    c7_ei_i = 0;
    while (c7_ei_i <= 4) {
      if (c7_bv4[c7_ei_i]) {
        c7_ud_trueCount++;
      }

      c7_ei_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_ud_trueCount;
    c7_ud_partialTrueCount = 0;
    c7_fi_i = 0;
    while (c7_fi_i <= 4) {
      if (c7_bv4[c7_fi_i]) {
        c7_c_tmp_data[c7_ud_partialTrueCount] = c7_fi_i + 1;
        c7_ud_partialTrueCount++;
      }

      c7_fi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_bc_data_struct_input_sizes[0] = 1;
    c7_bc_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_re_data_struct_input = c7_bc_data_struct_input_sizes[0];
    c7_se_data_struct_input = c7_bc_data_struct_input_sizes[1];
    c7_he_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i584 = 0; c7_i584 <= c7_he_loop_ub; c7_i584++) {
      c7_bc_data_struct_input_data[c7_i584] = c7_data_struct_input->
        IC_mins_left[c7_c_tmp_data[c7_i584] - 1];
    }

    c7_x_A = c7_b_mean(chartInstance, c7_bc_data_struct_input_data,
                       c7_bc_data_struct_input_sizes);
    c7_xe_y = c7_b_rdivide(chartInstance, c7_x_A, 3.0);
    c7_data_struct_input->stop_IC_th_left = c7_xe_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1075);
    for (c7_i585 = 0; c7_i585 < 5; c7_i585++) {
      c7_bv4[c7_i585] = (c7_data_struct_input->IC_mins_right[c7_i585] > -1.0E+6F);
    }

    c7_vd_trueCount = 0;
    c7_gi_i = 0;
    while (c7_gi_i <= 4) {
      if (c7_bv4[c7_gi_i]) {
        c7_vd_trueCount++;
      }

      c7_gi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_c_tmp_sizes[0] = 1;
    c7_c_tmp_sizes[1] = c7_vd_trueCount;
    c7_vd_partialTrueCount = 0;
    c7_hi_i = 0;
    while (c7_hi_i <= 4) {
      if (c7_bv4[c7_hi_i]) {
        c7_c_tmp_data[c7_vd_partialTrueCount] = c7_hi_i + 1;
        c7_vd_partialTrueCount++;
      }

      c7_hi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_cc_data_struct_input_sizes[0] = 1;
    c7_cc_data_struct_input_sizes[1] = c7_c_tmp_sizes[1];
    c7_te_data_struct_input = c7_cc_data_struct_input_sizes[0];
    c7_ue_data_struct_input = c7_cc_data_struct_input_sizes[1];
    c7_ie_loop_ub = c7_c_tmp_sizes[0] * c7_c_tmp_sizes[1] - 1;
    for (c7_i586 = 0; c7_i586 <= c7_ie_loop_ub; c7_i586++) {
      c7_cc_data_struct_input_data[c7_i586] =
        c7_data_struct_input->IC_mins_right[c7_c_tmp_data[c7_i586] - 1];
    }

    c7_y_A = c7_b_mean(chartInstance, c7_cc_data_struct_input_data,
                       c7_cc_data_struct_input_sizes);
    c7_ye_y = c7_b_rdivide(chartInstance, c7_y_A, 3.0);
    c7_data_struct_input->stop_IC_th_right = c7_ye_y;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1078);
    c7_uv40[0] = c7_data_struct_input->MA_LPF_index_right;
    c7_b63 = ((real_T)c7_data_struct_input->MA_LPF_index_right > 5.0);
    c7_wd_trueCount = 0;
    c7_ii_i = 0;
    while (c7_ii_i <= 0) {
      if (c7_b63) {
        c7_wd_trueCount++;
      }

      c7_ii_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_wd_partialTrueCount = 0;
    c7_ji_i = 0;
    while (c7_ji_i <= 0) {
      if (c7_b63) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_wd_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i587 = c7_tmp_sizes[0];
        c7_i588 = c7_tmp_sizes[1];
        c7_je_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i589 = 0; c7_i589 <= c7_je_loop_ub; c7_i589++) {
          c7_tmp_data[c7_i589] = 1U;
        }

        c7_uv40[c7_ji_i] = c7_tmp_data[c7_wd_partialTrueCount];
        c7_wd_partialTrueCount++;
      }

      c7_ji_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->MA_LPF_index_right = c7_uv40[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1079);
    c7_uv41[0] = c7_data_struct_input->MA_LPF_index_left;
    c7_b64 = ((real_T)c7_data_struct_input->MA_LPF_index_left > 5.0);
    c7_xd_trueCount = 0;
    c7_ki_i = 0;
    while (c7_ki_i <= 0) {
      if (c7_b64) {
        c7_xd_trueCount++;
      }

      c7_ki_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_xd_partialTrueCount = 0;
    c7_li_i = 0;
    while (c7_li_i <= 0) {
      if (c7_b64) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_xd_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i590 = c7_tmp_sizes[0];
        c7_i591 = c7_tmp_sizes[1];
        c7_ke_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i592 = 0; c7_i592 <= c7_ke_loop_ub; c7_i592++) {
          c7_tmp_data[c7_i592] = 1U;
        }

        c7_uv41[c7_li_i] = c7_tmp_data[c7_xd_partialTrueCount];
        c7_xd_partialTrueCount++;
      }

      c7_li_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->MA_LPF_index_left = c7_uv41[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1080);
    c7_uv42[0] = c7_data_struct_input->MA_index_right;
    c7_b65 = ((real_T)c7_data_struct_input->MA_index_right > 5.0);
    c7_yd_trueCount = 0;
    c7_mi_i = 0;
    while (c7_mi_i <= 0) {
      if (c7_b65) {
        c7_yd_trueCount++;
      }

      c7_mi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_yd_partialTrueCount = 0;
    c7_ni_i = 0;
    while (c7_ni_i <= 0) {
      if (c7_b65) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_yd_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i593 = c7_tmp_sizes[0];
        c7_i594 = c7_tmp_sizes[1];
        c7_le_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i595 = 0; c7_i595 <= c7_le_loop_ub; c7_i595++) {
          c7_tmp_data[c7_i595] = 1U;
        }

        c7_uv42[c7_ni_i] = c7_tmp_data[c7_yd_partialTrueCount];
        c7_yd_partialTrueCount++;
      }

      c7_ni_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->MA_index_right = c7_uv42[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1081);
    c7_uv43[0] = c7_data_struct_input->MA_index_left;
    c7_b66 = ((real_T)c7_data_struct_input->MA_index_left > 5.0);
    c7_ae_trueCount = 0;
    c7_oi_i = 0;
    while (c7_oi_i <= 0) {
      if (c7_b66) {
        c7_ae_trueCount++;
      }

      c7_oi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_ae_partialTrueCount = 0;
    c7_pi_i = 0;
    while (c7_pi_i <= 0) {
      if (c7_b66) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_ae_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i596 = c7_tmp_sizes[0];
        c7_i597 = c7_tmp_sizes[1];
        c7_me_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i598 = 0; c7_i598 <= c7_me_loop_ub; c7_i598++) {
          c7_tmp_data[c7_i598] = 1U;
        }

        c7_uv43[c7_pi_i] = c7_tmp_data[c7_ae_partialTrueCount];
        c7_ae_partialTrueCount++;
      }

      c7_pi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->MA_index_left = c7_uv43[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1082);
    c7_uv44[0] = c7_data_struct_input->IC_LPF_index_right;
    c7_b67 = ((real_T)c7_data_struct_input->IC_LPF_index_right > 5.0);
    c7_be_trueCount = 0;
    c7_qi_i = 0;
    while (c7_qi_i <= 0) {
      if (c7_b67) {
        c7_be_trueCount++;
      }

      c7_qi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_be_partialTrueCount = 0;
    c7_ri_i = 0;
    while (c7_ri_i <= 0) {
      if (c7_b67) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_be_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i599 = c7_tmp_sizes[0];
        c7_i600 = c7_tmp_sizes[1];
        c7_ne_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i601 = 0; c7_i601 <= c7_ne_loop_ub; c7_i601++) {
          c7_tmp_data[c7_i601] = 1U;
        }

        c7_uv44[c7_ri_i] = c7_tmp_data[c7_be_partialTrueCount];
        c7_be_partialTrueCount++;
      }

      c7_ri_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->IC_LPF_index_right = c7_uv44[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1083);
    c7_uv45[0] = c7_data_struct_input->IC_LPF_index_left;
    c7_b68 = ((real_T)c7_data_struct_input->IC_LPF_index_left > 5.0);
    c7_ce_trueCount = 0;
    c7_si_i = 0;
    while (c7_si_i <= 0) {
      if (c7_b68) {
        c7_ce_trueCount++;
      }

      c7_si_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_ce_partialTrueCount = 0;
    c7_ti_i = 0;
    while (c7_ti_i <= 0) {
      if (c7_b68) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_ce_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i602 = c7_tmp_sizes[0];
        c7_i603 = c7_tmp_sizes[1];
        c7_oe_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i604 = 0; c7_i604 <= c7_oe_loop_ub; c7_i604++) {
          c7_tmp_data[c7_i604] = 1U;
        }

        c7_uv45[c7_ti_i] = c7_tmp_data[c7_ce_partialTrueCount];
        c7_ce_partialTrueCount++;
      }

      c7_ti_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->IC_LPF_index_left = c7_uv45[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1084);
    c7_uv46[0] = c7_data_struct_input->IC_index_right;
    c7_b69 = ((real_T)c7_data_struct_input->IC_index_right > 5.0);
    c7_de_trueCount = 0;
    c7_ui_i = 0;
    while (c7_ui_i <= 0) {
      if (c7_b69) {
        c7_de_trueCount++;
      }

      c7_ui_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_de_partialTrueCount = 0;
    c7_vi_i = 0;
    while (c7_vi_i <= 0) {
      if (c7_b69) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_de_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i605 = c7_tmp_sizes[0];
        c7_i606 = c7_tmp_sizes[1];
        c7_pe_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i607 = 0; c7_i607 <= c7_pe_loop_ub; c7_i607++) {
          c7_tmp_data[c7_i607] = 1U;
        }

        c7_uv46[c7_vi_i] = c7_tmp_data[c7_de_partialTrueCount];
        c7_de_partialTrueCount++;
      }

      c7_vi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->IC_index_right = c7_uv46[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1085);
    c7_uv47[0] = c7_data_struct_input->IC_index_left;
    c7_b70 = ((real_T)c7_data_struct_input->IC_index_left > 5.0);
    c7_ee_trueCount = 0;
    c7_wi_i = 0;
    while (c7_wi_i <= 0) {
      if (c7_b70) {
        c7_ee_trueCount++;
      }

      c7_wi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_ee_partialTrueCount = 0;
    c7_xi_i = 0;
    while (c7_xi_i <= 0) {
      if (c7_b70) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_ee_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i608 = c7_tmp_sizes[0];
        c7_i609 = c7_tmp_sizes[1];
        c7_qe_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i610 = 0; c7_i610 <= c7_qe_loop_ub; c7_i610++) {
          c7_tmp_data[c7_i610] = 1U;
        }

        c7_uv47[c7_xi_i] = c7_tmp_data[c7_ee_partialTrueCount];
        c7_ee_partialTrueCount++;
      }

      c7_xi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->IC_index_left = c7_uv47[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1086);
    c7_uv48[0] = c7_data_struct_input->EC_events_index_right;
    c7_b71 = ((real_T)c7_data_struct_input->EC_events_index_right > 5.0);
    c7_fe_trueCount = 0;
    c7_yi_i = 0;
    while (c7_yi_i <= 0) {
      if (c7_b71) {
        c7_fe_trueCount++;
      }

      c7_yi_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_fe_partialTrueCount = 0;
    c7_aj_i = 0;
    while (c7_aj_i <= 0) {
      if (c7_b71) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_fe_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i611 = c7_tmp_sizes[0];
        c7_i612 = c7_tmp_sizes[1];
        c7_re_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i613 = 0; c7_i613 <= c7_re_loop_ub; c7_i613++) {
          c7_tmp_data[c7_i613] = 1U;
        }

        c7_uv48[c7_aj_i] = c7_tmp_data[c7_fe_partialTrueCount];
        c7_fe_partialTrueCount++;
      }

      c7_aj_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->EC_events_index_right = c7_uv48[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1087);
    c7_uv49[0] = c7_data_struct_input->EC_events_index_left;
    c7_b72 = ((real_T)c7_data_struct_input->EC_events_index_left > 5.0);
    c7_ge_trueCount = 0;
    c7_bj_i = 0;
    while (c7_bj_i <= 0) {
      if (c7_b72) {
        c7_ge_trueCount++;
      }

      c7_bj_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_ge_partialTrueCount = 0;
    c7_cj_i = 0;
    while (c7_cj_i <= 0) {
      if (c7_b72) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_ge_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i614 = c7_tmp_sizes[0];
        c7_i615 = c7_tmp_sizes[1];
        c7_se_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i616 = 0; c7_i616 <= c7_se_loop_ub; c7_i616++) {
          c7_tmp_data[c7_i616] = 1U;
        }

        c7_uv49[c7_cj_i] = c7_tmp_data[c7_ge_partialTrueCount];
        c7_ge_partialTrueCount++;
      }

      c7_cj_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->EC_events_index_left = c7_uv49[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1088);
    c7_uv50[0] = c7_data_struct_input->EC_peaks_index_right;
    c7_b73 = ((real_T)c7_data_struct_input->EC_peaks_index_right > 5.0);
    c7_he_trueCount = 0;
    c7_dj_i = 0;
    while (c7_dj_i <= 0) {
      if (c7_b73) {
        c7_he_trueCount++;
      }

      c7_dj_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_he_partialTrueCount = 0;
    c7_ej_i = 0;
    while (c7_ej_i <= 0) {
      if (c7_b73) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_he_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i617 = c7_tmp_sizes[0];
        c7_i618 = c7_tmp_sizes[1];
        c7_te_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i619 = 0; c7_i619 <= c7_te_loop_ub; c7_i619++) {
          c7_tmp_data[c7_i619] = 1U;
        }

        c7_uv50[c7_ej_i] = c7_tmp_data[c7_he_partialTrueCount];
        c7_he_partialTrueCount++;
      }

      c7_ej_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->EC_peaks_index_right = c7_uv50[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1089);
    c7_uv51[0] = c7_data_struct_input->EC_peaks_index_left;
    c7_b74 = ((real_T)c7_data_struct_input->EC_peaks_index_left > 5.0);
    c7_ie_trueCount = 0;
    c7_fj_i = 0;
    while (c7_fj_i <= 0) {
      if (c7_b74) {
        c7_ie_trueCount++;
      }

      c7_fj_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_ie_partialTrueCount = 0;
    c7_gj_i = 0;
    while (c7_gj_i <= 0) {
      if (c7_b74) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_ie_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i620 = c7_tmp_sizes[0];
        c7_i621 = c7_tmp_sizes[1];
        c7_ue_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i622 = 0; c7_i622 <= c7_ue_loop_ub; c7_i622++) {
          c7_tmp_data[c7_i622] = 1U;
        }

        c7_uv51[c7_gj_i] = c7_tmp_data[c7_ie_partialTrueCount];
        c7_ie_partialTrueCount++;
      }

      c7_gj_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->EC_peaks_index_left = c7_uv51[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1090);
    c7_uv52[0] = c7_data_struct_input->stop_DS_index;
    c7_b75 = ((real_T)c7_data_struct_input->stop_DS_index > 10.0);
    c7_je_trueCount = 0;
    c7_hj_i = 0;
    while (c7_hj_i <= 0) {
      if (c7_b75) {
        c7_je_trueCount++;
      }

      c7_hj_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_je_partialTrueCount = 0;
    c7_ij_i = 0;
    while (c7_ij_i <= 0) {
      if (c7_b75) {
        c7_iv0[0] = 1;
        c7_iv0[1] = c7_je_trueCount;
        c7_tmp_sizes[0] = 1;
        c7_tmp_sizes[1] = c7_iv0[1];
        c7_i623 = c7_tmp_sizes[0];
        c7_i624 = c7_tmp_sizes[1];
        c7_ve_loop_ub = c7_iv0[0] * c7_iv0[1] - 1;
        for (c7_i625 = 0; c7_i625 <= c7_ve_loop_ub; c7_i625++) {
          c7_tmp_data[c7_i625] = 1U;
        }

        c7_uv52[c7_ij_i] = c7_tmp_data[c7_je_partialTrueCount];
        c7_je_partialTrueCount++;
      }

      c7_ij_i++;
      _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
    }

    c7_data_struct_input->stop_DS_index = c7_uv52[0];
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1092);
    c7_data_struct_input->MA_flag_left = true;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1093);
    c7_data_struct_input->MA_flag_right = true;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1094);
    c7_data_struct_input->flag_calib = false;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1095);
    c7_data_struct_input->calibrating = 0;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1096);
    c7_data_struct_input->counter = 0U;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1098);
    c7_data_struct_input->state = 3;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1099);
    for (c7_i626 = 0; c7_i626 < 5; c7_i626++) {
      c7_c_varargin_1[c7_i626] = c7_IC_inds_right[c7_i626];
    }

    c7_g_ixstart = 1;
    c7_o_mtmp = c7_c_varargin_1[0];
    c7_q_x = c7_o_mtmp;
    c7_oe_b = muDoubleScalarIsNaN(c7_q_x);
    if (c7_oe_b) {
      c7_s_ix = 2;
      exitg2 = false;
      while ((exitg2 == false) && (c7_s_ix < 6)) {
        c7_t_ix = c7_s_ix - 1;
        c7_g_ixstart = c7_t_ix + 1;
        c7_r_x = c7_c_varargin_1[c7_t_ix];
        c7_pe_b = muDoubleScalarIsNaN(c7_r_x);
        if (!c7_pe_b) {
          c7_o_mtmp = c7_c_varargin_1[c7_t_ix];
          exitg2 = true;
        } else {
          c7_s_ix++;
        }
      }
    }

    if (c7_g_ixstart < 5) {
      c7_i627 = c7_g_ixstart;
      for (c7_u_ix = c7_i627 + 1; c7_u_ix < 6; c7_u_ix++) {
        c7_t_ix = c7_u_ix - 1;
        c7_h_a = c7_c_varargin_1[c7_t_ix];
        c7_qe_b = c7_o_mtmp;
        c7_h_p = (c7_h_a > c7_qe_b);
        if (c7_h_p) {
          c7_o_mtmp = c7_c_varargin_1[c7_t_ix];
        }
      }
    }

    c7_p_mtmp = c7_o_mtmp;
    c7_maxval = c7_p_mtmp;
    c7_d35 = muDoubleScalarRound(200.0 - c7_maxval);
    if (c7_d35 < 65536.0) {
      if (CV_SATURATION_EVAL(4, 0, 102, 1, c7_d35 >= 0.0)) {
        c7_u127 = (uint16_T)c7_d35;
      } else {
        c7_u127 = 0U;
      }
    } else if (CV_SATURATION_EVAL(4, 0, 102, 0, c7_d35 >= 65536.0)) {
      c7_u127 = MAX_uint16_T;
    } else {
      c7_u127 = 0U;
    }

    c7_data_struct_input->last_IC = c7_u127;
    _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1101);
    if (CV_EML_IF(0, 1, 99, !c7_data_struct_input->initial_leg)) {
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1102);
      c7_data_struct_input->state = 6;
      _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1103);
      for (c7_i628 = 0; c7_i628 < 5; c7_i628++) {
        c7_c_varargin_1[c7_i628] = c7_IC_inds_left[c7_i628];
      }

      c7_h_ixstart = 1;
      c7_q_mtmp = c7_c_varargin_1[0];
      c7_s_x = c7_q_mtmp;
      c7_re_b = muDoubleScalarIsNaN(c7_s_x);
      if (c7_re_b) {
        c7_v_ix = 2;
        exitg1 = false;
        while ((exitg1 == false) && (c7_v_ix < 6)) {
          c7_w_ix = c7_v_ix - 1;
          c7_h_ixstart = c7_w_ix + 1;
          c7_t_x = c7_c_varargin_1[c7_w_ix];
          c7_se_b = muDoubleScalarIsNaN(c7_t_x);
          if (!c7_se_b) {
            c7_q_mtmp = c7_c_varargin_1[c7_w_ix];
            exitg1 = true;
          } else {
            c7_v_ix++;
          }
        }
      }

      if (c7_h_ixstart < 5) {
        c7_i629 = c7_h_ixstart;
        for (c7_x_ix = c7_i629 + 1; c7_x_ix < 6; c7_x_ix++) {
          c7_w_ix = c7_x_ix - 1;
          c7_i_a = c7_c_varargin_1[c7_w_ix];
          c7_te_b = c7_q_mtmp;
          c7_i_p = (c7_i_a > c7_te_b);
          if (c7_i_p) {
            c7_q_mtmp = c7_c_varargin_1[c7_w_ix];
          }
        }
      }

      c7_r_mtmp = c7_q_mtmp;
      c7_b_maxval = c7_r_mtmp;
      c7_d36 = muDoubleScalarRound(200.0 - c7_b_maxval);
      if (c7_d36 < 65536.0) {
        if (CV_SATURATION_EVAL(4, 0, 103, 1, c7_d36 >= 0.0)) {
          c7_u128 = (uint16_T)c7_d36;
        } else {
          c7_u128 = 0U;
        }
      } else if (CV_SATURATION_EVAL(4, 0, 103, 0, c7_d36 >= 65536.0)) {
        c7_u128 = MAX_uint16_T;
      } else {
        c7_u128 = 0U;
      }

      c7_data_struct_input->last_IC = c7_u128;
    }
  }

  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1107);
  *c7_state_out = c7_data_struct_input->state;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, 1108);
  *c7_data_struct_output = *c7_data_struct_input;
  _SFD_EML_CALL(0U, *chartInstance->c7_sfEvent, -1108);
  _SFD_SYMBOL_SCOPE_POP();
}

static const mxArray *c7_j_sf_marshallOut(void *chartInstanceVoid, void
  *c7_inData)
{
  const mxArray *c7_mxArrayOutData = NULL;
  int32_T c7_u;
  const mxArray *c7_y = NULL;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxArrayOutData = NULL;
  c7_u = *(int32_T *)c7_inData;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_create("y", &c7_u, 6, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c7_mxArrayOutData, c7_y, false);
  return c7_mxArrayOutData;
}

static int32_T c7_q_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  int32_T c7_y;
  int32_T c7_i630;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), &c7_i630, 1, 6, 0U, 0, 0U, 0);
  c7_y = c7_i630;
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static void c7_j_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c7_mxArrayInData, const char_T *c7_varName, void *c7_outData)
{
  const mxArray *c7_b_sfEvent;
  const char_T *c7_identifier;
  emlrtMsgIdentifier c7_thisId;
  int32_T c7_y;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_b_sfEvent = sf_mex_dup(c7_mxArrayInData);
  c7_identifier = c7_varName;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_y = c7_q_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_b_sfEvent),
    &c7_thisId);
  sf_mex_destroy(&c7_b_sfEvent);
  *(int32_T *)c7_outData = c7_y;
  sf_mex_destroy(&c7_mxArrayInData);
}

static const mxArray *c7_data_struct_out_bus_io(void *chartInstanceVoid, void
  *c7_pData)
{
  const mxArray *c7_mxVal = NULL;
  int32_T c7_i631;
  c7_bus_datastruct c7_tmp;
  int32_T c7_i632;
  int32_T c7_i633;
  int32_T c7_i634;
  int32_T c7_i635;
  int32_T c7_i636;
  int32_T c7_i637;
  int32_T c7_i638;
  int32_T c7_i639;
  int32_T c7_i640;
  int32_T c7_i641;
  int32_T c7_i642;
  int32_T c7_i643;
  int32_T c7_i644;
  int32_T c7_i645;
  int32_T c7_i646;
  int32_T c7_i647;
  int32_T c7_i648;
  int32_T c7_i649;
  int32_T c7_i650;
  int32_T c7_i651;
  int32_T c7_i652;
  int32_T c7_i653;
  int32_T c7_i654;
  int32_T c7_i655;
  int32_T c7_i656;
  int32_T c7_i657;
  int32_T c7_i658;
  int32_T c7_i659;
  int32_T c7_i660;
  int32_T c7_i661;
  int32_T c7_i662;
  int32_T c7_i663;
  int32_T c7_i664;
  int32_T c7_i665;
  int32_T c7_i666;
  int32_T c7_i667;
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)chartInstanceVoid;
  c7_mxVal = NULL;
  for (c7_i631 = 0; c7_i631 < 200; c7_i631++) {
    c7_tmp.VelRShank[c7_i631] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[0])[c7_i631];
  }

  for (c7_i632 = 0; c7_i632 < 200; c7_i632++) {
    c7_tmp.VelLShank[c7_i632] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[800])[c7_i632];
  }

  for (c7_i633 = 0; c7_i633 < 200; c7_i633++) {
    c7_tmp.AngRShank[c7_i633] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[1600])[c7_i633];
  }

  for (c7_i634 = 0; c7_i634 < 200; c7_i634++) {
    c7_tmp.AngLShank[c7_i634] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[2400])[c7_i634];
  }

  for (c7_i635 = 0; c7_i635 < 200; c7_i635++) {
    c7_tmp.VelRShank_filt[c7_i635] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[3200])[c7_i635];
  }

  for (c7_i636 = 0; c7_i636 < 200; c7_i636++) {
    c7_tmp.VelLShank_filt[c7_i636] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[4000])[c7_i636];
  }

  for (c7_i637 = 0; c7_i637 < 200; c7_i637++) {
    c7_tmp.AngRShank_filt[c7_i637] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[4800])[c7_i637];
  }

  for (c7_i638 = 0; c7_i638 < 200; c7_i638++) {
    c7_tmp.AngLShank_filt[c7_i638] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[5600])[c7_i638];
  }

  for (c7_i639 = 0; c7_i639 < 200; c7_i639++) {
    c7_tmp.VelRShank_LPF[c7_i639] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[6400])[c7_i639];
  }

  for (c7_i640 = 0; c7_i640 < 200; c7_i640++) {
    c7_tmp.VelLShank_LPF[c7_i640] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[7200])[c7_i640];
  }

  for (c7_i641 = 0; c7_i641 < 200; c7_i641++) {
    c7_tmp.AngRShank_LPF[c7_i641] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[8000])[c7_i641];
  }

  for (c7_i642 = 0; c7_i642 < 200; c7_i642++) {
    c7_tmp.AngLShank_LPF[c7_i642] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[8800])[c7_i642];
  }

  for (c7_i643 = 0; c7_i643 < 200; c7_i643++) {
    c7_tmp.AngRShank_LPF2Hz[c7_i643] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[9600])[c7_i643];
  }

  for (c7_i644 = 0; c7_i644 < 200; c7_i644++) {
    c7_tmp.AngLShank_LPF2Hz[c7_i644] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[10400])[c7_i644];
  }

  c7_tmp.counter_stop = *(uint16_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11200];
  c7_tmp.counter = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)[11202];
  c7_tmp.index_start_calib = *(uint16_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11204];
  c7_tmp.index_stop_calib = *(uint16_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11206];
  c7_tmp.initial_leg = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11208];
  c7_tmp.flag_calib = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11209];
  c7_tmp.calibrating = *(int8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11210];
  c7_tmp.state = *(int8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)[11211];
  c7_tmp.prevstate = *(int8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)[11212];
  for (c7_i645 = 0; c7_i645 < 5; c7_i645++) {
    c7_tmp.MA_maxs_right[c7_i645] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[11216])[c7_i645];
  }

  for (c7_i646 = 0; c7_i646 < 5; c7_i646++) {
    c7_tmp.MA_maxs_left[c7_i646] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[11236])[c7_i646];
  }

  for (c7_i647 = 0; c7_i647 < 5; c7_i647++) {
    c7_tmp.MA_LPF_maxs_right[c7_i647] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11256])[c7_i647];
  }

  for (c7_i648 = 0; c7_i648 < 5; c7_i648++) {
    c7_tmp.MA_LPF_maxs_left[c7_i648] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11276])[c7_i648];
  }

  c7_tmp.MA_LPF_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11296];
  c7_tmp.MA_LPF_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11297];
  c7_tmp.MA_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11298];
  c7_tmp.MA_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11299];
  for (c7_i649 = 0; c7_i649 < 5; c7_i649++) {
    c7_tmp.IC_mins_right[c7_i649] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[11300])[c7_i649];
  }

  for (c7_i650 = 0; c7_i650 < 5; c7_i650++) {
    c7_tmp.IC_mins_left[c7_i650] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[11320])[c7_i650];
  }

  for (c7_i651 = 0; c7_i651 < 5; c7_i651++) {
    c7_tmp.IC_LPF_mins_right[c7_i651] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11340])[c7_i651];
  }

  for (c7_i652 = 0; c7_i652 < 5; c7_i652++) {
    c7_tmp.IC_LPF_mins_left[c7_i652] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11360])[c7_i652];
  }

  c7_tmp.IC_LPF_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11380];
  c7_tmp.IC_LPF_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11381];
  c7_tmp.IC_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11382];
  c7_tmp.IC_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11383];
  for (c7_i653 = 0; c7_i653 < 5; c7_i653++) {
    c7_tmp.EC_events_mins_right[c7_i653] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11384])[c7_i653];
  }

  for (c7_i654 = 0; c7_i654 < 5; c7_i654++) {
    c7_tmp.EC_events_mins_left[c7_i654] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11404])[c7_i654];
  }

  for (c7_i655 = 0; c7_i655 < 5; c7_i655++) {
    c7_tmp.EC_peaks_mins_right[c7_i655] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11424])[c7_i655];
  }

  for (c7_i656 = 0; c7_i656 < 5; c7_i656++) {
    c7_tmp.EC_peaks_mins_left[c7_i656] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11444])[c7_i656];
  }

  c7_tmp.EC_events_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11464];
  c7_tmp.EC_events_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11465];
  c7_tmp.EC_peaks_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11466];
  c7_tmp.EC_peaks_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11467];
  for (c7_i657 = 0; c7_i657 < 5; c7_i657++) {
    c7_tmp.AN_events_right[c7_i657] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[11468])[c7_i657];
  }

  for (c7_i658 = 0; c7_i658 < 5; c7_i658++) {
    c7_tmp.AN_events_left[c7_i658] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[11488])[c7_i658];
  }

  for (c7_i659 = 0; c7_i659 < 5; c7_i659++) {
    c7_tmp.AN_peaks_right[c7_i659] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[11508])[c7_i659];
  }

  for (c7_i660 = 0; c7_i660 < 5; c7_i660++) {
    c7_tmp.AN_peaks_left[c7_i660] = ((real32_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[11528])[c7_i660];
  }

  c7_tmp.stop_DS_index = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11548];
  for (c7_i661 = 0; c7_i661 < 10; c7_i661++) {
    c7_tmp.stop_DS[c7_i661] = ((uint16_T *)&((char_T *)(c7_bus_datastruct *)
      c7_pData)[11550])[c7_i661];
  }

  c7_tmp.MS_event_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11570];
  c7_tmp.MS_event_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11571];
  c7_tmp.EC_event_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11572];
  c7_tmp.EC_event_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11573];
  c7_tmp.IC_event_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11574];
  c7_tmp.IC_event_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11575];
  c7_tmp.AN_event_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11576];
  c7_tmp.AN_event_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11577];
  c7_tmp.MA_event_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11578];
  c7_tmp.MA_event_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11579];
  c7_tmp.stop_Vel_event_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11580];
  c7_tmp.stop_Vel_event_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11581];
  c7_tmp.stop_MA_event_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11582];
  c7_tmp.stop_MA_event_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11583];
  c7_tmp.stop_IC_event_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11584];
  c7_tmp.stop_IC_event_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[11585];
  c7_tmp.MA_flag_right = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11586];
  c7_tmp.MA_flag_left = *(boolean_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [11587];
  c7_tmp.last_EC = *(uint16_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)[11588];
  c7_tmp.last_IC = *(uint16_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)[11590];
  for (c7_i662 = 0; c7_i662 < 200; c7_i662++) {
    c7_tmp.IC_buffer_left[c7_i662] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[11592])[c7_i662];
  }

  for (c7_i663 = 0; c7_i663 < 200; c7_i663++) {
    c7_tmp.IC_buffer_right[c7_i663] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[12392])[c7_i663];
  }

  for (c7_i664 = 0; c7_i664 < 200; c7_i664++) {
    c7_tmp.EC_buffer_left[c7_i664] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[13192])[c7_i664];
  }

  for (c7_i665 = 0; c7_i665 < 200; c7_i665++) {
    c7_tmp.EC_buffer_right[c7_i665] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[13992])[c7_i665];
  }

  for (c7_i666 = 0; c7_i666 < 200; c7_i666++) {
    c7_tmp.MS_buffer_left[c7_i666] = ((real32_T *)&((char_T *)(c7_bus_datastruct
      *)c7_pData)[14792])[c7_i666];
  }

  for (c7_i667 = 0; c7_i667 < 200; c7_i667++) {
    c7_tmp.MS_buffer_right[c7_i667] = ((real32_T *)&((char_T *)
      (c7_bus_datastruct *)c7_pData)[15592])[c7_i667];
  }

  c7_tmp.IC_buffer_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16392];
  c7_tmp.IC_buffer_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16393];
  c7_tmp.EC_buffer_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16394];
  c7_tmp.EC_buffer_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16395];
  c7_tmp.MS_buffer_index_left = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16396];
  c7_tmp.MS_buffer_index_right = *(uint8_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16397];
  c7_tmp.MA_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16400];
  c7_tmp.MA_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16404];
  c7_tmp.IC_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16408];
  c7_tmp.IC_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16412];
  c7_tmp.AN_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16416];
  c7_tmp.AN_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16420];
  c7_tmp.EC_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16424];
  c7_tmp.EC_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16428];
  c7_tmp.stop_Vel_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16432];
  c7_tmp.stop_Vel_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16436];
  c7_tmp.stop_MA_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16440];
  c7_tmp.stop_MA_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16444];
  c7_tmp.stop_IC_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16448];
  c7_tmp.stop_IC_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16452];
  c7_tmp.stop_DS_th = *(uint16_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16456];
  c7_tmp.MA_LPF_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16460];
  c7_tmp.MA_LPF_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16464];
  c7_tmp.IC_LPF_th_left = *(real32_T *)&((char_T *)(c7_bus_datastruct *)c7_pData)
    [16468];
  c7_tmp.IC_LPF_th_right = *(real32_T *)&((char_T *)(c7_bus_datastruct *)
    c7_pData)[16472];
  sf_mex_assign(&c7_mxVal, c7_b_sf_marshallOut(chartInstance, &c7_tmp), false);
  return c7_mxVal;
}

static void c7_r_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_b_dataWrittenToVector, const char_T
  *c7_identifier, boolean_T c7_y[6])
{
  emlrtMsgIdentifier c7_thisId;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  c7_s_emlrt_marshallIn(chartInstance, sf_mex_dup(c7_b_dataWrittenToVector),
                        &c7_thisId, c7_y);
  sf_mex_destroy(&c7_b_dataWrittenToVector);
}

static void c7_s_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId,
  boolean_T c7_y[6])
{
  boolean_T c7_bv6[6];
  int32_T c7_i668;
  (void)chartInstance;
  sf_mex_import(c7_parentId, sf_mex_dup(c7_u), c7_bv6, 1, 11, 0U, 1, 0U, 1, 6);
  for (c7_i668 = 0; c7_i668 < 6; c7_i668++) {
    c7_y[c7_i668] = c7_bv6[c7_i668];
  }

  sf_mex_destroy(&c7_u);
}

static const mxArray *c7_t_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_b_setSimStateSideEffectsInfo, const char_T
  *c7_identifier)
{
  const mxArray *c7_y = NULL;
  emlrtMsgIdentifier c7_thisId;
  c7_y = NULL;
  c7_thisId.fIdentifier = c7_identifier;
  c7_thisId.fParent = NULL;
  c7_thisId.bParentIsCell = false;
  sf_mex_assign(&c7_y, c7_u_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c7_b_setSimStateSideEffectsInfo), &c7_thisId), false);
  sf_mex_destroy(&c7_b_setSimStateSideEffectsInfo);
  return c7_y;
}

static const mxArray *c7_u_emlrt_marshallIn(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, const mxArray *c7_u, const emlrtMsgIdentifier *c7_parentId)
{
  const mxArray *c7_y = NULL;
  (void)chartInstance;
  (void)c7_parentId;
  c7_y = NULL;
  sf_mex_assign(&c7_y, sf_mex_duplicatearraysafe(&c7_u), false);
  sf_mex_destroy(&c7_u);
  return c7_y;
}

static const mxArray *sf_get_hover_data_for_msg(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, int32_T c7_ssid)
{
  (void)chartInstance;
  (void)c7_ssid;
  return NULL;
}

static void c7_init_sf_message_store_memory(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c7_b_sign(SFc7_XsensLibrary2InstanceStruct *chartInstance, real32_T *
                      c7_x)
{
  (void)chartInstance;
  *c7_x = muSingleScalarSign(*c7_x);
}

static void c7_b_ceil(SFc7_XsensLibrary2InstanceStruct *chartInstance, uint16_T *
                      c7_x)
{
  (void)chartInstance;
  (void)c7_x;
}

static void c7_bus_rd_access_A_2(SFc7_XsensLibrary2InstanceStruct *chartInstance,
  int32_T c7_u0, int32_T c7_u1, int32_T c7_u2, int32_T c7_u3)
{
  SFcnMemRegionInfo *c7_reg;
  c7_reg = (SFcnMemRegionInfo *)0U;
  ssMemRegionCreateDescriptor_wrapper(chartInstance->S, 2, &c7_reg);
  ssMemRegionSetFlatSubElement_wrapper(chartInstance->S, c7_reg, 0, c7_u0, 1,
    &c7_u1);
  ssMemRegionSetFlatSubElement_wrapper(chartInstance->S, c7_reg, 1, c7_u2, 1,
    &c7_u3);
  ssReadFromDataStoreRegion_wrapper(chartInstance->S, 0, 0, c7_reg);
  ssMemRegionDestroyDescriptor_wrapper(chartInstance->S, &c7_reg);
}

static c7_bus_datastruct c7_get_A(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, uint32_T c7_elementIndex)
{
  ssReadFromDataStoreElement_wrapper(chartInstance->S, 0, NULL, c7_elementIndex);
  return *chartInstance->c7_A_address;
}

static void c7_set_A(SFc7_XsensLibrary2InstanceStruct *chartInstance, uint32_T
                     c7_elementIndex, c7_bus_datastruct c7_elementValue)
{
  ssWriteToDataStoreElement_wrapper(chartInstance->S, 0, NULL, c7_elementIndex);
  *chartInstance->c7_A_address = c7_elementValue;
}

static c7_bus_datastruct *c7_access_A(SFc7_XsensLibrary2InstanceStruct
  *chartInstance, uint32_T c7_rdOnly)
{
  (void)c7_rdOnly;
  return chartInstance->c7_A_address;
}

static void init_dsm_address_info(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  ssGetSFcnDataStoreNameAddrIdx_wrapper(chartInstance->S, "A", (void **)
    &chartInstance->c7_A_address, &chartInstance->c7__index);
}

static void init_simulink_io_address(SFc7_XsensLibrary2InstanceStruct
  *chartInstance)
{
  chartInstance->c7_sfEvent = (int32_T *)ssGetDWork_wrapper(chartInstance->S, 0);
  chartInstance->c7_isStable = (boolean_T *)ssGetDWork_wrapper(chartInstance->S,
    1);
  chartInstance->c7_is_active_c7_XsensLibrary2 = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 2);
  chartInstance->c7_is_c7_XsensLibrary2 = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 3);
  chartInstance->c7_time = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c7_value_VelRShank = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c7_value_VelLShank = (real32_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c7_value_AngRShank = (real32_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 3);
  chartInstance->c7_value_AngLShank = (real32_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 4);
  chartInstance->c7_state = (int8_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c7_data_struct_out = (c7_bus_datastruct *)
    ssGetOutputPortSignal_wrapper(chartInstance->S, 2);
  chartInstance->c7_data_struct = (c7_bus_datastruct *)ssGetDWork_wrapper
    (chartInstance->S, 4);
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

static uint32_T* sf_get_sfun_dwork_checksum(void);
void sf_c7_XsensLibrary2_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(4257577334U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2934339366U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1435977221U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(934329001U);
}

mxArray* sf_c7_XsensLibrary2_get_post_codegen_info(void);
mxArray *sf_c7_XsensLibrary2_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals", "postCodegenInfo" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1, 1, sizeof
    (autoinheritanceFields)/sizeof(autoinheritanceFields[0]),
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("2XPkGtptrti8dhWDJNcBDC");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,5,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(9));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,2,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(4));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(13));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(13));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxData);
  }

  {
    mxArray* mxPostCodegenInfo = sf_c7_XsensLibrary2_get_post_codegen_info();
    mxSetField(mxAutoinheritanceInfo,0,"postCodegenInfo",mxPostCodegenInfo);
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c7_XsensLibrary2_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c7_XsensLibrary2_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("early");
  mxArray *fallbackReason = mxCreateString("ext_mode");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c7_XsensLibrary2_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

mxArray* sf_c7_XsensLibrary2_get_post_codegen_info(void)
{
  const char* fieldNames[] = { "exportedFunctionsUsedByThisChart",
    "exportedFunctionsChecksum" };

  mwSize dims[2] = { 1, 1 };

  mxArray* mxPostCodegenInfo = mxCreateStructArray(2, dims, sizeof(fieldNames)/
    sizeof(fieldNames[0]), fieldNames);

  {
    mxArray* mxExportedFunctionsChecksum = mxCreateString("");
    mwSize exp_dims[2] = { 0, 1 };

    mxArray* mxExportedFunctionsUsedByThisChart = mxCreateCellArray(2, exp_dims);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsUsedByThisChart",
               mxExportedFunctionsUsedByThisChart);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsChecksum",
               mxExportedFunctionsChecksum);
  }

  return mxPostCodegenInfo;
}

static const mxArray *sf_get_sim_state_info_c7_XsensLibrary2(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x6'type','srcId','name','auxInfo'{{M[1],M[24],T\"data_struct_out\",},{M[1],M[23],T\"state\",},{M[3],M[28],T\"data_struct\",},{M[8],M[0],T\"is_active_c7_XsensLibrary2\",},{M[9],M[0],T\"is_c7_XsensLibrary2\",},{M[15],M[0],T\"dataWrittenToVector\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 6, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c7_XsensLibrary2_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const mxArray* sf_opaque_get_hover_data_for_msg(void* chartInstance,
  int32_T msgSSID)
{
  return sf_get_hover_data_for_msg( (SFc7_XsensLibrary2InstanceStruct *)
    chartInstance, msgSSID);
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc7_XsensLibrary2InstanceStruct *chartInstance =
      (SFc7_XsensLibrary2InstanceStruct *)sf_get_chart_instance_ptr(S);
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _XsensLibrary2MachineNumber_,
           7,
           3,
           1,
           0,
           19,
           0,
           0,
           0,
           0,
           0,
           &(chartInstance->chartNumber),
           &(chartInstance->instanceNumber),
           (void *)S);

        /* Each instance must initialize its own list of scripts */
        init_script_number_translation(_XsensLibrary2MachineNumber_,
          chartInstance->chartNumber,chartInstance->instanceNumber);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,_XsensLibrary2MachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _XsensLibrary2MachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,0,0,0,"data_struct");
          _SFD_SET_DATA_PROPS(1,1,1,0,"time");
          _SFD_SET_DATA_PROPS(2,1,1,0,"value_VelRShank");
          _SFD_SET_DATA_PROPS(3,1,1,0,"value_VelLShank");
          _SFD_SET_DATA_PROPS(4,1,1,0,"value_AngRShank");
          _SFD_SET_DATA_PROPS(5,1,1,0,"value_AngLShank");
          _SFD_SET_DATA_PROPS(6,2,0,1,"state");
          _SFD_SET_DATA_PROPS(7,2,0,1,"data_struct_out");
          _SFD_SET_DATA_PROPS(8,8,0,0,"");
          _SFD_SET_DATA_PROPS(9,8,0,0,"");
          _SFD_SET_DATA_PROPS(10,8,0,0,"");
          _SFD_SET_DATA_PROPS(11,8,0,0,"");
          _SFD_SET_DATA_PROPS(12,8,0,0,"");
          _SFD_SET_DATA_PROPS(13,8,0,0,"");
          _SFD_SET_DATA_PROPS(14,8,0,0,"");
          _SFD_SET_DATA_PROPS(15,9,0,0,"");
          _SFD_SET_DATA_PROPS(16,9,0,0,"");
          _SFD_SET_DATA_PROPS(17,9,0,0,"");
          _SFD_SET_DATA_PROPS(18,11,0,0,"A");
          _SFD_STATE_INFO(1,0,0);
          _SFD_STATE_INFO(0,0,2);
          _SFD_STATE_INFO(2,0,2);
          _SFD_CH_SUBSTATE_COUNT(1);
          _SFD_CH_SUBSTATE_DECOMP(0);
          _SFD_CH_SUBSTATE_INDEX(0,1);
          _SFD_ST_SUBSTATE_COUNT(1,0);
        }

        _SFD_CV_INIT_CHART(1,0,0,0);

        {
          _SFD_CV_INIT_STATE(1,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(2,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(2,1,1,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_FCN(2,0,"data_struct_creation",0,-1,4766);
        _SFD_CV_INIT_EML(0,1,1,0,100,0,104,0,13,24,228,76);
        _SFD_CV_INIT_EML_FCN(0,0,"RTDetection",0,-1,70396);
        _SFD_CV_INIT_EML_SATURATION(0,1,0,12543,-1,12583);
        _SFD_CV_INIT_EML_SATURATION(0,1,1,13265,-1,13305);
        _SFD_CV_INIT_EML_SATURATION(0,1,2,14028,-1,14079);
        _SFD_CV_INIT_EML_SATURATION(0,1,3,14126,-1,14159);
        _SFD_CV_INIT_EML_SATURATION(0,1,4,14293,-1,14363);
        _SFD_CV_INIT_EML_SATURATION(0,1,5,14516,-1,14557);
        _SFD_CV_INIT_EML_SATURATION(0,1,6,15135,-1,15176);
        _SFD_CV_INIT_EML_SATURATION(0,1,7,15866,-1,15907);
        _SFD_CV_INIT_EML_SATURATION(0,1,8,16621,-1,16672);
        _SFD_CV_INIT_EML_SATURATION(0,1,9,16719,-1,16752);
        _SFD_CV_INIT_EML_SATURATION(0,1,10,16886,-1,16956);
        _SFD_CV_INIT_EML_SATURATION(0,1,11,17106,-1,17146);
        _SFD_CV_INIT_EML_SATURATION(0,1,12,17335,-1,17365);
        _SFD_CV_INIT_EML_SATURATION(0,1,13,17438,-1,17468);
        _SFD_CV_INIT_EML_SATURATION(0,1,14,17542,-1,17572);
        _SFD_CV_INIT_EML_SATURATION(0,1,15,17920,-1,17950);
        _SFD_CV_INIT_EML_SATURATION(0,1,16,18022,-1,18052);
        _SFD_CV_INIT_EML_SATURATION(0,1,17,18124,-1,18154);
        _SFD_CV_INIT_EML_SATURATION(0,1,18,18465,-1,18495);
        _SFD_CV_INIT_EML_SATURATION(0,1,19,19084,-1,19125);
        _SFD_CV_INIT_EML_SATURATION(0,1,20,19750,-1,19790);
        _SFD_CV_INIT_EML_SATURATION(0,1,21,20703,-1,20740);
        _SFD_CV_INIT_EML_SATURATION(0,1,22,21571,-1,21604);
        _SFD_CV_INIT_EML_SATURATION(0,1,23,23967,-1,24007);
        _SFD_CV_INIT_EML_SATURATION(0,1,24,25835,-1,25874);
        _SFD_CV_INIT_EML_SATURATION(0,1,25,28015,-1,28052);
        _SFD_CV_INIT_EML_SATURATION(0,1,26,28865,-1,28898);
        _SFD_CV_INIT_EML_SATURATION(0,1,27,30960,-1,30998);
        _SFD_CV_INIT_EML_SATURATION(0,1,28,31839,-1,31873);
        _SFD_CV_INIT_EML_SATURATION(0,1,29,34261,-1,34302);
        _SFD_CV_INIT_EML_SATURATION(0,1,30,36146,-1,36186);
        _SFD_CV_INIT_EML_SATURATION(0,1,31,38455,-1,38493);
        _SFD_CV_INIT_EML_SATURATION(0,1,32,39316,-1,39350);
        _SFD_CV_INIT_EML_SATURATION(0,1,33,41137,-1,41177);
        _SFD_CV_INIT_EML_SATURATION(0,1,34,43807,-1,43844);
        _SFD_CV_INIT_EML_SATURATION(0,1,35,44636,-1,44652);
        _SFD_CV_INIT_EML_SATURATION(0,1,36,45058,-1,45085);
        _SFD_CV_INIT_EML_SATURATION(0,1,37,45698,-1,45714);
        _SFD_CV_INIT_EML_SATURATION(0,1,38,46120,-1,46147);
        _SFD_CV_INIT_EML_SATURATION(0,1,39,46519,-1,46592);
        _SFD_CV_INIT_EML_SATURATION(0,1,40,46555,-1,46592);
        _SFD_CV_INIT_EML_SATURATION(0,1,41,47126,-1,47166);
        _SFD_CV_INIT_EML_SATURATION(0,1,42,48176,-1,48251);
        _SFD_CV_INIT_EML_SATURATION(0,1,43,48176,-1,48253);
        _SFD_CV_INIT_EML_SATURATION(0,1,44,48445,-1,48448);
        _SFD_CV_INIT_EML_SATURATION(0,1,45,48522,-1,48525);
        _SFD_CV_INIT_EML_SATURATION(0,1,46,48740,-1,48778);
        _SFD_CV_INIT_EML_SATURATION(0,1,47,49042,-1,49117);
        _SFD_CV_INIT_EML_SATURATION(0,1,48,49042,-1,49119);
        _SFD_CV_INIT_EML_SATURATION(0,1,49,49214,-1,49221);
        _SFD_CV_INIT_EML_SATURATION(0,1,50,49299,-1,49306);
        _SFD_CV_INIT_EML_SATURATION(0,1,51,49518,-1,49552);
        _SFD_CV_INIT_EML_SATURATION(0,1,52,49688,-1,49695);
        _SFD_CV_INIT_EML_SATURATION(0,1,53,49831,-1,49838);
        _SFD_CV_INIT_EML_SATURATION(0,1,54,49996,-1,50003);
        _SFD_CV_INIT_EML_SATURATION(0,1,55,50317,-1,50324);
        _SFD_CV_INIT_EML_SATURATION(0,1,56,50510,-1,50513);
        _SFD_CV_INIT_EML_SATURATION(0,1,57,50587,-1,50590);
        _SFD_CV_INIT_EML_SATURATION(0,1,58,50802,-1,50839);
        _SFD_CV_INIT_EML_SATURATION(0,1,59,51101,-1,51176);
        _SFD_CV_INIT_EML_SATURATION(0,1,60,51101,-1,51178);
        _SFD_CV_INIT_EML_SATURATION(0,1,61,51273,-1,51280);
        _SFD_CV_INIT_EML_SATURATION(0,1,62,51358,-1,51365);
        _SFD_CV_INIT_EML_SATURATION(0,1,63,51574,-1,51607);
        _SFD_CV_INIT_EML_SATURATION(0,1,64,51741,-1,51748);
        _SFD_CV_INIT_EML_SATURATION(0,1,65,51883,-1,51890);
        _SFD_CV_INIT_EML_SATURATION(0,1,66,52048,-1,52055);
        _SFD_CV_INIT_EML_SATURATION(0,1,67,52363,-1,52370);
        _SFD_CV_INIT_EML_SATURATION(0,1,68,53594,-1,53632);
        _SFD_CV_INIT_EML_SATURATION(0,1,69,54539,-1,54576);
        _SFD_CV_INIT_EML_SATURATION(0,1,70,54916,-1,54954);
        _SFD_CV_INIT_EML_SATURATION(0,1,71,55042,-1,55117);
        _SFD_CV_INIT_EML_SATURATION(0,1,72,55042,-1,55119);
        _SFD_CV_INIT_EML_SATURATION(0,1,73,55549,-1,55583);
        _SFD_CV_INIT_EML_SATURATION(0,1,74,55862,-1,55899);
        _SFD_CV_INIT_EML_SATURATION(0,1,75,55986,-1,56061);
        _SFD_CV_INIT_EML_SATURATION(0,1,76,55986,-1,56063);
        _SFD_CV_INIT_EML_SATURATION(0,1,77,56488,-1,56521);
        _SFD_CV_INIT_EML_SATURATION(0,1,78,58440,-1,58515);
        _SFD_CV_INIT_EML_SATURATION(0,1,79,58440,-1,58517);
        _SFD_CV_INIT_EML_SATURATION(0,1,80,58877,-1,58953);
        _SFD_CV_INIT_EML_SATURATION(0,1,81,58877,-1,58955);
        _SFD_CV_INIT_EML_SATURATION(0,1,82,59872,-1,59913);
        _SFD_CV_INIT_EML_SATURATION(0,1,83,60391,-1,60466);
        _SFD_CV_INIT_EML_SATURATION(0,1,84,60391,-1,60468);
        _SFD_CV_INIT_EML_SATURATION(0,1,85,60828,-1,60904);
        _SFD_CV_INIT_EML_SATURATION(0,1,86,60828,-1,60906);
        _SFD_CV_INIT_EML_SATURATION(0,1,87,61813,-1,61853);
        _SFD_CV_INIT_EML_SATURATION(0,1,88,62155,-1,62196);
        _SFD_CV_INIT_EML_SATURATION(0,1,89,6351,-1,6386);
        _SFD_CV_INIT_EML_SATURATION(0,1,90,63822,-1,63862);
        _SFD_CV_INIT_EML_SATURATION(0,1,91,63981,-1,64021);
        _SFD_CV_INIT_EML_SATURATION(0,1,92,6418,-1,6453);
        _SFD_CV_INIT_EML_SATURATION(0,1,93,6563,-1,6600);
        _SFD_CV_INIT_EML_SATURATION(0,1,94,65681,-1,65720);
        _SFD_CV_INIT_EML_SATURATION(0,1,95,67045,-1,67085);
        _SFD_CV_INIT_EML_SATURATION(0,1,96,67304,-1,67318);
        _SFD_CV_INIT_EML_SATURATION(0,1,97,67364,-1,67397);
        _SFD_CV_INIT_EML_SATURATION(0,1,98,67515,-1,67556);
        _SFD_CV_INIT_EML_SATURATION(0,1,99,67774,-1,67788);
        _SFD_CV_INIT_EML_SATURATION(0,1,100,67834,-1,67867);
        _SFD_CV_INIT_EML_SATURATION(0,1,101,68006,-1,68076);
        _SFD_CV_INIT_EML_SATURATION(0,1,102,70016,-1,70046);
        _SFD_CV_INIT_EML_SATURATION(0,1,103,70235,-1,70264);
        _SFD_CV_INIT_EML_IF(0,1,0,6238,6320,-1,41190);
        _SFD_CV_INIT_EML_IF(0,1,1,6797,7109,-1,7163);
        _SFD_CV_INIT_EML_IF(0,1,2,7187,7353,-1,7407);
        _SFD_CV_INIT_EML_IF(0,1,3,7431,7743,-1,7797);
        _SFD_CV_INIT_EML_IF(0,1,4,7822,7969,-1,8104);
        _SFD_CV_INIT_EML_IF(0,1,5,8135,8449,-1,8504);
        _SFD_CV_INIT_EML_IF(0,1,6,8529,8842,-1,8897);
        _SFD_CV_INIT_EML_IF(0,1,7,8922,9088,-1,9143);
        _SFD_CV_INIT_EML_IF(0,1,8,9168,9482,-1,9537);
        _SFD_CV_INIT_EML_IF(0,1,9,9561,9707,-1,9840);
        _SFD_CV_INIT_EML_IF(0,1,10,9872,10185,-1,10239);
        _SFD_CV_INIT_EML_IF(0,1,11,10269,10457,-1,10517);
        _SFD_CV_INIT_EML_IF(0,1,12,10548,10737,-1,10798);
        _SFD_CV_INIT_EML_IF(0,1,13,10828,11015,-1,11074);
        _SFD_CV_INIT_EML_IF(0,1,14,11105,11293,-1,11353);
        _SFD_CV_INIT_EML_IF(0,1,15,11390,11578,-1,11638);
        _SFD_CV_INIT_EML_IF(0,1,16,11668,11855,-1,11914);
        _SFD_CV_INIT_EML_IF(0,1,17,12090,12167,-1,12688);
        _SFD_CV_INIT_EML_IF(0,1,18,12698,12776,-1,13410);
        _SFD_CV_INIT_EML_IF(0,1,19,13419,13540,-1,14664);
        _SFD_CV_INIT_EML_IF(0,1,20,13862,13949,-1,14255);
        _SFD_CV_INIT_EML_IF(0,1,21,14674,14752,-1,15283);
        _SFD_CV_INIT_EML_IF(0,1,22,15293,15372,-1,16014);
        _SFD_CV_INIT_EML_IF(0,1,23,16024,16143,-1,17251);
        _SFD_CV_INIT_EML_IF(0,1,24,16455,16542,-1,16848);
        _SFD_CV_INIT_EML_IF(0,1,25,17262,17718,-1,17837);
        _SFD_CV_INIT_EML_IF(0,1,26,17847,18303,-1,18420);
        _SFD_CV_INIT_EML_IF(0,1,27,18430,18496,-1,18568);
        _SFD_CV_INIT_EML_IF(0,1,28,18578,18654,-1,19232);
        _SFD_CV_INIT_EML_IF(0,1,29,19242,19318,-1,19895);
        _SFD_CV_INIT_EML_IF(0,1,30,20300,20538,-1,22252);
        _SFD_CV_INIT_EML_IF(0,1,31,21209,21397,-1,21732);
        _SFD_CV_INIT_EML_IF(0,1,32,22276,22405,-1,27588);
        _SFD_CV_INIT_EML_IF(0,1,33,22686,22788,-1,22865);
        _SFD_CV_INIT_EML_IF(0,1,34,23218,23454,-1,24149);
        _SFD_CV_INIT_EML_IF(0,1,35,24294,24307,-1,25570);
        _SFD_CV_INIT_EML_IF(0,1,36,24488,24724,-1,25064);
        _SFD_CV_INIT_EML_IF(0,1,37,25207,25220,-1,25558);
        _SFD_CV_INIT_EML_IF(0,1,38,26597,26670,-1,27580);
        _SFD_CV_INIT_EML_IF(0,1,39,26763,26799,27299,27568);
        _SFD_CV_INIT_EML_IF(0,1,40,27612,27850,-1,30528);
        _SFD_CV_INIT_EML_IF(0,1,41,28503,28691,-1,29026);
        _SFD_CV_INIT_EML_IF(0,1,42,29464,29536,-1,30520);
        _SFD_CV_INIT_EML_IF(0,1,43,29628,29665,30036,30508);
        _SFD_CV_INIT_EML_IF(0,1,44,30553,30792,-1,32528);
        _SFD_CV_INIT_EML_IF(0,1,45,31474,31662,-1,32003);
        _SFD_CV_INIT_EML_IF(0,1,46,32553,32683,-1,38023);
        _SFD_CV_INIT_EML_IF(0,1,47,32967,33069,-1,33147);
        _SFD_CV_INIT_EML_IF(0,1,48,33504,33740,-1,34446);
        _SFD_CV_INIT_EML_IF(0,1,49,34591,34604,-1,35876);
        _SFD_CV_INIT_EML_IF(0,1,50,34788,35024,-1,35364);
        _SFD_CV_INIT_EML_IF(0,1,51,35507,35520,-1,35864);
        _SFD_CV_INIT_EML_IF(0,1,52,36923,36996,-1,38015);
        _SFD_CV_INIT_EML_IF(0,1,53,37089,37126,37734,38003);
        _SFD_CV_INIT_EML_IF(0,1,54,38048,38287,-1,40757);
        _SFD_CV_INIT_EML_IF(0,1,55,38951,39139,-1,39480);
        _SFD_CV_INIT_EML_IF(0,1,56,39915,39987,-1,40749);
        _SFD_CV_INIT_EML_IF(0,1,57,40080,40116,40320,40737);
        _SFD_CV_INIT_EML_IF(0,1,58,40767,40826,41093,41186);
        _SFD_CV_INIT_EML_IF(0,1,59,41227,41308,-1,41401);
        _SFD_CV_INIT_EML_IF(0,1,60,41402,41511,-1,47491);
        _SFD_CV_INIT_EML_IF(0,1,61,41647,41766,-1,42163);
        _SFD_CV_INIT_EML_IF(0,1,62,41988,42027,-1,42113);
        _SFD_CV_INIT_EML_IF(0,1,63,44038,44212,-1,45094);
        _SFD_CV_INIT_EML_IF(0,1,64,44221,44254,-1,45023);
        _SFD_CV_INIT_EML_IF(0,1,65,44355,44550,-1,44673);
        _SFD_CV_INIT_EML_IF(0,1,66,44733,44746,-1,45011);
        _SFD_CV_INIT_EML_IF(0,1,67,45099,45274,-1,46156);
        _SFD_CV_INIT_EML_IF(0,1,68,45283,45316,-1,46085);
        _SFD_CV_INIT_EML_IF(0,1,69,45417,45612,-1,45735);
        _SFD_CV_INIT_EML_IF(0,1,70,45795,45808,-1,46073);
        _SFD_CV_INIT_EML_IF(0,1,71,46161,46236,-1,46702);
        _SFD_CV_INIT_EML_IF(0,1,72,46292,46342,-1,46606);
        _SFD_CV_INIT_EML_IF(0,1,73,46712,46829,-1,46884);
        _SFD_CV_INIT_EML_IF(0,1,74,47003,47084,47172,47234);
        _SFD_CV_INIT_EML_IF(0,1,75,47244,47292,-1,47487);
        _SFD_CV_INIT_EML_IF(0,1,76,47508,47551,-1,70321);
        _SFD_CV_INIT_EML_IF(0,1,77,48373,48568,-1,50353);
        _SFD_CV_INIT_EML_IF(0,1,78,49137,49308,-1,49665);
        _SFD_CV_INIT_EML_IF(0,1,79,49959,50054,-1,50294);
        _SFD_CV_INIT_EML_IF(0,1,80,50438,50633,-1,52399);
        _SFD_CV_INIT_EML_IF(0,1,81,51196,51367,-1,51718);
        _SFD_CV_INIT_EML_IF(0,1,82,52011,52106,-1,52340);
        _SFD_CV_INIT_EML_IF(0,1,83,53164,53331,-1,53770);
        _SFD_CV_INIT_EML_IF(0,1,84,54114,54281,-1,54712);
        _SFD_CV_INIT_EML_IF(0,1,85,55134,55305,-1,55713);
        _SFD_CV_INIT_EML_IF(0,1,86,55761,55772,-1,55841);
        _SFD_CV_INIT_EML_IF(0,1,87,56078,56249,-1,56649);
        _SFD_CV_INIT_EML_IF(0,1,88,56697,56708,-1,56776);
        _SFD_CV_INIT_EML_IF(0,1,89,58532,58744,-1,60152);
        _SFD_CV_INIT_EML_IF(0,1,90,58978,59195,-1,60081);
        _SFD_CV_INIT_EML_IF(0,1,91,60483,60695,-1,62090);
        _SFD_CV_INIT_EML_IF(0,1,92,60929,61146,-1,62019);
        _SFD_CV_INIT_EML_IF(0,1,93,62528,62744,-1,63052);
        _SFD_CV_INIT_EML_IF(0,1,94,63210,63223,-1,63561);
        _SFD_CV_INIT_EML_IF(0,1,95,64350,64566,-1,64874);
        _SFD_CV_INIT_EML_IF(0,1,96,65032,65093,-1,65425);
        _SFD_CV_INIT_EML_IF(0,1,97,67217,67232,-1,67494);
        _SFD_CV_INIT_EML_IF(0,1,98,67687,67702,-1,67964);
        _SFD_CV_INIT_EML_IF(0,1,99,70094,70135,-1,70317);
        _SFD_CV_INIT_EML_FOR(0,1,0,24403,24472,25080);
        _SFD_CV_INIT_EML_FOR(0,1,1,34700,34772,35380);
        _SFD_CV_INIT_EML_FOR(0,1,2,48169,48299,52407);
        _SFD_CV_INIT_EML_FOR(0,1,3,52950,52980,53817);
        _SFD_CV_INIT_EML_FOR(0,1,4,53903,53932,54759);
        _SFD_CV_INIT_EML_FOR(0,1,5,54908,54955,55849);
        _SFD_CV_INIT_EML_FOR(0,1,6,55854,55900,56784);
        _SFD_CV_INIT_EML_FOR(0,1,7,58255,58285,60199);
        _SFD_CV_INIT_EML_FOR(0,1,8,60209,60238,62137);
        _SFD_CV_INIT_EML_FOR(0,1,9,62147,62197,63963);
        _SFD_CV_INIT_EML_FOR(0,1,10,63973,64022,65819);
        _SFD_CV_INIT_EML_FOR(0,1,11,67037,67086,67502);
        _SFD_CV_INIT_EML_FOR(0,1,12,67507,67557,67972);
        _SFD_CV_INIT_EML_WHILE(0,1,0,21160,21196,21771);
        _SFD_CV_INIT_EML_WHILE(0,1,1,22637,22673,22904);
        _SFD_CV_INIT_EML_WHILE(0,1,2,23169,23205,24188);
        _SFD_CV_INIT_EML_WHILE(0,1,3,28454,28490,29065);
        _SFD_CV_INIT_EML_WHILE(0,1,4,31425,31461,32042);
        _SFD_CV_INIT_EML_WHILE(0,1,5,32918,32954,33186);
        _SFD_CV_INIT_EML_WHILE(0,1,6,33455,33491,34485);
        _SFD_CV_INIT_EML_WHILE(0,1,7,38902,38938,39519);
        _SFD_CV_INIT_EML_WHILE(0,1,8,44309,44338,44720);
        _SFD_CV_INIT_EML_WHILE(0,1,9,45371,45400,45782);
        _SFD_CV_INIT_EML_WHILE(0,1,10,49017,49120,49712);
        _SFD_CV_INIT_EML_WHILE(0,1,11,49873,49942,50341);
        _SFD_CV_INIT_EML_WHILE(0,1,12,51076,51179,51765);
        _SFD_CV_INIT_EML_WHILE(0,1,13,51925,51994,52387);
        _SFD_CV_INIT_EML_WHILE(0,1,14,53084,53151,53809);
        _SFD_CV_INIT_EML_WHILE(0,1,15,54034,54101,54751);
        _SFD_CV_INIT_EML_WHILE(0,1,16,55016,55121,55752);
        _SFD_CV_INIT_EML_WHILE(0,1,17,55960,56065,56688);
        _SFD_CV_INIT_EML_WHILE(0,1,18,58414,58519,60191);
        _SFD_CV_INIT_EML_WHILE(0,1,19,58851,58957,60136);
        _SFD_CV_INIT_EML_WHILE(0,1,20,60365,60470,62129);
        _SFD_CV_INIT_EML_WHILE(0,1,21,60802,60908,62074);
        _SFD_CV_INIT_EML_WHILE(0,1,22,62445,62515,63091);
        _SFD_CV_INIT_EML_WHILE(0,1,23,64269,64337,64913);

        {
          static int condStart[] = { 6242, 6281 };

          static int condEnd[] = { 6277, 6319 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,0,6242,6319,2,0,&(condStart[0]),&(condEnd[0]),
                                3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 6802, 6838, 6876, 6959, 7040 };

          static int condEnd[] = { 6834, 6870, 6955, 7036, 7108 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3, 3, -3, 4, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,1,6801,7108,5,2,&(condStart[0]),&(condEnd[0]),
                                9,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 7192, 7228, 7266, 7312 };

          static int condEnd[] = { 7224, 7260, 7308, 7352 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,2,7191,7352,4,7,&(condStart[0]),&(condEnd[0]),
                                7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 7436, 7472, 7510, 7593, 7674 };

          static int condEnd[] = { 7468, 7504, 7589, 7670, 7742 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3, 3, -3, 4, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,3,7435,7742,5,11,&(condStart[0]),&(condEnd[0]),
                                9,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 7827, 7863, 7901 };

          static int condEnd[] = { 7859, 7895, 7968 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,4,7826,7968,3,16,&(condStart[0]),&(condEnd[0]),
                                5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 8140, 8176, 8214, 8287, 8370 };

          static int condEnd[] = { 8172, 8208, 8283, 8366, 8448 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3, 3, -3, 4, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,5,8139,8448,5,19,&(condStart[0]),&(condEnd[0]),
                                9,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 8534, 8570, 8608, 8691, 8772 };

          static int condEnd[] = { 8566, 8602, 8687, 8768, 8841 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3, 3, -3, 4, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,6,8533,8841,5,24,&(condStart[0]),&(condEnd[0]),
                                9,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 8927, 8963, 9001, 9047 };

          static int condEnd[] = { 8959, 8995, 9043, 9087 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,7,8926,9087,4,29,&(condStart[0]),&(condEnd[0]),
                                7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 9173, 9209, 9248, 9331, 9412 };

          static int condEnd[] = { 9205, 9241, 9327, 9408, 9481 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3, 3, -3, 4, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,8,9172,9481,5,33,&(condStart[0]),&(condEnd[0]),
                                9,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 9566, 9602, 9640 };

          static int condEnd[] = { 9598, 9634, 9706 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,9,9565,9706,3,38,&(condStart[0]),&(condEnd[0]),
                                5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 9877, 9913, 9951, 10023, 10106 };

          static int condEnd[] = { 9909, 9945, 10019, 10102, 10184 };

          static int pfixExpr[] = { 0, 1, -2, 2, -3, 3, -3, 4, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,10,9876,10184,5,41,&(condStart[0]),
                                &(condEnd[0]),9,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 10274, 10310, 10346, 10384 };

          static int condEnd[] = { 10306, 10342, 10378, 10456 };

          static int pfixExpr[] = { 0, 1, -2, 2, -2, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,11,10273,10456,4,46,&(condStart[0]),
                                &(condEnd[0]),7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 10553, 10589, 10625, 10663 };

          static int condEnd[] = { 10585, 10621, 10657, 10736 };

          static int pfixExpr[] = { 0, 1, -2, 2, -2, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,12,10552,10736,4,50,&(condStart[0]),
                                &(condEnd[0]),7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 10833, 10869, 10905, 10943 };

          static int condEnd[] = { 10865, 10901, 10937, 11014 };

          static int pfixExpr[] = { 0, 1, -2, 2, -2, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,13,10832,11014,4,54,&(condStart[0]),
                                &(condEnd[0]),7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 11110, 11146, 11182, 11220 };

          static int condEnd[] = { 11142, 11178, 11214, 11292 };

          static int pfixExpr[] = { 0, 1, -2, 2, -2, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,14,11109,11292,4,58,&(condStart[0]),
                                &(condEnd[0]),7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 11395, 11431, 11467, 11505 };

          static int condEnd[] = { 11427, 11463, 11499, 11577 };

          static int pfixExpr[] = { 0, 1, -2, 2, -2, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,15,11394,11577,4,62,&(condStart[0]),
                                &(condEnd[0]),7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 11673, 11709, 11745, 11783 };

          static int condEnd[] = { 11705, 11741, 11777, 11854 };

          static int pfixExpr[] = { 0, 1, -2, 2, -2, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,16,11672,11854,4,66,&(condStart[0]),
                                &(condEnd[0]),7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 12094, 12130 };

          static int condEnd[] = { 12126, 12167 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,17,12094,12167,2,70,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 12702, 12738 };

          static int condEnd[] = { 12734, 12775 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,18,12702,12775,2,72,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 13423, 13459, 13501 };

          static int condEnd[] = { 13455, 13497, 13539 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,19,13423,13539,3,74,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 13866, 13897 };

          static int condEnd[] = { 13893, 13948 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,20,13866,13948,2,77,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 14678, 14714 };

          static int condEnd[] = { 14710, 14752 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,21,14678,14752,2,79,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 15297, 15333 };

          static int condEnd[] = { 15329, 15371 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,22,15297,15371,2,81,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 16028, 16064, 16105 };

          static int condEnd[] = { 16060, 16101, 16142 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,23,16028,16142,3,83,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 16459, 16490 };

          static int condEnd[] = { 16486, 16541 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,24,16459,16541,2,86,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 17268, 17304, 17371, 17407, 17475, 17511,
            17578, 17634, 17678 };

          static int condEnd[] = { 17300, 17365, 17403, 17468, 17507, 17572,
            17630, 17674, 17717 };

          static int pfixExpr[] = { 0, 1, -3, 2, 3, -3, -2, 4, 5, -3, -2, 6, -3,
            7, -3, 8, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,25,17266,17717,9,88,&(condStart[0]),
                                &(condEnd[0]),17,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 17853, 17889, 17955, 17991, 18057, 18093,
            18161, 18217, 18262 };

          static int condEnd[] = { 17885, 17950, 17987, 18052, 18089, 18154,
            18213, 18258, 18302 };

          static int pfixExpr[] = { 0, 1, -3, 2, 3, -3, -2, 4, 5, -3, -2, 6, -3,
            7, -3, 8, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,26,17851,18302,9,97,&(condStart[0]),
                                &(condEnd[0]),17,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 18582, 18618 };

          static int condEnd[] = { 18614, 18653 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,27,18582,18653,2,106,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 19246, 19282 };

          static int condEnd[] = { 19278, 19317 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,28,19246,19317,2,108,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 20304, 20385, 20465 };

          static int condEnd[] = { 20381, 20461, 20537 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,29,20304,20537,3,110,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 21213, 21306 };

          static int condEnd[] = { 21302, 21396 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,30,21213,21396,2,113,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 22280, 22325, 22368 };

          static int condEnd[] = { 22321, 22364, 22404 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,31,22280,22404,3,115,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 22690, 22742 };

          static int condEnd[] = { 22738, 22787 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,32,22690,22787,2,118,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 23222, 23315, 23408 };

          static int condEnd[] = { 23311, 23404, 23453 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,33,23222,23453,3,120,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 24492, 24585, 24678 };

          static int condEnd[] = { 24581, 24674, 24723 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,34,24492,24723,3,123,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 26601, 26637 };

          static int condEnd[] = { 26633, 26669 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,35,26601,26669,2,126,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 27616, 27697, 27777 };

          static int condEnd[] = { 27693, 27773, 27849 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,36,27616,27849,3,128,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 28507, 28600 };

          static int condEnd[] = { 28596, 28690 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,37,28507,28690,2,131,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 29468, 29504 };

          static int condEnd[] = { 29500, 29536 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,38,29468,29536,2,133,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 30557, 30638, 30718 };

          static int condEnd[] = { 30634, 30714, 30791 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,39,30557,30791,3,135,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 31478, 31571 };

          static int condEnd[] = { 31567, 31661 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,40,31478,31661,2,138,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 32557, 32602, 32645 };

          static int condEnd[] = { 32598, 32641, 32682 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,41,32557,32682,3,140,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 32971, 33023 };

          static int condEnd[] = { 33019, 33068 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,42,32971,33068,2,143,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 33508, 33601, 33694 };

          static int condEnd[] = { 33597, 33690, 33739 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,43,33508,33739,3,145,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 34792, 34885, 34978 };

          static int condEnd[] = { 34881, 34974, 35023 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,44,34792,35023,3,148,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 36927, 36963 };

          static int condEnd[] = { 36959, 36995 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,45,36927,36995,2,151,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 38052, 38133, 38213 };

          static int condEnd[] = { 38129, 38209, 38286 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,46,38052,38286,3,153,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 38955, 39048 };

          static int condEnd[] = { 39044, 39138 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,47,38955,39138,2,156,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 39919, 39955 };

          static int condEnd[] = { 39951, 39987 };

          static int pfixExpr[] = { 0, 1, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,48,39919,39987,2,158,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 41231, 41269 };

          static int condEnd[] = { 41265, 41307 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,49,41231,41307,2,160,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 41406, 41442, 41478 };

          static int condEnd[] = { 41438, 41474, 41510 };

          static int pfixExpr[] = { 0, 1, -2, 2, -2 };

          _SFD_CV_INIT_EML_MCDC(0,1,50,41406,41510,3,162,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 41651, 41688, 41728 };

          static int condEnd[] = { 41683, 41724, 41764 };

          static int pfixExpr[] = { 0, 1, 2, -2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,51,41651,41765,3,165,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 44042, 44084, 44123, 44170 };

          static int condEnd[] = { 44080, 44119, 44166, 44211 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,52,44042,44211,4,168,&(condStart[0]),
                                &(condEnd[0]),7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 44359, 44456 };

          static int condEnd[] = { 44452, 44549 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,53,44359,44549,2,172,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 45103, 45145, 45185, 45232 };

          static int condEnd[] = { 45141, 45181, 45228, 45273 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3, 3, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,54,45103,45273,4,174,&(condStart[0]),
                                &(condEnd[0]),7,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 45421, 45518 };

          static int condEnd[] = { 45514, 45611 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,55,45421,45611,2,178,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 46165, 46207 };

          static int condEnd[] = { 46203, 46235 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,56,46165,46235,2,180,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 46715, 46757 };

          static int condEnd[] = { 46753, 46828 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,57,46715,46828,2,182,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 47008, 47048 };

          static int condEnd[] = { 47044, 47083 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,58,47008,47083,2,184,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 48378, 48455, 48531 };

          static int condEnd[] = { 48449, 48526, 48567 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,59,48377,48567,3,186,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 49141, 49226 };

          static int condEnd[] = { 49222, 49307 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,60,49141,49307,2,189,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 49963, 50011 };

          static int condEnd[] = { 50007, 50053 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,61,49963,50053,2,191,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 50443, 50520, 50596 };

          static int condEnd[] = { 50514, 50591, 50632 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,62,50442,50632,3,193,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 51200, 51285 };

          static int condEnd[] = { 51281, 51366 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,63,51200,51366,2,196,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 52015, 52063 };

          static int condEnd[] = { 52059, 52105 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,64,52015,52105,2,198,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 53168, 53251 };

          static int condEnd[] = { 53247, 53330 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,65,53168,53330,2,200,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 54118, 54201 };

          static int condEnd[] = { 54197, 54280 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,66,54118,54280,2,202,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 55138, 55223 };

          static int condEnd[] = { 55219, 55304 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,67,55138,55304,2,204,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 56082, 56167 };

          static int condEnd[] = { 56163, 56248 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,68,56082,56248,2,206,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 58536, 58620, 58703 };

          static int condEnd[] = { 58615, 58699, 58743 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,69,58536,58743,3,208,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 58982, 59068, 59153 };

          static int condEnd[] = { 59063, 59149, 59194 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,70,58982,59194,3,211,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 60487, 60571, 60654 };

          static int condEnd[] = { 60566, 60650, 60694 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,71,60487,60694,3,214,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 60933, 61019, 61104 };

          static int condEnd[] = { 61014, 61100, 61145 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,72,60933,61145,3,217,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 62532, 62617, 62702 };

          static int condEnd[] = { 62613, 62698, 62743 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,73,62532,62743,3,220,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 64354, 64439, 64524 };

          static int condEnd[] = { 64435, 64520, 64565 };

          static int pfixExpr[] = { 0, 1, -3, 2, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,74,64354,64565,3,223,&(condStart[0]),
                                &(condEnd[0]),5,&(pfixExpr[0]));
        }

        {
          static int condStart[] = { 65036, 65048 };

          static int condEnd[] = { 65044, 65092 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(0,1,75,65036,65092,2,226,&(condStart[0]),
                                &(condEnd[0]),3,&(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML_RELATIONAL(0,1,-13,6281,6319,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-12,6802,6834,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-11,6838,6870,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-10,6876,6955,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-9,6959,7036,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-8,7040,7108,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-7,7192,7224,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-6,7228,7260,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-5,7266,7308,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-4,7312,7352,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-3,7436,7468,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-2,7472,7504,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,-1,7510,7589,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,0,7593,7670,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,1,7674,7742,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,2,7827,7859,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,3,7863,7895,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,4,7901,7968,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,5,8140,8172,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,6,8176,8208,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,7,8214,8283,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,8,8287,8366,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,9,8370,8448,-3,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,10,8534,8566,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,11,8570,8602,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,12,8608,8687,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,13,8691,8768,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,14,8772,8841,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,15,8927,8959,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,16,8963,8995,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,17,9001,9043,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,18,9047,9087,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,19,9173,9205,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,20,9209,9241,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,21,9248,9327,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,22,9331,9408,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,23,9412,9481,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,24,9566,9598,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,25,9602,9634,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,26,9640,9706,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,27,9877,9909,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,28,9913,9945,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,29,9951,10019,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,30,10023,10102,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,31,10106,10184,-3,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,32,10274,10306,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,33,10310,10342,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,34,10346,10378,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,35,10384,10456,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,36,10553,10585,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,37,10589,10621,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,38,10625,10657,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,39,10663,10736,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,40,10833,10865,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,41,10869,10901,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,42,10905,10937,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,43,10943,11014,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,44,11110,11142,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,45,11146,11178,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,46,11182,11214,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,47,11220,11292,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,48,11395,11427,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,49,11431,11463,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,50,11467,11499,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,51,11505,11577,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,52,11673,11705,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,53,11709,11741,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,54,11745,11777,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,55,11783,11854,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,56,12094,12126,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,59,12702,12734,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,62,13423,13455,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,67,13866,13893,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,68,13897,13948,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,69,14678,14710,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,72,15297,15329,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,75,16028,16060,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,80,16459,16486,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,81,16490,16541,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,82,17268,17300,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,83,17304,17365,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,84,17371,17403,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,85,17407,17468,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,86,17475,17507,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,87,17511,17572,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,88,17578,17630,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,89,17634,17674,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,90,17678,17717,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,91,17853,17885,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,92,17889,17950,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,93,17955,17987,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,94,17991,18052,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,95,18057,18089,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,96,18093,18154,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,97,18161,18213,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,98,18217,18258,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,99,18262,18302,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,100,18434,18495,0,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,101,18582,18614,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,102,18618,18653,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,103,19246,19278,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,104,19282,19317,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,105,20304,20381,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,106,20385,20461,-3,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,107,20465,20537,-3,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,108,21213,21302,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,109,21306,21396,-3,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,110,22280,22321,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,111,22325,22364,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,114,22690,22738,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,115,22742,22787,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,116,23222,23311,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,117,23315,23404,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,118,23408,23453,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,119,24298,24306,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,120,24492,24581,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,121,24585,24674,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,122,24678,24723,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,123,25211,25219,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,124,26601,26633,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,125,26637,26669,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,126,26766,26799,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,127,27616,27693,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,128,27697,27773,-3,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,129,27777,27849,-3,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,130,28507,28596,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,131,28600,28690,-3,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,132,29468,29500,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,133,29504,29536,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,134,29631,29665,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,135,30557,30634,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,136,30638,30714,-3,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,137,30718,30791,-3,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,138,31478,31567,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,139,31571,31661,-3,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,140,32557,32598,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,141,32602,32641,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,144,32971,33019,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,145,33023,33068,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,146,33508,33597,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,147,33601,33690,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,148,33694,33739,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,149,34595,34603,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,150,34792,34881,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,151,34885,34974,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,152,34978,35023,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,153,35511,35519,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,154,36927,36959,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,155,36963,36995,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,156,37092,37126,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,157,38052,38129,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,158,38133,38209,-3,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,159,38213,38286,-3,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,160,38955,39044,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,161,39048,39138,-3,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,162,39919,39951,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,163,39955,39987,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,164,40083,40116,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,165,40771,40825,0,1);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,168,41269,41307,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,169,41406,41438,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,170,41442,41474,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,171,41478,41510,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,172,41651,41683,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,173,41688,41724,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,174,41728,41764,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,175,41991,42027,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,176,44042,44080,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,179,44123,44166,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,180,44170,44211,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,181,44225,44253,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,182,44359,44452,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,183,44456,44549,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,184,44737,44745,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,185,45103,45141,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,188,45185,45228,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,189,45232,45273,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,190,45287,45315,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,191,45421,45514,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,192,45518,45611,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,193,45799,45807,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,194,46165,46203,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,195,46207,46235,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,196,46296,46341,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,197,46715,46753,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,198,46757,46828,0,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,199,47008,47044,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,200,47048,47083,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,201,47248,47291,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,202,47512,47550,0,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,203,48378,48449,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,204,48455,48526,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,205,48531,48567,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,206,49141,49222,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,207,49226,49307,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,208,49963,50007,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,209,50011,50053,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,210,50443,50514,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,211,50520,50591,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,212,50596,50632,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,213,51200,51281,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,214,51285,51366,-3,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,215,52015,52059,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,216,52063,52105,-1,3);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,217,53168,53247,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,218,53251,53330,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,219,54118,54197,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,220,54201,54280,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,221,55138,55219,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,222,55223,55304,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,223,55764,55772,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,224,56082,56163,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,225,56167,56248,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,226,56700,56708,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,227,58536,58615,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,228,58620,58699,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,229,58703,58743,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,230,58982,59063,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,231,59068,59149,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,232,59153,59194,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,233,60487,60566,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,234,60571,60650,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,235,60654,60694,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,236,60933,61014,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,237,61019,61100,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,238,61104,61145,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,239,62532,62613,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,240,62617,62698,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,241,62702,62743,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,242,63214,63222,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,243,64354,64435,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,244,64439,64520,-3,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,245,64524,64565,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,246,65036,65044,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,247,65048,65092,-1,4);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,248,67221,67231,-1,2);
        _SFD_CV_INIT_EML_RELATIONAL(0,1,249,67691,67701,-1,2);
        _SFD_CV_INIT_EML(1,1,0,0,0,0,0,0,0,0,0,0);
        _SFD_SET_DATA_COMPILED_PROPS(0,SF_STRUCT,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_b_sf_marshallOut,(MexInFcnForType)c7_b_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_d_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_d_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_SINGLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_d_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_INT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_c_sf_marshallOut,(MexInFcnForType)c7_c_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_STRUCT,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_data_struct_out_bus_io,(MexInFcnForType)NULL);

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(8,SF_STRUCT,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(10,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(11,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(12,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(13,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(14,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(15,SF_STRUCT,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(16,SF_STRUCT,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(17,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_COMPILED_PROPS(18,SF_STRUCT,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c7_data_struct_out_bus_io,(MexInFcnForType)NULL);
        _SFD_SET_DATA_VALUE_PTR(8,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(9,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(10,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(11,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(12,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(13,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(14,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(15,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(16,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(17,(void *)(NULL));
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _XsensLibrary2MachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static void chart_debug_initialize_data_addresses(SimStruct *S)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc7_XsensLibrary2InstanceStruct *chartInstance =
      (SFc7_XsensLibrary2InstanceStruct *)sf_get_chart_instance_ptr(S);
    if (ssIsFirstInitCond(S)) {
      /* do this only if simulation is starting and after we know the addresses of all data */
      {
        _SFD_SET_DATA_VALUE_PTR(1U, chartInstance->c7_time);
        _SFD_SET_DATA_VALUE_PTR(2U, chartInstance->c7_value_VelRShank);
        _SFD_SET_DATA_VALUE_PTR(3U, chartInstance->c7_value_VelLShank);
        _SFD_SET_DATA_VALUE_PTR(4U, chartInstance->c7_value_AngRShank);
        _SFD_SET_DATA_VALUE_PTR(5U, chartInstance->c7_value_AngLShank);
        _SFD_SET_DATA_VALUE_PTR(6U, chartInstance->c7_state);
        _SFD_SET_DATA_VALUE_PTR(7U, chartInstance->c7_data_struct_out);
        _SFD_SET_DATA_VALUE_PTR(18U, chartInstance->c7_A_address);
        _SFD_SET_DATA_VALUE_PTR(0U, chartInstance->c7_data_struct);
      }
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "sYbWCEqsLzTZrGsvwVByESC";
}

static void sf_check_dwork_consistency(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    const uint32_T *sfunDWorkChecksum = sf_get_sfun_dwork_checksum();
    mxArray *infoStruct = load_XsensLibrary2_optimization_info();
    mxArray* mxRTWDWorkChecksum = sf_get_dwork_info_from_mat_file(S,
      sf_get_instance_specialization(), infoStruct, 7, "dworkChecksum");
    if (mxRTWDWorkChecksum != NULL) {
      double *pr = mxGetPr(mxRTWDWorkChecksum);
      if ((uint32_T)pr[0] != sfunDWorkChecksum[0] ||
          (uint32_T)pr[1] != sfunDWorkChecksum[1] ||
          (uint32_T)pr[2] != sfunDWorkChecksum[2] ||
          (uint32_T)pr[3] != sfunDWorkChecksum[3]) {
        sf_mex_error_message("Code generation and simulation targets registered different sets of persistent variables for the block. "
                             "External or Rapid Accelerator mode simulation requires code generation and simulation targets to "
                             "register the same set of persistent variables for this block. "
                             "This discrepancy is typically caused by MATLAB functions that have different code paths for "
                             "simulation and code generation targets where these code paths define different sets of persistent variables. "
                             "Please identify these code paths in the offending block and rewrite the MATLAB code so that "
                             "the set of persistent variables is the same between simulation and code generation.");
      }
    }
  }
}

static void sf_opaque_initialize_c7_XsensLibrary2(void *chartInstanceVar)
{
  sf_check_dwork_consistency(((SFc7_XsensLibrary2InstanceStruct*)
    chartInstanceVar)->S);
  chart_debug_initialization(((SFc7_XsensLibrary2InstanceStruct*)
    chartInstanceVar)->S,0);
  initialize_params_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*)
    chartInstanceVar);
  initialize_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_enable_c7_XsensLibrary2(void *chartInstanceVar)
{
  enable_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c7_XsensLibrary2(void *chartInstanceVar)
{
  disable_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c7_XsensLibrary2(void *chartInstanceVar)
{
  sf_gateway_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_ext_mode_exec_c7_XsensLibrary2(void *chartInstanceVar)
{
  ext_mode_exec_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*)
    chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c7_XsensLibrary2(SimStruct* S)
{
  return get_sim_state_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct *)
    sf_get_chart_instance_ptr(S));     /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c7_XsensLibrary2(SimStruct* S, const mxArray
  *st)
{
  set_sim_state_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_terminate_c7_XsensLibrary2(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc7_XsensLibrary2InstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_XsensLibrary2_optimization_info();
    }

    finalize_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*)
      chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*)
    chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c7_XsensLibrary2(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c7_XsensLibrary2((SFc7_XsensLibrary2InstanceStruct*)
      sf_get_chart_instance_ptr(S));
  }
}

mxArray *sf_c7_XsensLibrary2_get_testpoint_info(void)
{
  const char *infoEncStr[] = {
    "100 S1x2'varName','path'{{T\"is_active_c7_XsensLibrary2\",T\"is_active_c7_XsensLibrary2\"},{T\"is_c7_XsensLibrary2\",T\"is_c7_XsensLibrary2\"}}"
  };

  mxArray *mxTpInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 2, 10);
  return mxTpInfo;
}

static void sf_set_sfun_dwork_info(SimStruct *S)
{
  const char *dworkEncStr[] = {
    "100 S1x5'type','isSigned','wordLength','bias','slope','exponent','isScaledDouble','isComplex','size','local_queue_dwork_idx','local_queue_id'{{T\"int32\",,,,,,,M[0],M[],M[-1],M[-1]},{T\"boolean\",,,,,,,M[0],M[],M[-1],M[-1]},{T\"uint8\",,,,,,,M[0],M[],M[-1],M[-1]},{T\"uint8\",,,,,,,M[0],M[],M[-1],M[-1]},{T\"bus_datastruct\",,,,,,,M[0],M[],M[-1],M[-1]}}"
  };

  sf_set_encoded_dwork_info(S, dworkEncStr, 5, 10);
}

static uint32_T* sf_get_sfun_dwork_checksum()
{
  static uint32_T checksum[4] = { 3089381191U, 2354204323U, 1900786959U,
    3353829151U };

  return checksum;
}

static void mdlSetWorkWidths_c7_XsensLibrary2(SimStruct *S)
{
  ssMdlUpdateIsEmpty(S, 1);
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_XsensLibrary2_optimization_info();
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(sf_get_instance_specialization(),infoStruct,7);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,1);
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop
      (sf_get_instance_specialization(),infoStruct,7,
       "gatewayCannotBeInlinedMultipleTimes"));
    sf_set_chart_accesses_machine_info(S, sf_get_instance_specialization(),
      infoStruct, 7);
    sf_update_buildInfo(sf_get_instance_specialization(),infoStruct,7);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,7,5);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,7,2);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=2; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 5; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,7);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
    sf_set_sfun_dwork_info(S);
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(4205909130U));
  ssSetChecksum1(S,(2862763443U));
  ssSetChecksum2(S,(3917142546U));
  ssSetChecksum3(S,(3027161913U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,0);
}

static void mdlRTW_c7_XsensLibrary2(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Stateflow");
  }
}

static void mdlStart_c7_XsensLibrary2(SimStruct *S)
{
  SFc7_XsensLibrary2InstanceStruct *chartInstance;
  chartInstance = (SFc7_XsensLibrary2InstanceStruct *)utMalloc(sizeof
    (SFc7_XsensLibrary2InstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc7_XsensLibrary2InstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 0;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c7_XsensLibrary2;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c7_XsensLibrary2;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c7_XsensLibrary2;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c7_XsensLibrary2;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c7_XsensLibrary2;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c7_XsensLibrary2;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c7_XsensLibrary2;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c7_XsensLibrary2;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c7_XsensLibrary2;
  chartInstance->chartInfo.mdlStart = mdlStart_c7_XsensLibrary2;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c7_XsensLibrary2;
  chartInstance->chartInfo.callGetHoverDataForMsg =
    sf_opaque_get_hover_data_for_msg;
  chartInstance->chartInfo.extModeExec =
    sf_opaque_ext_mode_exec_c7_XsensLibrary2;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.debugInstance = sfGlobalDebugInstanceStruct;
  chartInstance->S = S;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  chart_debug_initialization(S,1);
  mdl_start_c7_XsensLibrary2(chartInstance);
}

void c7_XsensLibrary2_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c7_XsensLibrary2(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c7_XsensLibrary2(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c7_XsensLibrary2(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c7_XsensLibrary2_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
