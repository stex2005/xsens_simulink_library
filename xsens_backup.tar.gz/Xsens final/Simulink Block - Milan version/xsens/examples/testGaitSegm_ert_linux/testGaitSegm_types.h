//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: testGaitSegm_types.h
//
// Code generated for Simulink model 'testGaitSegm'.
//
// Model version                  : 1.164
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Fri Oct 28 18:25:55 2016
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_testGaitSegm_types_h_
#define RTW_HEADER_testGaitSegm_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#ifndef _DEFINED_TYPEDEF_FOR_bus_datastruct_
#define _DEFINED_TYPEDEF_FOR_bus_datastruct_

typedef struct {
  real32_T VelRShank[200];
  real32_T VelLShank[200];
  real32_T AngRShank[200];
  real32_T AngLShank[200];
  real32_T VelRShank_filt[200];
  real32_T VelLShank_filt[200];
  real32_T AngRShank_filt[200];
  real32_T AngLShank_filt[200];
  real32_T VelRShank_LPF[200];
  real32_T VelLShank_LPF[200];
  real32_T AngRShank_LPF[200];
  real32_T AngLShank_LPF[200];
  real32_T AngRShank_LPF2Hz[200];
  real32_T AngLShank_LPF2Hz[200];
  uint16_T counter_stop;
  uint8_T counter;
  uint16_T index_start_calib;
  uint16_T index_stop_calib;
  boolean_T initial_leg;
  boolean_T flag_calib;
  int8_T calibrating;
  int8_T state;
  int8_T prevstate;
  real32_T MA_maxs_right[5];
  real32_T MA_maxs_left[5];
  real32_T MA_LPF_maxs_right[5];
  real32_T MA_LPF_maxs_left[5];
  uint8_T MA_LPF_index_right;
  uint8_T MA_LPF_index_left;
  uint8_T MA_index_right;
  uint8_T MA_index_left;
  real32_T IC_mins_right[5];
  real32_T IC_mins_left[5];
  real32_T IC_LPF_mins_right[5];
  real32_T IC_LPF_mins_left[5];
  uint8_T IC_LPF_index_right;
  uint8_T IC_LPF_index_left;
  uint8_T IC_index_right;
  uint8_T IC_index_left;
  real32_T EC_events_mins_right[5];
  real32_T EC_events_mins_left[5];
  real32_T EC_peaks_mins_right[5];
  real32_T EC_peaks_mins_left[5];
  uint8_T EC_events_index_right;
  uint8_T EC_events_index_left;
  uint8_T EC_peaks_index_right;
  uint8_T EC_peaks_index_left;
  real32_T AN_events_right[5];
  real32_T AN_events_left[5];
  real32_T AN_peaks_right[5];
  real32_T AN_peaks_left[5];
  uint8_T stop_DS_index;
  uint16_T stop_DS[10];
  boolean_T MS_event_left;
  boolean_T MS_event_right;
  boolean_T EC_event_left;
  boolean_T EC_event_right;
  boolean_T IC_event_left;
  boolean_T IC_event_right;
  boolean_T AN_event_left;
  boolean_T AN_event_right;
  boolean_T MA_event_left;
  boolean_T MA_event_right;
  boolean_T stop_Vel_event_left;
  boolean_T stop_Vel_event_right;
  boolean_T stop_MA_event_left;
  boolean_T stop_MA_event_right;
  boolean_T stop_IC_event_left;
  boolean_T stop_IC_event_right;
  boolean_T MA_flag_right;
  boolean_T MA_flag_left;
  uint16_T last_EC;
  uint16_T last_IC;
  real32_T IC_buffer_left[200];
  real32_T IC_buffer_right[200];
  real32_T EC_buffer_left[200];
  real32_T EC_buffer_right[200];
  real32_T MS_buffer_left[200];
  real32_T MS_buffer_right[200];
  uint8_T IC_buffer_index_left;
  uint8_T IC_buffer_index_right;
  uint8_T EC_buffer_index_left;
  uint8_T EC_buffer_index_right;
  uint8_T MS_buffer_index_left;
  uint8_T MS_buffer_index_right;
  real32_T MA_th_left;
  real32_T MA_th_right;
  real32_T IC_th_left;
  real32_T IC_th_right;
  real32_T AN_th_right;
  real32_T AN_th_left;
  real32_T EC_th_right;
  real32_T EC_th_left;
  real32_T stop_Vel_th_left;
  real32_T stop_Vel_th_right;
  real32_T stop_MA_th_left;
  real32_T stop_MA_th_right;
  real32_T stop_IC_th_right;
  real32_T stop_IC_th_left;
  uint16_T stop_DS_th;
  real32_T MA_LPF_th_left;
  real32_T MA_LPF_th_right;
  real32_T IC_LPF_th_left;
  real32_T IC_LPF_th_right;
} bus_datastruct;

#endif

// Parameters (auto storage)
typedef struct P_testGaitSegm_T_ P_testGaitSegm_T;

// Forward declaration for rtModel
typedef struct tag_RTM_testGaitSegm_T RT_MODEL_testGaitSegm_T;

#endif                                 // RTW_HEADER_testGaitSegm_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
