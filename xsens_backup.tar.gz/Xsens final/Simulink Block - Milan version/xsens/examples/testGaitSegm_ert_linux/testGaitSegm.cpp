//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: testGaitSegm.cpp
//
// Code generated for Simulink model 'testGaitSegm'.
//
// Model version                  : 1.164
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Fri Oct 28 18:25:55 2016
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "testGaitSegm.h"
#include "testGaitSegm_private.h"
#include "testGaitSegm_dt.h"

// Named constants for Chart: '<S1>/Chart'
#define testGaitSegm_CALL_EVENT_g      (-1)
#define testGaitSegm_IN_DATARECEIVED   ((uint8_T)1U)
#define testGaitSegm_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define testGaitSegm_IN_WAITFORDATA    ((uint8_T)2U)

// Named constants for Chart: '<S2>/Chart'
#define testGaitSegm_IN_SEGMENTATION   ((uint8_T)1U)

// Block signals (auto storage)
B_testGaitSegm_T testGaitSegm_B;

// Block states (auto storage)
DW_testGaitSegm_T testGaitSegm_DW;

// Real-time model
RT_MODEL_testGaitSegm_T testGaitSegm_M_;
RT_MODEL_testGaitSegm_T *const testGaitSegm_M = &testGaitSegm_M_;

// Forward declaration for local functions
static real_T testGaitSegm_mean(const uint16_T x_data[], const int32_T x_sizes[2]);
static real32_T testGaitSegm_mean_l(const real32_T x_data[], const int32_T
  x_sizes[2]);
static real32_T testGaitSegm_std(const real32_T varargin_1_data[], const int32_T
  varargin_1_sizes[2]);
static real_T testGaitSegm_mean_lh(const real_T x_data[], const int32_T x_sizes);
static int8_T testGaitSegm_RTDetection(bus_datastruct *data_struct_input, real_T
  timestamp, real_T newVelRShank, real32_T newVelLShank, real32_T newAngRShank,
  real32_T newAngLShank);
static void testGaitSegm_SEGMENTATION(void);
static void testGaitSe_data_struct_creation(bus_datastruct *data_struct_in);

//
// Initial conditions for atomic system:
//    '<S7>/Extractor'
//    '<S8>/Extractor'
//
void testGaitSegm_Extractor_Init(DW_Extractor_testGaitSegm_T *localDW)
{
  localDW->lastSampleNumber = 0.0;
  localDW->lastFactor = 1.0;
}

//
// Output and update for atomic system:
//    '<S7>/Extractor'
//    '<S8>/Extractor'
//
void testGaitSegm_Extractor(const real_T rtu_data[160],
  B_Extractor_testGaitSegm_T *localB, DW_Extractor_testGaitSegm_T *localDW,
  real_T rtp_correction)
{
  real_T factor;
  real_T diff;

  // MATLAB Function 'Extract/Extractor': '<S9>:1'
  // '<S9>:1:4'
  // '<S9>:1:6'
  // '<S9>:1:7'
  // '<S9>:1:8'
  localB->omega[0] = rtu_data[4];
  localB->omega[1] = rtu_data[5];
  localB->omega[2] = rtu_data[6];

  // '<S9>:1:9'
  // '<S9>:1:10'
  // '<S9>:1:11'
  // '<S9>:1:22'
  factor = 1.0;

  // '<S9>:1:24'
  diff = fabs(rtu_data[0] - localDW->lastSampleNumber);
  if (diff >= 1.0) {
    // '<S9>:1:26'
    // '<S9>:1:27'
    factor = diff;
  }

  if (diff == 0.0) {
    // '<S9>:1:29'
    // '<S9>:1:30'
    factor = localDW->lastFactor;
  }

  // '<S9>:1:33'
  localDW->lastFactor = factor;

  // '<S9>:1:34'
  localDW->lastSampleNumber = rtu_data[0];
  if (rtp_correction == 1.0) {
    // '<S9>:1:36'
    // '<S9>:1:37'
    // '<S9>:1:38'
    localB->omega[0] /= factor;
    localB->omega[1] /= factor;
    localB->omega[2] /= factor;

    // '<S9>:1:39'
    // '<S9>:1:40'
  } else {
    // '<S9>:1:42'
    // '<S9>:1:43'
    // '<S9>:1:44'
    // '<S9>:1:45'
  }
}

// Function for Chart: '<S2>/Chart'
static real_T testGaitSegm_mean(const uint16_T x_data[], const int32_T x_sizes[2])
{
  real_T b_y;
  int32_T k;
  if (x_sizes[1] == 0) {
    b_y = 0.0;
  } else {
    b_y = x_data[0];
    for (k = 2; k <= x_sizes[1]; k++) {
      b_y += (real_T)x_data[k - 1];
    }
  }

  return b_y / (real_T)x_sizes[1];
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

// Function for Chart: '<S2>/Chart'
static real32_T testGaitSegm_mean_l(const real32_T x_data[], const int32_T
  x_sizes[2])
{
  real32_T b_y;
  int32_T k;
  if (x_sizes[1] == 0) {
    b_y = 0.0F;
  } else {
    b_y = x_data[0];
    for (k = 2; k <= x_sizes[1]; k++) {
      b_y += x_data[k - 1];
    }
  }

  return b_y / (real32_T)x_sizes[1];
}

// Function for Chart: '<S2>/Chart'
static real32_T testGaitSegm_std(const real32_T varargin_1_data[], const int32_T
  varargin_1_sizes[2])
{
  int32_T n;
  int32_T ix;
  real32_T xbar;
  int32_T k;
  real32_T r;
  real32_T b_r;
  n = varargin_1_sizes[1];
  if (varargin_1_sizes[1] == 0) {
    r = 0.0F;
  } else {
    ix = 0;
    xbar = varargin_1_data[0];
    for (k = 2; k <= n; k++) {
      ix++;
      xbar += varargin_1_data[ix];
    }

    xbar /= (real32_T)varargin_1_sizes[1];
    ix = 0;
    r = varargin_1_data[0] - xbar;
    r *= r;
    for (k = 2; k <= n; k++) {
      ix++;
      b_r = varargin_1_data[ix] - xbar;
      r += b_r * b_r;
    }

    if (varargin_1_sizes[1] > 1) {
      n = varargin_1_sizes[1] - 1;
    } else {
      n = varargin_1_sizes[1];
    }

    r /= (real32_T)n;
  }

  return (real32_T)sqrt((real_T)r);
}

// Function for Chart: '<S2>/Chart'
static real_T testGaitSegm_mean_lh(const real_T x_data[], const int32_T x_sizes)
{
  real_T b_y;
  int32_T k;
  if (x_sizes == 0) {
    b_y = 0.0;
  } else {
    b_y = x_data[0];
    for (k = 2; k <= x_sizes; k++) {
      b_y += x_data[k - 1];
    }
  }

  return b_y / (real_T)x_sizes;
}

// Function for Chart: '<S2>/Chart'
static int8_T testGaitSegm_RTDetection(bus_datastruct *data_struct_input, real_T
  timestamp, real_T newVelRShank, real32_T newVelLShank, real32_T newAngRShank,
  real32_T newAngLShank)
{
  int8_T state_out;
  int32_T found;
  real_T b_index;
  int32_T MS_inds_left;
  int32_T EC_distance_left;
  real_T EC_peaks[50];
  real_T AN_peaks[50];
  real_T EC_peaks_index;
  real_T MS_inds_index_left;
  real_T IC_LPF_inds_right[5];
  real_T IC_LPF_inds_left[5];
  uint8_T IC_inds_right[5];
  uint8_T IC_inds_left[5];
  real_T b_MS_inds_right[5];
  real_T b_MS_inds_left[5];
  real_T b_EC_distance_right[5];
  real_T b_EC_distance_left[5];
  real_T b_EC_events_inds_right[5];
  real_T b_EC_events_inds_left[5];
  uint16_T c_index;
  boolean_T qc[10];
  boolean_T rc[5];
  boolean_T sc[5];
  uint16_T mtmp;
  boolean_T exitg4;
  int32_T i;
  int32_T EC_events_inds_left;
  real_T temp_data[5];
  int32_T tc_data[10];
  int32_T vc_data[5];
  int8_T wc_data[50];
  int32_T xc_data[5];
  int32_T data_struct_input_sizes[2];
  int32_T data_struct_input_sizes_0[2];
  int32_T data_struct_input_sizes_1[2];
  int32_T data_struct_input_sizes_2[2];
  int32_T data_struct_input_sizes_3[2];
  int32_T data_struct_input_sizes_4[2];
  int32_T data_struct_input_sizes_5[2];
  int32_T data_struct_input_sizes_6[2];
  int32_T data_struct_input_sizes_7[2];
  int32_T data_struct_input_sizes_8[2];
  int32_T data_struct_input_sizes_9[2];
  int32_T data_struct_input_sizes_a[2];
  int32_T data_struct_input_sizes_b[2];
  int32_T data_struct_input_sizes_c[2];
  int32_T data_struct_input_sizes_d[2];
  int32_T data_struct_input_sizes_e[2];
  int32_T data_struct_input_sizes_f[2];
  int32_T data_struct_input_sizes_g[2];
  int32_T data_struct_input_sizes_h[2];
  int32_T data_struct_input_sizes_i[2];
  int32_T data_struct_input_sizes_j[2];
  int32_T data_struct_input_sizes_k[2];
  int32_T data_struct_input_sizes_l[2];
  int32_T data_struct_input_sizes_m[2];
  int32_T data_struct_input_sizes_n[2];
  int32_T data_struct_input_sizes_o[2];
  int32_T data_struct_input_sizes_p[2];
  int32_T data_struct_input_sizes_q[2];
  int32_T data_struct_input_sizes_r[2];
  int32_T data_struct_input_sizes_s[2];
  int32_T data_struct_input_sizes_t[2];
  int32_T data_struct_input_sizes_u[2];
  int32_T data_struct_input_sizes_v[2];
  int32_T data_struct_input_sizes_w[2];
  int32_T data_struct_input_sizes_x[2];
  int32_T data_struct_input_sizes_y[2];
  int32_T data_struct_input_sizes_z[2];
  int32_T data_struct_input_sizes_10[2];
  int32_T data_struct_input_sizes_11[2];
  int32_T data_struct_input_sizes_12[2];
  int32_T data_struct_input_sizes_13[2];
  int32_T data_struct_input_sizes_14[2];
  int32_T data_struct_input_sizes_15[2];
  int32_T data_struct_input_sizes_16[2];
  int32_T data_struct_input_sizes_17[2];
  int32_T data_struct_input_sizes_18[2];
  real_T EC_peaks_data[50];
  int32_T data_struct_input_sizes_19[2];
  int32_T data_struct_input_sizes_1a[2];
  int32_T data_struct_input_sizes_1b[2];
  real32_T data_struct_input_data[5];
  int32_T data_struct_input_sizes_1c[2];
  real32_T data_struct_input_data_0[5];
  int32_T data_struct_input_sizes_1d[2];
  int32_T data_struct_input_sizes_1e[2];
  uint16_T data_struct_input_data_1[10];
  int32_T data_struct_input_sizes_1f[2];
  uint8_T cc_idx_0;
  uint8_T b_idx_0;
  uint32_T tmp;
  uint32_T qY;
  uint32_T qY_0;
  real32_T u;
  int32_T exitg1;
  int32_T exitg2;
  int32_T exitg3;
  int32_T exitg41;
  int32_T exitg5;
  int32_T exitg6;
  int32_T exitg7;
  int32_T exitg8;

  // MATLAB Function 'RTDetection': '<S6>:5'
  // % Buffers (VelRShank, VelLShank, angRShank, AngLShank, and the filtered versions) have 200 samples (4 seconds when sampling at 50 Hz=. 
  //  To work with higher frequencies, the buffer size must be increased.
  // % Parameters valid for sampling at 50 Hz
  //  Sampling frequency in Hz
  //  Moving average filter, 1st order
  //  % LPF Filter 4 Hz, 10th order, constrained equiripple, sampling frequency 50 Hz 
  //  LPF4Hz_filter_num=[0.00292564269948630,0.0162914708337147,0.0480431969152572,0.0959815438003878,0.141880590810861,0.161052831583004,0.141880590810861,0.0959815438003878,0.0480431969152572,0.0162914708337147,0.00292564269948630;]; 
  //  % LPF Filter 2 Hz, 10th order, constrained equiripple, , sampling frequency 50 Hz 
  //  LPF2Hz_filter_num=[0.281316797560040,0.0441010056735896,0.0466086628670363,0.0484165382088245,0.0493651349798801,0.0499926524084468,0.0493651349798801,0.0484165382088245,0.0466086628670363,0.0441010056735896,0.281316797560040;]; 
  //  LPF Filter 4 Hz, 10th order, constrained equiripple, sampling frequency 60 Hz 
  //  LPF Filter 2 Hz, 10th order, constrained equiripple, , sampling frequency 60 Hz 
  // % Read new data
  //  Process new sample
  // '<S6>:5:22'
  // '<S6>:5:23'
  for (i = 0; i < 199; i++) {
    data_struct_input->VelRShank[i] = data_struct_input->VelRShank[1 + i];
    data_struct_input->VelLShank[i] = data_struct_input->VelLShank[1 + i];
    data_struct_input->AngRShank[i] = data_struct_input->AngRShank[1 + i];
    data_struct_input->AngLShank[i] = data_struct_input->AngLShank[1 + i];
    data_struct_input->VelRShank_filt[i] = data_struct_input->VelRShank_filt[1 +
      i];
    data_struct_input->VelLShank_filt[i] = data_struct_input->VelLShank_filt[1 +
      i];
    data_struct_input->AngRShank_filt[i] = data_struct_input->AngRShank_filt[1 +
      i];
    data_struct_input->AngLShank_filt[i] = data_struct_input->AngLShank_filt[1 +
      i];
    data_struct_input->VelRShank_LPF[i] = data_struct_input->VelRShank_LPF[1 + i];
    data_struct_input->VelLShank_LPF[i] = data_struct_input->VelLShank_LPF[1 + i];
    data_struct_input->AngRShank_LPF[i] = data_struct_input->AngRShank_LPF[1 + i];
    data_struct_input->AngLShank_LPF[i] = data_struct_input->AngLShank_LPF[1 + i];
  }

  data_struct_input->VelRShank[199] = (real32_T)newVelRShank;

  // '<S6>:5:24'
  // '<S6>:5:25'
  data_struct_input->VelLShank[199] = newVelLShank;

  // '<S6>:5:26'
  // '<S6>:5:27'
  data_struct_input->AngRShank[199] = newAngRShank;

  // '<S6>:5:28'
  // '<S6>:5:29'
  data_struct_input->AngLShank[199] = newAngLShank;

  //  Moving average filter
  // '<S6>:5:32'
  // '<S6>:5:33'
  data_struct_input->VelRShank_filt[199] = 0.7F * (real32_T)newVelRShank + 0.3F *
    data_struct_input->VelRShank[198];

  // '<S6>:5:34'
  // '<S6>:5:35'
  data_struct_input->VelLShank_filt[199] = 0.7F * newVelLShank + 0.3F *
    data_struct_input->VelLShank[198];

  // '<S6>:5:36'
  // '<S6>:5:37'
  data_struct_input->AngRShank_filt[199] = 0.7F * newAngRShank + 0.3F *
    data_struct_input->AngRShank[198];

  // '<S6>:5:38'
  // '<S6>:5:39'
  data_struct_input->AngLShank_filt[199] = 0.7F * newAngLShank + 0.3F *
    data_struct_input->AngLShank[198];

  //  LPF filter
  // '<S6>:5:42'
  // '<S6>:5:43'
  data_struct_input->VelRShank_LPF[199] = (((((((((0.00265183463F * (real32_T)
    newVelRShank + 0.0145335365F * data_struct_input->VelRShank[198]) +
    0.0424117036F * data_struct_input->VelRShank[197]) + 0.0841515288F *
    data_struct_input->VelRShank[196]) + 0.123907335F *
    data_struct_input->VelRShank[195]) + 0.140471607F *
    data_struct_input->VelRShank[194]) + 0.123907335F *
    data_struct_input->VelRShank[193]) + 0.0841515288F *
    data_struct_input->VelRShank[192]) + 0.0424117036F *
    data_struct_input->VelRShank[191]) + 0.0145335365F *
    data_struct_input->VelRShank[190]) + 0.00265183463F *
    data_struct_input->VelRShank[189];

  // '<S6>:5:46'
  // '<S6>:5:47'
  data_struct_input->VelLShank_LPF[199] = (((((((((0.00265183463F * newVelLShank
    + 0.0145335365F * data_struct_input->VelLShank[198]) + 0.0424117036F *
    data_struct_input->VelLShank[197]) + 0.0841515288F *
    data_struct_input->VelLShank[196]) + 0.123907335F *
    data_struct_input->VelLShank[195]) + 0.140471607F *
    data_struct_input->VelLShank[194]) + 0.123907335F *
    data_struct_input->VelLShank[193]) + 0.0841515288F *
    data_struct_input->VelLShank[192]) + 0.0424117036F *
    data_struct_input->VelLShank[191]) + 0.0145335365F *
    data_struct_input->VelLShank[190]) + 0.00265183463F *
    data_struct_input->VelLShank[189];

  // '<S6>:5:50'
  // '<S6>:5:51'
  data_struct_input->AngRShank_LPF[199] = (((((((((0.00265183463F * newAngRShank
    + 0.0145335365F * data_struct_input->AngRShank[198]) + 0.0424117036F *
    data_struct_input->AngRShank[197]) + 0.0841515288F *
    data_struct_input->AngRShank[196]) + 0.123907335F *
    data_struct_input->AngRShank[195]) + 0.140471607F *
    data_struct_input->AngRShank[194]) + 0.123907335F *
    data_struct_input->AngRShank[193]) + 0.0841515288F *
    data_struct_input->AngRShank[192]) + 0.0424117036F *
    data_struct_input->AngRShank[191]) + 0.0145335365F *
    data_struct_input->AngRShank[190]) + 0.00265183463F *
    data_struct_input->AngRShank[189];

  // '<S6>:5:54'
  // '<S6>:5:55'
  data_struct_input->AngLShank_LPF[199] = (((((((((0.00265183463F * newAngLShank
    + 0.0145335365F * data_struct_input->AngLShank[198]) + 0.0424117036F *
    data_struct_input->AngLShank[197]) + 0.0841515288F *
    data_struct_input->AngLShank[196]) + 0.123907335F *
    data_struct_input->AngLShank[195]) + 0.140471607F *
    data_struct_input->AngLShank[194]) + 0.123907335F *
    data_struct_input->AngLShank[193]) + 0.0841515288F *
    data_struct_input->AngLShank[192]) + 0.0424117036F *
    data_struct_input->AngLShank[191]) + 0.0145335365F *
    data_struct_input->AngLShank[190]) + 0.00265183463F *
    data_struct_input->AngLShank[189];
  if ((!data_struct_input->flag_calib) && (data_struct_input->calibrating == 0))
  {
    // '<S6>:5:59'
    // '<S6>:5:60'
    qY = data_struct_input->last_IC + 1U;
    if (qY > 65535U) {
      qY = 65535U;
    }

    data_struct_input->last_IC = (uint16_T)qY;

    // '<S6>:5:61'
    qY = data_struct_input->last_EC + 1U;
    if (qY > 65535U) {
      qY = 65535U;
    }

    data_struct_input->last_EC = (uint16_T)qY;

    // '<S6>:5:64'
    data_struct_input->prevstate = data_struct_input->state;

    // '<S6>:5:66'
    qY = data_struct_input->index_start_calib + 1U;
    if (qY > 65535U) {
      qY = 65535U;
    }

    data_struct_input->index_start_calib = (uint16_T)qY;

    // '<S6>:5:67'
    c_index = data_struct_input->index_start_calib;
    mtmp = 199U;
    if (c_index < 199) {
      mtmp = c_index;
    }

    //     %% Events
    //  This part raises flags when it detects an event, but it does not
    //  change the state.
    //  Left MA
    if (((data_struct_input->state == 1) || (data_struct_input->state == 2)) &&
        (data_struct_input->AngLShank_filt[198] >
         data_struct_input->AngLShank_filt[197]) &&
        (data_struct_input->AngLShank_filt[198] >
         data_struct_input->AngLShank_filt[199]) &&
        (data_struct_input->AngLShank_filt[198] > data_struct_input->MA_th_left))
    {
      // '<S6>:5:73'
      // '<S6>:5:74'
      data_struct_input->MA_event_left = true;
    }

    //  Left MS
    if (((data_struct_input->state == 1) || (data_struct_input->state == 2)) &&
        (data_struct_input->AngLShank_filt[198] >= 0.0F) &&
        (data_struct_input->AngLShank_filt[199] <= 0.0F)) {
      // '<S6>:5:78'
      // '<S6>:5:79'
      data_struct_input->MS_event_left = true;
    }

    //  Left IC
    if (((data_struct_input->state == 2) || (data_struct_input->state == 3)) &&
        (data_struct_input->AngLShank_filt[198] <
         data_struct_input->AngLShank_filt[197]) &&
        (data_struct_input->AngLShank_filt[198] <
         data_struct_input->AngLShank_filt[199]) &&
        (data_struct_input->AngLShank_filt[198] < data_struct_input->IC_th_left))
    {
      // '<S6>:5:83'
      // '<S6>:5:84'
      data_struct_input->IC_event_left = true;
    }

    //  Right AN
    if (((data_struct_input->state == 3) || (data_struct_input->state == 4)) &&
        (data_struct_input->AngRShank_filt[199] > data_struct_input->AN_th_right))
    {
      // '<S6>:5:88'
      // '<S6>:5:89'
      data_struct_input->AN_event_right = true;

      //          data_struct_input.EC_event_right=false; % EC can only happen after AN 
    }

    //  Right EC
    if (((data_struct_input->state == 3) || (data_struct_input->state == 4)) &&
        (data_struct_input->VelRShank_filt[198] < data_struct_input->EC_th_right)
        && (data_struct_input->VelRShank_filt[198] <
            data_struct_input->VelRShank_filt[197]) &&
        (data_struct_input->VelRShank_filt[198] <=
         data_struct_input->VelRShank_filt[199])) {
      // '<S6>:5:95'
      // '<S6>:5:96'
      data_struct_input->EC_event_right = true;
    }

    //  Right MA
    if (((data_struct_input->state == 4) || (data_struct_input->state == 5)) &&
        (data_struct_input->AngRShank_filt[198] >
         data_struct_input->AngRShank_filt[197]) &&
        (data_struct_input->AngRShank_filt[198] >
         data_struct_input->AngRShank_filt[199]) &&
        (data_struct_input->AngRShank_filt[198] > data_struct_input->MA_th_right))
    {
      // '<S6>:5:100'
      // '<S6>:5:101'
      data_struct_input->MA_event_right = true;
    }

    //  Right MS
    if (((data_struct_input->state == 4) || (data_struct_input->state == 5)) &&
        (data_struct_input->AngRShank_filt[198] >= 0.0F) &&
        (data_struct_input->AngRShank_filt[199] <= 0.0F)) {
      // '<S6>:5:105'
      // '<S6>:5:106'
      data_struct_input->MS_event_right = true;
    }

    //  Right IC
    if (((data_struct_input->state == 5) || (data_struct_input->state == 6)) &&
        (data_struct_input->AngRShank_filt[198] <
         data_struct_input->AngRShank_filt[197]) &&
        (data_struct_input->AngRShank_filt[198] <
         data_struct_input->AngRShank_filt[199]) &&
        (data_struct_input->AngRShank_filt[198] < data_struct_input->IC_th_right))
    {
      // '<S6>:5:110'
      // '<S6>:5:111'
      data_struct_input->IC_event_right = true;
    }

    //  Left AN
    if (((data_struct_input->state == 6) || (data_struct_input->state == 1)) &&
        (data_struct_input->AngLShank_filt[199] > data_struct_input->AN_th_left))
    {
      // '<S6>:5:115'
      // '<S6>:5:116'
      data_struct_input->AN_event_left = true;

      //          data_struct_input.EC_event_left=false; % EC can only happen after AN 
    }

    //  Left EC
    if (((data_struct_input->state == 6) || (data_struct_input->state == 1)) &&
        (data_struct_input->VelLShank_filt[198] < data_struct_input->EC_th_left)
        && (data_struct_input->VelLShank_filt[198] <
            data_struct_input->VelLShank_filt[197]) &&
        (data_struct_input->VelLShank_filt[198] <=
         data_struct_input->VelLShank_filt[199])) {
      // '<S6>:5:122'
      // '<S6>:5:123'
      data_struct_input->EC_event_left = true;
    }

    //  Stop: left EC
    if (((data_struct_input->state == 5) || (data_struct_input->state == 6) ||
         (data_struct_input->state == 1)) && (data_struct_input->VelLShank_filt
         [199] < data_struct_input->stop_Vel_th_left)) {
      // '<S6>:5:127'
      // '<S6>:5:128'
      data_struct_input->stop_Vel_event_left = true;
    }

    //  Stop: right EC
    if (((data_struct_input->state == 2) || (data_struct_input->state == 3) ||
         (data_struct_input->state == 4)) && (data_struct_input->VelRShank_filt
         [199] < data_struct_input->stop_Vel_th_right)) {
      // '<S6>:5:132'
      // '<S6>:5:133'
      data_struct_input->stop_Vel_event_right = true;
    }

    //  Stop: left MA
    if (((data_struct_input->state == 5) || (data_struct_input->state == 6) ||
         (data_struct_input->state == 1)) && (data_struct_input->AngLShank_filt
         [199] > data_struct_input->stop_MA_th_left)) {
      // '<S6>:5:137'
      // '<S6>:5:138'
      data_struct_input->stop_MA_event_left = true;
    }

    //  Stop: right MA
    if (((data_struct_input->state == 2) || (data_struct_input->state == 3) ||
         (data_struct_input->state == 4)) && (data_struct_input->AngRShank_filt
         [199] > data_struct_input->stop_MA_th_right)) {
      // '<S6>:5:142'
      // '<S6>:5:143'
      data_struct_input->stop_MA_event_right = true;
    }

    //  Stop: right IC
    if (((data_struct_input->state == 5) || (data_struct_input->state == 6) ||
         (data_struct_input->state == 1)) && (data_struct_input->AngRShank_filt
         [199] < data_struct_input->stop_IC_th_right)) {
      // '<S6>:5:147'
      // '<S6>:5:148'
      data_struct_input->stop_IC_event_right = true;
    }

    //  Stop: left IC
    if (((data_struct_input->state == 2) || (data_struct_input->state == 3) ||
         (data_struct_input->state == 4)) && (data_struct_input->AngLShank_filt
         [199] < data_struct_input->stop_IC_th_left)) {
      // '<S6>:5:152'
      // '<S6>:5:153'
      data_struct_input->stop_IC_event_left = true;
    }

    //     %% Real-time transitions
    //  This part uses the flag to choose the change in the state. It
    //  also sets to zero some flags after it changes the state.
    if ((data_struct_input->state == 2) && data_struct_input->MS_event_left) {
      // '<S6>:5:160'
      // && data_struct_input.MA_event_left==true)
      // '<S6>:5:161'
      data_struct_input->state = 3;

      // '<S6>:5:162'
      data_struct_input->MS_event_left = false;

      // '<S6>:5:163'
      data_struct_input->MA_event_left = false;

      // '<S6>:5:164'
      data_struct_input->IC_event_left = false;

      // '<S6>:5:166'
      data_struct_input->MS_buffer_left[data_struct_input->MS_buffer_index_left
        - 1] = (real32_T)timestamp;

      // '<S6>:5:167'
      i = (int32_T)(data_struct_input->MS_buffer_index_left + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->MS_buffer_index_left = (uint8_T)i;
      b_idx_0 = data_struct_input->MS_buffer_index_left;

      // '<S6>:5:168'
      if (data_struct_input->MS_buffer_index_left > 200) {
        // '<S6>:5:168'
        b_idx_0 = 200U;
      }

      data_struct_input->MS_buffer_index_left = b_idx_0;
    }

    if ((data_struct_input->state == 3) && data_struct_input->IC_event_left) {
      // '<S6>:5:171'
      // '<S6>:5:172'
      data_struct_input->state = 4;

      // '<S6>:5:173'
      data_struct_input->last_IC = 1U;

      // '<S6>:5:174'
      data_struct_input->IC_event_left = false;

      // '<S6>:5:175'
      data_struct_input->EC_event_right = false;

      // '<S6>:5:176'
      data_struct_input->AN_event_right = false;

      // '<S6>:5:177'
      data_struct_input->stop_Vel_event_right = false;

      // '<S6>:5:178'
      data_struct_input->stop_MA_event_right = false;

      // '<S6>:5:180'
      data_struct_input->IC_buffer_left[data_struct_input->IC_buffer_index_left
        - 1] = (real32_T)timestamp;

      // '<S6>:5:181'
      i = (int32_T)(data_struct_input->IC_buffer_index_left + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->IC_buffer_index_left = (uint8_T)i;
      b_idx_0 = data_struct_input->IC_buffer_index_left;

      // '<S6>:5:182'
      if (data_struct_input->IC_buffer_index_left > 200) {
        // '<S6>:5:182'
        b_idx_0 = 200U;
      }

      data_struct_input->IC_buffer_index_left = b_idx_0;
    }

    if ((data_struct_input->state == 4) && data_struct_input->EC_event_right &&
        data_struct_input->AN_event_right) {
      // '<S6>:5:185'
      // '<S6>:5:186'
      data_struct_input->state = 5;

      // '<S6>:5:187'
      data_struct_input->last_EC = 1U;

      // '<S6>:5:188'
      data_struct_input->EC_event_right = false;

      // '<S6>:5:189'
      data_struct_input->AN_event_right = false;

      // '<S6>:5:190'
      data_struct_input->MS_event_right = false;

      // '<S6>:5:191'
      data_struct_input->MA_event_right = false;

      //  Stop: DS
      if (data_struct_input->last_IC > 1) {
        // '<S6>:5:194'
        // '<S6>:5:195'
        found = data_struct_input->last_IC;
        qY = found - 1U;
        if (qY > (uint32_T)found) {
          qY = 0U;
        }

        data_struct_input->stop_DS[data_struct_input->stop_DS_index - 1] =
          (uint16_T)qY;

        // '<S6>:5:196'
        i = (int32_T)(data_struct_input->stop_DS_index + 1U);
        if ((uint32_T)i > 255U) {
          i = 255;
        }

        data_struct_input->stop_DS_index = (uint8_T)i;
        b_idx_0 = data_struct_input->stop_DS_index;

        // '<S6>:5:197'
        if (data_struct_input->stop_DS_index > 10) {
          // '<S6>:5:197'
          b_idx_0 = 1U;
        }

        data_struct_input->stop_DS_index = b_idx_0;
      }

      // '<S6>:5:199'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 10;
           EC_events_inds_left++) {
        exitg4 = (data_struct_input->stop_DS[EC_events_inds_left] < 10000);
        if (exitg4) {
          found++;
        }

        qc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 10;
           EC_events_inds_left++) {
        if (qc[EC_events_inds_left]) {
          tc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:199'
      data_struct_input_sizes_1f[0] = 1;
      data_struct_input_sizes_1f[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_1[i] = data_struct_input->stop_DS[tc_data[i] - 1];
      }

      b_index = rt_roundd_snf(testGaitSegm_mean(data_struct_input_data_1,
        data_struct_input_sizes_1f));
      if (b_index < 65536.0) {
        if (b_index >= 0.0) {
          data_struct_input->stop_DS_th = (uint16_T)b_index;
        } else {
          data_struct_input->stop_DS_th = 0U;
        }
      } else {
        data_struct_input->stop_DS_th = MAX_uint16_T;
      }

      // '<S6>:5:201'
      data_struct_input->EC_buffer_right
        [data_struct_input->EC_buffer_index_right - 1] = (real32_T)timestamp;

      // '<S6>:5:202'
      i = (int32_T)(data_struct_input->EC_buffer_index_right + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->EC_buffer_index_right = (uint8_T)i;
      b_idx_0 = data_struct_input->EC_buffer_index_right;

      // '<S6>:5:203'
      if (data_struct_input->EC_buffer_index_right > 200) {
        // '<S6>:5:203'
        b_idx_0 = 200U;
      }

      data_struct_input->EC_buffer_index_right = b_idx_0;
    }

    if ((data_struct_input->state == 5) && data_struct_input->MS_event_right) {
      // '<S6>:5:206'
      // && data_struct_input.MA_event_right==true)
      // '<S6>:5:207'
      data_struct_input->state = 6;

      // '<S6>:5:208'
      data_struct_input->MS_event_right = false;

      // '<S6>:5:209'
      data_struct_input->MA_event_right = false;

      // '<S6>:5:210'
      data_struct_input->IC_event_right = false;

      // '<S6>:5:212'
      data_struct_input->MS_buffer_right
        [data_struct_input->MS_buffer_index_right - 1] = (real32_T)timestamp;

      // '<S6>:5:213'
      i = (int32_T)(data_struct_input->MS_buffer_index_right + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->MS_buffer_index_right = (uint8_T)i;
      b_idx_0 = data_struct_input->MS_buffer_index_right;

      // '<S6>:5:214'
      if (data_struct_input->MS_buffer_index_right > 200) {
        // '<S6>:5:214'
        b_idx_0 = 200U;
      }

      data_struct_input->MS_buffer_index_right = b_idx_0;
    }

    if ((data_struct_input->state == 6) && data_struct_input->IC_event_right) {
      // '<S6>:5:217'
      // '<S6>:5:218'
      data_struct_input->state = 1;

      // '<S6>:5:219'
      data_struct_input->last_IC = 1U;

      // '<S6>:5:220'
      data_struct_input->IC_event_right = false;

      // '<S6>:5:221'
      data_struct_input->EC_event_left = false;

      // '<S6>:5:222'
      data_struct_input->AN_event_left = false;

      // '<S6>:5:223'
      data_struct_input->stop_Vel_event_left = false;

      // '<S6>:5:224'
      data_struct_input->stop_MA_event_left = false;

      // '<S6>:5:227'
      data_struct_input->IC_buffer_right
        [data_struct_input->IC_buffer_index_right - 1] = (real32_T)timestamp;

      // '<S6>:5:228'
      i = (int32_T)(data_struct_input->IC_buffer_index_right + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->IC_buffer_index_right = (uint8_T)i;
      b_idx_0 = data_struct_input->IC_buffer_index_right;

      // '<S6>:5:229'
      if (data_struct_input->IC_buffer_index_right > 200) {
        // '<S6>:5:229'
        b_idx_0 = 200U;
      }

      data_struct_input->IC_buffer_index_right = b_idx_0;
    }

    if ((data_struct_input->state == 1) && data_struct_input->EC_event_left &&
        data_struct_input->AN_event_left) {
      // '<S6>:5:232'
      // '<S6>:5:233'
      data_struct_input->state = 2;

      // '<S6>:5:234'
      data_struct_input->last_EC = 1U;

      // '<S6>:5:235'
      data_struct_input->EC_event_left = false;

      // '<S6>:5:236'
      data_struct_input->AN_event_left = false;

      // '<S6>:5:237'
      data_struct_input->MS_event_left = false;

      // '<S6>:5:238'
      data_struct_input->MA_event_left = false;

      //  Stop: DS
      if (data_struct_input->last_IC > 1) {
        // '<S6>:5:242'
        // '<S6>:5:243'
        found = data_struct_input->last_IC;
        qY = found - 1U;
        if (qY > (uint32_T)found) {
          qY = 0U;
        }

        data_struct_input->stop_DS[data_struct_input->stop_DS_index - 1] =
          (uint16_T)qY;

        // '<S6>:5:244'
        i = (int32_T)(data_struct_input->stop_DS_index + 1U);
        if ((uint32_T)i > 255U) {
          i = 255;
        }

        data_struct_input->stop_DS_index = (uint8_T)i;
        b_idx_0 = data_struct_input->stop_DS_index;

        // '<S6>:5:245'
        if (data_struct_input->stop_DS_index > 10) {
          // '<S6>:5:245'
          b_idx_0 = 1U;
        }

        data_struct_input->stop_DS_index = b_idx_0;
      }

      // '<S6>:5:247'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 10;
           EC_events_inds_left++) {
        exitg4 = (data_struct_input->stop_DS[EC_events_inds_left] < 10000);
        if (exitg4) {
          found++;
        }

        qc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 10;
           EC_events_inds_left++) {
        if (qc[EC_events_inds_left]) {
          tc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:247'
      data_struct_input_sizes_1e[0] = 1;
      data_struct_input_sizes_1e[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_1[i] = data_struct_input->stop_DS[tc_data[i] - 1];
      }

      b_index = rt_roundd_snf(testGaitSegm_mean(data_struct_input_data_1,
        data_struct_input_sizes_1e));
      if (b_index < 65536.0) {
        if (b_index >= 0.0) {
          data_struct_input->stop_DS_th = (uint16_T)b_index;
        } else {
          data_struct_input->stop_DS_th = 0U;
        }
      } else {
        data_struct_input->stop_DS_th = MAX_uint16_T;
      }

      // '<S6>:5:249'
      data_struct_input->EC_buffer_left[data_struct_input->EC_buffer_index_left
        - 1] = (real32_T)timestamp;

      // '<S6>:5:250'
      i = (int32_T)(data_struct_input->EC_buffer_index_left + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->EC_buffer_index_left = (uint8_T)i;
      b_idx_0 = data_struct_input->EC_buffer_index_left;

      // '<S6>:5:251'
      if (data_struct_input->EC_buffer_index_left > 200) {
        // '<S6>:5:251'
        b_idx_0 = 200U;
      }

      data_struct_input->EC_buffer_index_left = b_idx_0;
    }

    qY = 3U * data_struct_input->stop_DS_th;
    if (qY > 65535U) {
      qY = 65535U;
    }

    qY_0 = 3U * data_struct_input->stop_DS_th;
    if (qY_0 > 65535U) {
      qY_0 = 65535U;
    }

    tmp = 3U * data_struct_input->stop_DS_th;
    if (tmp > 65535U) {
      tmp = 65535U;
    }

    if ((((data_struct_input->state == 5) && (data_struct_input->counter_stop >
           (int32_T)qY)) || ((data_struct_input->state == 6) &&
          (data_struct_input->counter_stop > (int32_T)qY_0)) ||
         ((data_struct_input->state == 1) && (data_struct_input->counter_stop >
           (int32_T)tmp))) && (data_struct_input->state ==
         data_struct_input->prevstate) &&
        (!data_struct_input->stop_Vel_event_left) &&
        (!data_struct_input->stop_MA_event_left)) {
      // '<S6>:5:255'
      //  && data_struct_input.stop_IC_event_right==0)
      // '<S6>:5:256'
      data_struct_input->state = 0;

      //          disp('stop')
    }

    qY = 3U * data_struct_input->stop_DS_th;
    if (qY > 65535U) {
      qY = 65535U;
    }

    qY_0 = 3U * data_struct_input->stop_DS_th;
    if (qY_0 > 65535U) {
      qY_0 = 65535U;
    }

    tmp = 3U * data_struct_input->stop_DS_th;
    if (tmp > 65535U) {
      tmp = 65535U;
    }

    if ((((data_struct_input->state == 2) && (data_struct_input->counter_stop >
           (int32_T)qY)) || ((data_struct_input->state == 3) &&
          (data_struct_input->counter_stop > (int32_T)qY_0)) ||
         ((data_struct_input->state == 4) && (data_struct_input->counter_stop >
           (int32_T)tmp))) && (data_struct_input->state ==
         data_struct_input->prevstate) &&
        (!data_struct_input->stop_Vel_event_right) &&
        (!data_struct_input->stop_MA_event_right)) {
      // '<S6>:5:260'
      // && data_struct_input.stop_IC_event_left==0)
      // '<S6>:5:261'
      data_struct_input->state = 0;

      //          disp('stop')
    }

    qY = 6U * data_struct_input->stop_DS_th;
    if (qY > 65535U) {
      qY = 65535U;
    }

    if (data_struct_input->counter_stop > (int32_T)qY) {
      // '<S6>:5:265'
      // '<S6>:5:266'
      data_struct_input->state = 0;

      //          disp('stop')
    }

    if ((data_struct_input->state == 0) && ((real32_T)newVelRShank > 50.0F)) {
      // '<S6>:5:270'
      // '<S6>:5:271'
      data_struct_input->state = 5;

      // '<S6>:5:272'
      data_struct_input->MA_event_right = true;

      // '<S6>:5:274'
      data_struct_input->last_EC = 1U;

      // '<S6>:5:275'
      data_struct_input->EC_event_right = false;

      // '<S6>:5:276'
      data_struct_input->AN_event_right = false;

      // '<S6>:5:277'
      data_struct_input->MS_event_right = false;

      // '<S6>:5:279'
      data_struct_input->EC_buffer_right
        [data_struct_input->EC_buffer_index_right - 1] = (real32_T)timestamp;

      // '<S6>:5:280'
      i = (int32_T)(data_struct_input->EC_buffer_index_right + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->EC_buffer_index_right = (uint8_T)i;
      b_idx_0 = data_struct_input->EC_buffer_index_right;

      // '<S6>:5:281'
      if (data_struct_input->EC_buffer_index_right > 200) {
        // '<S6>:5:281'
        b_idx_0 = 200U;
      }

      data_struct_input->EC_buffer_index_right = b_idx_0;
    }

    if ((data_struct_input->state == 0) && (newVelLShank > 50.0F)) {
      // '<S6>:5:284'
      // '<S6>:5:285'
      data_struct_input->state = 2;

      // '<S6>:5:286'
      data_struct_input->MA_event_left = true;

      // '<S6>:5:288'
      data_struct_input->last_EC = 1U;

      // '<S6>:5:289'
      data_struct_input->EC_event_left = false;

      // '<S6>:5:290'
      data_struct_input->AN_event_left = false;

      // '<S6>:5:291'
      data_struct_input->MS_event_left = false;

      // '<S6>:5:294'
      data_struct_input->EC_buffer_left[data_struct_input->EC_buffer_index_left
        - 1] = (real32_T)timestamp;

      // '<S6>:5:295'
      i = (int32_T)(data_struct_input->EC_buffer_index_left + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->EC_buffer_index_left = (uint8_T)i;
      b_idx_0 = data_struct_input->EC_buffer_index_left;

      // '<S6>:5:296'
      if (data_struct_input->EC_buffer_index_left > 200) {
        // '<S6>:5:296'
        b_idx_0 = 200U;
      }

      data_struct_input->EC_buffer_index_left = b_idx_0;
    }

    //     %% Offline detection
    //  This part uses the LPF signal to detect the events, look for the
    //  corresponding events on the moving-average filtered signal and
    //  update the thresholds. It can also change the state to correct
    //  the state machine.
    //  The way the peaks are detected and thresholds are update, is the
    //  same than in the calibration.
    //  Left MA
    if ((data_struct_input->AngLShank_LPF[198] >
         data_struct_input->AngLShank_LPF[197]) &&
        (data_struct_input->AngLShank_LPF[198] >=
         data_struct_input->AngLShank_LPF[199]) &&
        (data_struct_input->AngLShank_LPF[198] >=
         data_struct_input->MA_LPF_th_left)) {
      // '<S6>:5:310'
      // '<S6>:5:311'
      data_struct_input->MA_LPF_maxs_left[data_struct_input->MA_LPF_index_left -
        1] = data_struct_input->AngLShank_LPF[198];

      // '<S6>:5:312'
      i = (int32_T)(data_struct_input->MA_LPF_index_left + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->MA_LPF_index_left = (uint8_T)i;
      b_idx_0 = data_struct_input->MA_LPF_index_left;

      // '<S6>:5:313'
      if (data_struct_input->MA_LPF_index_left > 5) {
        // '<S6>:5:313'
        b_idx_0 = 1U;
      }

      data_struct_input->MA_LPF_index_left = b_idx_0;

      // '<S6>:5:315'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->MA_LPF_maxs_left[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:315'
      data_struct_input_sizes_1c[0] = 1;
      data_struct_input_sizes_1c[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->
          MA_LPF_maxs_left[vc_data[i] - 1];
      }

      data_struct_input_sizes_1d[0] = 1;
      data_struct_input_sizes_1d[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->
          MA_LPF_maxs_left[vc_data[i] - 1];
      }

      data_struct_input->MA_LPF_th_left = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_1c) - 5.0F *
        testGaitSegm_std(data_struct_input_data_0, data_struct_input_sizes_1d);

      //  Finds MA in the moving-average filtered signal
      // '<S6>:5:318'
      found = 0;

      // '<S6>:5:319'
      b_index = 1.0;
      while ((found == 0) && ((int32_T)b_index < mtmp)) {
        // '<S6>:5:320'
        if ((data_struct_input->AngLShank_filt[199 - (int32_T)b_index] >
             data_struct_input->AngLShank_filt[200 - (int32_T)b_index]) &&
            (data_struct_input->AngLShank_filt[199 - (int32_T)b_index] >=
             data_struct_input->AngLShank_filt[198 - (int32_T)b_index])) {
          // '<S6>:5:321'
          // '<S6>:5:322'
          data_struct_input->MA_maxs_left[data_struct_input->MA_index_left - 1] =
            data_struct_input->AngLShank_filt[199 - (int32_T)b_index];

          // '<S6>:5:323'
          i = (int32_T)(data_struct_input->MA_index_left + 1U);
          if ((uint32_T)i > 255U) {
            i = 255;
          }

          data_struct_input->MA_index_left = (uint8_T)i;
          b_idx_0 = data_struct_input->MA_index_left;

          // '<S6>:5:324'
          if (data_struct_input->MA_index_left > 5) {
            // '<S6>:5:324'
            b_idx_0 = 1U;
          }

          data_struct_input->MA_index_left = b_idx_0;

          // '<S6>:5:325'
          found = 1;
        }

        // '<S6>:5:327'
        b_index++;
      }

      // '<S6>:5:330'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->MA_maxs_left[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:330'
      data_struct_input_sizes_1a[0] = 1;
      data_struct_input_sizes_1a[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->MA_maxs_left[vc_data[i] -
          1];
      }

      data_struct_input_sizes_1b[0] = 1;
      data_struct_input_sizes_1b[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->MA_maxs_left[vc_data[i]
          - 1];
      }

      data_struct_input->MA_th_left = testGaitSegm_mean_l(data_struct_input_data,
        data_struct_input_sizes_1a) - 5.0F * testGaitSegm_std
        (data_struct_input_data_0, data_struct_input_sizes_1b);

      //  flag_MA_left is raised when we have detected MA, and we can search the left MS 
      // '<S6>:5:333'
      data_struct_input->MA_flag_left = true;

      // '<S6>:5:334'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->MA_maxs_left[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:334'
      data_struct_input_sizes_19[0] = 1;
      data_struct_input_sizes_19[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->MA_maxs_left[vc_data[i] -
          1];
      }

      data_struct_input->stop_MA_th_left = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_19) / 3.0F;
    }

    //  Left MS
    if ((data_struct_input->AngLShank_LPF[198] >= 0.0F) &&
        (data_struct_input->AngLShank_LPF[199] <= 0.0F) &&
        data_struct_input->MA_flag_left) {
      // '<S6>:5:338'
      // '<S6>:5:339'
      data_struct_input->MA_flag_left = false;

      //  flag_MA_left is lowered
      // '<S6>:5:342'
      MS_inds_left = 0;

      //  Look for the event on the moving-average signal
      // '<S6>:5:344'
      b_index = 0.0;

      // '<S6>:5:345'
      found = 0;
      while (((int32_T)b_index < mtmp) && (found == 0)) {
        // '<S6>:5:346'
        if ((data_struct_input->AngLShank_filt[198 - (int32_T)b_index] >= 0.0F) &&
            (data_struct_input->AngLShank_filt[199 - (int32_T)b_index] < 0.0F))
        {
          // '<S6>:5:347'
          // '<S6>:5:348'
          MS_inds_left = (int32_T)b_index;

          // '<S6>:5:349'
          found = 1;
        }

        // '<S6>:5:351'
        b_index++;
      }

      //  Update Left EC and AN (same way than in calibration)
      // '<S6>:5:355'
      b_index = MS_inds_left;

      // '<S6>:5:356'
      found = 0;

      // '<S6>:5:357'
      EC_events_inds_left = 0;

      // '<S6>:5:358'
      EC_distance_left = -199;

      //  Finds EC event on moving-average filtered signal
      while (((int32_T)b_index < mtmp) && (found == 0)) {
        // '<S6>:5:361'
        if ((data_struct_input->VelLShank_filt[199 - (int32_T)b_index] <
             data_struct_input->VelLShank_filt[200 - (int32_T)b_index]) &&
            (data_struct_input->VelLShank_filt[199 - (int32_T)b_index] <
             data_struct_input->VelLShank_filt[198 - (int32_T)b_index]) &&
            (data_struct_input->VelLShank_filt[199 - (int32_T)b_index] < 0.0F))
        {
          // '<S6>:5:362'
          // '<S6>:5:363'
          data_struct_input->EC_events_mins_left
            [data_struct_input->EC_events_index_left - 1] =
            data_struct_input->VelLShank_filt[199 - (int32_T)b_index];

          // '<S6>:5:364'
          EC_events_inds_left = (int32_T)b_index;

          //  Index of the peaks and events (number of sample)
          // '<S6>:5:365'
          EC_distance_left = ((int32_T)b_index - MS_inds_left) - 199;

          //  Distance (number of samples) EC-MS
          // '<S6>:5:366'
          data_struct_input->AN_events_left
            [data_struct_input->EC_events_index_left - 1] =
            data_struct_input->AngLShank_filt[199 - (int32_T)b_index];

          // '<S6>:5:367'
          i = (int32_T)(data_struct_input->EC_events_index_left + 1U);
          if ((uint32_T)i > 255U) {
            i = 255;
          }

          data_struct_input->EC_events_index_left = (uint8_T)i;
          b_idx_0 = data_struct_input->EC_events_index_left;

          // '<S6>:5:368'
          if (data_struct_input->EC_events_index_left > 5) {
            // '<S6>:5:368'
            b_idx_0 = 1U;
          }

          data_struct_input->EC_events_index_left = b_idx_0;

          // '<S6>:5:369'
          found = 1;
        }

        // '<S6>:5:371'
        b_index++;
      }

      // '<S6>:5:373'
      // '<S6>:5:374'
      for (i = 0; i < 50; i++) {
        EC_peaks[i] = -2.0E+6;
        AN_peaks[i] = 2.0E+6;
      }

      // '<S6>:5:375'
      EC_peaks_index = 1.0;
      if (found == 1) {
        // '<S6>:5:376'
        // '<S6>:5:377'
        found = 0;

        //  Finds EC peak on moving-average filtered signal
        // '<S6>:5:379'
        MS_inds_left = ((EC_events_inds_left + EC_distance_left) -
                        EC_events_inds_left) + 198;

        // '<S6>:5:379'
        for (i = 0; i <= MS_inds_left; i++) {
          // '<S6>:5:379'
          b_index = (EC_events_inds_left + i) + 1;
          if ((data_struct_input->VelLShank_filt[199 - (int32_T)b_index] <
               data_struct_input->VelLShank_filt[200 - (int32_T)b_index]) &&
              (data_struct_input->VelLShank_filt[199 - (int32_T)b_index] <
               data_struct_input->VelLShank_filt[198 - (int32_T)b_index]) &&
              (data_struct_input->VelLShank_filt[199 - (int32_T)b_index] < 0.0F))
          {
            // '<S6>:5:380'
            // '<S6>:5:381'
            EC_peaks[(int32_T)EC_peaks_index - 1] =
              data_struct_input->VelLShank_filt[199 - (int32_T)b_index];

            // '<S6>:5:382'
            AN_peaks[(int32_T)EC_peaks_index - 1] =
              data_struct_input->AngLShank_filt[199 - (int32_T)b_index];

            // '<S6>:5:383'
            EC_peaks_index++;
            if (EC_peaks_index > 50.0) {
              // '<S6>:5:384'
              EC_peaks_index = 50.0;
            }

            // '<S6>:5:385'
            found = 1;
          }

          // '<S6>:5:379'
        }

        //  If it has not found any, it saves the element at EC-(MS-EC). If it is a positive value, it saves 0. 
        if (found == 0) {
          // '<S6>:5:389'
          // '<S6>:5:390'
          u = data_struct_input->VelLShank_filt[-(EC_events_inds_left +
            EC_distance_left)] + 1.0F;
          if (u < 0.0F) {
            u = -1.0F;
          } else if (u > 0.0F) {
            u = 1.0F;
          } else {
            if (u == 0.0F) {
              u = 0.0F;
            }
          }

          EC_peaks[(int32_T)EC_peaks_index - 1] =
            data_struct_input->VelLShank_filt[-(EC_events_inds_left +
            EC_distance_left)] * (-u / 2.0F);

          // '<S6>:5:391'
          AN_peaks[(int32_T)EC_peaks_index - 1] =
            data_struct_input->AngLShank_filt[-(EC_events_inds_left +
            EC_distance_left)];
        }
      }

      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 50;
           EC_events_inds_left++) {
        if (EC_peaks[EC_events_inds_left] > -1.0E+6) {
          // '<S6>:5:395'
          found++;
        }
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 50;
           EC_events_inds_left++) {
        if (EC_peaks[EC_events_inds_left] > -1.0E+6) {
          // '<S6>:5:395'
          wc_data[found] = (int8_T)(EC_events_inds_left + 1);
          found++;
        }
      }

      // '<S6>:5:395'
      for (i = 0; i < EC_distance_left; i++) {
        EC_peaks_data[i] = EC_peaks[wc_data[i] - 1];
      }

      data_struct_input->EC_peaks_mins_left
        [data_struct_input->EC_peaks_index_left - 1] = (real32_T)
        testGaitSegm_mean_lh(EC_peaks_data, EC_distance_left);

      // '<S6>:5:396'
      found = 1;
      b_index = AN_peaks[0];
      if (rtIsNaN(AN_peaks[0])) {
        EC_events_inds_left = 2;
        exitg4 = false;
        while ((!exitg4) && (EC_events_inds_left < 51)) {
          found = EC_events_inds_left;
          if (!rtIsNaN(AN_peaks[EC_events_inds_left - 1])) {
            b_index = AN_peaks[EC_events_inds_left - 1];
            exitg4 = true;
          } else {
            EC_events_inds_left++;
          }
        }
      }

      if (found < 50) {
        while (found + 1 < 51) {
          if (AN_peaks[found] < b_index) {
            b_index = AN_peaks[found];
          }

          found++;
        }
      }

      data_struct_input->AN_peaks_left[data_struct_input->EC_peaks_index_left -
        1] = (real32_T)b_index;

      // '<S6>:5:397'
      i = (int32_T)(data_struct_input->EC_peaks_index_left + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->EC_peaks_index_left = (uint8_T)i;
      b_idx_0 = data_struct_input->EC_peaks_index_left;

      // '<S6>:5:398'
      if (data_struct_input->EC_peaks_index_left > 5) {
        // '<S6>:5:398'
        b_idx_0 = 1U;
      }

      data_struct_input->EC_peaks_index_left = b_idx_0;

      // '<S6>:5:400'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->EC_events_mins_left[EC_events_inds_left] >
                  -1.0E+6F);
        sc[EC_events_inds_left] = (data_struct_input->
          EC_peaks_mins_left[EC_events_inds_left] > -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (sc[EC_events_inds_left]) {
          found++;
        }
      }

      MS_inds_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (sc[EC_events_inds_left]) {
          xc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:400'
      data_struct_input_sizes_17[0] = 1;
      data_struct_input_sizes_17[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->
          EC_events_mins_left[vc_data[i] - 1];
      }

      data_struct_input_sizes_18[0] = 1;
      data_struct_input_sizes_18[1] = MS_inds_left;
      for (i = 0; i < MS_inds_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->
          EC_peaks_mins_left[xc_data[i] - 1];
      }

      data_struct_input->EC_th_left = (testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_17) +
        testGaitSegm_mean_l(data_struct_input_data_0, data_struct_input_sizes_18))
        / 2.0F;

      // '<S6>:5:401'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->AN_events_left[EC_events_inds_left] >
                  -1.0E+6F);
        sc[EC_events_inds_left] = (data_struct_input->
          AN_peaks_left[EC_events_inds_left] > -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (sc[EC_events_inds_left]) {
          found++;
        }
      }

      MS_inds_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (sc[EC_events_inds_left]) {
          xc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:401'
      data_struct_input_sizes_15[0] = 1;
      data_struct_input_sizes_15[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->AN_events_left[vc_data[i]
          - 1];
      }

      data_struct_input_sizes_16[0] = 1;
      data_struct_input_sizes_16[1] = MS_inds_left;
      for (i = 0; i < MS_inds_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->AN_peaks_left[xc_data[i]
          - 1];
      }

      data_struct_input->AN_th_left = (testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_15) +
        testGaitSegm_mean_l(data_struct_input_data_0, data_struct_input_sizes_16))
        / 2.0F;

      //  Stop: EC
      // '<S6>:5:404'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->EC_events_mins_left[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:404'
      data_struct_input_sizes_14[0] = 1;
      data_struct_input_sizes_14[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->
          EC_events_mins_left[vc_data[i] - 1];
      }

      data_struct_input->stop_Vel_th_left = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_14) / 3.0F;
      if ((data_struct_input->state == 1) || (data_struct_input->state == 2)) {
        // '<S6>:5:407'
        //  If the left MS event has not been detected (states after left MS and left IC) 
        if ((int32_T)data_struct_input->IC_event_left > 0) {
          // '<S6>:5:408'
          //  If the left IC has been detected
          // '<S6>:5:409'
          data_struct_input->state = 4;

          // '<S6>:5:410'
          data_struct_input->IC_event_left = false;

          // '<S6>:5:411'
          data_struct_input->EC_event_right = false;

          // '<S6>:5:412'
          data_struct_input->AN_event_right = false;

          // '<S6>:5:413'
          data_struct_input->stop_Vel_event_right = false;

          // '<S6>:5:414'
          data_struct_input->stop_MA_event_right = false;

          // '<S6>:5:415'
          data_struct_input->stop_IC_event_left = false;

          // '<S6>:5:416'
          data_struct_input->last_IC = 1U;
        } else {
          //  If IC has not been detected yet.
          // '<S6>:5:418'
          data_struct_input->state = 3;

          // '<S6>:5:419'
          data_struct_input->MS_event_left = false;

          // '<S6>:5:420'
          data_struct_input->MA_event_left = false;

          // '<S6>:5:421'
          data_struct_input->IC_event_left = false;
        }
      }
    }

    //  Left IC
    if ((data_struct_input->AngLShank_LPF[198] <
         data_struct_input->AngLShank_LPF[197]) &&
        (data_struct_input->AngLShank_LPF[198] <=
         data_struct_input->AngLShank_LPF[199]) &&
        (data_struct_input->AngLShank_LPF[198] <=
         data_struct_input->IC_LPF_th_left)) {
      // '<S6>:5:427'
      // '<S6>:5:428'
      data_struct_input->IC_LPF_mins_left[data_struct_input->IC_LPF_index_left -
        1] = data_struct_input->AngLShank_LPF[198];

      // '<S6>:5:429'
      i = (int32_T)(data_struct_input->IC_LPF_index_left + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->IC_LPF_index_left = (uint8_T)i;
      b_idx_0 = data_struct_input->IC_LPF_index_left;

      // '<S6>:5:430'
      if (data_struct_input->IC_LPF_index_left > 5) {
        // '<S6>:5:430'
        b_idx_0 = 1U;
      }

      data_struct_input->IC_LPF_index_left = b_idx_0;

      // '<S6>:5:432'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->IC_LPF_mins_left[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:432'
      data_struct_input_sizes_12[0] = 1;
      data_struct_input_sizes_12[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->
          IC_LPF_mins_left[vc_data[i] - 1];
      }

      data_struct_input_sizes_13[0] = 1;
      data_struct_input_sizes_13[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->
          IC_LPF_mins_left[vc_data[i] - 1];
      }

      data_struct_input->IC_LPF_th_left = 5.0F * testGaitSegm_std
        (data_struct_input_data_0, data_struct_input_sizes_13) +
        testGaitSegm_mean_l(data_struct_input_data, data_struct_input_sizes_12);

      //  IC on moving-average filtered signal
      // '<S6>:5:435'
      found = 0;

      // '<S6>:5:436'
      b_index = 1.0;
      while ((found == 0) && ((int32_T)b_index < mtmp)) {
        // '<S6>:5:437'
        if ((data_struct_input->AngLShank_filt[199 - (int32_T)b_index] <
             data_struct_input->AngLShank_filt[200 - (int32_T)b_index]) &&
            (data_struct_input->AngLShank_filt[199 - (int32_T)b_index] <=
             data_struct_input->AngLShank_filt[198 - (int32_T)b_index])) {
          // '<S6>:5:438'
          // '<S6>:5:439'
          data_struct_input->IC_mins_left[data_struct_input->IC_index_left - 1] =
            data_struct_input->AngLShank_filt[199 - (int32_T)b_index];

          // '<S6>:5:440'
          i = (int32_T)(data_struct_input->IC_index_left + 1U);
          if ((uint32_T)i > 255U) {
            i = 255;
          }

          data_struct_input->IC_index_left = (uint8_T)i;
          b_idx_0 = data_struct_input->IC_index_left;

          // '<S6>:5:441'
          if (data_struct_input->IC_index_left > 5) {
            // '<S6>:5:441'
            b_idx_0 = 1U;
          }

          data_struct_input->IC_index_left = b_idx_0;

          // '<S6>:5:442'
          found = 1;
        }

        // '<S6>:5:444'
        b_index++;
      }

      //          disp (['IC left, time ' num2str(time(end))])
      // '<S6>:5:448'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->IC_mins_left[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:448'
      data_struct_input_sizes_10[0] = 1;
      data_struct_input_sizes_10[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->IC_mins_left[vc_data[i] -
          1];
      }

      data_struct_input_sizes_11[0] = 1;
      data_struct_input_sizes_11[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->IC_mins_left[vc_data[i]
          - 1];
      }

      data_struct_input->IC_th_left = 5.0F * testGaitSegm_std
        (data_struct_input_data_0, data_struct_input_sizes_11) +
        testGaitSegm_mean_l(data_struct_input_data, data_struct_input_sizes_10);

      // '<S6>:5:449'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->IC_mins_left[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:449'
      data_struct_input_sizes_z[0] = 1;
      data_struct_input_sizes_z[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->IC_mins_left[vc_data[i] -
          1];
      }

      data_struct_input->stop_IC_th_left = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_z) / 3.0F;
      if ((data_struct_input->state == 3) || (data_struct_input->state == 2)) {
        // '<S6>:5:451'
        //  If left IC has not been detected (states after left IC and after right EC) 
        if ((int32_T)data_struct_input->EC_event_right > 0) {
          // '<S6>:5:452'
          //  If right EC has been detected
          // '<S6>:5:453'
          data_struct_input->state = 5;

          // '<S6>:5:454'
          data_struct_input->EC_event_right = false;

          // '<S6>:5:455'
          data_struct_input->AN_event_right = false;

          // '<S6>:5:456'
          data_struct_input->last_EC = 1U;

          // '<S6>:5:457'
          data_struct_input->MS_event_right = false;

          // '<S6>:5:458'
          data_struct_input->MA_event_right = false;
        } else {
          // '<S6>:5:460'
          data_struct_input->state = 4;

          // '<S6>:5:461'
          data_struct_input->IC_event_left = false;

          // '<S6>:5:462'
          data_struct_input->EC_event_right = false;

          // '<S6>:5:463'
          data_struct_input->AN_event_right = false;

          // '<S6>:5:464'
          data_struct_input->stop_Vel_event_right = false;

          // '<S6>:5:465'
          data_struct_input->stop_MA_event_right = false;

          // '<S6>:5:466'
          data_struct_input->stop_IC_event_left = false;

          // '<S6>:5:467'
          data_struct_input->last_IC = 1U;
        }
      }
    }

    //  Right MA
    if ((data_struct_input->AngRShank_LPF[198] >
         data_struct_input->AngRShank_LPF[197]) &&
        (data_struct_input->AngRShank_LPF[198] >=
         data_struct_input->AngRShank_LPF[199]) &&
        (data_struct_input->AngRShank_LPF[198] >=
         data_struct_input->MA_LPF_th_right)) {
      // '<S6>:5:473'
      // '<S6>:5:474'
      data_struct_input->MA_LPF_maxs_right[data_struct_input->MA_LPF_index_right
        - 1] = data_struct_input->AngRShank_LPF[198];

      // '<S6>:5:475'
      i = (int32_T)(data_struct_input->MA_LPF_index_right + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->MA_LPF_index_right = (uint8_T)i;
      b_idx_0 = data_struct_input->MA_LPF_index_right;

      // '<S6>:5:476'
      if (data_struct_input->MA_LPF_index_right > 5) {
        // '<S6>:5:476'
        b_idx_0 = 1U;
      }

      data_struct_input->MA_LPF_index_right = b_idx_0;

      // '<S6>:5:478'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->MA_LPF_maxs_right[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:478'
      data_struct_input_sizes_x[0] = 1;
      data_struct_input_sizes_x[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->
          MA_LPF_maxs_right[vc_data[i] - 1];
      }

      data_struct_input_sizes_y[0] = 1;
      data_struct_input_sizes_y[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->
          MA_LPF_maxs_right[vc_data[i] - 1];
      }

      data_struct_input->MA_LPF_th_right = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_x) - 5.0F *
        testGaitSegm_std(data_struct_input_data_0, data_struct_input_sizes_y);

      //  Finds MA in the moving-average filtered signal
      // '<S6>:5:481'
      found = 0;

      // '<S6>:5:482'
      b_index = 1.0;
      while ((found == 0) && ((int32_T)b_index < mtmp)) {
        // '<S6>:5:483'
        if ((data_struct_input->AngRShank_filt[199 - (int32_T)b_index] >
             data_struct_input->AngRShank_filt[200 - (int32_T)b_index]) &&
            (data_struct_input->AngRShank_filt[199 - (int32_T)b_index] >=
             data_struct_input->AngRShank_filt[198 - (int32_T)b_index])) {
          // '<S6>:5:484'
          // '<S6>:5:485'
          data_struct_input->MA_maxs_right[data_struct_input->MA_index_right - 1]
            = data_struct_input->AngRShank_filt[199 - (int32_T)b_index];

          // '<S6>:5:486'
          i = (int32_T)(data_struct_input->MA_index_right + 1U);
          if ((uint32_T)i > 255U) {
            i = 255;
          }

          data_struct_input->MA_index_right = (uint8_T)i;
          b_idx_0 = data_struct_input->MA_index_right;

          // '<S6>:5:487'
          if (data_struct_input->MA_index_right > 5) {
            // '<S6>:5:487'
            b_idx_0 = 1U;
          }

          data_struct_input->MA_index_right = b_idx_0;

          // '<S6>:5:488'
          found = 1;
        }

        // '<S6>:5:490'
        b_index++;
      }

      // '<S6>:5:493'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->MA_maxs_right[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:493'
      data_struct_input_sizes_v[0] = 1;
      data_struct_input_sizes_v[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->MA_maxs_right[vc_data[i]
          - 1];
      }

      data_struct_input_sizes_w[0] = 1;
      data_struct_input_sizes_w[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->MA_maxs_right[vc_data[i]
          - 1];
      }

      data_struct_input->MA_th_right = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_v) - 5.0F *
        testGaitSegm_std(data_struct_input_data_0, data_struct_input_sizes_w);

      //  flag_MA_right is raised when we have detected MA, and we can search the right MS 
      // '<S6>:5:496'
      data_struct_input->MA_flag_right = true;

      // '<S6>:5:497'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->MA_maxs_right[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:497'
      data_struct_input_sizes_u[0] = 1;
      data_struct_input_sizes_u[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->MA_maxs_right[vc_data[i]
          - 1];
      }

      data_struct_input->stop_MA_th_right = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_u) / 3.0F;
    }

    //  Right MS
    if ((data_struct_input->AngRShank_LPF[198] >= 0.0F) &&
        (data_struct_input->AngRShank_LPF[199] <= 0.0F) &&
        data_struct_input->MA_flag_right) {
      // '<S6>:5:501'
      // '<S6>:5:502'
      data_struct_input->MA_flag_right = false;

      //  flag_MA_left is lowered
      // '<S6>:5:505'
      MS_inds_left = 0;

      //  Look for the event on the moving-average signal
      // '<S6>:5:507'
      b_index = 0.0;

      // '<S6>:5:508'
      found = 0;
      while (((int32_T)b_index < mtmp) && (found == 0)) {
        // '<S6>:5:509'
        if ((data_struct_input->AngRShank_filt[198 - (int32_T)b_index] >= 0.0F) &&
            (data_struct_input->AngRShank_filt[199 - (int32_T)b_index] < 0.0F))
        {
          // '<S6>:5:510'
          // '<S6>:5:511'
          MS_inds_left = (int32_T)b_index;

          // '<S6>:5:512'
          found = 1;
        }

        // '<S6>:5:514'
        b_index++;
      }

      //  Update Right EC and AN (same way than in calibration)
      // '<S6>:5:518'
      b_index = MS_inds_left;

      // '<S6>:5:519'
      found = 0;

      // '<S6>:5:520'
      EC_events_inds_left = 0;

      // '<S6>:5:521'
      EC_distance_left = -199;

      //  Finds EC event on moving-average filtered signal
      while (((int32_T)b_index < mtmp) && (found == 0)) {
        // '<S6>:5:524'
        if ((data_struct_input->VelRShank_filt[199 - (int32_T)b_index] <
             data_struct_input->VelRShank_filt[200 - (int32_T)b_index]) &&
            (data_struct_input->VelRShank_filt[199 - (int32_T)b_index] <
             data_struct_input->VelRShank_filt[198 - (int32_T)b_index]) &&
            (data_struct_input->VelRShank_filt[199 - (int32_T)b_index] < 0.0F))
        {
          // '<S6>:5:525'
          // '<S6>:5:526'
          data_struct_input->EC_events_mins_right
            [data_struct_input->EC_events_index_right - 1] =
            data_struct_input->VelRShank_filt[199 - (int32_T)b_index];

          // '<S6>:5:527'
          EC_events_inds_left = (int32_T)b_index;

          //  Index of the peaks and events (number of sample)
          // '<S6>:5:528'
          EC_distance_left = ((int32_T)b_index - MS_inds_left) - 199;

          //  Distance (number of samples) EC-MS
          // '<S6>:5:529'
          data_struct_input->AN_events_right
            [data_struct_input->EC_events_index_right - 1] =
            data_struct_input->AngRShank_filt[199 - (int32_T)b_index];

          // '<S6>:5:530'
          i = (int32_T)(data_struct_input->EC_events_index_right + 1U);
          if ((uint32_T)i > 255U) {
            i = 255;
          }

          data_struct_input->EC_events_index_right = (uint8_T)i;
          b_idx_0 = data_struct_input->EC_events_index_right;

          // '<S6>:5:531'
          if (data_struct_input->EC_events_index_right > 5) {
            // '<S6>:5:531'
            b_idx_0 = 1U;
          }

          data_struct_input->EC_events_index_right = b_idx_0;

          // '<S6>:5:532'
          found = 1;
        }

        // '<S6>:5:534'
        b_index++;
      }

      // '<S6>:5:536'
      // '<S6>:5:537'
      for (i = 0; i < 50; i++) {
        EC_peaks[i] = -2.0E+6;
        AN_peaks[i] = 2.0E+6;
      }

      // '<S6>:5:538'
      EC_peaks_index = 1.0;
      if (found == 1) {
        // '<S6>:5:539'
        // '<S6>:5:540'
        found = 0;

        //  Finds EC peak on moving-average filtered signal
        // '<S6>:5:542'
        MS_inds_left = ((EC_events_inds_left + EC_distance_left) -
                        EC_events_inds_left) + 198;

        // '<S6>:5:542'
        for (i = 0; i <= MS_inds_left; i++) {
          // '<S6>:5:542'
          b_index = (EC_events_inds_left + i) + 1;
          if ((data_struct_input->VelRShank_filt[199 - (int32_T)b_index] <
               data_struct_input->VelRShank_filt[200 - (int32_T)b_index]) &&
              (data_struct_input->VelRShank_filt[199 - (int32_T)b_index] <
               data_struct_input->VelRShank_filt[198 - (int32_T)b_index]) &&
              (data_struct_input->VelRShank_filt[199 - (int32_T)b_index] < 0.0F))
          {
            // '<S6>:5:543'
            // '<S6>:5:544'
            EC_peaks[(int32_T)EC_peaks_index - 1] =
              data_struct_input->VelRShank_filt[199 - (int32_T)b_index];

            // '<S6>:5:545'
            AN_peaks[(int32_T)EC_peaks_index - 1] =
              data_struct_input->AngRShank_filt[199 - (int32_T)b_index];

            // '<S6>:5:546'
            EC_peaks_index++;
            if (EC_peaks_index > 50.0) {
              // '<S6>:5:547'
              EC_peaks_index = 50.0;
            }

            // '<S6>:5:548'
            found = 1;
          }

          // '<S6>:5:542'
        }

        //  If it has not found any, it saves the element at EC-(MS-EC). If it is a positive value, it saves 0. 
        if (found == 0) {
          // '<S6>:5:552'
          // '<S6>:5:553'
          u = data_struct_input->VelRShank_filt[-(EC_events_inds_left +
            EC_distance_left)] + 1.0F;
          if (u < 0.0F) {
            u = -1.0F;
          } else if (u > 0.0F) {
            u = 1.0F;
          } else {
            if (u == 0.0F) {
              u = 0.0F;
            }
          }

          EC_peaks[(int32_T)EC_peaks_index - 1] =
            data_struct_input->VelRShank_filt[-(EC_events_inds_left +
            EC_distance_left)] * (-u / 2.0F);

          // '<S6>:5:554'
          AN_peaks[(int32_T)EC_peaks_index - 1] =
            data_struct_input->AngRShank_filt[-(EC_events_inds_left +
            EC_distance_left)];
        }
      }

      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 50;
           EC_events_inds_left++) {
        if (EC_peaks[EC_events_inds_left] > -1.0E+6) {
          // '<S6>:5:558'
          found++;
        }
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 50;
           EC_events_inds_left++) {
        if (EC_peaks[EC_events_inds_left] > -1.0E+6) {
          // '<S6>:5:558'
          wc_data[found] = (int8_T)(EC_events_inds_left + 1);
          found++;
        }
      }

      // '<S6>:5:558'
      for (i = 0; i < EC_distance_left; i++) {
        EC_peaks_data[i] = EC_peaks[wc_data[i] - 1];
      }

      data_struct_input->EC_peaks_mins_right
        [data_struct_input->EC_peaks_index_right - 1] = (real32_T)
        testGaitSegm_mean_lh(EC_peaks_data, EC_distance_left);

      // '<S6>:5:559'
      found = 1;
      b_index = AN_peaks[0];
      if (rtIsNaN(AN_peaks[0])) {
        EC_events_inds_left = 2;
        exitg4 = false;
        while ((!exitg4) && (EC_events_inds_left < 51)) {
          found = EC_events_inds_left;
          if (!rtIsNaN(AN_peaks[EC_events_inds_left - 1])) {
            b_index = AN_peaks[EC_events_inds_left - 1];
            exitg4 = true;
          } else {
            EC_events_inds_left++;
          }
        }
      }

      if (found < 50) {
        while (found + 1 < 51) {
          if (AN_peaks[found] < b_index) {
            b_index = AN_peaks[found];
          }

          found++;
        }
      }

      data_struct_input->AN_peaks_right[data_struct_input->EC_peaks_index_right
        - 1] = (real32_T)b_index;

      // '<S6>:5:560'
      i = (int32_T)(data_struct_input->EC_peaks_index_right + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->EC_peaks_index_right = (uint8_T)i;
      b_idx_0 = data_struct_input->EC_peaks_index_right;

      // '<S6>:5:561'
      if (data_struct_input->EC_peaks_index_right > 5) {
        // '<S6>:5:561'
        b_idx_0 = 1U;
      }

      data_struct_input->EC_peaks_index_right = b_idx_0;

      // '<S6>:5:563'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->EC_events_mins_right[EC_events_inds_left] >
                  -1.0E+6F);
        sc[EC_events_inds_left] = (data_struct_input->
          EC_peaks_mins_right[EC_events_inds_left] > -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (sc[EC_events_inds_left]) {
          found++;
        }
      }

      MS_inds_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (sc[EC_events_inds_left]) {
          xc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:563'
      data_struct_input_sizes_s[0] = 1;
      data_struct_input_sizes_s[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->
          EC_events_mins_right[vc_data[i] - 1];
      }

      data_struct_input_sizes_t[0] = 1;
      data_struct_input_sizes_t[1] = MS_inds_left;
      for (i = 0; i < MS_inds_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->
          EC_peaks_mins_right[xc_data[i] - 1];
      }

      data_struct_input->EC_th_right = (testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_s) +
        testGaitSegm_mean_l(data_struct_input_data_0, data_struct_input_sizes_t))
        / 2.0F;

      // '<S6>:5:564'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->AN_events_right[EC_events_inds_left] >
                  -1.0E+6F);
        sc[EC_events_inds_left] = (data_struct_input->
          AN_peaks_right[EC_events_inds_left] > -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (sc[EC_events_inds_left]) {
          found++;
        }
      }

      MS_inds_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (sc[EC_events_inds_left]) {
          xc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:564'
      data_struct_input_sizes_q[0] = 1;
      data_struct_input_sizes_q[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->AN_events_right[vc_data[i]
          - 1];
      }

      data_struct_input_sizes_r[0] = 1;
      data_struct_input_sizes_r[1] = MS_inds_left;
      for (i = 0; i < MS_inds_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->
          AN_peaks_right[xc_data[i] - 1];
      }

      data_struct_input->AN_th_right = (testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_q) +
        testGaitSegm_mean_l(data_struct_input_data_0, data_struct_input_sizes_r))
        / 2.0F;

      //  Stop: EC
      // '<S6>:5:567'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->EC_events_mins_right[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:567'
      data_struct_input_sizes_p[0] = 1;
      data_struct_input_sizes_p[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->
          EC_events_mins_right[vc_data[i] - 1];
      }

      data_struct_input->stop_Vel_th_right = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_p) / 3.0F;
      if ((data_struct_input->state == 4) || (data_struct_input->state == 5)) {
        // '<S6>:5:570'
        //  If the left MS event has not been detected (states after left MS and left IC) 
        if ((int32_T)data_struct_input->IC_event_right > 0) {
          // '<S6>:5:571'
          //  If the left IC has been detected
          // '<S6>:5:572'
          data_struct_input->state = 1;

          // '<S6>:5:573'
          data_struct_input->IC_event_right = false;

          // '<S6>:5:574'
          data_struct_input->EC_event_left = false;

          // '<S6>:5:575'
          data_struct_input->AN_event_left = false;

          // '<S6>:5:576'
          data_struct_input->stop_Vel_event_left = false;

          // '<S6>:5:577'
          data_struct_input->stop_MA_event_left = false;

          // '<S6>:5:578'
          data_struct_input->stop_IC_event_right = false;

          // '<S6>:5:579'
          data_struct_input->last_EC = 1U;

          // '<S6>:5:580'
          data_struct_input->MS_event_left = false;

          // '<S6>:5:581'
          data_struct_input->MA_event_left = false;
        } else {
          //  If IC has not been detected yet.
          // '<S6>:5:583'
          data_struct_input->state = 6;

          // '<S6>:5:584'
          data_struct_input->MS_event_right = false;

          // '<S6>:5:585'
          data_struct_input->MA_event_right = false;

          // '<S6>:5:586'
          data_struct_input->last_IC = 1U;
        }
      }
    }

    //  Right IC
    if ((data_struct_input->AngRShank_LPF[198] <
         data_struct_input->AngRShank_LPF[197]) &&
        (data_struct_input->AngRShank_LPF[198] <=
         data_struct_input->AngRShank_LPF[199]) &&
        (data_struct_input->AngRShank_LPF[198] <=
         data_struct_input->IC_LPF_th_right)) {
      // '<S6>:5:592'
      // '<S6>:5:593'
      data_struct_input->IC_LPF_mins_right[data_struct_input->IC_LPF_index_right
        - 1] = data_struct_input->AngRShank_LPF[198];

      // '<S6>:5:594'
      i = (int32_T)(data_struct_input->IC_LPF_index_right + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->IC_LPF_index_right = (uint8_T)i;
      b_idx_0 = data_struct_input->IC_LPF_index_right;

      // '<S6>:5:595'
      if (data_struct_input->IC_LPF_index_right > 5) {
        // '<S6>:5:595'
        b_idx_0 = 1U;
      }

      data_struct_input->IC_LPF_index_right = b_idx_0;

      // '<S6>:5:597'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->IC_LPF_mins_right[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:597'
      data_struct_input_sizes_n[0] = 1;
      data_struct_input_sizes_n[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->
          IC_LPF_mins_right[vc_data[i] - 1];
      }

      data_struct_input_sizes_o[0] = 1;
      data_struct_input_sizes_o[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->
          IC_LPF_mins_right[vc_data[i] - 1];
      }

      data_struct_input->IC_LPF_th_right = 5.0F * testGaitSegm_std
        (data_struct_input_data_0, data_struct_input_sizes_o) +
        testGaitSegm_mean_l(data_struct_input_data, data_struct_input_sizes_n);

      //  IC on moving-average filtered signal
      // '<S6>:5:600'
      found = 0;

      // '<S6>:5:601'
      b_index = 1.0;
      while ((found == 0) && ((int32_T)b_index < mtmp)) {
        // '<S6>:5:602'
        if ((data_struct_input->AngRShank_filt[199 - (int32_T)b_index] <
             data_struct_input->AngRShank_filt[200 - (int32_T)b_index]) &&
            (data_struct_input->AngRShank_filt[199 - (int32_T)b_index] <=
             data_struct_input->AngRShank_filt[198 - (int32_T)b_index])) {
          // '<S6>:5:603'
          // '<S6>:5:604'
          data_struct_input->IC_mins_right[data_struct_input->IC_index_right - 1]
            = data_struct_input->AngRShank_filt[199 - (int32_T)b_index];

          // '<S6>:5:605'
          i = (int32_T)(data_struct_input->IC_index_right + 1U);
          if ((uint32_T)i > 255U) {
            i = 255;
          }

          data_struct_input->IC_index_right = (uint8_T)i;
          b_idx_0 = data_struct_input->IC_index_right;

          // '<S6>:5:606'
          if (data_struct_input->IC_index_right > 5) {
            // '<S6>:5:606'
            b_idx_0 = 1U;
          }

          data_struct_input->IC_index_right = b_idx_0;

          // '<S6>:5:607'
          found = 1;
        }

        // '<S6>:5:609'
        b_index++;
      }

      //          disp (['IC right, time ' num2str(time(end))])
      // '<S6>:5:612'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->IC_mins_right[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:612'
      data_struct_input_sizes_l[0] = 1;
      data_struct_input_sizes_l[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->IC_mins_right[vc_data[i]
          - 1];
      }

      data_struct_input_sizes_m[0] = 1;
      data_struct_input_sizes_m[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data_0[i] = data_struct_input->IC_mins_right[vc_data[i]
          - 1];
      }

      data_struct_input->IC_th_right = 5.0F * testGaitSegm_std
        (data_struct_input_data_0, data_struct_input_sizes_m) +
        testGaitSegm_mean_l(data_struct_input_data, data_struct_input_sizes_l);

      // '<S6>:5:613'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        exitg4 = (data_struct_input->IC_mins_right[EC_events_inds_left] >
                  -1.0E+6F);
        if (exitg4) {
          found++;
        }

        rc[EC_events_inds_left] = exitg4;
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (rc[EC_events_inds_left]) {
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:613'
      data_struct_input_sizes_k[0] = 1;
      data_struct_input_sizes_k[1] = EC_distance_left;
      for (i = 0; i < EC_distance_left; i++) {
        data_struct_input_data[i] = data_struct_input->IC_mins_right[vc_data[i]
          - 1];
      }

      data_struct_input->stop_IC_th_right = testGaitSegm_mean_l
        (data_struct_input_data, data_struct_input_sizes_k) / 3.0F;
      if ((data_struct_input->state == 5) || (data_struct_input->state == 6)) {
        // '<S6>:5:615'
        //  If right IC has not been detected (states after right IC and after left EC) 
        if ((int32_T)data_struct_input->EC_event_left > 0) {
          // '<S6>:5:616'
          //  If right EC has been detected
          // '<S6>:5:617'
          data_struct_input->state = 2;

          // '<S6>:5:618'
          data_struct_input->EC_event_left = false;

          // '<S6>:5:619'
          data_struct_input->AN_event_left = false;
        } else {
          // '<S6>:5:621'
          data_struct_input->state = 1;

          // '<S6>:5:622'
          data_struct_input->IC_event_right = false;

          // '<S6>:5:623'
          data_struct_input->EC_event_left = false;

          // '<S6>:5:624'
          data_struct_input->AN_event_left = false;

          // '<S6>:5:625'
          data_struct_input->stop_Vel_event_left = false;

          // '<S6>:5:626'
          data_struct_input->stop_MA_event_left = false;

          // '<S6>:5:627'
          data_struct_input->stop_IC_event_right = false;
        }
      }
    }

    if (data_struct_input->prevstate != data_struct_input->state) {
      // '<S6>:5:632'
      // '<S6>:5:633'
      data_struct_input->counter_stop = 0U;

      // '<S6>:5:634'
      data_struct_input->stop_Vel_event_left = false;

      // '<S6>:5:635'
      data_struct_input->stop_MA_event_right = false;

      // '<S6>:5:636'
      data_struct_input->stop_Vel_event_right = false;

      // '<S6>:5:637'
      data_struct_input->stop_MA_event_left = false;
    } else {
      // '<S6>:5:639'
      qY = data_struct_input->counter_stop + 1U;
      if (qY > 65535U) {
        qY = 65535U;
      }

      data_struct_input->counter_stop = (uint16_T)qY;
    }
  }

  // % Start procedure for calibration
  if (data_struct_input->flag_calib && (data_struct_input->calibrating == 0)) {
    // '<S6>:5:644'
    // '<S6>:5:645'
    data_struct_input->calibrating = 1;

    // '<S6>:5:646'
    data_struct_input->counter_stop = 0U;
  }

  if ((data_struct_input->calibrating == 1) || (data_struct_input->calibrating ==
       2) || (data_struct_input->calibrating == 3)) {
    // '<S6>:5:648'
    //  We only consider the signals after the gait has started, i.e., one of
    //  the angular velocities rised above 50 degrees/s.
    if ((data_struct_input->calibrating == 1) && (((real32_T)newVelRShank >=
          50.0F) || (newVelLShank >= 50.0F))) {
      // '<S6>:5:651'
      // '<S6>:5:652'
      data_struct_input->index_start_calib = 0U;

      // '<S6>:5:653'
      data_struct_input->calibrating = 2;

      // '<S6>:5:654'
      data_struct_input->counter = 0U;

      //  Initial leg is right
      // '<S6>:5:655'
      data_struct_input->initial_leg = true;
      if (newVelLShank >= 50.0F) {
        // '<S6>:5:656'
        //  If initial leg is left
        // '<S6>:5:657'
        data_struct_input->initial_leg = false;
      }

      // '<S6>:5:659'
      data_struct_input->state = -1;
    }

    //  2-Hz LP-filtered signals
    // '<S6>:5:663'
    // '<S6>:5:664'
    for (i = 0; i < 199; i++) {
      data_struct_input->AngRShank_LPF2Hz[i] =
        data_struct_input->AngRShank_LPF2Hz[1 + i];
      data_struct_input->AngLShank_LPF2Hz[i] =
        data_struct_input->AngLShank_LPF2Hz[1 + i];
    }

    data_struct_input->AngRShank_LPF2Hz[199] = (((((((((0.00224619219F *
      newAngRShank + 0.0119676683F * data_struct_input->AngRShank[198]) +
      0.0342848971F * data_struct_input->AngRShank[197]) + 0.067212306F *
      data_struct_input->AngRShank[196]) + 0.0982885659F *
      data_struct_input->AngRShank[195]) + 0.111179359F *
      data_struct_input->AngRShank[194]) + 0.0982885659F *
      data_struct_input->AngRShank[193]) + 0.067212306F *
      data_struct_input->AngRShank[192]) + 0.0342848971F *
      data_struct_input->AngRShank[191]) + 0.0119676683F *
      data_struct_input->AngRShank[190]) + 0.00224619219F *
      data_struct_input->AngRShank[189];

    // '<S6>:5:667'
    // '<S6>:5:668'
    data_struct_input->AngLShank_LPF2Hz[199] = (((((((((0.00224619219F *
      newAngLShank + 0.0119676683F * data_struct_input->AngLShank[198]) +
      0.0342848971F * data_struct_input->AngLShank[197]) + 0.067212306F *
      data_struct_input->AngLShank[196]) + 0.0982885659F *
      data_struct_input->AngLShank[195]) + 0.111179359F *
      data_struct_input->AngLShank[194]) + 0.0982885659F *
      data_struct_input->AngLShank[193]) + 0.067212306F *
      data_struct_input->AngLShank[192]) + 0.0342848971F *
      data_struct_input->AngLShank[191]) + 0.0119676683F *
      data_struct_input->AngLShank[190]) + 0.00224619219F *
      data_struct_input->AngLShank[189];

    // '<S6>:5:672'
    qY = data_struct_input->index_start_calib + 1U;
    if (qY > 65535U) {
      qY = 65535U;
    }

    data_struct_input->index_start_calib = (uint16_T)qY;

    //  Counts 1 zero-crosses of the 2-Hz filtered Angle of the shank.
    //  It will fix the range of the signals to perform the calibration (from
    //  the 1st zero-cross to the 4th).
    if ((data_struct_input->calibrating == 2) && data_struct_input->initial_leg &&
        (data_struct_input->AngLShank_LPF2Hz[198] > 0.0F) &&
        (data_struct_input->AngLShank_LPF2Hz[199] < 0.0F)) {
      // '<S6>:5:677'
      if (data_struct_input->counter == 0) {
        // '<S6>:5:678'
        // '<S6>:5:679'
        b_index = 1.0;

        // '<S6>:5:680'
        found = 0;
        while ((b_index < 200.0) && (found == 0)) {
          // '<S6>:5:681'
          if ((data_struct_input->AngLShank_LPF2Hz[199 - (int32_T)b_index] >
               data_struct_input->AngLShank_LPF2Hz[198 - (int32_T)b_index]) &&
              (data_struct_input->AngLShank_LPF2Hz[199 - (int32_T)b_index] >
               data_struct_input->AngLShank_LPF2Hz[200 - (int32_T)b_index])) {
            // '<S6>:5:682'
            // '<S6>:5:683'
            found = 1;

            // '<S6>:5:684'
            data_struct_input->index_start_calib = (uint16_T)((int32_T)b_index +
              10);
          }

          // '<S6>:5:686'
          b_index++;
        }

        if (found == 0) {
          // '<S6>:5:688'
          //  If we did not found the MA that precedes the zero-cross, we wait a bit after the last zero-cross, to include the IC event 
          // '<S6>:5:689'
          data_struct_input->index_start_calib = 0U;

          // '<S6>:5:690'
          data_struct_input->index_stop_calib = 1U;
        }
      }

      // '<S6>:5:693'
      i = (int32_T)(data_struct_input->counter + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->counter = (uint8_T)i;
    }

    if ((data_struct_input->calibrating == 2) &&
        (!data_struct_input->initial_leg) &&
        (data_struct_input->AngRShank_LPF2Hz[198] > 0.0F) &&
        (data_struct_input->AngRShank_LPF2Hz[199] < 0.0F)) {
      // '<S6>:5:695'
      if (data_struct_input->counter == 0) {
        // '<S6>:5:696'
        // '<S6>:5:697'
        b_index = 1.0;

        // '<S6>:5:698'
        found = 0;
        while ((b_index < 200.0) && (found == 0)) {
          // '<S6>:5:699'
          if ((data_struct_input->AngRShank_LPF2Hz[199 - (int32_T)b_index] >
               data_struct_input->AngRShank_LPF2Hz[198 - (int32_T)b_index]) &&
              (data_struct_input->AngRShank_LPF2Hz[199 - (int32_T)b_index] >
               data_struct_input->AngRShank_LPF2Hz[200 - (int32_T)b_index])) {
            // '<S6>:5:700'
            // '<S6>:5:701'
            found = 1;

            // '<S6>:5:702'
            data_struct_input->index_start_calib = (uint16_T)((int32_T)b_index +
              10);
          }

          // '<S6>:5:704'
          b_index++;
        }

        if (found == 0) {
          // '<S6>:5:706'
          //  If we did not found the MA that precedes the zero-cross, we wait a bit after the last zero-cross, to include the IC event 
          // '<S6>:5:707'
          data_struct_input->index_start_calib = 0U;

          // '<S6>:5:708'
          data_struct_input->index_stop_calib = 1U;
        }
      }

      // '<S6>:5:711'
      i = (int32_T)(data_struct_input->counter + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->counter = (uint8_T)i;
    }

    if ((data_struct_input->calibrating == 2) && (data_struct_input->counter >=
         3)) {
      // '<S6>:5:713'
      // '<S6>:5:714'
      data_struct_input->calibrating = 3;
      if (data_struct_input->index_stop_calib == 1) {
        // '<S6>:5:715'
        //  If we did not found the MA that precedes the zero-cross, we wait a bit after the last zero-cross, to include the IC event 
        // '<S6>:5:716'
        qY = (uint32_T)(uint16_T)(int32_T)rt_roundd_snf((real_T)
          data_struct_input->index_start_calib / 4.0) +
          data_struct_input->index_start_calib;
        if (qY > 65535U) {
          qY = 65535U;
        }

        data_struct_input->index_stop_calib = (uint16_T)qY;
      }

      mtmp = data_struct_input->index_stop_calib;

      // '<S6>:5:718'
      if (data_struct_input->index_stop_calib > 200) {
        // '<S6>:5:718'
        mtmp = 200U;
      }

      data_struct_input->index_stop_calib = mtmp;
    }

    if ((data_struct_input->calibrating == 3) &&
        (data_struct_input->index_start_calib >=
         data_struct_input->index_stop_calib)) {
      // '<S6>:5:721'
      // '<S6>:5:722'
      data_struct_input->calibrating = 4;
    }

    //  If the subject stops walking, then the calibration is suspended and
    //  we go back to rest (state 0)
    if (((real32_T)newVelRShank <= 20.0F) && (newVelLShank < 20.0F)) {
      // '<S6>:5:727'
      // '<S6>:5:728'
      qY = data_struct_input->counter_stop + 1U;
      if (qY > 65535U) {
        qY = 65535U;
      }

      data_struct_input->counter_stop = (uint16_T)qY;
    } else {
      // '<S6>:5:730'
      data_struct_input->counter_stop = 0U;
    }

    if (data_struct_input->counter_stop > 100) {
      // '<S6>:5:733'
      // '<S6>:5:734'
      data_struct_input->index_start_calib = 0U;

      // '<S6>:5:735'
      data_struct_input->calibrating = 0;

      // '<S6>:5:736'
      data_struct_input->counter = 0U;

      // '<S6>:5:737'
      data_struct_input->state = 0;
    }
  }

  // % Calibration
  if (data_struct_input->calibrating == 4) {
    // '<S6>:5:742'
    mtmp = data_struct_input->index_start_calib;

    // '<S6>:5:744'
    if (data_struct_input->index_start_calib >= 200) {
      // '<S6>:5:744'
      mtmp = 199U;
    }

    data_struct_input->index_start_calib = mtmp;

    // '<S6>:5:746'
    // '<S6>:5:747'
    EC_peaks_index = 1.0;

    // '<S6>:5:748'
    // '<S6>:5:749'
    MS_inds_index_left = 1.0;

    // '<S6>:5:750'
    // '<S6>:5:751'
    // '<S6>:5:754'
    // '<S6>:5:755'
    // '<S6>:5:756'
    // '<S6>:5:757'
    // '<S6>:5:758'
    // '<S6>:5:759'
    for (i = 0; i < 5; i++) {
      b_MS_inds_right[i] = 0.0;
      b_MS_inds_left[i] = 0.0;
      b_EC_distance_right[i] = 0.0;
      b_EC_distance_left[i] = 0.0;
      b_EC_events_inds_right[i] = 0.0;
      b_EC_events_inds_left[i] = 0.0;
      IC_LPF_inds_right[i] = 0.0;
      IC_LPF_inds_left[i] = 0.0;
      IC_inds_right[i] = 0U;
      IC_inds_left[i] = 0U;
    }

    //     %% MS calibration as zero-cross of the angle, after MA (maximum angle) 
    // '<S6>:5:762'
    qY = 200U - mtmp;
    if (qY > 200U) {
      qY = 0U;
    }

    for (mtmp = (uint16_T)((int32_T)qY + 1); mtmp < 200; mtmp++) {
      // '<S6>:5:762'
      //  Finds MA on the LPF signal (positive maxima). Right leg
      if ((data_struct_input->AngRShank_LPF[mtmp - 1] >
           data_struct_input->AngRShank_LPF[mtmp - 2]) &&
          (data_struct_input->AngRShank_LPF[mtmp - 1] >
           data_struct_input->AngRShank_LPF[mtmp]) &&
          (data_struct_input->AngRShank_LPF[mtmp - 1] > 0.0F)) {
        // '<S6>:5:764'
        // '<S6>:5:765'
        data_struct_input->MA_LPF_maxs_right
          [data_struct_input->MA_LPF_index_right - 1] =
          data_struct_input->AngRShank_LPF[mtmp - 1];

        // '<S6>:5:766'
        i = (int32_T)(data_struct_input->MA_LPF_index_right + 1U);
        if ((uint32_T)i > 255U) {
          i = 255;
        }

        data_struct_input->MA_LPF_index_right = (uint8_T)i;
        b_idx_0 = data_struct_input->MA_LPF_index_right;

        // '<S6>:5:767'
        if (data_struct_input->MA_LPF_index_right > 5) {
          // '<S6>:5:767'
          b_idx_0 = 5U;
        }

        data_struct_input->MA_LPF_index_right = b_idx_0;

        // '<S6>:5:769'
        c_index = mtmp;

        // '<S6>:5:770'
        found = 0;

        //  Finds the corresponding MA on the moving-average filtered signal. Right leg 
        do {
          exitg8 = 0;
          qY = 200U - data_struct_input->index_start_calib;
          if (qY > 200U) {
            qY = 0U;
          }

          if ((found == 0) && (c_index > (int32_T)qY + 1)) {
            // '<S6>:5:772'
            if ((data_struct_input->AngRShank_filt[c_index - 1] >
                 data_struct_input->AngRShank_filt[c_index - 2]) &&
                (data_struct_input->AngRShank_filt[c_index - 1] >
                 data_struct_input->AngRShank_filt[c_index])) {
              // '<S6>:5:773'
              // '<S6>:5:774'
              data_struct_input->MA_maxs_right[data_struct_input->MA_index_right
                - 1] = data_struct_input->AngRShank_filt[c_index - 1];

              // '<S6>:5:775'
              found = 1;

              // '<S6>:5:776'
              i = (int32_T)(data_struct_input->MA_index_right + 1U);
              if ((uint32_T)i > 255U) {
                i = 255;
              }

              data_struct_input->MA_index_right = (uint8_T)i;
              b_idx_0 = data_struct_input->MA_index_right;

              // '<S6>:5:777'
              if (data_struct_input->MA_index_right > 5) {
                // '<S6>:5:777'
                b_idx_0 = 5U;
              }

              data_struct_input->MA_index_right = b_idx_0;
            }

            // '<S6>:5:779'
            c_index--;
          } else {
            exitg8 = 1;
          }
        } while (exitg8 == 0);

        //  Finds the position of the MS after the MA that was just found. Right leg 
        // '<S6>:5:783'
        c_index++;

        // '<S6>:5:784'
        found = 0;
        while ((found == 0) && (c_index < 199)) {
          // '<S6>:5:785'
          if ((data_struct_input->AngRShank_filt[c_index - 2] >= 0.0F) &&
              (data_struct_input->AngRShank_filt[c_index - 1] <= 0.0F)) {
            // '<S6>:5:786'
            // '<S6>:5:787'
            b_MS_inds_right[(int32_T)EC_peaks_index - 1] = c_index;

            // '<S6>:5:788'
            found = 1;

            // '<S6>:5:789'
            EC_peaks_index++;
            if (EC_peaks_index > 5.0) {
              // '<S6>:5:790'
              EC_peaks_index = 5.0;
            }
          }

          // '<S6>:5:792'
          c_index++;
        }
      }

      //  Finds MA on the LPF signal (positive maximums). Left Leg
      if ((data_struct_input->AngLShank_LPF[mtmp - 1] >
           data_struct_input->AngLShank_LPF[mtmp - 2]) &&
          (data_struct_input->AngLShank_LPF[mtmp - 1] >
           data_struct_input->AngLShank_LPF[mtmp]) &&
          (data_struct_input->AngLShank_LPF[mtmp - 1] > 0.0F)) {
        // '<S6>:5:797'
        // '<S6>:5:798'
        data_struct_input->MA_LPF_maxs_left[data_struct_input->MA_LPF_index_left
          - 1] = data_struct_input->AngLShank_LPF[mtmp - 1];

        // '<S6>:5:799'
        i = (int32_T)(data_struct_input->MA_LPF_index_left + 1U);
        if ((uint32_T)i > 255U) {
          i = 255;
        }

        data_struct_input->MA_LPF_index_left = (uint8_T)i;
        b_idx_0 = data_struct_input->MA_LPF_index_left;

        // '<S6>:5:800'
        if (data_struct_input->MA_LPF_index_left > 5) {
          // '<S6>:5:800'
          b_idx_0 = 5U;
        }

        data_struct_input->MA_LPF_index_left = b_idx_0;

        // '<S6>:5:802'
        c_index = mtmp;

        // '<S6>:5:803'
        found = 0;

        //  Finds the corresponding MA on the moving-average filtered signal. Left leg. 
        do {
          exitg7 = 0;
          qY = 200U - data_struct_input->index_start_calib;
          if (qY > 200U) {
            qY = 0U;
          }

          if ((found == 0) && (c_index > (int32_T)qY + 1)) {
            // '<S6>:5:805'
            if ((data_struct_input->AngLShank_filt[c_index - 1] >
                 data_struct_input->AngLShank_filt[c_index - 2]) &&
                (data_struct_input->AngLShank_filt[c_index - 1] >
                 data_struct_input->AngLShank_filt[c_index])) {
              // '<S6>:5:806'
              // '<S6>:5:807'
              data_struct_input->MA_maxs_left[data_struct_input->MA_index_left -
                1] = data_struct_input->AngLShank_filt[c_index - 1];

              // '<S6>:5:808'
              found = 1;

              // '<S6>:5:809'
              i = (int32_T)(data_struct_input->MA_index_left + 1U);
              if ((uint32_T)i > 255U) {
                i = 255;
              }

              data_struct_input->MA_index_left = (uint8_T)i;
              b_idx_0 = data_struct_input->MA_index_left;

              // '<S6>:5:810'
              if (data_struct_input->MA_index_left > 5) {
                // '<S6>:5:810'
                b_idx_0 = 5U;
              }

              data_struct_input->MA_index_left = b_idx_0;
            }

            // '<S6>:5:812'
            c_index--;
          } else {
            exitg7 = 1;
          }
        } while (exitg7 == 0);

        //  Finds the position of the MS after the MA that was just found. Left leg 
        // '<S6>:5:816'
        c_index++;

        // '<S6>:5:817'
        found = 0;
        while ((found == 0) && (c_index < 199)) {
          // '<S6>:5:818'
          if ((data_struct_input->AngLShank_filt[c_index - 2] >= 0.0F) &&
              (data_struct_input->AngLShank_filt[c_index - 1] <= 0.0F)) {
            // '<S6>:5:819'
            // '<S6>:5:820'
            b_MS_inds_left[(int32_T)MS_inds_index_left - 1] = c_index;

            // '<S6>:5:821'
            found = 1;

            // '<S6>:5:822'
            MS_inds_index_left++;
            if (MS_inds_index_left > 5.0) {
              // '<S6>:5:823'
              MS_inds_index_left = 5.0;
            }
          }

          // '<S6>:5:825'
          c_index++;
        }
      }
    }

    //  MA thresholds, for the LPF signal and the moving average-filtered signal. 
    // '<S6>:5:830'
    data_struct_input->MA_LPF_th_left = 0.0F;

    // '<S6>:5:831'
    data_struct_input->MA_LPF_th_right = 0.0F;

    // '<S6>:5:832'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->MA_maxs_left[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:832'
    data_struct_input_sizes_j[0] = 1;
    data_struct_input_sizes_j[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->MA_maxs_left[vc_data[i] - 1];
    }

    data_struct_input->MA_th_left = testGaitSegm_mean_l(data_struct_input_data,
      data_struct_input_sizes_j) - 20.0F;

    // '<S6>:5:833'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->MA_maxs_right[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:833'
    data_struct_input_sizes_i[0] = 1;
    data_struct_input_sizes_i[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->MA_maxs_right[vc_data[i] -
        1];
    }

    data_struct_input->MA_th_right = testGaitSegm_mean_l(data_struct_input_data,
      data_struct_input_sizes_i) - 20.0F;

    //     %% IC calibration: minimum of the angle
    //  It starts searching the minimum of the angle after the MS events
    // '<S6>:5:837'
    for (EC_events_inds_left = 0; EC_events_inds_left < (int32_T)(EC_peaks_index
          - 1.0); EC_events_inds_left++) {
      // '<S6>:5:837'
      // '<S6>:5:838'
      found = 0;

      // '<S6>:5:839'
      b_index = b_MS_inds_right[EC_events_inds_left];

      //  Finds minimum of the right LPF Angle
      while ((found == 0) && (b_index < 199.0)) {
        // '<S6>:5:841'
        if ((data_struct_input->AngRShank_LPF[(int32_T)b_index - 1] <
             data_struct_input->AngRShank_LPF[(int32_T)(b_index + 1.0) - 1]) &&
            (data_struct_input->AngRShank_LPF[(int32_T)b_index - 1] <
             data_struct_input->AngRShank_LPF[(int32_T)(b_index - 1.0) - 1])) {
          // '<S6>:5:842'
          // '<S6>:5:843'
          data_struct_input->IC_LPF_mins_right
            [data_struct_input->IC_LPF_index_right - 1] =
            data_struct_input->AngRShank_LPF[(int32_T)b_index - 1];

          // '<S6>:5:844'
          IC_LPF_inds_right[data_struct_input->IC_LPF_index_right - 1] = b_index;

          // '<S6>:5:845'
          i = (int32_T)(data_struct_input->IC_LPF_index_right + 1U);
          if ((uint32_T)i > 255U) {
            i = 255;
          }

          data_struct_input->IC_LPF_index_right = (uint8_T)i;
          b_idx_0 = data_struct_input->IC_LPF_index_right;

          // '<S6>:5:846'
          if (data_struct_input->IC_LPF_index_right > 5) {
            // '<S6>:5:846'
            b_idx_0 = 5U;
          }

          data_struct_input->IC_LPF_index_right = b_idx_0;

          // '<S6>:5:847'
          found = 1;
        }

        // '<S6>:5:849'
        b_index++;
      }

      // '<S6>:5:837'
    }

    //  It starts searching the minimum of the angle after the MS events
    // '<S6>:5:855'
    for (EC_events_inds_left = 0; EC_events_inds_left < (int32_T)
         (MS_inds_index_left - 1.0); EC_events_inds_left++) {
      // '<S6>:5:855'
      // '<S6>:5:856'
      found = 0;

      // '<S6>:5:857'
      b_index = b_MS_inds_left[EC_events_inds_left];

      //  Finds minimum of the left LPF Angle
      while ((found == 0) && (b_index < 199.0)) {
        // '<S6>:5:859'
        if ((data_struct_input->AngLShank_LPF[(int32_T)b_index - 1] <
             data_struct_input->AngLShank_LPF[(int32_T)(b_index + 1.0) - 1]) &&
            (data_struct_input->AngLShank_LPF[(int32_T)b_index - 1] <
             data_struct_input->AngLShank_LPF[(int32_T)(b_index - 1.0) - 1])) {
          // '<S6>:5:860'
          // '<S6>:5:861'
          data_struct_input->IC_LPF_mins_left
            [data_struct_input->IC_LPF_index_left - 1] =
            data_struct_input->AngLShank_LPF[(int32_T)b_index - 1];

          // '<S6>:5:862'
          IC_LPF_inds_left[data_struct_input->IC_LPF_index_left - 1] = b_index;

          // '<S6>:5:863'
          i = (int32_T)(data_struct_input->IC_LPF_index_left + 1U);
          if ((uint32_T)i > 255U) {
            i = 255;
          }

          data_struct_input->IC_LPF_index_left = (uint8_T)i;
          b_idx_0 = data_struct_input->IC_LPF_index_left;

          // '<S6>:5:864'
          if (data_struct_input->IC_LPF_index_left > 5) {
            // '<S6>:5:864'
            b_idx_0 = 5U;
          }

          data_struct_input->IC_LPF_index_left = b_idx_0;

          // '<S6>:5:865'
          found = 1;
        }

        // '<S6>:5:867'
        b_index++;
      }

      // '<S6>:5:855'
    }

    //  Using the IC detected in the LPF signal, it looks for the IC in the
    //  moving-average filtered signal, on the right and left leg.
    // '<S6>:5:873'
    found = data_struct_input->IC_LPF_index_right;
    qY = found - 1U;
    if (qY > (uint32_T)found) {
      qY = 0U;
    }

    // '<S6>:5:873'
    for (b_idx_0 = 1U; b_idx_0 <= (uint8_T)qY; b_idx_0++) {
      // '<S6>:5:873'
      // '<S6>:5:874'
      found = 0;

      // '<S6>:5:875'
      b_index = IC_LPF_inds_right[b_idx_0 - 1];
      do {
        exitg6 = 0;
        qY_0 = 200U - data_struct_input->index_start_calib;
        if (qY_0 > 200U) {
          qY_0 = 0U;
        }

        if ((found == 0) && (b_index > (real_T)(int32_T)qY_0 + 1.0)) {
          // '<S6>:5:876'
          if ((data_struct_input->AngRShank_filt[(int32_T)b_index - 1] <
               data_struct_input->AngRShank_filt[(int32_T)b_index]) &&
              (data_struct_input->AngRShank_filt[(int32_T)b_index - 1] <
               data_struct_input->AngRShank_filt[(int32_T)b_index - 2])) {
            // '<S6>:5:877'
            // '<S6>:5:878'
            data_struct_input->IC_mins_right[data_struct_input->IC_index_right -
              1] = data_struct_input->AngRShank_filt[(int32_T)b_index - 1];

            // '<S6>:5:879'
            IC_inds_right[data_struct_input->IC_index_right - 1] = (uint8_T)
              b_index;

            // '<S6>:5:880'
            i = (int32_T)(data_struct_input->IC_index_right + 1U);
            if ((uint32_T)i > 255U) {
              i = 255;
            }

            data_struct_input->IC_index_right = (uint8_T)i;
            cc_idx_0 = data_struct_input->IC_index_right;

            // '<S6>:5:881'
            if (data_struct_input->IC_index_right > 5) {
              // '<S6>:5:881'
              cc_idx_0 = 5U;
            }

            data_struct_input->IC_index_right = cc_idx_0;

            // '<S6>:5:882'
            found = 1;
          }

          // '<S6>:5:884'
          b_index--;
        } else {
          exitg6 = 1;
        }
      } while (exitg6 == 0);

      if (found == 0) {
        // '<S6>:5:886'
        // '<S6>:5:887'
        data_struct_input->IC_LPF_mins_right[b_idx_0 - 1] = -2.0E+6F;
      }
    }

    // '<S6>:5:890'
    found = data_struct_input->IC_LPF_index_left;
    qY = found - 1U;
    if (qY > (uint32_T)found) {
      qY = 0U;
    }

    // '<S6>:5:890'
    for (b_idx_0 = 1U; b_idx_0 <= (uint8_T)qY; b_idx_0++) {
      // '<S6>:5:890'
      // '<S6>:5:891'
      found = 0;

      // '<S6>:5:892'
      b_index = IC_LPF_inds_left[b_idx_0 - 1];
      do {
        exitg5 = 0;
        qY_0 = 200U - data_struct_input->index_start_calib;
        if (qY_0 > 200U) {
          qY_0 = 0U;
        }

        if ((found == 0) && (b_index > (real_T)(int32_T)qY_0 + 1.0)) {
          // '<S6>:5:893'
          if ((data_struct_input->AngLShank_filt[(int32_T)b_index - 1] <
               data_struct_input->AngLShank_filt[(int32_T)b_index]) &&
              (data_struct_input->AngLShank_filt[(int32_T)b_index - 1] <
               data_struct_input->AngLShank_filt[(int32_T)b_index - 2])) {
            // '<S6>:5:894'
            // '<S6>:5:895'
            data_struct_input->IC_mins_left[data_struct_input->IC_index_left - 1]
              = data_struct_input->AngLShank_filt[(int32_T)b_index - 1];

            // '<S6>:5:896'
            IC_inds_left[data_struct_input->IC_index_left - 1] = (uint8_T)
              b_index;

            // '<S6>:5:897'
            i = (int32_T)(data_struct_input->IC_index_left + 1U);
            if ((uint32_T)i > 255U) {
              i = 255;
            }

            data_struct_input->IC_index_left = (uint8_T)i;
            cc_idx_0 = data_struct_input->IC_index_left;

            // '<S6>:5:898'
            if (data_struct_input->IC_index_left > 5) {
              // '<S6>:5:898'
              cc_idx_0 = 5U;
            }

            data_struct_input->IC_index_left = cc_idx_0;

            // '<S6>:5:899'
            found = 1;
          }

          // '<S6>:5:901'
          b_index--;
        } else {
          exitg5 = 1;
        }
      } while (exitg5 == 0);

      if (found == 0) {
        // '<S6>:5:903'
        // '<S6>:5:904'
        data_struct_input->IC_LPF_mins_left[b_idx_0 - 1] = -2.0E+6F;
      }
    }

    // '<S6>:5:908'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->IC_LPF_mins_left[EC_events_inds_left] >
                -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:908'
    data_struct_input_sizes_h[0] = 1;
    data_struct_input_sizes_h[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->IC_LPF_mins_left[vc_data[i]
        - 1];
    }

    data_struct_input->IC_LPF_th_left = testGaitSegm_mean_l
      (data_struct_input_data, data_struct_input_sizes_h) + 10.0F;

    // '<S6>:5:909'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->IC_LPF_mins_right[EC_events_inds_left] >
                -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:909'
    data_struct_input_sizes_g[0] = 1;
    data_struct_input_sizes_g[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->IC_LPF_mins_right[vc_data[i]
        - 1];
    }

    data_struct_input->IC_LPF_th_right = testGaitSegm_mean_l
      (data_struct_input_data, data_struct_input_sizes_g) + 10.0F;

    // '<S6>:5:910'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->IC_mins_left[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:910'
    data_struct_input_sizes_f[0] = 1;
    data_struct_input_sizes_f[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->IC_mins_left[vc_data[i] - 1];
    }

    data_struct_input->IC_th_left = testGaitSegm_mean_l(data_struct_input_data,
      data_struct_input_sizes_f) + 10.0F;

    // '<S6>:5:911'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->IC_mins_right[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:911'
    data_struct_input_sizes_e[0] = 1;
    data_struct_input_sizes_e[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->IC_mins_right[vc_data[i] -
        1];
    }

    data_struct_input->IC_th_right = testGaitSegm_mean_l(data_struct_input_data,
      data_struct_input_sizes_e) + 10.0F;

    //     %% EC calibration & AN calibration
    //  Starting from the MS event, it goes back in the angular velocity to
    //  find the first negative minimum of the LPF signal. That minimum is
    //  the EC event, and it is also found on the moving-average filtered
    //  signal.
    //  It obtains the distance between events EC-MS, and then it looks for
    //  other minimums on the left of EC that are inside the range
    //  EC-(MS-EC). This are other peaks (EC peaks) that could be misdetected
    //  as EC events.
    //  Then, the EC threshold is obtained as the mean between the maximum of
    //  the EC events found on the 3 steps, and the minimum of the EC peaks.
    //  AN is an angular threshold that helps detecting EC. The AN vector is
    //  created with the values of the angle that correspond to the EC event
    //  and peaks.
    //  The threshold is the mean of the minimum angle of the EC events and
    //  the maximum angle of the EC peaks.
    // '<S6>:5:931'
    for (EC_events_inds_left = 0; EC_events_inds_left < (int32_T)(EC_peaks_index
          - 1.0); EC_events_inds_left++) {
      // '<S6>:5:931'
      // '<S6>:5:932'
      found = 0;

      // '<S6>:5:933'
      b_index = b_MS_inds_right[EC_events_inds_left];

      //  Find the EC event on the right LPF angular velocity (minimum)
      do {
        exitg3 = 0;
        qY = 200U - data_struct_input->index_start_calib;
        if (qY > 200U) {
          qY = 0U;
        }

        if ((found == 0) && (b_index > (real_T)(int32_T)qY + 1.0)) {
          // '<S6>:5:935'
          if ((data_struct_input->VelRShank_LPF[(int32_T)b_index - 1] <
               data_struct_input->VelRShank_LPF[(int32_T)(b_index + 1.0) - 1]) &&
              (data_struct_input->VelRShank_LPF[(int32_T)b_index - 1] <
               data_struct_input->VelRShank_LPF[(int32_T)(b_index - 1.0) - 1]) &&
              (data_struct_input->VelRShank_LPF[(int32_T)b_index - 1] < 0.0F)) {
            // '<S6>:5:936'
            //  Find the EC event on the right moving-average filtered angular velocity 
            do {
              exitg41 = 0;
              qY = 200U - data_struct_input->index_start_calib;
              if (qY > 200U) {
                qY = 0U;
              }

              if ((found == 0) && (b_index > (real_T)(int32_T)qY + 1.0)) {
                // '<S6>:5:938'
                if ((data_struct_input->VelRShank_filt[(int32_T)b_index - 1] <
                     data_struct_input->VelRShank_filt[(int32_T)(b_index + 1.0)
                     - 1]) && (data_struct_input->VelRShank_filt[(int32_T)
                               b_index - 1] < data_struct_input->VelRShank_filt
                               [(int32_T)(b_index - 1.0) - 1]) &&
                    (data_struct_input->VelRShank_filt[(int32_T)b_index - 1] <
                     0.0F)) {
                  // '<S6>:5:939'
                  // '<S6>:5:940'
                  data_struct_input->EC_events_mins_right
                    [data_struct_input->EC_events_index_right - 1] =
                    data_struct_input->VelRShank_filt[(int32_T)b_index - 1];

                  //  Amplitude of the EC peaks and events
                  // '<S6>:5:941'
                  b_EC_events_inds_right
                    [data_struct_input->EC_events_index_right - 1] = b_index;

                  //  Index of the peaks and events (number of sample)
                  // '<S6>:5:942'
                  b_EC_distance_right[data_struct_input->EC_events_index_right -
                    1] = b_MS_inds_right[EC_events_inds_left] - b_index;

                  //  Distance (number of samples) MS-EC
                  // '<S6>:5:943'
                  data_struct_input->AN_events_right
                    [data_struct_input->EC_events_index_right - 1] =
                    data_struct_input->AngRShank_filt[(int32_T)b_index - 1];

                  // '<S6>:5:944'
                  i = (int32_T)(data_struct_input->EC_events_index_right + 1U);
                  if ((uint32_T)i > 255U) {
                    i = 255;
                  }

                  data_struct_input->EC_events_index_right = (uint8_T)i;
                  b_idx_0 = data_struct_input->EC_events_index_right;

                  // '<S6>:5:945'
                  if (data_struct_input->EC_events_index_right > 5) {
                    // '<S6>:5:945'
                    b_idx_0 = 5U;
                  }

                  data_struct_input->EC_events_index_right = b_idx_0;

                  // '<S6>:5:946'
                  found = 1;
                }

                // '<S6>:5:948'
                b_index--;
              } else {
                exitg41 = 1;
              }
            } while (exitg41 == 0);
          }

          // '<S6>:5:951'
          b_index--;
        } else {
          exitg3 = 1;
        }
      } while (exitg3 == 0);

      // '<S6>:5:931'
    }

    // '<S6>:5:955'
    for (EC_events_inds_left = 0; EC_events_inds_left < (int32_T)
         (MS_inds_index_left - 1.0); EC_events_inds_left++) {
      // '<S6>:5:955'
      // '<S6>:5:956'
      found = 0;

      // '<S6>:5:957'
      b_index = b_MS_inds_left[EC_events_inds_left];

      //  Find the EC event on the left LPF angular velocity (minimum)
      do {
        exitg1 = 0;
        qY = 200U - data_struct_input->index_start_calib;
        if (qY > 200U) {
          qY = 0U;
        }

        if ((found == 0) && (b_index > (real_T)(int32_T)qY + 1.0)) {
          // '<S6>:5:959'
          if ((data_struct_input->VelLShank_LPF[(int32_T)b_index - 1] <
               data_struct_input->VelLShank_LPF[(int32_T)(b_index + 1.0) - 1]) &&
              (data_struct_input->VelLShank_LPF[(int32_T)b_index - 1] <
               data_struct_input->VelLShank_LPF[(int32_T)(b_index - 1.0) - 1]) &&
              (data_struct_input->VelLShank_LPF[(int32_T)b_index - 1] < 0.0F)) {
            // '<S6>:5:960'
            //  Find the EC event on the right moving-average filtered angular velocity 
            do {
              exitg2 = 0;
              qY = 200U - data_struct_input->index_start_calib;
              if (qY > 200U) {
                qY = 0U;
              }

              if ((found == 0) && (b_index > (real_T)(int32_T)qY + 1.0)) {
                // '<S6>:5:962'
                if ((data_struct_input->VelLShank_filt[(int32_T)b_index - 1] <
                     data_struct_input->VelLShank_filt[(int32_T)(b_index + 1.0)
                     - 1]) && (data_struct_input->VelLShank_filt[(int32_T)
                               b_index - 1] < data_struct_input->VelLShank_filt
                               [(int32_T)(b_index - 1.0) - 1]) &&
                    (data_struct_input->VelLShank_filt[(int32_T)b_index - 1] <
                     0.0F)) {
                  // '<S6>:5:963'
                  // '<S6>:5:964'
                  data_struct_input->EC_events_mins_left
                    [data_struct_input->EC_events_index_left - 1] =
                    data_struct_input->VelLShank_filt[(int32_T)b_index - 1];

                  //  Amplitude of the EC peaks and events
                  // '<S6>:5:965'
                  b_EC_events_inds_left[data_struct_input->EC_events_index_left
                    - 1] = b_index;

                  //  Index of the peaks and events (number of sample)
                  // '<S6>:5:966'
                  b_EC_distance_left[data_struct_input->EC_events_index_left - 1]
                    = b_MS_inds_left[EC_events_inds_left] - b_index;

                  //  Distance (number of samples) MS-EC
                  // '<S6>:5:967'
                  data_struct_input->AN_events_left
                    [data_struct_input->EC_events_index_left - 1] =
                    data_struct_input->AngLShank_filt[(int32_T)b_index - 1];

                  // '<S6>:5:968'
                  i = (int32_T)(data_struct_input->EC_events_index_left + 1U);
                  if ((uint32_T)i > 255U) {
                    i = 255;
                  }

                  data_struct_input->EC_events_index_left = (uint8_T)i;
                  b_idx_0 = data_struct_input->EC_events_index_left;

                  // '<S6>:5:969'
                  if (data_struct_input->EC_events_index_left > 5) {
                    // '<S6>:5:969'
                    b_idx_0 = 5U;
                  }

                  data_struct_input->EC_events_index_left = b_idx_0;

                  // '<S6>:5:970'
                  found = 1;
                }

                // '<S6>:5:972'
                b_index--;
              } else {
                exitg2 = 1;
              }
            } while (exitg2 == 0);
          }

          // '<S6>:5:975'
          b_index--;
        } else {
          exitg1 = 1;
        }
      } while (exitg1 == 0);

      // '<S6>:5:955'
    }

    // '<S6>:5:979'
    found = data_struct_input->EC_events_index_right;
    qY = found - 1U;
    if (qY > (uint32_T)found) {
      qY = 0U;
    }

    // '<S6>:5:979'
    for (b_idx_0 = 1U; b_idx_0 <= (uint8_T)qY; b_idx_0++) {
      // '<S6>:5:979'
      // '<S6>:5:980'
      found = 0;

      // '<S6>:5:981'
      b_index = b_EC_events_inds_right[b_idx_0 - 1] - 1.0;

      // '<S6>:5:982'
      // '<S6>:5:983'
      for (i = 0; i < 50; i++) {
        EC_peaks[i] = -2.0E+6;
        AN_peaks[i] = 2.0E+6;
      }

      // '<S6>:5:984'
      EC_peaks_index = 1.0;

      //  Searches the EC peaks in the range [EC-distance,EC], where distance=MS-EC. 
      while ((b_index >= b_EC_events_inds_right[b_idx_0 - 1] -
              b_EC_distance_right[b_idx_0 - 1]) && (b_index > 2.0)) {
        // '<S6>:5:986'
        if ((data_struct_input->VelRShank_filt[(int32_T)b_index - 1] <
             data_struct_input->VelRShank_filt[(int32_T)(b_index + 1.0) - 1]) &&
            (data_struct_input->VelRShank_filt[(int32_T)b_index - 1] <
             data_struct_input->VelRShank_filt[(int32_T)(b_index - 1.0) - 1]) &&
            (data_struct_input->VelRShank_filt[(int32_T)b_index - 1] < 0.0F)) {
          // '<S6>:5:987'
          // '<S6>:5:988'
          EC_peaks[(int32_T)EC_peaks_index - 1] =
            data_struct_input->VelRShank_filt[(int32_T)b_index - 1];

          // '<S6>:5:989'
          AN_peaks[(int32_T)EC_peaks_index - 1] =
            data_struct_input->AngRShank_filt[(int32_T)b_index - 1];

          // '<S6>:5:990'
          EC_peaks_index++;
          if (EC_peaks_index > 50.0) {
            // '<S6>:5:991'
            EC_peaks_index = 50.0;
          }

          // '<S6>:5:992'
          found = 1;
        }

        // '<S6>:5:994'
        b_index--;
      }

      //  If it has not found any, it saves the element at EC-(MS-EC). If it is a positive value, it saves 0. 
      if (found == 0) {
        // '<S6>:5:997'
        // '<S6>:5:998'
        u = data_struct_input->VelRShank_filt[(int32_T)
          (b_EC_events_inds_right[b_idx_0 - 1] - b_EC_distance_right[b_idx_0 - 1])
          - 1] + 1.0F;
        if (u < 0.0F) {
          u = -1.0F;
        } else if (u > 0.0F) {
          u = 1.0F;
        } else {
          if (u == 0.0F) {
            u = 0.0F;
          }
        }

        EC_peaks[(int32_T)EC_peaks_index - 1] =
          data_struct_input->VelRShank_filt[(int32_T)
          (b_EC_events_inds_right[b_idx_0 - 1] - b_EC_distance_right[b_idx_0 - 1])
          - 1] * (-u / 2.0F);

        // '<S6>:5:999'
        AN_peaks[(int32_T)EC_peaks_index - 1] =
          data_struct_input->AngRShank_filt[(int32_T)
          (b_EC_events_inds_right[b_idx_0 - 1] - b_EC_distance_right[b_idx_0 - 1])
          - 1];
      }

      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 50;
           EC_events_inds_left++) {
        if (EC_peaks[EC_events_inds_left] > -1.0E+6) {
          // '<S6>:5:1001'
          found++;
        }
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 50;
           EC_events_inds_left++) {
        if (EC_peaks[EC_events_inds_left] > -1.0E+6) {
          // '<S6>:5:1001'
          wc_data[found] = (int8_T)(EC_events_inds_left + 1);
          found++;
        }
      }

      // '<S6>:5:1001'
      for (i = 0; i < EC_distance_left; i++) {
        EC_peaks_data[i] = EC_peaks[wc_data[i] - 1];
      }

      data_struct_input->EC_peaks_mins_right
        [data_struct_input->EC_peaks_index_right - 1] = (real32_T)
        testGaitSegm_mean_lh(EC_peaks_data, EC_distance_left);

      // '<S6>:5:1002'
      found = 1;
      b_index = AN_peaks[0];
      if (rtIsNaN(AN_peaks[0])) {
        EC_events_inds_left = 2;
        exitg4 = false;
        while ((!exitg4) && (EC_events_inds_left < 51)) {
          found = EC_events_inds_left;
          if (!rtIsNaN(AN_peaks[EC_events_inds_left - 1])) {
            b_index = AN_peaks[EC_events_inds_left - 1];
            exitg4 = true;
          } else {
            EC_events_inds_left++;
          }
        }
      }

      if (found < 50) {
        while (found + 1 < 51) {
          if (AN_peaks[found] < b_index) {
            b_index = AN_peaks[found];
          }

          found++;
        }
      }

      data_struct_input->AN_peaks_right[data_struct_input->EC_peaks_index_right
        - 1] = (real32_T)b_index;

      // '<S6>:5:1003'
      i = (int32_T)(data_struct_input->EC_peaks_index_right + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->EC_peaks_index_right = (uint8_T)i;
      cc_idx_0 = data_struct_input->EC_peaks_index_right;

      // '<S6>:5:1004'
      if (data_struct_input->EC_peaks_index_right > 5) {
        // '<S6>:5:1004'
        cc_idx_0 = 5U;
      }

      data_struct_input->EC_peaks_index_right = cc_idx_0;
    }

    // '<S6>:5:1007'
    found = data_struct_input->EC_events_index_left;
    qY = found - 1U;
    if (qY > (uint32_T)found) {
      qY = 0U;
    }

    // '<S6>:5:1007'
    for (b_idx_0 = 1U; b_idx_0 <= (uint8_T)qY; b_idx_0++) {
      // '<S6>:5:1007'
      // '<S6>:5:1008'
      found = 0;

      // '<S6>:5:1009'
      b_index = b_EC_events_inds_left[b_idx_0 - 1] - 1.0;

      // '<S6>:5:1010'
      // '<S6>:5:1011'
      for (i = 0; i < 50; i++) {
        EC_peaks[i] = -2.0E+6;
        AN_peaks[i] = 2.0E+6;
      }

      // '<S6>:5:1012'
      EC_peaks_index = 1.0;

      //  Searches the EC peaks in the range [EC-distance,EC], where distance=MS-EC. 
      while ((b_index >= b_EC_events_inds_left[b_idx_0 - 1] -
              b_EC_distance_left[b_idx_0 - 1]) && (b_index > 2.0)) {
        // '<S6>:5:1014'
        if ((data_struct_input->VelLShank_filt[(int32_T)b_index - 1] <
             data_struct_input->VelLShank_filt[(int32_T)(b_index + 1.0) - 1]) &&
            (data_struct_input->VelLShank_filt[(int32_T)b_index - 1] <
             data_struct_input->VelLShank_filt[(int32_T)(b_index - 1.0) - 1]) &&
            (data_struct_input->VelLShank_filt[(int32_T)b_index - 1] < 0.0F)) {
          // '<S6>:5:1015'
          // '<S6>:5:1016'
          EC_peaks[(int32_T)EC_peaks_index - 1] =
            data_struct_input->VelLShank_filt[(int32_T)b_index - 1];

          // '<S6>:5:1017'
          AN_peaks[(int32_T)EC_peaks_index - 1] =
            data_struct_input->AngLShank_filt[(int32_T)b_index - 1];

          // '<S6>:5:1018'
          EC_peaks_index++;
          if (EC_peaks_index > 50.0) {
            // '<S6>:5:1019'
            EC_peaks_index = 50.0;
          }

          // '<S6>:5:1020'
          found = 1;
        }

        // '<S6>:5:1022'
        b_index--;
      }

      //  If it has not found any, it saves the element at EC-(MS-EC). If it is a positive value, it saves 0. 
      if ((found == 0) && (b_EC_events_inds_left[b_idx_0 - 1] -
                           b_EC_distance_left[b_idx_0 - 1] > 0.0)) {
        // '<S6>:5:1025'
        // '<S6>:5:1026'
        u = data_struct_input->VelLShank_filt[(int32_T)
          (b_EC_events_inds_left[b_idx_0 - 1] - b_EC_distance_left[b_idx_0 - 1])
          - 1] + 1.0F;
        if (u < 0.0F) {
          u = -1.0F;
        } else if (u > 0.0F) {
          u = 1.0F;
        } else {
          if (u == 0.0F) {
            u = 0.0F;
          }
        }

        EC_peaks[(int32_T)EC_peaks_index - 1] =
          data_struct_input->VelLShank_filt[(int32_T)
          (b_EC_events_inds_left[b_idx_0 - 1] - b_EC_distance_left[b_idx_0 - 1])
          - 1] * (-u / 2.0F);

        // '<S6>:5:1027'
        AN_peaks[(int32_T)EC_peaks_index - 1] =
          data_struct_input->AngLShank_filt[(int32_T)
          (b_EC_events_inds_left[b_idx_0 - 1] - b_EC_distance_left[b_idx_0 - 1])
          - 1];
      }

      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 50;
           EC_events_inds_left++) {
        if (EC_peaks[EC_events_inds_left] > -1.0E+6) {
          // '<S6>:5:1029'
          found++;
        }
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 50;
           EC_events_inds_left++) {
        if (EC_peaks[EC_events_inds_left] > -1.0E+6) {
          // '<S6>:5:1029'
          wc_data[found] = (int8_T)(EC_events_inds_left + 1);
          found++;
        }
      }

      // '<S6>:5:1029'
      for (i = 0; i < EC_distance_left; i++) {
        EC_peaks_data[i] = EC_peaks[wc_data[i] - 1];
      }

      data_struct_input->EC_peaks_mins_left
        [data_struct_input->EC_peaks_index_left - 1] = (real32_T)
        testGaitSegm_mean_lh(EC_peaks_data, EC_distance_left);

      // '<S6>:5:1030'
      found = 1;
      b_index = AN_peaks[0];
      if (rtIsNaN(AN_peaks[0])) {
        EC_events_inds_left = 2;
        exitg4 = false;
        while ((!exitg4) && (EC_events_inds_left < 51)) {
          found = EC_events_inds_left;
          if (!rtIsNaN(AN_peaks[EC_events_inds_left - 1])) {
            b_index = AN_peaks[EC_events_inds_left - 1];
            exitg4 = true;
          } else {
            EC_events_inds_left++;
          }
        }
      }

      if (found < 50) {
        while (found + 1 < 51) {
          if (AN_peaks[found] < b_index) {
            b_index = AN_peaks[found];
          }

          found++;
        }
      }

      data_struct_input->AN_peaks_left[data_struct_input->EC_peaks_index_left -
        1] = (real32_T)b_index;

      // '<S6>:5:1031'
      i = (int32_T)(data_struct_input->EC_peaks_index_left + 1U);
      if ((uint32_T)i > 255U) {
        i = 255;
      }

      data_struct_input->EC_peaks_index_left = (uint8_T)i;
      cc_idx_0 = data_struct_input->EC_peaks_index_left;

      // '<S6>:5:1032'
      if (data_struct_input->EC_peaks_index_left > 5) {
        // '<S6>:5:1032'
        cc_idx_0 = 5U;
      }

      data_struct_input->EC_peaks_index_left = cc_idx_0;
    }

    // '<S6>:5:1035'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->EC_events_mins_right[EC_events_inds_left] >
                -1.0E+6F);
      sc[EC_events_inds_left] = (data_struct_input->
        EC_peaks_mins_right[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (sc[EC_events_inds_left]) {
        found++;
      }
    }

    MS_inds_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (sc[EC_events_inds_left]) {
        xc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1035'
    data_struct_input_sizes_c[0] = 1;
    data_struct_input_sizes_c[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->
        EC_events_mins_right[vc_data[i] - 1];
    }

    data_struct_input_sizes_d[0] = 1;
    data_struct_input_sizes_d[1] = MS_inds_left;
    for (i = 0; i < MS_inds_left; i++) {
      data_struct_input_data_0[i] = data_struct_input->
        EC_peaks_mins_right[xc_data[i] - 1];
    }

    data_struct_input->EC_th_right = (testGaitSegm_mean_l(data_struct_input_data,
      data_struct_input_sizes_c) + testGaitSegm_mean_l(data_struct_input_data_0,
      data_struct_input_sizes_d)) / 2.0F;

    // '<S6>:5:1036'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->EC_events_mins_left[EC_events_inds_left] >
                -1.0E+6F);
      sc[EC_events_inds_left] = (data_struct_input->
        EC_peaks_mins_left[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (sc[EC_events_inds_left]) {
        found++;
      }
    }

    MS_inds_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (sc[EC_events_inds_left]) {
        xc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1036'
    data_struct_input_sizes_a[0] = 1;
    data_struct_input_sizes_a[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->
        EC_events_mins_left[vc_data[i] - 1];
    }

    data_struct_input_sizes_b[0] = 1;
    data_struct_input_sizes_b[1] = MS_inds_left;
    for (i = 0; i < MS_inds_left; i++) {
      data_struct_input_data_0[i] = data_struct_input->
        EC_peaks_mins_left[xc_data[i] - 1];
    }

    data_struct_input->EC_th_left = (testGaitSegm_mean_l(data_struct_input_data,
      data_struct_input_sizes_a) + testGaitSegm_mean_l(data_struct_input_data_0,
      data_struct_input_sizes_b)) / 2.0F;

    // '<S6>:5:1037'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->AN_events_right[EC_events_inds_left] >
                -1.0E+6F);
      sc[EC_events_inds_left] = (data_struct_input->
        AN_peaks_right[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (sc[EC_events_inds_left]) {
        found++;
      }
    }

    MS_inds_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (sc[EC_events_inds_left]) {
        xc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1037'
    data_struct_input_sizes_8[0] = 1;
    data_struct_input_sizes_8[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->AN_events_right[vc_data[i]
        - 1];
    }

    data_struct_input_sizes_9[0] = 1;
    data_struct_input_sizes_9[1] = MS_inds_left;
    for (i = 0; i < MS_inds_left; i++) {
      data_struct_input_data_0[i] = data_struct_input->AN_peaks_right[xc_data[i]
        - 1];
    }

    data_struct_input->AN_th_right = (testGaitSegm_mean_l(data_struct_input_data,
      data_struct_input_sizes_8) + testGaitSegm_mean_l(data_struct_input_data_0,
      data_struct_input_sizes_9)) / 2.0F;

    // '<S6>:5:1038'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->AN_events_left[EC_events_inds_left] >
                -1.0E+6F);
      sc[EC_events_inds_left] = (data_struct_input->
        AN_peaks_left[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (sc[EC_events_inds_left]) {
        found++;
      }
    }

    MS_inds_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (sc[EC_events_inds_left]) {
        xc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1038'
    data_struct_input_sizes_6[0] = 1;
    data_struct_input_sizes_6[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->AN_events_left[vc_data[i] -
        1];
    }

    data_struct_input_sizes_7[0] = 1;
    data_struct_input_sizes_7[1] = MS_inds_left;
    for (i = 0; i < MS_inds_left; i++) {
      data_struct_input_data_0[i] = data_struct_input->AN_peaks_left[xc_data[i]
        - 1];
    }

    data_struct_input->AN_th_left = (testGaitSegm_mean_l(data_struct_input_data,
      data_struct_input_sizes_6) + testGaitSegm_mean_l(data_struct_input_data_0,
      data_struct_input_sizes_7)) / 2.0F;

    //     %% Stop: EC
    // '<S6>:5:1042'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->EC_events_mins_left[EC_events_inds_left] >
                -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1042'
    data_struct_input_sizes_5[0] = 1;
    data_struct_input_sizes_5[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->
        EC_events_mins_left[vc_data[i] - 1];
    }

    data_struct_input->stop_Vel_th_left = testGaitSegm_mean_l
      (data_struct_input_data, data_struct_input_sizes_5) / 3.0F;

    // '<S6>:5:1043'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->EC_events_mins_right[EC_events_inds_left] >
                -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1043'
    data_struct_input_sizes_4[0] = 1;
    data_struct_input_sizes_4[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->
        EC_events_mins_right[vc_data[i] - 1];
    }

    data_struct_input->stop_Vel_th_right = testGaitSegm_mean_l
      (data_struct_input_data, data_struct_input_sizes_4) / 3.0F;

    //     %% Stop: Double support
    // '<S6>:5:1047'
    found = data_struct_input->EC_events_index_left;
    qY = found - 1U;
    if (qY > (uint32_T)found) {
      qY = 0U;
    }

    // '<S6>:5:1047'
    for (b_idx_0 = 1U; b_idx_0 <= (uint8_T)qY; b_idx_0++) {
      // '<S6>:5:1047'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (IC_inds_right[EC_events_inds_left] > 0) {
          // '<S6>:5:1048'
          found++;
        }
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (IC_inds_right[EC_events_inds_left] > 0) {
          // '<S6>:5:1048'
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:1048'
      for (i = 0; i < EC_distance_left; i++) {
        temp_data[i] = b_EC_events_inds_left[b_idx_0 - 1] - (real_T)
          IC_inds_right[vc_data[i] - 1];
      }

      for (found = 0; found < EC_distance_left; found++) {
        if (temp_data[found] < 0.0) {
          // '<S6>:5:1049'
          temp_data[found] = 2.0E+6;
        }
      }

      // '<S6>:5:1050'
      b_index = temp_data[0];
      if ((EC_distance_left > 1) && (1 < EC_distance_left)) {
        for (found = 1; found + 1 <= EC_distance_left; found++) {
          if (temp_data[found] < b_index) {
            b_index = temp_data[found];
          }
        }
      }

      if (b_index < 1.0E+6) {
        // '<S6>:5:1051'
        // '<S6>:5:1052'
        i = (int32_T)rt_roundd_snf(b_index);
        if (i < 65536) {
          if (i >= 0) {
            data_struct_input->stop_DS[data_struct_input->stop_DS_index - 1] =
              (uint16_T)i;
          } else {
            data_struct_input->stop_DS[data_struct_input->stop_DS_index - 1] =
              0U;
          }
        } else {
          data_struct_input->stop_DS[data_struct_input->stop_DS_index - 1] =
            MAX_uint16_T;
        }

        // '<S6>:5:1053'
        i = (int32_T)(data_struct_input->stop_DS_index + 1U);
        if ((uint32_T)i > 255U) {
          i = 255;
        }

        data_struct_input->stop_DS_index = (uint8_T)i;
        cc_idx_0 = data_struct_input->stop_DS_index;

        // '<S6>:5:1054'
        if (data_struct_input->stop_DS_index > 10) {
          // '<S6>:5:1054'
          cc_idx_0 = 10U;
        }

        data_struct_input->stop_DS_index = cc_idx_0;
      }
    }

    // '<S6>:5:1057'
    found = data_struct_input->EC_events_index_right;
    qY = found - 1U;
    if (qY > (uint32_T)found) {
      qY = 0U;
    }

    // '<S6>:5:1057'
    for (b_idx_0 = 1U; b_idx_0 <= (uint8_T)qY; b_idx_0++) {
      // '<S6>:5:1057'
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (IC_inds_left[EC_events_inds_left] > 0) {
          // '<S6>:5:1058'
          found++;
        }
      }

      EC_distance_left = found;
      found = 0;
      for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left
           ++) {
        if (IC_inds_left[EC_events_inds_left] > 0) {
          // '<S6>:5:1058'
          vc_data[found] = EC_events_inds_left + 1;
          found++;
        }
      }

      // '<S6>:5:1058'
      for (i = 0; i < EC_distance_left; i++) {
        temp_data[i] = b_EC_events_inds_right[b_idx_0 - 1] - (real_T)
          IC_inds_left[vc_data[i] - 1];
      }

      for (found = 0; found < EC_distance_left; found++) {
        if (temp_data[found] < 0.0) {
          // '<S6>:5:1059'
          temp_data[found] = 2.0E+6;
        }
      }

      // '<S6>:5:1060'
      b_index = temp_data[0];
      if ((EC_distance_left > 1) && (1 < EC_distance_left)) {
        for (found = 1; found + 1 <= EC_distance_left; found++) {
          if (temp_data[found] < b_index) {
            b_index = temp_data[found];
          }
        }
      }

      if (b_index < 1.0E+6) {
        // '<S6>:5:1061'
        // '<S6>:5:1062'
        i = (int32_T)rt_roundd_snf(b_index);
        if (i < 65536) {
          if (i >= 0) {
            data_struct_input->stop_DS[data_struct_input->stop_DS_index - 1] =
              (uint16_T)i;
          } else {
            data_struct_input->stop_DS[data_struct_input->stop_DS_index - 1] =
              0U;
          }
        } else {
          data_struct_input->stop_DS[data_struct_input->stop_DS_index - 1] =
            MAX_uint16_T;
        }

        // '<S6>:5:1063'
        i = (int32_T)(data_struct_input->stop_DS_index + 1U);
        if ((uint32_T)i > 255U) {
          i = 255;
        }

        data_struct_input->stop_DS_index = (uint8_T)i;
        cc_idx_0 = data_struct_input->stop_DS_index;

        // '<S6>:5:1064'
        if (data_struct_input->stop_DS_index > 10) {
          // '<S6>:5:1064'
          cc_idx_0 = 10U;
        }

        data_struct_input->stop_DS_index = cc_idx_0;
      }
    }

    // '<S6>:5:1067'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 10; EC_events_inds_left
         ++) {
      exitg4 = (data_struct_input->stop_DS[EC_events_inds_left] < 10000);
      if (exitg4) {
        found++;
      }

      qc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 10; EC_events_inds_left
         ++) {
      if (qc[EC_events_inds_left]) {
        tc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1067'
    data_struct_input_sizes_3[0] = 1;
    data_struct_input_sizes_3[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data_1[i] = data_struct_input->stop_DS[tc_data[i] - 1];
    }

    b_index = rt_roundd_snf(testGaitSegm_mean(data_struct_input_data_1,
      data_struct_input_sizes_3));
    if (b_index < 65536.0) {
      if (b_index >= 0.0) {
        data_struct_input->stop_DS_th = (uint16_T)b_index;
      } else {
        data_struct_input->stop_DS_th = 0U;
      }
    } else {
      data_struct_input->stop_DS_th = MAX_uint16_T;
    }

    //     %% Stop: MA
    // '<S6>:5:1070'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->MA_maxs_left[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1070'
    data_struct_input_sizes_2[0] = 1;
    data_struct_input_sizes_2[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->MA_maxs_left[vc_data[i] - 1];
    }

    data_struct_input->stop_MA_th_left = testGaitSegm_mean_l
      (data_struct_input_data, data_struct_input_sizes_2) / 3.0F;

    // '<S6>:5:1071'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->MA_maxs_right[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1071'
    data_struct_input_sizes_1[0] = 1;
    data_struct_input_sizes_1[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->MA_maxs_right[vc_data[i] -
        1];
    }

    data_struct_input->stop_MA_th_right = testGaitSegm_mean_l
      (data_struct_input_data, data_struct_input_sizes_1) / 3.0F;

    //     %% Stop: IC
    // '<S6>:5:1074'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->IC_mins_left[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1074'
    data_struct_input_sizes_0[0] = 1;
    data_struct_input_sizes_0[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->IC_mins_left[vc_data[i] - 1];
    }

    data_struct_input->stop_IC_th_left = testGaitSegm_mean_l
      (data_struct_input_data, data_struct_input_sizes_0) / 3.0F;

    // '<S6>:5:1075'
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      exitg4 = (data_struct_input->IC_mins_right[EC_events_inds_left] > -1.0E+6F);
      if (exitg4) {
        found++;
      }

      rc[EC_events_inds_left] = exitg4;
    }

    EC_distance_left = found;
    found = 0;
    for (EC_events_inds_left = 0; EC_events_inds_left < 5; EC_events_inds_left++)
    {
      if (rc[EC_events_inds_left]) {
        vc_data[found] = EC_events_inds_left + 1;
        found++;
      }
    }

    // '<S6>:5:1075'
    data_struct_input_sizes[0] = 1;
    data_struct_input_sizes[1] = EC_distance_left;
    for (i = 0; i < EC_distance_left; i++) {
      data_struct_input_data[i] = data_struct_input->IC_mins_right[vc_data[i] -
        1];
    }

    data_struct_input->stop_IC_th_right = testGaitSegm_mean_l
      (data_struct_input_data, data_struct_input_sizes) / 3.0F;

    //     %% Finish calibration
    b_idx_0 = data_struct_input->MA_LPF_index_right;

    // '<S6>:5:1078'
    if (data_struct_input->MA_LPF_index_right > 5) {
      // '<S6>:5:1078'
      b_idx_0 = 1U;
    }

    data_struct_input->MA_LPF_index_right = b_idx_0;
    b_idx_0 = data_struct_input->MA_LPF_index_left;

    // '<S6>:5:1079'
    if (data_struct_input->MA_LPF_index_left > 5) {
      // '<S6>:5:1079'
      b_idx_0 = 1U;
    }

    data_struct_input->MA_LPF_index_left = b_idx_0;
    b_idx_0 = data_struct_input->MA_index_right;

    // '<S6>:5:1080'
    if (data_struct_input->MA_index_right > 5) {
      // '<S6>:5:1080'
      b_idx_0 = 1U;
    }

    data_struct_input->MA_index_right = b_idx_0;
    b_idx_0 = data_struct_input->MA_index_left;

    // '<S6>:5:1081'
    if (data_struct_input->MA_index_left > 5) {
      // '<S6>:5:1081'
      b_idx_0 = 1U;
    }

    data_struct_input->MA_index_left = b_idx_0;
    b_idx_0 = data_struct_input->IC_LPF_index_right;

    // '<S6>:5:1082'
    if (data_struct_input->IC_LPF_index_right > 5) {
      // '<S6>:5:1082'
      b_idx_0 = 1U;
    }

    data_struct_input->IC_LPF_index_right = b_idx_0;
    b_idx_0 = data_struct_input->IC_LPF_index_left;

    // '<S6>:5:1083'
    if (data_struct_input->IC_LPF_index_left > 5) {
      // '<S6>:5:1083'
      b_idx_0 = 1U;
    }

    data_struct_input->IC_LPF_index_left = b_idx_0;
    b_idx_0 = data_struct_input->IC_index_right;

    // '<S6>:5:1084'
    if (data_struct_input->IC_index_right > 5) {
      // '<S6>:5:1084'
      b_idx_0 = 1U;
    }

    data_struct_input->IC_index_right = b_idx_0;
    b_idx_0 = data_struct_input->IC_index_left;

    // '<S6>:5:1085'
    if (data_struct_input->IC_index_left > 5) {
      // '<S6>:5:1085'
      b_idx_0 = 1U;
    }

    data_struct_input->IC_index_left = b_idx_0;
    b_idx_0 = data_struct_input->EC_events_index_right;

    // '<S6>:5:1086'
    if (data_struct_input->EC_events_index_right > 5) {
      // '<S6>:5:1086'
      b_idx_0 = 1U;
    }

    data_struct_input->EC_events_index_right = b_idx_0;
    b_idx_0 = data_struct_input->EC_events_index_left;

    // '<S6>:5:1087'
    if (data_struct_input->EC_events_index_left > 5) {
      // '<S6>:5:1087'
      b_idx_0 = 1U;
    }

    data_struct_input->EC_events_index_left = b_idx_0;
    b_idx_0 = data_struct_input->EC_peaks_index_right;

    // '<S6>:5:1088'
    if (data_struct_input->EC_peaks_index_right > 5) {
      // '<S6>:5:1088'
      b_idx_0 = 1U;
    }

    data_struct_input->EC_peaks_index_right = b_idx_0;
    b_idx_0 = data_struct_input->EC_peaks_index_left;

    // '<S6>:5:1089'
    if (data_struct_input->EC_peaks_index_left > 5) {
      // '<S6>:5:1089'
      b_idx_0 = 1U;
    }

    data_struct_input->EC_peaks_index_left = b_idx_0;
    b_idx_0 = data_struct_input->stop_DS_index;

    // '<S6>:5:1090'
    if (data_struct_input->stop_DS_index > 10) {
      // '<S6>:5:1090'
      b_idx_0 = 1U;
    }

    data_struct_input->stop_DS_index = b_idx_0;

    // '<S6>:5:1092'
    data_struct_input->MA_flag_left = true;

    // '<S6>:5:1093'
    data_struct_input->MA_flag_right = true;

    // '<S6>:5:1094'
    data_struct_input->flag_calib = false;

    // '<S6>:5:1095'
    data_struct_input->calibrating = 0;

    // '<S6>:5:1096'
    data_struct_input->counter = 0U;

    // '<S6>:5:1098'
    data_struct_input->state = 3;

    //  Started with right leg
    // '<S6>:5:1099'
    found = IC_inds_right[0];
    for (EC_events_inds_left = 1; EC_events_inds_left + 1 < 6;
         EC_events_inds_left++) {
      if (IC_inds_right[EC_events_inds_left] > found) {
        found = IC_inds_right[EC_events_inds_left];
      }
    }

    data_struct_input->last_IC = (uint16_T)(200 - found);

    //  Initial value of IC_inds_rightis 0
    if (!data_struct_input->initial_leg) {
      // '<S6>:5:1101'
      //  Started with left leg
      // '<S6>:5:1102'
      data_struct_input->state = 6;

      // '<S6>:5:1103'
      found = IC_inds_left[0];
      for (EC_events_inds_left = 1; EC_events_inds_left + 1 < 6;
           EC_events_inds_left++) {
        if (IC_inds_left[EC_events_inds_left] > found) {
          found = IC_inds_left[EC_events_inds_left];
        }
      }

      data_struct_input->last_IC = (uint16_T)(200 - found);

      //  Initial value of IC_inds_left is 0
    }
  }

  // '<S6>:5:1107'
  state_out = data_struct_input->state;

  // '<S6>:5:1108'
  return state_out;
}

// Function for Chart: '<S2>/Chart'
static void testGaitSegm_SEGMENTATION(void)
{
  // During 'SEGMENTATION': '<S6>:1'
  testGaitSegm_RTDetection(&testGaitSegm_DW.data_struct,
    testGaitSegm_B.SFunction_o3, testGaitSegm_B.DiscreteFilter1,
    testGaitSegm_B.DataTypeConversion1, testGaitSegm_B.DataTypeConversion3,
    testGaitSegm_B.DataTypeConversion2);
  testGaitSegm_B.data_struct_out = testGaitSegm_DW.data_struct;
  testGaitSegm_B.state = testGaitSegm_B.data_struct_out.state;
}

// Function for Chart: '<S2>/Chart'
static void testGaitSe_data_struct_creation(bus_datastruct *data_struct_in)
{
  int32_T i;

  // MATLAB Function 'data_struct_creation': '<S6>:2'
  // % Buffers (VelRShank, VelLShank, angRShank, AngLShank, and the filtered versions) have 200 samples (4 seconds when sampling at 50 Hz=. 
  //  To work with higher frequencies, the buffer size must be increased.
  // % General
  // '<S6>:2:5'
  // '<S6>:2:6'
  // '<S6>:2:7'
  // '<S6>:2:8'
  // '<S6>:2:10'
  // '<S6>:2:11'
  // '<S6>:2:12'
  // '<S6>:2:13'
  // '<S6>:2:15'
  // '<S6>:2:16'
  // '<S6>:2:17'
  // '<S6>:2:18'
  // '<S6>:2:19'
  // '<S6>:2:20'
  for (i = 0; i < 200; i++) {
    data_struct_in->VelRShank[i] = 0.0F;
    data_struct_in->VelLShank[i] = 0.0F;
    data_struct_in->AngRShank[i] = 0.0F;
    data_struct_in->AngLShank[i] = 0.0F;
    data_struct_in->VelRShank_filt[i] = 0.0F;
    data_struct_in->VelLShank_filt[i] = 0.0F;
    data_struct_in->AngRShank_filt[i] = 0.0F;
    data_struct_in->AngLShank_filt[i] = 0.0F;
    data_struct_in->VelRShank_LPF[i] = 0.0F;
    data_struct_in->VelLShank_LPF[i] = 0.0F;
    data_struct_in->AngRShank_LPF[i] = 0.0F;
    data_struct_in->AngLShank_LPF[i] = 0.0F;
    data_struct_in->AngRShank_LPF2Hz[i] = 0.0F;
    data_struct_in->AngLShank_LPF2Hz[i] = 0.0F;
  }

  // '<S6>:2:22'
  data_struct_in->counter_stop = 0U;

  // '<S6>:2:23'
  data_struct_in->counter = 0U;

  // '<S6>:2:24'
  data_struct_in->index_start_calib = 0U;

  // '<S6>:2:25'
  data_struct_in->index_stop_calib = 0U;

  // '<S6>:2:26'
  data_struct_in->initial_leg = false;

  //  boolean: 0 left, 1 right
  //  left_limit
  // '<S6>:2:30'
  data_struct_in->flag_calib = true;

  //  boolean
  // '<S6>:2:31'
  data_struct_in->calibrating = 0;

  //  int. 0 if not calibrating, 1 waiting for person to start walking, 2 saving data, , 3 waiting for +1/4 cycle, 4 RT detection 
  // '<S6>:2:33'
  data_struct_in->state = 0;

  // '<S6>:2:34'
  data_struct_in->prevstate = 0;

  // % MA
  // '<S6>:2:37'
  // '<S6>:2:38'
  // '<S6>:2:39'
  // '<S6>:2:40'
  // '<S6>:2:41'
  data_struct_in->MA_LPF_index_right = 1U;

  // '<S6>:2:42'
  data_struct_in->MA_LPF_index_left = 1U;

  // '<S6>:2:43'
  data_struct_in->MA_index_right = 1U;

  // '<S6>:2:44'
  data_struct_in->MA_index_left = 1U;

  //  MA_LPF_th_left
  //  MA_LPF_th_right
  //  MA_th_left
  //  MA_th_right
  // % IC
  // '<S6>:2:51'
  // '<S6>:2:52'
  // '<S6>:2:53'
  // '<S6>:2:54'
  // '<S6>:2:55'
  data_struct_in->IC_LPF_index_right = 1U;

  // '<S6>:2:56'
  data_struct_in->IC_LPF_index_left = 1U;

  // '<S6>:2:57'
  data_struct_in->IC_index_right = 1U;

  // '<S6>:2:58'
  data_struct_in->IC_index_left = 1U;

  //  IC_LPF_th_left
  //  IC_LPF_th_right
  //  IC_th_left
  //  IC_th_right
  // % EC
  // '<S6>:2:65'
  // '<S6>:2:66'
  // '<S6>:2:67'
  // '<S6>:2:68'
  // '<S6>:2:69'
  data_struct_in->EC_events_index_right = 1U;

  // '<S6>:2:70'
  data_struct_in->EC_peaks_index_right = 1U;

  // '<S6>:2:71'
  data_struct_in->EC_events_index_left = 1U;

  // '<S6>:2:72'
  data_struct_in->EC_peaks_index_left = 1U;

  //  EC_th_right
  //  EC_th_left
  // % AN
  // '<S6>:2:77'
  // '<S6>:2:78'
  // '<S6>:2:79'
  // '<S6>:2:80'
  for (i = 0; i < 5; i++) {
    data_struct_in->MA_maxs_right[i] = -2.0E+6F;
    data_struct_in->MA_maxs_left[i] = -2.0E+6F;
    data_struct_in->MA_LPF_maxs_right[i] = -2.0E+6F;
    data_struct_in->MA_LPF_maxs_left[i] = -2.0E+6F;
    data_struct_in->IC_mins_right[i] = -2.0E+6F;
    data_struct_in->IC_mins_left[i] = -2.0E+6F;
    data_struct_in->IC_LPF_mins_right[i] = -2.0E+6F;
    data_struct_in->IC_LPF_mins_left[i] = -2.0E+6F;
    data_struct_in->EC_events_mins_right[i] = -2.0E+6F;
    data_struct_in->EC_events_mins_left[i] = -2.0E+6F;
    data_struct_in->EC_peaks_mins_right[i] = -2.0E+6F;
    data_struct_in->EC_peaks_mins_left[i] = -2.0E+6F;
    data_struct_in->AN_events_right[i] = -2.0E+6F;
    data_struct_in->AN_peaks_right[i] = -2.0E+6F;
    data_struct_in->AN_events_left[i] = -2.0E+6F;
    data_struct_in->AN_peaks_left[i] = -2.0E+6F;
  }

  //  AN_th_right
  //  AN_th_left
  // % Stop
  // '<S6>:2:86'
  data_struct_in->stop_DS_index = 1U;

  // '<S6>:2:87'
  for (i = 0; i < 10; i++) {
    data_struct_in->stop_DS[i] = 20000U;
  }

  //  stop_Vel_th_left
  //  stop_Vel_th_right
  //  stop_MA_th_right
  //  stop_MA_th_left
  //  stop_IC_th_right
  //  stop_IC_th_left
  //  stop_DS_th
  // % Events
  // '<S6>:2:97'
  data_struct_in->MS_event_left = false;

  // '<S6>:2:98'
  data_struct_in->MS_event_right = false;

  // '<S6>:2:99'
  data_struct_in->EC_event_left = false;

  // '<S6>:2:100'
  data_struct_in->EC_event_right = false;

  // '<S6>:2:101'
  data_struct_in->IC_event_left = false;

  // '<S6>:2:102'
  data_struct_in->IC_event_right = false;

  // '<S6>:2:103'
  data_struct_in->AN_event_left = false;

  // '<S6>:2:104'
  data_struct_in->AN_event_right = false;

  // '<S6>:2:105'
  data_struct_in->MA_event_left = false;

  // '<S6>:2:106'
  data_struct_in->MA_event_right = false;

  // '<S6>:2:107'
  data_struct_in->stop_Vel_event_left = false;

  // '<S6>:2:108'
  data_struct_in->stop_Vel_event_right = false;

  // '<S6>:2:109'
  data_struct_in->stop_MA_event_left = false;

  // '<S6>:2:110'
  data_struct_in->stop_MA_event_right = false;

  // '<S6>:2:111'
  data_struct_in->stop_IC_event_left = false;

  // '<S6>:2:112'
  data_struct_in->stop_IC_event_right = false;

  // '<S6>:2:113'
  data_struct_in->MA_flag_right = false;

  // '<S6>:2:114'
  data_struct_in->MA_flag_left = false;

  // '<S6>:2:116'
  data_struct_in->last_EC = 0U;

  // '<S6>:2:117'
  data_struct_in->last_IC = 0U;

  // % Event buffers
  // '<S6>:2:120'
  // '<S6>:2:121'
  // '<S6>:2:122'
  // '<S6>:2:123'
  // '<S6>:2:124'
  // '<S6>:2:125'
  for (i = 0; i < 200; i++) {
    data_struct_in->IC_buffer_left[i] = -2.0E+6F;
    data_struct_in->IC_buffer_right[i] = -2.0E+6F;
    data_struct_in->EC_buffer_left[i] = -2.0E+6F;
    data_struct_in->EC_buffer_right[i] = -2.0E+6F;
    data_struct_in->MS_buffer_left[i] = -2.0E+6F;
    data_struct_in->MS_buffer_right[i] = -2.0E+6F;
  }

  // '<S6>:2:127'
  data_struct_in->IC_buffer_index_left = 1U;

  // '<S6>:2:128'
  data_struct_in->IC_buffer_index_right = 1U;

  // '<S6>:2:129'
  data_struct_in->EC_buffer_index_left = 1U;

  // '<S6>:2:130'
  data_struct_in->EC_buffer_index_right = 1U;

  // '<S6>:2:131'
  data_struct_in->MS_buffer_index_left = 1U;

  // '<S6>:2:132'
  data_struct_in->MS_buffer_index_right = 1U;

  // '<S6>:2:134'
}

// Model step function
void testGaitSegm_step(void)
{
  // local block i/o variables
  real_T rtb_XsensIMUs_o1[160];
  real_T rtb_XsensIMUs_o2[160];
  real_T rtb_XsensIMUs_o3[160];
  real_T rtb_XsensIMUs_o4[160];
  real_T rtb_XsensIMUs_o5[160];
  real_T rtb_XsensIMUs_o6[160];
  real_T rtb_XsensIMUs_o7[160];
  real_T rtb_XsensIMUs_o8[160];
  real_T rtb_XsensIMUs_o9[160];
  real_T rtb_XsensIMUs_o10[160];
  real_T rtb_SFunction_o1;
  real_T rtb_SFunction_o2;
  real_T rtb_SFunction_o4;
  real_T factor;
  real_T diff;
  int16_T c;
  real_T rtb_Gain3;

  // Reset subsysRan breadcrumbs
  srClearBC(testGaitSegm_DW.Gaitsegmentation_SubsysRanBC);

  // S-Function (ex_sfun_sci_xsens): '<Root>/Xsens IMUs'
  output_xsens( &testGaitSegm_DW.XsensIMUs_PWORK, &rtb_XsensIMUs_o1[0],
               &rtb_XsensIMUs_o2[0], &rtb_XsensIMUs_o3[0], &rtb_XsensIMUs_o4[0],
               &rtb_XsensIMUs_o5[0], &rtb_XsensIMUs_o6[0], &rtb_XsensIMUs_o7[0],
               &rtb_XsensIMUs_o8[0], &rtb_XsensIMUs_o9[0], &rtb_XsensIMUs_o10[0]);

  // MATLAB Function: '<S4>/Extractor'
  // MATLAB Function 'Extract/Extractor': '<S5>:1'
  // '<S5>:1:4'
  // '<S5>:1:6'
  // '<S5>:1:7'
  testGaitSegm_B.a[0] = rtb_XsensIMUs_o1[1];
  testGaitSegm_B.a[1] = rtb_XsensIMUs_o1[2];
  testGaitSegm_B.a[2] = rtb_XsensIMUs_o1[3];

  // '<S5>:1:8'
  // '<S5>:1:9'
  // '<S5>:1:10'
  // '<S5>:1:11'
  // '<S5>:1:22'
  factor = 1.0;

  // '<S5>:1:24'
  diff = fabs(rtb_XsensIMUs_o1[0] - testGaitSegm_DW.lastSampleNumber);
  if (diff >= 1.0) {
    // '<S5>:1:26'
    // '<S5>:1:27'
    factor = diff;
  }

  if (diff == 0.0) {
    // '<S5>:1:29'
    // '<S5>:1:30'
    factor = testGaitSegm_DW.lastFactor;
  }

  // '<S5>:1:33'
  testGaitSegm_DW.lastFactor = factor;

  // '<S5>:1:34'
  testGaitSegm_DW.lastSampleNumber = rtb_XsensIMUs_o1[0];
  if (testGaitSegm_P.Extract_correction == 1.0) {
    // '<S5>:1:36'
    // '<S5>:1:37'
    testGaitSegm_B.a[0] /= factor;
    testGaitSegm_B.a[1] /= factor;
    testGaitSegm_B.a[2] /= factor;

    // '<S5>:1:38'
    // '<S5>:1:39'
    // '<S5>:1:40'
  } else {
    // '<S5>:1:42'
    // '<S5>:1:43'
    // '<S5>:1:44'
    // '<S5>:1:45'
  }

  // End of MATLAB Function: '<S4>/Extractor'

  // Chart: '<S1>/Chart'
  // Gateway: Data Available/Chart
  testGaitSegm_DW.sfEvent_g = testGaitSegm_CALL_EVENT_g;

  // During: Data Available/Chart
  if (testGaitSegm_DW.is_active_c4_XsensLibrary2 == 0U) {
    // Entry: Data Available/Chart
    testGaitSegm_DW.is_active_c4_XsensLibrary2 = 1U;

    // Entry Internal: Data Available/Chart
    // Transition: '<S3>:36'
    testGaitSegm_DW.is_c4_XsensLibrary2 = testGaitSegm_IN_WAITFORDATA;

    // Entry 'WAITFORDATA': '<S3>:35'
    testGaitSegm_B.FlagAvailable = 0.0;
    testGaitSegm_DW.do_transition = 0.0;
  } else if (testGaitSegm_DW.is_c4_XsensLibrary2 == testGaitSegm_IN_DATARECEIVED)
  {
    // During 'DATARECEIVED': '<S3>:39'
    testGaitSegm_B.FlagAvailable = 1.0;
  } else {
    // During 'WAITFORDATA': '<S3>:35'
    if (testGaitSegm_DW.do_transition > 0.0) {
      // Transition: '<S3>:40'
      testGaitSegm_DW.is_c4_XsensLibrary2 = testGaitSegm_IN_DATARECEIVED;
    } else {
      if (sqrt((testGaitSegm_B.a[0] * testGaitSegm_B.a[0] + testGaitSegm_B.a[1] *
                testGaitSegm_B.a[1]) + testGaitSegm_B.a[2] * testGaitSegm_B.a[2])
          >= 5.0) {
        testGaitSegm_DW.do_transition = 1.0;
      }
    }
  }

  // End of Chart: '<S1>/Chart'

  // Outputs for Enabled SubSystem: '<Root>/Gait segmentation' incorporates:
  //   EnablePort: '<S2>/Enable'

  if (testGaitSegm_B.FlagAvailable > 0.0) {
    // S-Function (Timing): '<S2>/S-Function'
    output_timing( &rtb_SFunction_o1, &rtb_SFunction_o2,
                  &testGaitSegm_B.SFunction_o3, &rtb_SFunction_o4);

    // MATLAB Function: '<S8>/Extractor'
    testGaitSegm_Extractor(rtb_XsensIMUs_o2, &testGaitSegm_B.sf_Extractor_i,
      &testGaitSegm_DW.sf_Extractor_i, testGaitSegm_P.Extract1_correction);

    // DiscreteFilter: '<S2>/Discrete Filter1' incorporates:
    //   Gain: '<S2>/Gain1'

    testGaitSegm_DW.DiscreteFilter1_tmp = ((testGaitSegm_P.Gain1_Gain *
      testGaitSegm_B.sf_Extractor_i.omega[2] -
      testGaitSegm_P.DiscreteFilter1_DenCoef[1] *
      testGaitSegm_DW.DiscreteFilter1_states[0]) -
      testGaitSegm_P.DiscreteFilter1_DenCoef[2] *
      testGaitSegm_DW.DiscreteFilter1_states[1]) /
      testGaitSegm_P.DiscreteFilter1_DenCoef[0];
    testGaitSegm_B.DiscreteFilter1 = (testGaitSegm_P.DiscreteFilter1_NumCoef[0] *
      testGaitSegm_DW.DiscreteFilter1_tmp +
      testGaitSegm_P.DiscreteFilter1_NumCoef[1] *
      testGaitSegm_DW.DiscreteFilter1_states[0]) +
      testGaitSegm_P.DiscreteFilter1_NumCoef[2] *
      testGaitSegm_DW.DiscreteFilter1_states[1];

    // MATLAB Function: '<S7>/Extractor'
    testGaitSegm_Extractor(rtb_XsensIMUs_o1, &testGaitSegm_B.sf_Extractor_ir,
      &testGaitSegm_DW.sf_Extractor_ir, testGaitSegm_P.Extract_correction_o);

    // DiscreteFilter: '<S2>/Discrete Filter' incorporates:
    //   Gain: '<S2>/Gain'

    testGaitSegm_DW.DiscreteFilter_tmp = ((testGaitSegm_P.Gain_Gain *
      testGaitSegm_B.sf_Extractor_ir.omega[2] -
      testGaitSegm_P.DiscreteFilter_DenCoef[1] *
      testGaitSegm_DW.DiscreteFilter_states[0]) -
      testGaitSegm_P.DiscreteFilter_DenCoef[2] *
      testGaitSegm_DW.DiscreteFilter_states[1]) /
      testGaitSegm_P.DiscreteFilter_DenCoef[0];
    testGaitSegm_B.DiscreteFilter = (testGaitSegm_P.DiscreteFilter_NumCoef[0] *
      testGaitSegm_DW.DiscreteFilter_tmp +
      testGaitSegm_P.DiscreteFilter_NumCoef[1] *
      testGaitSegm_DW.DiscreteFilter_states[0]) +
      testGaitSegm_P.DiscreteFilter_NumCoef[2] *
      testGaitSegm_DW.DiscreteFilter_states[1];

    // DataTypeConversion: '<S2>/Data Type Conversion1'
    testGaitSegm_B.DataTypeConversion1 = (real32_T)testGaitSegm_B.DiscreteFilter;

    // S-Function (sdspcumsumprod): '<S2>/Cumulative Sum1'
    c = 0;
    while (c < 1) {
      factor = testGaitSegm_DW.CumulativeSum1_RunningCumVal;
      c = 0;
      while (c < 1) {
        factor += testGaitSegm_B.DiscreteFilter1;
        rtb_Gain3 = factor;
        c = 1;
      }

      testGaitSegm_DW.CumulativeSum1_RunningCumVal = factor;
      c = 1;
    }

    // End of S-Function (sdspcumsumprod): '<S2>/Cumulative Sum1'

    // Gain: '<S2>/Gain4'
    rtb_Gain3 *= testGaitSegm_P.Gain4_Gain;

    // DataTypeConversion: '<S2>/Data Type Conversion3'
    testGaitSegm_B.DataTypeConversion3 = (real32_T)rtb_Gain3;

    // S-Function (sdspcumsumprod): '<S2>/Cumulative Sum'
    c = 0;
    while (c < 1) {
      factor = testGaitSegm_DW.CumulativeSum_RunningCumVal;
      c = 0;
      while (c < 1) {
        factor += testGaitSegm_B.DiscreteFilter;
        rtb_Gain3 = factor;
        c = 1;
      }

      testGaitSegm_DW.CumulativeSum_RunningCumVal = factor;
      c = 1;
    }

    // End of S-Function (sdspcumsumprod): '<S2>/Cumulative Sum'

    // Gain: '<S2>/Gain3'
    rtb_Gain3 *= testGaitSegm_P.Gain3_Gain;

    // DataTypeConversion: '<S2>/Data Type Conversion2' incorporates:
    //   DataTypeConversion: '<S2>/Data Type Conversion'

    testGaitSegm_B.DataTypeConversion2 = (real32_T)rtb_Gain3;

    // Chart: '<S2>/Chart'
    // Gateway: Gait segmentation/Chart
    testGaitSegm_DW.sfEvent = testGaitSegm_CALL_EVENT_g;

    // During: Gait segmentation/Chart
    if (testGaitSegm_DW.is_active_c7_XsensLibrary2 == 0U) {
      // Entry: Gait segmentation/Chart
      testGaitSegm_DW.is_active_c7_XsensLibrary2 = 1U;

      // Entry Internal: Gait segmentation/Chart
      // Transition: '<S6>:16'
      testGaitSegm_DW.is_c7_XsensLibrary2 = testGaitSegm_IN_SEGMENTATION;

      // Entry 'SEGMENTATION': '<S6>:1'
      testGaitSegm_DW.data_struct = testGaitSegm_DW.A;
      testGaitSe_data_struct_creation(&testGaitSegm_DW.data_struct);
    } else {
      testGaitSegm_SEGMENTATION();
    }

    // End of Chart: '<S2>/Chart'

    // Update for DiscreteFilter: '<S2>/Discrete Filter1'
    testGaitSegm_DW.DiscreteFilter1_states[1] =
      testGaitSegm_DW.DiscreteFilter1_states[0];
    testGaitSegm_DW.DiscreteFilter1_states[0] =
      testGaitSegm_DW.DiscreteFilter1_tmp;

    // Update for DiscreteFilter: '<S2>/Discrete Filter'
    testGaitSegm_DW.DiscreteFilter_states[1] =
      testGaitSegm_DW.DiscreteFilter_states[0];
    testGaitSegm_DW.DiscreteFilter_states[0] =
      testGaitSegm_DW.DiscreteFilter_tmp;
    srUpdateBC(testGaitSegm_DW.Gaitsegmentation_SubsysRanBC);
  }

  // End of Outputs for SubSystem: '<Root>/Gait segmentation'

  // External mode
  rtExtModeUploadCheckTrigger(1);

  {                                    // Sample time: [0.0167s, 0.0s]
    rtExtModeUpload(0, testGaitSegm_M->Timing.taskTime0);
  }

  // signal main to stop simulation
  {                                    // Sample time: [0.0167s, 0.0s]
    if ((rtmGetTFinal(testGaitSegm_M)!=-1) &&
        !((rtmGetTFinal(testGaitSegm_M)-testGaitSegm_M->Timing.taskTime0) >
          testGaitSegm_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(testGaitSegm_M, "Simulation finished");
    }

    if (rtmGetStopRequested(testGaitSegm_M)) {
      rtmSetErrorStatus(testGaitSegm_M, "Simulation finished");
    }
  }

  // Update absolute time for base rate
  // The "clockTick0" counts the number of times the code of this task has
  //  been executed. The absolute time is the multiplication of "clockTick0"
  //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
  //  overflow during the application lifespan selected.

  testGaitSegm_M->Timing.taskTime0 =
    (++testGaitSegm_M->Timing.clockTick0) * testGaitSegm_M->Timing.stepSize0;
}

// Model initialize function
void testGaitSegm_initialize(void)
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // initialize real-time model
  (void) memset((void *)testGaitSegm_M, 0,
                sizeof(RT_MODEL_testGaitSegm_T));
  rtmSetTFinal(testGaitSegm_M, -1);
  testGaitSegm_M->Timing.stepSize0 = 0.0167;

  // External mode info
  testGaitSegm_M->Sizes.checksums[0] = (1849536221U);
  testGaitSegm_M->Sizes.checksums[1] = (3082246785U);
  testGaitSegm_M->Sizes.checksums[2] = (2191264295U);
  testGaitSegm_M->Sizes.checksums[3] = (3682970405U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[7];
    testGaitSegm_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    systemRan[3] = (sysRanDType *)&testGaitSegm_DW.Gaitsegmentation_SubsysRanBC;
    systemRan[4] = (sysRanDType *)&testGaitSegm_DW.Gaitsegmentation_SubsysRanBC;
    systemRan[5] = (sysRanDType *)&testGaitSegm_DW.Gaitsegmentation_SubsysRanBC;
    systemRan[6] = (sysRanDType *)&testGaitSegm_DW.Gaitsegmentation_SubsysRanBC;
    rteiSetModelMappingInfoPtr(testGaitSegm_M->extModeInfo,
      &testGaitSegm_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(testGaitSegm_M->extModeInfo,
                        testGaitSegm_M->Sizes.checksums);
    rteiSetTPtr(testGaitSegm_M->extModeInfo, rtmGetTPtr(testGaitSegm_M));
  }

  // block I/O
  (void) memset(((void *) &testGaitSegm_B), 0,
                sizeof(B_testGaitSegm_T));

  // states (dwork)
  (void) memset((void *)&testGaitSegm_DW, 0,
                sizeof(DW_testGaitSegm_T));

  // data type transition information
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    testGaitSegm_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 15;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    // Block I/O transition table
    dtInfo.B = &rtBTransTable;

    // Parameters transition table
    dtInfo.P = &rtPTransTable;
  }

  // S-Function (ex_sfun_sci_xsens): <Root>/Xsens IMUs
  init_xsens( &testGaitSegm_DW.XsensIMUs_PWORK, (uint8_T*)
             testGaitSegm_P.XsensIMUs_p1, (uint32_T)10, (uint8_T*)
             testGaitSegm_P.XsensIMUs_p2, (uint32_T)8, (uint8_T*)
             testGaitSegm_P.XsensIMUs_p3, (uint32_T)8, (uint8_T*)
             &testGaitSegm_P.XsensIMUs_p4, (uint32_T)1, (uint8_T*)
             &testGaitSegm_P.XsensIMUs_p5, (uint32_T)1, (uint8_T*)
             &testGaitSegm_P.XsensIMUs_p6, (uint32_T)1, (uint8_T*)
             &testGaitSegm_P.XsensIMUs_p7, (uint32_T)1, (uint8_T*)
             &testGaitSegm_P.XsensIMUs_p8, (uint32_T)1, (uint8_T*)
             &testGaitSegm_P.XsensIMUs_p9, (uint32_T)1, (uint8_T*)
             &testGaitSegm_P.XsensIMUs_p10, (uint32_T)1, (uint8_T*)
             &testGaitSegm_P.XsensIMUs_p11, (uint32_T)1, (uint32_T)
             testGaitSegm_P.XsensIMUs_p12, (uint32_T)
             testGaitSegm_P.XsensIMUs_p13);

  // Start for Enabled SubSystem: '<Root>/Gait segmentation'

  // S-Function (Timing): <S2>/S-Function
  init_timing();

  // Start for DataStoreMemory: '<S2>/Data Store Memory'
  testGaitSegm_DW.A = testGaitSegm_P.DataStoreMemory_InitialValue;

  // End of Start for SubSystem: '<Root>/Gait segmentation'

  // InitializeConditions for Enabled SubSystem: '<Root>/Gait segmentation'
  // InitializeConditions for MATLAB Function: '<S8>/Extractor'
  testGaitSegm_Extractor_Init(&testGaitSegm_DW.sf_Extractor_i);

  // InitializeConditions for DiscreteFilter: '<S2>/Discrete Filter1'
  testGaitSegm_DW.DiscreteFilter1_states[0] =
    testGaitSegm_P.DiscreteFilter1_InitialStates[0];
  testGaitSegm_DW.DiscreteFilter1_states[1] =
    testGaitSegm_P.DiscreteFilter1_InitialStates[1];

  // InitializeConditions for MATLAB Function: '<S7>/Extractor'
  testGaitSegm_Extractor_Init(&testGaitSegm_DW.sf_Extractor_ir);

  // InitializeConditions for DiscreteFilter: '<S2>/Discrete Filter'
  testGaitSegm_DW.DiscreteFilter_states[0] =
    testGaitSegm_P.DiscreteFilter_InitialStates[0];
  testGaitSegm_DW.DiscreteFilter_states[1] =
    testGaitSegm_P.DiscreteFilter_InitialStates[1];

  // InitializeConditions for S-Function (sdspcumsumprod): '<S2>/Cumulative Sum1' 
  testGaitSegm_DW.CumulativeSum1_RunningCumVal = 0.0;

  // InitializeConditions for S-Function (sdspcumsumprod): '<S2>/Cumulative Sum' 
  testGaitSegm_DW.CumulativeSum_RunningCumVal = 0.0;

  // InitializeConditions for Chart: '<S2>/Chart'
  testGaitSegm_DW.sfEvent = testGaitSegm_CALL_EVENT_g;
  testGaitSegm_DW.is_active_c7_XsensLibrary2 = 0U;
  testGaitSegm_DW.is_c7_XsensLibrary2 = testGaitSegm_IN_NO_ACTIVE_CHILD;

  // End of InitializeConditions for SubSystem: '<Root>/Gait segmentation'

  // Start for Enabled SubSystem: '<Root>/Gait segmentation'
  // VirtualOutportStart for Outport: '<S2>/Out2'
  testGaitSegm_B.DiscreteFilter1 = testGaitSegm_P.Out2_Y0;

  // VirtualOutportStart for Outport: '<S2>/Out3'
  testGaitSegm_B.DataTypeConversion1 = testGaitSegm_P.Out3_Y0;

  // VirtualOutportStart for Outport: '<S2>/Out4'
  testGaitSegm_B.DataTypeConversion3 = testGaitSegm_P.Out4_Y0;

  // VirtualOutportStart for Outport: '<S2>/Out5'
  testGaitSegm_B.DataTypeConversion2 = testGaitSegm_P.Out5_Y0;

  // End of Start for SubSystem: '<Root>/Gait segmentation'

  // InitializeConditions for MATLAB Function: '<S4>/Extractor'
  testGaitSegm_DW.lastSampleNumber = 0.0;
  testGaitSegm_DW.lastFactor = 1.0;

  // InitializeConditions for Chart: '<S1>/Chart'
  testGaitSegm_DW.sfEvent_g = testGaitSegm_CALL_EVENT_g;
  testGaitSegm_DW.is_active_c4_XsensLibrary2 = 0U;
  testGaitSegm_DW.is_c4_XsensLibrary2 = testGaitSegm_IN_NO_ACTIVE_CHILD;
}

// Model terminate function
void testGaitSegm_terminate(void)
{
  // S-Function (ex_sfun_sci_xsens): <Root>/Xsens IMUs
  terminate_xsens( &testGaitSegm_DW.XsensIMUs_PWORK);

  // Terminate for Enabled SubSystem: '<Root>/Gait segmentation'

  // S-Function (Timing): <S2>/S-Function
  terminate_timing();

  // End of Terminate for SubSystem: '<Root>/Gait segmentation'
}

//
// File trailer for generated code.
//
// [EOF]
//
