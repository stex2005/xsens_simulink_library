  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 6;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (testGaitSegm_P)
    ;%
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% testGaitSegm_P.Extract_correction
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_P.Extract1_correction
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testGaitSegm_P.Extract_correction_o
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% testGaitSegm_P.DataStoreMemory_InitialValue
	  section.data(1).logicalSrcIdx = 3;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(2) = section;
      clear section
      
      section.nData     = 11;
      section.data(11)  = dumData; %prealloc
      
	  ;% testGaitSegm_P.Out2_Y0
	  section.data(1).logicalSrcIdx = 4;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_P.Gain1_Gain
	  section.data(2).logicalSrcIdx = 5;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testGaitSegm_P.DiscreteFilter1_NumCoef
	  section.data(3).logicalSrcIdx = 6;
	  section.data(3).dtTransOffset = 2;
	
	  ;% testGaitSegm_P.DiscreteFilter1_DenCoef
	  section.data(4).logicalSrcIdx = 7;
	  section.data(4).dtTransOffset = 5;
	
	  ;% testGaitSegm_P.DiscreteFilter1_InitialStates
	  section.data(5).logicalSrcIdx = 8;
	  section.data(5).dtTransOffset = 8;
	
	  ;% testGaitSegm_P.Gain_Gain
	  section.data(6).logicalSrcIdx = 9;
	  section.data(6).dtTransOffset = 10;
	
	  ;% testGaitSegm_P.DiscreteFilter_NumCoef
	  section.data(7).logicalSrcIdx = 10;
	  section.data(7).dtTransOffset = 11;
	
	  ;% testGaitSegm_P.DiscreteFilter_DenCoef
	  section.data(8).logicalSrcIdx = 11;
	  section.data(8).dtTransOffset = 14;
	
	  ;% testGaitSegm_P.DiscreteFilter_InitialStates
	  section.data(9).logicalSrcIdx = 12;
	  section.data(9).dtTransOffset = 17;
	
	  ;% testGaitSegm_P.Gain4_Gain
	  section.data(10).logicalSrcIdx = 13;
	  section.data(10).dtTransOffset = 19;
	
	  ;% testGaitSegm_P.Gain3_Gain
	  section.data(11).logicalSrcIdx = 14;
	  section.data(11).dtTransOffset = 20;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(3) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% testGaitSegm_P.Out3_Y0
	  section.data(1).logicalSrcIdx = 15;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_P.Out4_Y0
	  section.data(2).logicalSrcIdx = 16;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testGaitSegm_P.Out5_Y0
	  section.data(3).logicalSrcIdx = 17;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(4) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testGaitSegm_P.XsensIMUs_p12
	  section.data(1).logicalSrcIdx = 18;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_P.XsensIMUs_p13
	  section.data(2).logicalSrcIdx = 19;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(5) = section;
      clear section
      
      section.nData     = 11;
      section.data(11)  = dumData; %prealloc
      
	  ;% testGaitSegm_P.XsensIMUs_p1
	  section.data(1).logicalSrcIdx = 20;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_P.XsensIMUs_p2
	  section.data(2).logicalSrcIdx = 21;
	  section.data(2).dtTransOffset = 10;
	
	  ;% testGaitSegm_P.XsensIMUs_p3
	  section.data(3).logicalSrcIdx = 22;
	  section.data(3).dtTransOffset = 18;
	
	  ;% testGaitSegm_P.XsensIMUs_p4
	  section.data(4).logicalSrcIdx = 23;
	  section.data(4).dtTransOffset = 26;
	
	  ;% testGaitSegm_P.XsensIMUs_p5
	  section.data(5).logicalSrcIdx = 24;
	  section.data(5).dtTransOffset = 27;
	
	  ;% testGaitSegm_P.XsensIMUs_p6
	  section.data(6).logicalSrcIdx = 25;
	  section.data(6).dtTransOffset = 28;
	
	  ;% testGaitSegm_P.XsensIMUs_p7
	  section.data(7).logicalSrcIdx = 26;
	  section.data(7).dtTransOffset = 29;
	
	  ;% testGaitSegm_P.XsensIMUs_p8
	  section.data(8).logicalSrcIdx = 27;
	  section.data(8).dtTransOffset = 30;
	
	  ;% testGaitSegm_P.XsensIMUs_p9
	  section.data(9).logicalSrcIdx = 28;
	  section.data(9).dtTransOffset = 31;
	
	  ;% testGaitSegm_P.XsensIMUs_p10
	  section.data(10).logicalSrcIdx = 29;
	  section.data(10).dtTransOffset = 32;
	
	  ;% testGaitSegm_P.XsensIMUs_p11
	  section.data(11).logicalSrcIdx = 30;
	  section.data(11).dtTransOffset = 33;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(6) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 6;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (testGaitSegm_B)
    ;%
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% testGaitSegm_B.data_struct_out
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 5;
      section.data(5)  = dumData; %prealloc
      
	  ;% testGaitSegm_B.SFunction_o3
	  section.data(1).logicalSrcIdx = 1;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_B.DiscreteFilter1
	  section.data(2).logicalSrcIdx = 2;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testGaitSegm_B.a
	  section.data(3).logicalSrcIdx = 3;
	  section.data(3).dtTransOffset = 2;
	
	  ;% testGaitSegm_B.FlagAvailable
	  section.data(4).logicalSrcIdx = 4;
	  section.data(4).dtTransOffset = 5;
	
	  ;% testGaitSegm_B.DiscreteFilter
	  section.data(5).logicalSrcIdx = 5;
	  section.data(5).dtTransOffset = 6;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% testGaitSegm_B.DataTypeConversion1
	  section.data(1).logicalSrcIdx = 6;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_B.DataTypeConversion3
	  section.data(2).logicalSrcIdx = 7;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testGaitSegm_B.DataTypeConversion2
	  section.data(3).logicalSrcIdx = 8;
	  section.data(3).dtTransOffset = 2;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% testGaitSegm_B.state
	  section.data(1).logicalSrcIdx = 9;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(4) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% testGaitSegm_B.sf_Extractor_i.omega
	  section.data(1).logicalSrcIdx = 10;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(5) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% testGaitSegm_B.sf_Extractor_ir.omega
	  section.data(1).logicalSrcIdx = 11;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(6) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 9;
    sectIdxOffset = 6;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (testGaitSegm_DW)
    ;%
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.A
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_DW.data_struct
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.DiscreteFilter1_states
	  section.data(1).logicalSrcIdx = 2;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_DW.DiscreteFilter_states
	  section.data(2).logicalSrcIdx = 3;
	  section.data(2).dtTransOffset = 2;
	
	  ;% testGaitSegm_DW.DiscreteFilter1_tmp
	  section.data(3).logicalSrcIdx = 4;
	  section.data(3).dtTransOffset = 4;
	
	  ;% testGaitSegm_DW.DiscreteFilter_tmp
	  section.data(4).logicalSrcIdx = 5;
	  section.data(4).dtTransOffset = 5;
	
	  ;% testGaitSegm_DW.CumulativeSum1_RunningCumVal
	  section.data(5).logicalSrcIdx = 6;
	  section.data(5).dtTransOffset = 6;
	
	  ;% testGaitSegm_DW.CumulativeSum_RunningCumVal
	  section.data(6).logicalSrcIdx = 7;
	  section.data(6).dtTransOffset = 7;
	
	  ;% testGaitSegm_DW.lastSampleNumber
	  section.data(7).logicalSrcIdx = 8;
	  section.data(7).dtTransOffset = 8;
	
	  ;% testGaitSegm_DW.lastFactor
	  section.data(8).logicalSrcIdx = 9;
	  section.data(8).dtTransOffset = 9;
	
	  ;% testGaitSegm_DW.do_transition
	  section.data(9).logicalSrcIdx = 10;
	  section.data(9).dtTransOffset = 10;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.XsensIMUs_PWORK
	  section.data(1).logicalSrcIdx = 11;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_DW.Scope_PWORK.LoggedData
	  section.data(2).logicalSrcIdx = 12;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testGaitSegm_DW.Scope1_PWORK.LoggedData
	  section.data(3).logicalSrcIdx = 13;
	  section.data(3).dtTransOffset = 4;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.sfEvent
	  section.data(1).logicalSrcIdx = 14;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_DW.sfEvent_g
	  section.data(2).logicalSrcIdx = 15;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.Gaitsegmentation_SubsysRanBC
	  section.data(1).logicalSrcIdx = 16;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
      section.nData     = 4;
      section.data(4)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.is_active_c7_XsensLibrary2
	  section.data(1).logicalSrcIdx = 17;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_DW.is_c7_XsensLibrary2
	  section.data(2).logicalSrcIdx = 18;
	  section.data(2).dtTransOffset = 1;
	
	  ;% testGaitSegm_DW.is_active_c4_XsensLibrary2
	  section.data(3).logicalSrcIdx = 19;
	  section.data(3).dtTransOffset = 2;
	
	  ;% testGaitSegm_DW.is_c4_XsensLibrary2
	  section.data(4).logicalSrcIdx = 20;
	  section.data(4).dtTransOffset = 3;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(6) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.isStable
	  section.data(1).logicalSrcIdx = 21;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_DW.isStable_j
	  section.data(2).logicalSrcIdx = 22;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(7) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.sf_Extractor_i.lastSampleNumber
	  section.data(1).logicalSrcIdx = 23;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_DW.sf_Extractor_i.lastFactor
	  section.data(2).logicalSrcIdx = 24;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(8) = section;
      clear section
      
      section.nData     = 2;
      section.data(2)  = dumData; %prealloc
      
	  ;% testGaitSegm_DW.sf_Extractor_ir.lastSampleNumber
	  section.data(1).logicalSrcIdx = 25;
	  section.data(1).dtTransOffset = 0;
	
	  ;% testGaitSegm_DW.sf_Extractor_ir.lastFactor
	  section.data(2).logicalSrcIdx = 26;
	  section.data(2).dtTransOffset = 1;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(9) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 1849536221;
  targMap.checksum1 = 3082246785;
  targMap.checksum2 = 2191264295;
  targMap.checksum3 = 3682970405;

