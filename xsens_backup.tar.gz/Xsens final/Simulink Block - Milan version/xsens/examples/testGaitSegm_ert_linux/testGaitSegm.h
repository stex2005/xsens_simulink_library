//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: testGaitSegm.h
//
// Code generated for Simulink model 'testGaitSegm'.
//
// Model version                  : 1.164
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Fri Oct 28 18:25:55 2016
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_testGaitSegm_h_
#define RTW_HEADER_testGaitSegm_h_
#include <math.h>
#include <float.h>
#include <string.h>
#ifndef testGaitSegm_COMMON_INCLUDES_
# define testGaitSegm_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "dt_info.h"
#include "ext_work.h"
#include "timing.h"
#include "sci_xsens.hpp"
#include "xsens.h"
#endif                                 // testGaitSegm_COMMON_INCLUDES_

#include "testGaitSegm_types.h"

// Shared type includes
#include "multiword_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

// Macros for accessing real-time model data structure
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

// Block signals for system '<S7>/Extractor'
typedef struct {
  real_T omega[3];                     // '<S7>/Extractor'
} B_Extractor_testGaitSegm_T;

// Block states (auto storage) for system '<S7>/Extractor'
typedef struct {
  real_T lastSampleNumber;             // '<S7>/Extractor'
  real_T lastFactor;                   // '<S7>/Extractor'
} DW_Extractor_testGaitSegm_T;

// Block signals (auto storage)
typedef struct {
  bus_datastruct data_struct_out;      // '<S2>/Chart'
  real_T SFunction_o3;                 // '<S2>/S-Function'
  real_T DiscreteFilter1;              // '<S2>/Discrete Filter1'
  real_T a[3];                         // '<S4>/Extractor'
  real_T FlagAvailable;                // '<S1>/Chart'
  real_T DiscreteFilter;               // '<S2>/Discrete Filter'
  real32_T DataTypeConversion1;        // '<S2>/Data Type Conversion1'
  real32_T DataTypeConversion3;        // '<S2>/Data Type Conversion3'
  real32_T DataTypeConversion2;        // '<S2>/Data Type Conversion2'
  int8_T state;                        // '<S2>/Chart'
  B_Extractor_testGaitSegm_T sf_Extractor_i;// '<S8>/Extractor'
  B_Extractor_testGaitSegm_T sf_Extractor_ir;// '<S7>/Extractor'
} B_testGaitSegm_T;

// Block states (auto storage) for system '<Root>'
typedef struct {
  bus_datastruct A;                    // '<S2>/Data Store Memory'
  bus_datastruct data_struct;          // '<S2>/Chart'
  real_T DiscreteFilter1_states[2];    // '<S2>/Discrete Filter1'
  real_T DiscreteFilter_states[2];     // '<S2>/Discrete Filter'
  real_T DiscreteFilter1_tmp;          // '<S2>/Discrete Filter1'
  real_T DiscreteFilter_tmp;           // '<S2>/Discrete Filter'
  real_T CumulativeSum1_RunningCumVal; // '<S2>/Cumulative Sum1'
  real_T CumulativeSum_RunningCumVal;  // '<S2>/Cumulative Sum'
  real_T lastSampleNumber;             // '<S4>/Extractor'
  real_T lastFactor;                   // '<S4>/Extractor'
  real_T do_transition;                // '<S1>/Chart'
  void *XsensIMUs_PWORK;               // '<Root>/Xsens IMUs'
  struct {
    void *LoggedData[3];
  } Scope_PWORK;                       // '<Root>/Scope'

  struct {
    void *LoggedData[4];
  } Scope1_PWORK;                      // '<Root>/Scope1'

  int32_T sfEvent;                     // '<S2>/Chart'
  int32_T sfEvent_g;                   // '<S1>/Chart'
  int8_T Gaitsegmentation_SubsysRanBC; // '<Root>/Gait segmentation'
  uint8_T is_active_c7_XsensLibrary2;  // '<S2>/Chart'
  uint8_T is_c7_XsensLibrary2;         // '<S2>/Chart'
  uint8_T is_active_c4_XsensLibrary2;  // '<S1>/Chart'
  uint8_T is_c4_XsensLibrary2;         // '<S1>/Chart'
  boolean_T isStable;                  // '<S2>/Chart'
  boolean_T isStable_j;                // '<S1>/Chart'
  DW_Extractor_testGaitSegm_T sf_Extractor_i;// '<S8>/Extractor'
  DW_Extractor_testGaitSegm_T sf_Extractor_ir;// '<S7>/Extractor'
} DW_testGaitSegm_T;

// Parameters (auto storage)
struct P_testGaitSegm_T_ {
  real_T Extract_correction;           // Mask Parameter: Extract_correction
                                       //  Referenced by: '<S4>/Extractor'

  real_T Extract1_correction;          // Mask Parameter: Extract1_correction
                                       //  Referenced by: '<S8>/Extractor'

  real_T Extract_correction_o;         // Mask Parameter: Extract_correction_o
                                       //  Referenced by: '<S7>/Extractor'

  bus_datastruct DataStoreMemory_InitialValue;// Computed Parameter: DataStoreMemory_InitialValue
                                              //  Referenced by: '<S2>/Data Store Memory'

  real_T Out2_Y0;                      // Computed Parameter: Out2_Y0
                                       //  Referenced by: '<S2>/Out2'

  real_T Gain1_Gain;                   // Expression: 180/pi
                                       //  Referenced by: '<S2>/Gain1'

  real_T DiscreteFilter1_NumCoef[3];   // Expression: [1 -1 0]
                                       //  Referenced by: '<S2>/Discrete Filter1'

  real_T DiscreteFilter1_DenCoef[3];   // Expression: [1 -0.987574299109071 0]
                                       //  Referenced by: '<S2>/Discrete Filter1'

  real_T DiscreteFilter1_InitialStates[2];// Expression: [0 0]
                                          //  Referenced by: '<S2>/Discrete Filter1'

  real_T Gain_Gain;                    // Expression: -180/pi
                                       //  Referenced by: '<S2>/Gain'

  real_T DiscreteFilter_NumCoef[3];    // Expression: [1 -1 0]
                                       //  Referenced by: '<S2>/Discrete Filter'

  real_T DiscreteFilter_DenCoef[3];    // Expression: [1 -0.987574299109071 0]
                                       //  Referenced by: '<S2>/Discrete Filter'

  real_T DiscreteFilter_InitialStates[2];// Expression: [0 0]
                                         //  Referenced by: '<S2>/Discrete Filter'

  real_T Gain4_Gain;                   // Expression: -1
                                       //  Referenced by: '<S2>/Gain4'

  real_T Gain3_Gain;                   // Expression: -1
                                       //  Referenced by: '<S2>/Gain3'

  real32_T Out3_Y0;                    // Computed Parameter: Out3_Y0
                                       //  Referenced by: '<S2>/Out3'

  real32_T Out4_Y0;                    // Computed Parameter: Out4_Y0
                                       //  Referenced by: '<S2>/Out4'

  real32_T Out5_Y0;                    // Computed Parameter: Out5_Y0
                                       //  Referenced by: '<S2>/Out5'

  uint32_T XsensIMUs_p12;              // Expression: uint32(Freq)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint32_T XsensIMUs_p13;              // Expression: uint32(UseCalibratedValues)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p1[10];            // Expression: uint8(SID00)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p2[8];             // Expression: uint8(SID01)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p3[8];             // Expression: uint8(SID02)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p4;                // Expression: uint8(SID03)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p5;                // Expression: uint8(SID04)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p6;                // Expression: uint8(SID05)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p7;                // Expression: uint8(SID06)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p8;                // Expression: uint8(SID07)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p9;                // Expression: uint8(SID08)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p10;               // Expression: uint8(SID09)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p11;               // Expression: uint8(SID10)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

};

// Real-time Model Data Structure
struct tag_RTM_testGaitSegm_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    uint32_T checksums[4];
  } Sizes;

  //
  //  SpecialInfo:
  //  The following substructure contains special information
  //  related to other components that are dependent on RTW.

  struct {
    const void *mappingInfo;
  } SpecialInfo;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

// Block parameters (auto storage)
#ifdef __cplusplus

extern "C" {

#endif

  extern P_testGaitSegm_T testGaitSegm_P;

#ifdef __cplusplus

}
#endif

// Block signals (auto storage)
extern B_testGaitSegm_T testGaitSegm_B;

// Block states (auto storage)
extern DW_testGaitSegm_T testGaitSegm_DW;

#ifdef __cplusplus

extern "C" {

#endif

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  // Model entry point functions
  extern void testGaitSegm_initialize(void);
  extern void testGaitSegm_step(void);
  extern void testGaitSegm_terminate(void);

#ifdef __cplusplus

}
#endif

// Real-time Model object
#ifdef __cplusplus

extern "C" {

#endif

  extern RT_MODEL_testGaitSegm_T *const testGaitSegm_M;

#ifdef __cplusplus

}
#endif

//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'testGaitSegm'
//  '<S1>'   : 'testGaitSegm/Data Available'
//  '<S2>'   : 'testGaitSegm/Gait segmentation'
//  '<S3>'   : 'testGaitSegm/Data Available/Chart'
//  '<S4>'   : 'testGaitSegm/Data Available/Extract'
//  '<S5>'   : 'testGaitSegm/Data Available/Extract/Extractor'
//  '<S6>'   : 'testGaitSegm/Gait segmentation/Chart'
//  '<S7>'   : 'testGaitSegm/Gait segmentation/Extract'
//  '<S8>'   : 'testGaitSegm/Gait segmentation/Extract1'
//  '<S9>'   : 'testGaitSegm/Gait segmentation/Extract/Extractor'
//  '<S10>'  : 'testGaitSegm/Gait segmentation/Extract1/Extractor'

#endif                                 // RTW_HEADER_testGaitSegm_h_

//
// File trailer for generated code.
//
// [EOF]
//
