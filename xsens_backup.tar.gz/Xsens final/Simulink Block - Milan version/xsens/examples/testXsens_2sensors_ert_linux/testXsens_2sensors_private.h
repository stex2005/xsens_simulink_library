//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: testXsens_2sensors_private.h
//
// Code generated for Simulink model 'testXsens_2sensors'.
//
// Model version                  : 1.161
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Fri Oct 28 18:08:56 2016
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_testXsens_2sensors_private_h_
#define RTW_HEADER_testXsens_2sensors_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"

// Private macros used by the generated code to access rtModel
#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

extern real_T rt_atan2d_snf(real_T u0, real_T u1);
extern void testXsens_2senso_Extractor_Init(DW_Extractor_testXsens_2senso_T
  *localDW);
extern void testXsens_2sensors_Extractor(const real_T rtu_data[160],
  B_Extractor_testXsens_2sensor_T *localB, DW_Extractor_testXsens_2senso_T
  *localDW, real_T rtp_correction);

#endif                                 // RTW_HEADER_testXsens_2sensors_private_h_ 

//
// File trailer for generated code.
//
// [EOF]
//
