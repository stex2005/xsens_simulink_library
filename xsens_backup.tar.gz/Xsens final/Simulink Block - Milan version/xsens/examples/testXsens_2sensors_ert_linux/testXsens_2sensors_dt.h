//
//  testXsens_2sensors_dt.h
//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  Code generation for model "testXsens_2sensors".
//
//  Model version              : 1.161
//  Simulink Coder version : 8.9 (R2015b) 13-Aug-2015
//  C++ source code generated on : Fri Oct 28 18:08:56 2016
//
//  Target selection: ert_linux.tlc
//  Embedded hardware selection: 32-bit Generic
//  Code generation objectives: Unspecified
//  Validation result: Not run


#include "ext_types.h"

// data type size table
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T)
};

// data type name table
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T"
};

// data type transitions for block I/O structure
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&testXsens_2sensors_B.TmpSignalConversionAtToWorkspac[0]), 0, 0,
    31 },

  { (char_T *)(&testXsens_2sensors_B.Constant), 1, 0, 2 },

  { (char_T *)(&testXsens_2sensors_B.sf_Extractor_l.a[0]), 0, 0, 12 },

  { (char_T *)(&testXsens_2sensors_B.sf_Extractor_m.a[0]), 0, 0, 12 }
  ,

  { (char_T *)(&testXsens_2sensors_DW.RotMatrix0[0]), 0, 0, 244 },

  { (char_T *)(&testXsens_2sensors_DW.XsensIMUs_PWORK), 11, 0, 6 },

  { (char_T *)(&testXsens_2sensors_DW.sfEvent), 6, 0, 3 },

  { (char_T *)(&testXsens_2sensors_DW.AlignmentCalibration1_SubsysRan), 2, 0, 3
  },

  { (char_T *)(&testXsens_2sensors_DW.is_active_c4_XsensLibrary2), 3, 0, 6 },

  { (char_T *)(&testXsens_2sensors_DW.isStable), 8, 0, 3 },

  { (char_T *)(&testXsens_2sensors_DW.sf_Extractor_l.lastSampleNumber), 0, 0, 2
  },

  { (char_T *)(&testXsens_2sensors_DW.sf_Extractor_m.lastSampleNumber), 0, 0, 2
  }
};

// data type transition table for block I/O structure
static DataTypeTransitionTable rtBTransTable = {
  12U,
  rtBTransitions
};

// data type transitions for Parameters structure
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&testXsens_2sensors_P.AlignmentCalibration1_RotationT), 0, 0, 78
  },

  { (char_T *)(&testXsens_2sensors_P.Constant_Value), 1, 0, 2 },

  { (char_T *)(&testXsens_2sensors_P.XsensIMUs_p12), 7, 0, 2 },

  { (char_T *)(&testXsens_2sensors_P.XsensIMUs_p1[0]), 3, 0, 34 }
};

// data type transition table for Parameters structure
static DataTypeTransitionTable rtPTransTable = {
  4U,
  rtPTransitions
};

// [EOF] testXsens_2sensors_dt.h
