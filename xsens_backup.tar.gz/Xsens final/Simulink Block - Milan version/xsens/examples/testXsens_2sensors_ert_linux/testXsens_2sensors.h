//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: testXsens_2sensors.h
//
// Code generated for Simulink model 'testXsens_2sensors'.
//
// Model version                  : 1.161
// Simulink Coder version         : 8.9 (R2015b) 13-Aug-2015
// C/C++ source code generated on : Fri Oct 28 18:08:56 2016
//
// Target selection: ert_linux.tlc
// Embedded hardware selection: 32-bit Generic
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_testXsens_2sensors_h_
#define RTW_HEADER_testXsens_2sensors_h_
#include <math.h>
#include <string.h>
#include <float.h>
#ifndef testXsens_2sensors_COMMON_INCLUDES_
# define testXsens_2sensors_COMMON_INCLUDES_
#include <stdio.h>
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "dt_info.h"
#include "ext_work.h"
#include "sci_xsens.hpp"
#include "xsens.h"
#endif                                 // testXsens_2sensors_COMMON_INCLUDES_

#include "testXsens_2sensors_types.h"

// Shared type includes
#include "multiword_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "rt_defines.h"
#include "rtGetInf.h"

// Macros for accessing real-time model data structure
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

// Block signals for system '<S6>/Extractor'
typedef struct {
  real_T a[3];                         // '<S6>/Extractor'
  real_T rotmat[9];                    // '<S6>/Extractor'
} B_Extractor_testXsens_2sensor_T;

// Block states (auto storage) for system '<S6>/Extractor'
typedef struct {
  real_T lastSampleNumber;             // '<S6>/Extractor'
  real_T lastFactor;                   // '<S6>/Extractor'
} DW_Extractor_testXsens_2senso_T;

// Block signals (auto storage)
typedef struct {
  real_T TmpSignalConversionAtToWorkspac[3];
  real_T OutportBufferForOut1;         // '<S4>/ExtractAngles'
  real_T OutportBufferForOut2;         // '<S4>/ExtractAngles'
  real_T OutportBufferForOut3;         // '<S4>/ExtractAngles'
  real_T flex_ext;                     // '<S4>/ExtractAngles'
  real_T lat_bend;                     // '<S4>/ExtractAngles'
  real_T twist;                        // '<S4>/ExtractAngles'
  real_T a[3];                         // '<S12>/Extractor'
  real_T FlagAvailable;                // '<S3>/Chart'
  real_T RotMatrix_out[9];             // '<S2>/Chart'
  real_T RotMatrix_out_m[9];           // '<S1>/Chart'
  real32_T Constant;                   // '<Root>/Constant'
  real32_T Constant1;                  // '<Root>/Constant1'
  B_Extractor_testXsens_2sensor_T sf_Extractor_l;// '<S9>/Extractor'
  B_Extractor_testXsens_2sensor_T sf_Extractor_m;// '<S6>/Extractor'
} B_testXsens_2sensors_T;

// Block states (auto storage) for system '<Root>'
typedef struct {
  real_T RotMatrix0[9];                // '<S4>/Data storage2'
  real_T lastSampleNumber;             // '<S12>/Extractor'
  real_T lastFactor;                   // '<S12>/Extractor'
  real_T do_transition;                // '<S3>/Chart'
  real_T gRf[9];                       // '<S2>/Data storage'
  real_T sRb[9];                       // '<S2>/Data storage1'
  real_T RotMatrix_init[9];            // '<S2>/Data storage2'
  real_T Accelerationbuffer[15];       // '<S2>/Chart'
  real_T mean_accel_b[3];              // '<S2>/Chart'
  real_T mean_accel[3];                // '<S2>/Chart'
  real_T mean_rotmat[9];               // '<S2>/Chart'
  real_T gamma;                        // '<S2>/Chart'
  real_T beta;                         // '<S2>/Chart'
  real_T gRb[9];                       // '<S2>/Chart'
  real_T RotMatbuffer[45];             // '<S2>/Chart'
  real_T samples;                      // '<S2>/Chart'
  real_T Calib_performed;              // '<S2>/Chart'
  real_T data_received;                // '<S2>/Chart'
  real_T gRf_g[9];                     // '<S1>/Data storage'
  real_T sRb_n[9];                     // '<S1>/Data storage1'
  real_T RotMatrix_init_m[9];          // '<S1>/Data storage2'
  real_T Accelerationbuffer_h[15];     // '<S1>/Chart'
  real_T mean_accel_b_g[3];            // '<S1>/Chart'
  real_T mean_accel_f[3];              // '<S1>/Chart'
  real_T mean_rotmat_l[9];             // '<S1>/Chart'
  real_T gamma_b;                      // '<S1>/Chart'
  real_T beta_k;                       // '<S1>/Chart'
  real_T gRb_i[9];                     // '<S1>/Chart'
  real_T RotMatbuffer_n[45];           // '<S1>/Chart'
  real_T samples_j;                    // '<S1>/Chart'
  real_T Calib_performed_m;            // '<S1>/Chart'
  real_T data_received_i;              // '<S1>/Chart'
  void *XsensIMUs_PWORK;               // '<Root>/Xsens IMUs'
  struct {
    void *LoggedData[3];
  } Scope_PWORK;                       // '<Root>/Scope'

  struct {
    void *LoggedData;
  } ToWorkspace1_PWORK;                // '<Root>/To Workspace1'

  struct {
    void *LoggedData;
  } ToWorkspace3_PWORK;                // '<Root>/To Workspace3'

  int32_T sfEvent;                     // '<S3>/Chart'
  int32_T sfEvent_n;                   // '<S2>/Chart'
  int32_T sfEvent_l;                   // '<S1>/Chart'
  int8_T AlignmentCalibration1_SubsysRan;// '<Root>/Alignment Calibration1'
  int8_T AlignmentCalibration2_SubsysRan;// '<Root>/Alignment Calibration2'
  int8_T Extractangles_SubsysRanBC;    // '<Root>/Extract angles'
  uint8_T is_active_c4_XsensLibrary2;  // '<S3>/Chart'
  uint8_T is_c4_XsensLibrary2;         // '<S3>/Chart'
  uint8_T is_active_c3_XsensLibrary2;  // '<S2>/Chart'
  uint8_T is_c3_XsensLibrary2;         // '<S2>/Chart'
  uint8_T is_active_c3_XsensLibrary2_o;// '<S1>/Chart'
  uint8_T is_c3_XsensLibrary2_a;       // '<S1>/Chart'
  boolean_T isStable;                  // '<S3>/Chart'
  boolean_T isStable_d;                // '<S2>/Chart'
  boolean_T isStable_dk;               // '<S1>/Chart'
  DW_Extractor_testXsens_2senso_T sf_Extractor_l;// '<S9>/Extractor'
  DW_Extractor_testXsens_2senso_T sf_Extractor_m;// '<S6>/Extractor'
} DW_testXsens_2sensors_T;

// Parameters (auto storage)
struct P_testXsens_2sensors_T_ {
  real_T AlignmentCalibration1_RotationT;// Mask Parameter: AlignmentCalibration1_RotationT
                                         //  Referenced by: '<S1>/Chart'

  real_T AlignmentCalibration2_RotationT;// Mask Parameter: AlignmentCalibration2_RotationT
                                         //  Referenced by: '<S2>/Chart'

  real_T Extractangles_TwistCorrection;// Mask Parameter: Extractangles_TwistCorrection
                                       //  Referenced by: '<S4>/ExtractAngles'

  real_T AlignmentCalibration1_XAxis;  // Mask Parameter: AlignmentCalibration1_XAxis
                                       //  Referenced by: '<S1>/Chart'

  real_T AlignmentCalibration2_XAxis;  // Mask Parameter: AlignmentCalibration2_XAxis
                                       //  Referenced by: '<S2>/Chart'

  real_T AlignmentCalibration1_YAxis;  // Mask Parameter: AlignmentCalibration1_YAxis
                                       //  Referenced by: '<S1>/Chart'

  real_T AlignmentCalibration2_YAxis;  // Mask Parameter: AlignmentCalibration2_YAxis
                                       //  Referenced by: '<S2>/Chart'

  real_T AlignmentCalibration1_ZAxis;  // Mask Parameter: AlignmentCalibration1_ZAxis
                                       //  Referenced by: '<S1>/Chart'

  real_T AlignmentCalibration2_ZAxis;  // Mask Parameter: AlignmentCalibration2_ZAxis
                                       //  Referenced by: '<S2>/Chart'

  real_T Extract_correction;           // Mask Parameter: Extract_correction
                                       //  Referenced by: '<S6>/Extractor'

  real_T Extract_correction_b;         // Mask Parameter: Extract_correction_b
                                       //  Referenced by: '<S9>/Extractor'

  real_T Extract_correction_c;         // Mask Parameter: Extract_correction_c
                                       //  Referenced by: '<S12>/Extractor'

  real_T Datastorage_InitialValue[9];  // Expression: eye(3)
                                       //  Referenced by: '<S1>/Data storage'

  real_T Datastorage1_InitialValue[9]; // Expression: eye(3)
                                       //  Referenced by: '<S1>/Data storage1'

  real_T Datastorage2_InitialValue[9]; // Expression: eye(3)
                                       //  Referenced by: '<S1>/Data storage2'

  real_T Datastorage_InitialValue_c[9];// Expression: eye(3)
                                       //  Referenced by: '<S2>/Data storage'

  real_T Datastorage1_InitialValue_d[9];// Expression: eye(3)
                                        //  Referenced by: '<S2>/Data storage1'

  real_T Datastorage2_InitialValue_c[9];// Expression: eye(3)
                                        //  Referenced by: '<S2>/Data storage2'

  real_T Out1_Y0;                      // Computed Parameter: Out1_Y0
                                       //  Referenced by: '<S4>/Out1'

  real_T Out2_Y0;                      // Computed Parameter: Out2_Y0
                                       //  Referenced by: '<S4>/Out2'

  real_T Out3_Y0;                      // Computed Parameter: Out3_Y0
                                       //  Referenced by: '<S4>/Out3'

  real_T Datastorage2_InitialValue_n[9];// Expression: [0 0 0; 0 0 0; 0 0 0]
                                        //  Referenced by: '<S4>/Data storage2'

  real32_T Constant_Value;             // Computed Parameter: Constant_Value
                                       //  Referenced by: '<Root>/Constant'

  real32_T Constant1_Value;            // Computed Parameter: Constant1_Value
                                       //  Referenced by: '<Root>/Constant1'

  uint32_T XsensIMUs_p12;              // Expression: uint32(Freq)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint32_T XsensIMUs_p13;              // Expression: uint32(UseCalibratedValues)
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p1[10];            // Expression: uint8(SID00)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p2[8];             // Expression: uint8(SID01)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p3[8];             // Expression: uint8(SID02)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p4;                // Expression: uint8(SID03)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p5;                // Expression: uint8(SID04)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p6;                // Expression: uint8(SID05)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p7;                // Expression: uint8(SID06)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p8;                // Expression: uint8(SID07)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p9;                // Expression: uint8(SID08)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p10;               // Expression: uint8(SID09)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

  uint8_T XsensIMUs_p11;               // Expression: uint8(SID10)'
                                       //  Referenced by: '<Root>/Xsens IMUs'

};

// Real-time Model Data Structure
struct tag_RTM_testXsens_2sensors_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  //
  //  Sizes:
  //  The following substructure contains sizes information
  //  for many of the model attributes such as inputs, outputs,
  //  dwork, sample times, etc.

  struct {
    uint32_T checksums[4];
  } Sizes;

  //
  //  SpecialInfo:
  //  The following substructure contains special information
  //  related to other components that are dependent on RTW.

  struct {
    const void *mappingInfo;
  } SpecialInfo;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

// Block parameters (auto storage)
#ifdef __cplusplus

extern "C" {

#endif

  extern P_testXsens_2sensors_T testXsens_2sensors_P;

#ifdef __cplusplus

}
#endif

// Block signals (auto storage)
extern B_testXsens_2sensors_T testXsens_2sensors_B;

// Block states (auto storage)
extern DW_testXsens_2sensors_T testXsens_2sensors_DW;

#ifdef __cplusplus

extern "C" {

#endif

#ifdef __cplusplus

}
#endif

#ifdef __cplusplus

extern "C" {

#endif

  // Model entry point functions
  extern void testXsens_2sensors_initialize(void);
  extern void testXsens_2sensors_step(void);
  extern void testXsens_2sensors_terminate(void);

#ifdef __cplusplus

}
#endif

// Real-time Model object
#ifdef __cplusplus

extern "C" {

#endif

  extern RT_MODEL_testXsens_2sensors_T *const testXsens_2sensors_M;

#ifdef __cplusplus

}
#endif

//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'testXsens_2sensors'
//  '<S1>'   : 'testXsens_2sensors/Alignment Calibration1'
//  '<S2>'   : 'testXsens_2sensors/Alignment Calibration2'
//  '<S3>'   : 'testXsens_2sensors/Data Available'
//  '<S4>'   : 'testXsens_2sensors/Extract angles'
//  '<S5>'   : 'testXsens_2sensors/Alignment Calibration1/Chart'
//  '<S6>'   : 'testXsens_2sensors/Alignment Calibration1/Extract'
//  '<S7>'   : 'testXsens_2sensors/Alignment Calibration1/Extract/Extractor'
//  '<S8>'   : 'testXsens_2sensors/Alignment Calibration2/Chart'
//  '<S9>'   : 'testXsens_2sensors/Alignment Calibration2/Extract'
//  '<S10>'  : 'testXsens_2sensors/Alignment Calibration2/Extract/Extractor'
//  '<S11>'  : 'testXsens_2sensors/Data Available/Chart'
//  '<S12>'  : 'testXsens_2sensors/Data Available/Extract'
//  '<S13>'  : 'testXsens_2sensors/Data Available/Extract/Extractor'
//  '<S14>'  : 'testXsens_2sensors/Extract angles/ExtractAngles'

#endif                                 // RTW_HEADER_testXsens_2sensors_h_

//
// File trailer for generated code.
//
// [EOF]
//
